/* India Sheets – offline support.
 * IMPORTANT: change VERSION every time you upload a new version of any file,
 * so installed apps download the update. */
const VERSION = 'isheets-2.0.1';
const FILES = [
  './', './index.html', './privacy.html', './manifest.json', './css/app.css',
  './js/formula.js', './js/functions.js', './js/storage.js', './js/ui.js', './js/model.js', './js/calc.js', './js/grid.js',
  './js/licence.js', './js/app.js', './js/chrome.js',
  './js/features/format.js', './js/features/data.js', './js/features/objects.js', './js/features/io.js',
  './js/features/templates.js', './js/features/assistant.js', './js/features/extras.js',
  './vendor/qrcode.js', './vendor/xlsx.bundle.js', './vendor/chart.umd.js', './vendor/LICENSES.txt',
  './icons/icon.svg', './icons/icon-48.png', './icons/icon-96.png', './icons/icon-192.png', './icons/icon-512.png', './icons/maskable-192.png', './icons/maskable-512.png'
];

self.addEventListener('install', event => {
  event.waitUntil(caches.open(VERSION).then(cache => cache.addAll(FILES)));
});
self.addEventListener('activate', event => {
  event.waitUntil((async () => {
    for (const key of await caches.keys()) if (key !== VERSION) await caches.delete(key);
    await self.clients.claim();
  })());
});
self.addEventListener('message', event => { if (event.data === 'skipWaiting') self.skipWaiting(); });
self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);
  if (url.origin !== self.location.origin) return; // payments, voice etc. go straight to the network
  event.respondWith((async () => {
    const cache = await caches.open(VERSION);
    const hit = await cache.match(req, { ignoreSearch: true });
    if (hit) return hit;
    try {
      const res = await fetch(req);
      if (res && res.ok && res.type === 'basic') cache.put(req, res.clone());
      return res;
    } catch (e) {
      if (req.mode === 'navigate') { const page = await cache.match('./index.html'); if (page) return page; }
      return new Response('Offline', { status: 503, statusText: 'Offline' });
    }
  })());
});
