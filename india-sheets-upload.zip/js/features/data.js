/* India Sheets – data tools: sort, filter, remove duplicates, text to columns, clean-up, pivot (summary), names, fill series */
(function (global) {
  'use strict';
  const IS = global.IS, ui = IS.ui, X = global.Formula, esc = ui.esc, K = IS.K;
  const val = (sh, r, c) => X.norm(IS.calc.value(sh, r, c));
  const disp = (sh, r, c) => { const cell = sh.cells[K(r, c)]; return X.formatValue(IS.calc.value(sh, r, c), cell && cell.s && cell.s.nf).text; };
  const A1R = R => X.numToCol(R.l) + (R.t + 1) + ':' + X.numToCol(R.r) + (R.b + 1);
  const isBlank = v => v === null || v === undefined || v === '';

  /** The range a data command should work on: the selection, or the block of data around the cursor */
  function workRange(sh, opts = {}) {
    let R = IS.selRect();
    const used = IS.usedRange(sh);
    const single = R.t === R.b && R.l === R.r;
    const oneCol = R.l === R.r && !single;
    if (single || (opts.expandColumn && oneCol)) { const reg = IS.currentRegion(sh, R.t, R.l); if (reg) R = reg; }
    R = { t: R.t, l: R.l, b: Math.min(R.b, used.b), r: Math.min(R.r, used.r) };
    if (R.b < R.t || R.r < R.l) return null;
    return R;
  }
  IS.workRange = workRange;
  function detectHeader(sh, R) {
    if (R.b <= R.t) return false;
    let allText = true, styled = false, typeDiff = false, nonEmpty = 0;
    for (let c = R.l; c <= R.r; c++) {
      const v = val(sh, R.t, c), cell = sh.cells[K(R.t, c)];
      if (isBlank(v)) continue; nonEmpty++;
      if (typeof v !== 'string') allText = false;
      if (cell && cell.s && (cell.s.b || cell.s.bg)) styled = true;
      for (let r = R.t + 1; r <= Math.min(R.b, R.t + 5); r++) { const b = val(sh, r, c); if (!isBlank(b) && typeof b !== 'string') { typeDiff = true; break; } }
    }
    return nonEmpty > 0 && allText && (styled || typeDiff);
  }
  IS.detectHeader = detectHeader;
  function headerNames(sh, R, header) {
    const out = [];
    for (let c = R.l; c <= R.r; c++) { const h = header ? String(disp(sh, R.t, c) || '').trim() : ''; out.push({ c, name: h || 'Column ' + X.numToCol(c) }); }
    return out;
  }
  IS.headerNames = headerNames;
  function cmpVals(a, b, dir) {
    const ea = isBlank(a), eb = isBlank(b);
    if (ea || eb) return ea === eb ? 0 : ea ? 1 : -1;
    return X.sortCmp(a, b) * dir;
  }

  // =================================================================== sort
  function sortRange(sh, R, keys, header) {
    const t0 = R.t + (header ? 1 : 0);
    if (t0 >= R.b) { ui.toast('There is nothing to sort – select at least two rows of data.'); return; }
    if ((sh.merges || []).some(m => !(m.r2 < t0 || m.r > R.b || m.c2 < R.l || m.c > R.r))) { ui.toast('Unmerge the cells in this range before sorting.', { type: 'error' }); return; }
    if (!IS.guardEdit({ t: t0, l: R.l, b: R.b, r: R.r })) return;
    const rows = [];
    for (let r = t0; r <= R.b; r++) rows.push({ from: r, k: keys.map(k => val(sh, r, k.c)) });
    rows.sort((a, b) => { for (let i = 0; i < keys.length; i++) { const c = cmpVals(a.k[i], b.k[i], keys[i].dir); if (c) return c; } return a.from - b.from; });
    if (rows.every((row, i) => row.from === t0 + i)) { ui.toast('Already sorted.', { ms: 1500 }); return; }
    IS.tx('Sort', () => {
      const snap = {};
      for (let r = t0; r <= R.b; r++) for (let c = R.l; c <= R.r; c++) snap[K(r, c)] = IS.cloneCell(sh.cells[K(r, c)]);
      rows.forEach((row, i) => {
        const to = t0 + i; if (to === row.from) return;
        for (let c = R.l; c <= R.r; c++) {
          const src = snap[K(row.from, c)];
          if (!src) { IS.putCell(sh, to, c, null); continue; }
          const nc = IS.cloneCell(src);
          if (IS.isFormulaCell(nc)) nc.v = X.shiftFormula(nc.v, to - row.from, 0);
          IS.putCell(sh, to, c, nc);
        }
      });
      if (sh.filter) { IS.rec.meta(sh); computeHidden(sh); }
    }, { full: !!sh.filter });
  }
  IS.sortRange = sortRange;
  function quickSort(dir) {
    const sh = IS.sheet; const s = IS.state.sel;
    let R;
    if (sh.filter && s.r >= sh.filter.t && s.r <= sh.filter.b && s.c >= sh.filter.l && s.c <= sh.filter.r) { extendFilter(sh); R = { t: sh.filter.t, l: sh.filter.l, b: sh.filter.b, r: sh.filter.r }; sortRange(sh, R, [{ c: s.c, dir }], true); return; }
    const sel = IS.selRect();
    if (sel.t === 0 && sel.b >= sh.rows - 1) { const used = IS.usedRange(sh); R = { t: 0, l: 0, b: used.b, r: used.r }; }
    else R = workRange(sh, { expandColumn: true });
    if (!R) { ui.toast('There is no data to sort here.'); return; }
    const header = detectHeader(sh, R);
    sortRange(sh, R, [{ c: s.c >= R.l && s.c <= R.r ? s.c : R.l, dir }], header);
    if (header) ui.toast('Sorted – the first row was kept as a header.', { ms: 2200 });
  }
  function sortDialog() {
    const sh = IS.sheet; const R = workRange(sh, { expandColumn: true });
    if (!R) { ui.toast('Select the data you want to sort.'); return; }
    let header = detectHeader(sh, R);
    const s = IS.state.sel;
    const levels = [{ c: s.c >= R.l && s.c <= R.r ? s.c : R.l, dir: 1 }];
    const body = document.createElement('div');
    const render = () => {
      const names = headerNames(sh, R, header);
      body.innerHTML = `<p class="hint">Sorting <b>${esc(A1R(R))}</b></p>
        <label class="check"><input type="checkbox" id="sdHead" ${header ? 'checked' : ''}> My data has a header row</label>
        ${levels.map((lv, i) => `<div class="row"><label class="field"><span>${i ? 'Then by' : 'Sort by'}</span><select data-lc="${i}">${names.map(n => `<option value="${n.c}" ${n.c === lv.c ? 'selected' : ''}>${esc(n.name)}</option>`).join('')}</select></label>
          <label class="field" style="max-width:170px"><span>Order</span><select data-ld="${i}"><option value="1" ${lv.dir > 0 ? 'selected' : ''}>A → Z / small → large</option><option value="-1" ${lv.dir < 0 ? 'selected' : ''}>Z → A / large → small</option></select></label>
          ${i ? `<button type="button" class="btn small" data-rm="${i}" style="margin-bottom:10px">✕</button>` : ''}</div>`).join('')}
        <button type="button" class="btn small" id="sdAdd">+ Add another sort column</button>`;
      body.querySelector('#sdHead').onchange = e => { header = e.target.checked; render(); };
      body.querySelectorAll('[data-lc]').forEach(el => el.onchange = () => { levels[+el.dataset.lc].c = +el.value; });
      body.querySelectorAll('[data-ld]').forEach(el => el.onchange = () => { levels[+el.dataset.ld].dir = +el.value; });
      body.querySelectorAll('[data-rm]').forEach(el => el.onclick = () => { levels.splice(+el.dataset.rm, 1); render(); });
      body.querySelector('#sdAdd').onclick = () => { if (levels.length < 6) { levels.push({ c: R.l, dir: 1 }); render(); } };
    };
    render();
    ui.modal({ title: 'Sort range', body, actions: [{ label: 'Cancel', value: null }, { label: 'Sort', primary: true, onClick: () => { sortRange(sh, R, levels.slice(), header); return true; } }] });
  }

  // =================================================================== filter
  function extendFilter(sh) {
    const f = sh.filter; if (!f) return;
    const reg = IS.currentRegion(sh, f.t, f.l);
    if (reg && reg.b > f.b) f.b = reg.b;
  }
  function passes(sh, crit, r, c, stats) {
    if (crit.values) { if (!crit._set) Object.defineProperty(crit, '_set', { value: new Set(crit.values), enumerable: false, configurable: true }); if (!crit._set.has(disp(sh, r, c))) return false; }
    if (crit.op) {
      const v = val(sh, r, c); const t = isBlank(v) ? '' : String(X.toStr(v)).toLowerCase(); const q = String(crit.v1 == null ? '' : crit.v1).toLowerCase();
      const num = x => { if (typeof x === 'number') return x; const p = X.parseInput(String(x == null ? '' : x)); return typeof p.value === 'number' ? p.value : NaN; };
      switch (crit.op) {
        case 'contains': return t.includes(q); case 'notContains': return !t.includes(q);
        case 'begins': return t.startsWith(q); case 'ends': return t.endsWith(q);
        case 'eq': return typeof v === 'number' && !isNaN(num(crit.v1)) ? v === num(crit.v1) : t === q;
        case 'neq': return typeof v === 'number' && !isNaN(num(crit.v1)) ? v !== num(crit.v1) : t !== q;
        case 'gt': return typeof v === 'number' && v > num(crit.v1); case 'gte': return typeof v === 'number' && v >= num(crit.v1);
        case 'lt': return typeof v === 'number' && v < num(crit.v1); case 'lte': return typeof v === 'number' && v <= num(crit.v1);
        case 'between': return typeof v === 'number' && v >= num(crit.v1) && v <= num(crit.v2);
        case 'empty': return isBlank(v); case 'notEmpty': return !isBlank(v);
        case 'top10': return typeof v === 'number' && stats && v >= stats.top10;
        case 'above': return typeof v === 'number' && stats && v > stats.avg;
        case 'below': return typeof v === 'number' && stats && v < stats.avg;
      }
    }
    return true;
  }
  function computeHidden(sh) {
    const f = sh.filter; if (!f) return;
    extendFilter(sh);
    const hidden = [];
    const cols = Object.keys(f.crit || {}).map(Number).filter(c => f.crit[c] && (f.crit[c].values || f.crit[c].op));
    if (cols.length) {
      const stats = {};
      cols.forEach(c => { const cr = f.crit[c]; if (['top10', 'above', 'below'].includes(cr.op)) { const nums = []; for (let r = f.t + 1; r <= f.b; r++) { const v = val(sh, r, c); if (typeof v === 'number') nums.push(v); } nums.sort((a, b) => b - a); stats[c] = { top10: nums.length ? nums[Math.min(9, nums.length - 1)] : Infinity, avg: nums.length ? nums.reduce((a, b) => a + b, 0) / nums.length : 0 }; } });
      for (let r = f.t + 1; r <= f.b; r++) for (const c of cols) if (!passes(sh, f.crit[c], r, c, stats[c])) { hidden.push(r); break; }
    }
    f.hidden = hidden;
    IS.invalidateHidden(sh);
  }
  IS.refilter = computeHidden;
  function applyFilter(R) {
    const sh = IS.sheet; if (!IS.guardEdit(null, { structure: !!(sh.protect && sh.protect.on) })) return;
    IS.tx('Create filter', () => { IS.rec.meta(sh); sh.filter = { t: R.t, l: R.l, b: R.b, r: R.r, crit: {}, hidden: [] }; IS.invalidateHidden(sh); }, { full: true });
    ui.toast('Filter added – click the ▾ buttons in the header row.', { ms: 2500 });
  }
  IS.applyFilter = applyFilter;
  function filterToggle() {
    const sh = IS.sheet;
    if (sh.filter) { IS.tx('Remove filter', () => { IS.rec.meta(sh); sh.filter = null; IS.invalidateHidden(sh); }, { full: true }); return; }
    let R = workRange(sh, { expandColumn: true });
    if (!R) { ui.toast('Put the cursor inside your data (with a header row) first.'); return; }
    if (R.t === R.b) R = { ...R, b: R.b + 1 };
    applyFilter(R);
  }
  function setCrit(sh, c, crit, label) {
    IS.tx(label || 'Filter', () => {
      IS.rec.meta(sh);
      const f = sh.filter; f.crit = f.crit || {};
      if (crit && (crit.values || crit.op)) f.crit[c] = crit; else delete f.crit[c];
      computeHidden(sh);
    }, { full: true });
    const n = (sh.filter.hidden || []).length;
    IS.ui.toast(n ? n + ' row' + (n > 1 ? 's' : '') + ' hidden by the filter' : 'Showing all rows', { ms: 1800 });
  }
  function filterMenu(arg) {
    const sh = IS.sheet, f = sh.filter; if (!f) return;
    extendFilter(sh);
    const c = arg.c;
    const counts = new Map();
    for (let r = f.t + 1; r <= f.b; r++) { const d = disp(sh, r, c); counts.set(d, (counts.get(d) || 0) + 1); }
    const values = [...counts.keys()].sort((a, b) => (a === '' ? 1 : b === '' ? -1 : a.localeCompare(b, 'en-IN', { numeric: true, sensitivity: 'base' })));
    const crit = (f.crit && f.crit[c]) || {};
    const chosen = new Set(crit.values || values);
    const wrap = document.createElement('div');
    wrap.innerHTML = `
      <div class="row" style="gap:6px;margin-bottom:6px"><button type="button" class="btn small" data-sort="1">Sort A → Z</button><button type="button" class="btn small" data-sort="-1">Sort Z → A</button></div>
      <label class="field"><span>Filter by condition</span><select id="flOp">
        <option value="">None</option><option value="contains">Text contains</option><option value="notContains">Text does not contain</option><option value="begins">Text starts with</option><option value="ends">Text ends with</option>
        <option value="eq">Is equal to</option><option value="neq">Is not equal to</option><option value="gt">Greater than</option><option value="gte">Greater than or equal to</option><option value="lt">Less than</option><option value="lte">Less than or equal to</option><option value="between">Between</option>
        <option value="empty">Is empty</option><option value="notEmpty">Is not empty</option><option value="top10">Top 10 values</option><option value="above">Above average</option><option value="below">Below average</option></select></label>
      <div class="row" id="flVals"><input id="flV1" class="inp" placeholder="Value"><input id="flV2" class="inp" placeholder="and" hidden></div>
      <span class="hint">Filter by values</span>
      <input id="flSearch" class="inp" placeholder="Search…" style="margin-top:4px">
      <div class="row" style="gap:6px;margin-top:4px"><button type="button" class="btn small" id="flAll">Select all</button><button type="button" class="btn small" id="flNone">Clear</button><span class="hint" id="flCount"></span></div>
      <div class="filter-list" id="flList"></div>
      <div class="filter-actions"><button type="button" class="btn small" id="flReset">Reset</button><button type="button" class="btn small" id="flCancel">Cancel</button><button type="button" class="btn small primary" id="flOk">OK</button></div>`;
    const q = s => wrap.querySelector(s);
    q('#flOp').value = crit.op || ''; q('#flV1').value = crit.v1 == null ? '' : crit.v1; q('#flV2').value = crit.v2 == null ? '' : crit.v2;
    const syncOp = () => { const op = q('#flOp').value; q('#flV1').hidden = !op || ['empty', 'notEmpty', 'top10', 'above', 'below'].includes(op); q('#flV2').hidden = op !== 'between'; };
    q('#flOp').onchange = syncOp; syncOp();
    const renderList = () => {
      const term = q('#flSearch').value.toLowerCase();
      const vis = values.filter(v => (v || '(Blanks)').toLowerCase().includes(term)).slice(0, 3000);
      q('#flList').innerHTML = vis.map(v => `<label><input type="checkbox" data-v="${esc(v)}" ${chosen.has(v) ? 'checked' : ''}> ${esc(v === '' ? '(Blanks)' : v)} <span class="hint">(${counts.get(v)})</span></label>`).join('') + (values.length > 3000 ? '<p class="hint">Showing the first 3,000 values – use search.</p>' : '');
      q('#flCount').textContent = chosen.size + ' of ' + values.length;
    };
    renderList();
    q('#flSearch').oninput = renderList;
    q('#flList').onchange = e => { const v = e.target.dataset.v; if (v === undefined) return; if (e.target.checked) chosen.add(v); else chosen.delete(v); q('#flCount').textContent = chosen.size + ' of ' + values.length; };
    q('#flAll').onclick = () => { const term = q('#flSearch').value.toLowerCase(); values.forEach(v => { if ((v || '(Blanks)').toLowerCase().includes(term)) chosen.add(v); }); renderList(); };
    q('#flNone').onclick = () => { const term = q('#flSearch').value.toLowerCase(); values.forEach(v => { if ((v || '(Blanks)').toLowerCase().includes(term)) chosen.delete(v); }); renderList(); };
    wrap.querySelectorAll('[data-sort]').forEach(b => b.onclick = () => { ui.closePopups(); sortRange(sh, { t: f.t, l: f.l, b: f.b, r: f.r }, [{ c, dir: +b.dataset.sort }], true); });
    q('#flCancel').onclick = () => { ui.closePopups(); IS.focusGrid(); };
    q('#flReset').onclick = () => { ui.closePopups(); setCrit(sh, c, null, 'Clear column filter'); IS.focusGrid(); };
    q('#flOk').onclick = () => {
      const op = q('#flOp').value;
      const nc = {};
      if (chosen.size < values.length) nc.values = [...chosen];
      if (op) { nc.op = op; nc.v1 = q('#flV1').value; if (op === 'between') nc.v2 = q('#flV2').value; }
      ui.closePopups(); setCrit(sh, c, nc); IS.focusGrid();
    };
    const el = ui.popover(wrap, arg.x, arg.y + 6, { className: 'filter-pop' });
    el.addEventListener('keydown', e => { if (e.key === 'Enter' && e.target.tagName === 'INPUT' && e.target.type !== 'checkbox') { e.preventDefault(); q('#flOk').click(); } if (e.key === 'Escape') { ui.closePopups(); IS.focusGrid(); } });
  }
  function filterByValue() {
    const sh = IS.sheet, s = IS.state.sel;
    if (!sh.filter || s.r <= sh.filter.t || s.r > sh.filter.b || s.c < sh.filter.l || s.c > sh.filter.r) {
      const reg = IS.currentRegion(sh, s.r, s.c);
      if (!reg || reg.b <= reg.t) { ui.toast('Put the cursor on a value inside a table with a header row.'); return; }
      if (sh.filter) IS.tx('Remove filter', () => { IS.rec.meta(sh); sh.filter = null; IS.invalidateHidden(sh); }, { full: true });
      IS.tx('Create filter', () => { IS.rec.meta(sh); sh.filter = { t: reg.t, l: reg.l, b: reg.b, r: reg.r, crit: {}, hidden: [] }; }, { full: true });
    }
    if (s.r === sh.filter.t) { ui.toast('Choose a value below the header row.'); return; }
    setCrit(sh, s.c, { values: [disp(sh, s.r, s.c)] }, 'Filter by value');
  }
  function filterClear() { const sh = IS.sheet; if (!sh.filter) return; IS.tx('Clear filter', () => { IS.rec.meta(sh); sh.filter.crit = {}; computeHidden(sh); }, { full: true }); }

  // =================================================================== rewrite rows of a block (dedupe / blank rows)
  function compactRows(sh, R, keepRows) {
    IS.tx('Remove rows', () => {
      const snap = {};
      for (let r = R.t; r <= R.b; r++) for (let c = R.l; c <= R.r; c++) snap[K(r, c)] = IS.cloneCell(sh.cells[K(r, c)]);
      let to = R.t;
      for (const from of keepRows) {
        for (let c = R.l; c <= R.r; c++) {
          const src = snap[K(from, c)];
          if (!src) { if (sh.cells[K(to, c)]) IS.putCell(sh, to, c, null); continue; }
          const nc = IS.cloneCell(src); if (IS.isFormulaCell(nc) && to !== from) nc.v = X.shiftFormula(nc.v, to - from, 0);
          IS.putCell(sh, to, c, nc);
        }
        to++;
      }
      for (; to <= R.b; to++) for (let c = R.l; c <= R.r; c++) if (sh.cells[K(to, c)]) IS.putCell(sh, to, c, null);
    });
  }
  function removeDuplicates() {
    const sh = IS.sheet; const R = workRange(sh, { expandColumn: true });
    if (!R || R.b <= R.t) { ui.toast('Select the data that has duplicates.'); return; }
    let header = detectHeader(sh, R);
    const body = document.createElement('div');
    const render = () => {
      const names = headerNames(sh, R, header);
      body.innerHTML = `<p class="hint">Range <b>${esc(A1R(R))}</b> – rows with the same values in the ticked columns are removed (the first one is kept).</p>
        <label class="check"><input type="checkbox" id="rdHead" ${header ? 'checked' : ''}> My data has a header row</label>
        <div class="filter-list">${names.map(n => `<label><input type="checkbox" data-c="${n.c}" checked> ${esc(n.name)}</label>`).join('')}</div>`;
      body.querySelector('#rdHead').onchange = e => { header = e.target.checked; render(); };
    };
    render();
    ui.modal({
      title: 'Remove duplicates', body, actions: [{ label: 'Cancel', value: null }, {
        label: 'Remove duplicates', primary: true, onClick: () => {
          const cols = [...body.querySelectorAll('[data-c]:checked')].map(x => +x.dataset.c);
          if (!cols.length) { ui.toast('Tick at least one column.', { type: 'error' }); return false; }
          if (!IS.guardEdit(R)) return false;
          const t0 = R.t + (header ? 1 : 0); const seen = new Set(), keep = [];
          for (let r = t0; r <= R.b; r++) { const key = cols.map(c => { const v = val(sh, r, c); return typeof v === 'string' ? 's' + v.trim().toLowerCase() : typeof v + String(v); }).join('\u0001'); if (seen.has(key)) continue; seen.add(key); keep.push(r); }
          const removed = R.b - t0 + 1 - keep.length;
          if (!removed) { ui.toast('No duplicates found 👍'); return true; }
          compactRows(sh, { t: t0, l: R.l, b: R.b, r: R.r }, keep);
          ui.toast('Removed ' + removed + ' duplicate row' + (removed > 1 ? 's' : '') + '. ' + keep.length + ' unique rows remain.', { ms: 4000 });
          return true;
        }
      }]
    });
  }

  // =================================================================== text to columns
  function textToColumns() {
    const sh = IS.sheet; let R = IS.selRect();
    if (R.l !== R.r) { ui.toast('Select a single column of text to split.'); return; }
    if (R.t === R.b) { let b = R.t; while (b + 1 < sh.rows && !isBlank(val(sh, b + 1, R.l))) b++; R = { ...R, b }; }
    const used = IS.usedRange(sh); R.b = Math.min(R.b, used.b);
    const sample = []; for (let r = R.t; r <= Math.min(R.b, R.t + 4); r++) sample.push(String(X.toStr(val(sh, r, R.l)) || ''));
    const body = document.createElement('div');
    body.innerHTML = `<p class="hint">Splits ${esc(X.numToCol(R.l) + (R.t + 1) + ':' + X.numToCol(R.l) + (R.b + 1))} into columns to the right.</p>
      <div class="row"><label class="field"><span>Separator</span><select id="tcSep"><option value=",">Comma ,</option><option value=";">Semicolon ;</option><option value="\t">Tab</option><option value=" ">Space</option><option value="-">Dash -</option><option value="/">Slash /</option><option value="|">Pipe |</option><option value="other">Other…</option></select></label>
      <label class="field"><span>Other separator</span><input id="tcOther" maxlength="5"></label></div>
      <label class="check"><input type="checkbox" id="tcMerge" checked> Treat repeated separators as one</label>
      <label class="check"><input type="checkbox" id="tcTrim" checked> Trim spaces</label>
      <span class="hint">Preview</span><div id="tcPrev" class="preview-box" style="overflow:auto"></div>`;
    const q = s => body.querySelector(s);
    const split = text => { let sep = q('#tcSep').value; if (sep === 'other') sep = q('#tcOther').value || ','; let parts = String(text).split(sep); if (q('#tcMerge').checked) parts = parts.filter((p, i) => p !== '' || i === 0); if (q('#tcTrim').checked) parts = parts.map(p => p.trim()); return parts; };
    const prev = () => { q('#tcPrev').innerHTML = '<table class="table">' + sample.map(t => '<tr>' + split(t).map(p => '<td>' + esc(p) + '</td>').join('') + '</tr>').join('') + '</table>'; };
    ['#tcSep', '#tcOther', '#tcMerge', '#tcTrim'].forEach(id => q(id).addEventListener('input', prev));
    q('#tcSep').addEventListener('change', prev);
    if (sample.some(s => s.includes('\t'))) q('#tcSep').value = '\t'; else if (!sample.some(s => s.includes(',')) && sample.some(s => s.includes(' '))) q('#tcSep').value = ' ';
    prev();
    ui.modal({
      title: 'Split text to columns', body, actions: [{ label: 'Cancel', value: null }, {
        label: 'Split', primary: true, onClick: async () => {
          const rowsParts = []; let maxW = 1;
          for (let r = R.t; r <= R.b; r++) { const cell = sh.cells[K(r, R.l)]; if (IS.isFormulaCell(cell)) { rowsParts.push(null); continue; } const p = split(X.toStr(val(sh, r, R.l)) || ''); rowsParts.push(p); maxW = Math.max(maxW, p.length); }
          let filled = 0; for (let r = R.t; r <= R.b; r++) for (let c = R.l + 1; c < R.l + maxW; c++) if (IS.hasContent(sh, r, c)) filled++;
          if (filled && !(await ui.confirm('Cells to the right already have data (' + filled + '). Replace them?', { ok: 'Replace' }))) return false;
          if (!IS.guardEdit({ t: R.t, l: R.l, b: R.b, r: R.l + maxW - 1 })) return false;
          IS.tx('Split text', () => rowsParts.forEach((parts, i) => { if (!parts) return; parts.forEach((p, j) => IS.writeText(sh, R.t + i, R.l + j, p)); }));
          return true;
        }
      }]
    });
  }

  // =================================================================== clean-up tools
  function cleanup(op) {
    const sh = IS.sheet; let R = IS.selRect();
    if (R.t === R.b && R.l === R.r) { const reg = IS.currentRegion(sh, R.t, R.l); if (reg) R = reg; }
    const used = IS.usedRange(sh); R = { t: R.t, l: R.l, b: Math.min(R.b, used.b), r: Math.min(R.r, used.r) };
    if (R.b < R.t || R.r < R.l) return;
    if (!IS.guardEdit(R)) return;
    const labels = { trim: 'Trim spaces', upper: 'UPPER CASE', lower: 'lower case', proper: 'Proper Case', numbers: 'Text to numbers', fillBlanks: 'Fill blanks', blankRows: 'Remove blank rows', breaks: 'Remove line breaks', values: 'Formulas to values' };
    if (op === 'blankRows') {
      const keep = []; for (let r = R.t; r <= R.b; r++) { let any = false; for (let c = R.l; c <= R.r; c++) if (IS.hasContent(sh, r, c)) { any = true; break; } if (any) keep.push(r); }
      const n = R.b - R.t + 1 - keep.length; if (!n) { ui.toast('No blank rows found.'); return; }
      compactRows(sh, R, keep); ui.toast('Removed ' + n + ' blank row' + (n > 1 ? 's' : '') + '.'); return;
    }
    let changed = 0;
    IS.tx(labels[op] || 'Clean up', () => {
      for (let c = R.l; c <= R.r; c++) {
        let last = null, lastR = -1;
        for (let r = R.t; r <= R.b; r++) {
          const key = K(r, c), cell = sh.cells[key];
          if (op === 'fillBlanks') {
            if (IS.hasValue(cell)) { last = cell; lastR = r; continue; }
            if (last && !IS.isCovered(sh, r, c)) { IS.editCell(sh, r, c, cl => { cl.v = IS.isFormulaCell(last) ? X.shiftFormula(last.v, r - lastR, 0) : last.v; if (last.t) cl.t = last.t; if (last.s && last.s.nf && !(cl.s && cl.s.nf)) cl.s = Object.assign({}, cl.s, { nf: last.s.nf }); }); changed++; }
            continue;
          }
          if (!IS.hasValue(cell)) continue;
          if (op === 'values') { if (!IS.isFormulaCell(cell)) continue; const v = X.norm(IS.calc.value(sh, r, c)); IS.editCell(sh, r, c, cl => { if (X.isErr(v) || v === null || v === undefined) delete cl.v; else cl.v = v; delete cl.t; }); changed++; continue; }
          if (IS.isFormulaCell(cell) || typeof cell.v !== 'string') continue;
          let v = cell.v, nf = null;
          switch (op) {
            case 'trim': v = v.replace(/[  \t]+/g, ' ').trim(); break;
            case 'upper': v = v.toUpperCase(); break;
            case 'lower': v = v.toLowerCase(); break;
            case 'proper': v = X.F.PROPER([v]); break;
            case 'breaks': v = v.replace(/\s*\r?\n\s*/g, ' '); break;
            case 'numbers': { const p = X.parseInput(v.replace(/[ \s]/g, '')); if (typeof p.value === 'number') { v = p.value; nf = p.nf; } break; }
          }
          if (v !== cell.v) { IS.editCell(sh, r, c, cl => { cl.v = v; delete cl.t; if (nf && !(cl.s && cl.s.nf)) cl.s = Object.assign({}, cl.s, { nf }); }); changed++; }
        }
      }
    });
    ui.toast(changed ? labels[op] + ': ' + changed + ' cell' + (changed > 1 ? 's' : '') + ' changed.' : 'Nothing needed changing.', { ms: 2500 });
  }

  // =================================================================== pivot / summary table
  const AGG = { sum: ['Sum', 'SUMIFS'], count: ['Count', 'COUNTIFS'], avg: ['Average', 'AVERAGEIFS'], min: ['Minimum', 'MINIFS'], max: ['Maximum', 'MAXIFS'], unique: ['Count unique', null] };
  function pivotDialog() {
    const sh = IS.sheet; const R = workRange(sh, { expandColumn: true });
    if (!R || R.b <= R.t || R.r < R.l) { ui.toast('Click inside a table that has a header row first.'); return; }
    const names = headerNames(sh, R, true);
    const numericCol = names.find(n => { for (let r = R.t + 1; r <= Math.min(R.b, R.t + 50); r++) if (typeof val(sh, r, n.c) === 'number') return true; return false; });
    const textCol = names.find(n => typeof val(sh, R.t + 1, n.c) === 'string') || names[0];
    const opts = (sel, none) => (none ? '<option value="">— none —</option>' : '') + names.map(n => `<option value="${n.c}" ${sel && n.c === sel.c ? 'selected' : ''}>${esc(n.name)}</option>`).join('');
    const body = document.createElement('div');
    body.innerHTML = `<p class="hint">Data: <b>${esc(sh.name)}!${esc(A1R(R))}</b> (first row = headings)</p>
      <div class="row"><label class="field"><span>Rows (group by)</span><select id="pvRow">${opts(textCol)}</select></label><label class="field"><span>Then by (optional)</span><select id="pvRow2">${opts(null, true)}</select></label></div>
      <label class="field"><span>Columns (optional)</span><select id="pvCol">${opts(null, true)}</select></label>
      <div class="row"><label class="field"><span>Values</span><select id="pvVal">${opts(numericCol || names[names.length - 1])}</select></label>
      <label class="field"><span>Summarise by</span><select id="pvAgg">${Object.entries(AGG).map(([k, [l]]) => `<option value="${k}">${l}</option>`).join('')}</select></label></div>
      <div class="row"><label class="field"><span>Order rows</span><select id="pvSort"><option value="az">A → Z</option><option value="desc">Largest total first</option><option value="asc">Smallest total first</option></select></label></div>
      <label class="check"><input type="checkbox" id="pvLive" checked> Live – update automatically when the data changes (uses SUMIFS formulas)</label>
      <p class="hint">A new sheet is created with the summary. Re-run it after adding new categories.</p>`;
    if (!numericCol) body.querySelector('#pvAgg').value = 'count';
    ui.modal({
      title: 'Pivot / summary table', body, actions: [{ label: 'Cancel', value: null }, {
        label: 'Create', primary: true, onClick: () => {
          const g = id => body.querySelector(id).value;
          const def = { sheetId: sh.id, range: R, row: +g('#pvRow'), row2: g('#pvRow2') === '' ? null : +g('#pvRow2'), col: g('#pvCol') === '' ? null : +g('#pvCol'), val: +g('#pvVal'), agg: g('#pvAgg'), sort: g('#pvSort'), live: body.querySelector('#pvLive').checked };
          if (def.row2 === def.row) def.row2 = null; if (def.col === def.row || def.col === def.row2) def.col = null;
          buildPivot(def); return true;
        }
      }]
    });
  }
  function buildPivot(def, into) {
    const src = IS.sheetById(def.sheetId); if (!src) { ui.toast('The source sheet no longer exists.', { type: 'error' }); return; }
    const R = def.range; const t0 = R.t + 1;
    const extendB = (() => { const reg = IS.currentRegion(src, R.t, R.l); return reg ? Math.max(R.b, reg.b) : R.b; })();
    const B = extendB;
    const keyOf = v => (isBlank(v) ? '\u0000blank' : typeof v === 'string' ? 's' + v.trim().toLowerCase() : typeof v + String(v));
    const rowKeys = new Map(), colKeys = new Map(), cells = new Map();
    const addKey = (map, v, r, c) => { const k = keyOf(v); if (!map.has(k)) map.set(k, { k, v: isBlank(v) ? null : (typeof v === 'string' ? v.trim() : v), label: isBlank(v) ? '(blank)' : disp(src, r, c), total: 0, n: 0, set: new Set(), min: Infinity, max: -Infinity }); return map.get(k); };
    for (let r = t0; r <= B; r++) {
      const rv = val(src, r, def.row), rv2 = def.row2 != null ? val(src, r, def.row2) : null, cv = def.col != null ? val(src, r, def.col) : null, v = val(src, r, def.val);
      let allBlank = true; for (let c = R.l; c <= R.r; c++) if (!isBlank(val(src, r, c))) { allBlank = false; break; } if (allBlank) continue;
      const rk = addKey(rowKeys, rv, r, def.row); const rk2 = def.row2 != null ? addKey(new Map(), rv2, r, def.row2) : null;
      const compound = rk.k + (rk2 ? '\u0002' + rk2.k : '');
      if (rk2) { if (!rowKeys.has(compound)) rowKeys.set(compound, { k: compound, parts: [rk, rk2], v: rk.v, label: rk.label, total: 0, n: 0, set: new Set(), min: Infinity, max: -Infinity }); }
      const row = rowKeys.get(compound);
      const ck = def.col != null ? addKey(colKeys, cv, r, def.col) : null;
      const cellKey = compound + '\u0003' + (ck ? ck.k : '');
      if (!cells.has(cellKey)) cells.set(cellKey, { total: 0, n: 0, set: new Set(), min: Infinity, max: -Infinity });
      for (const acc of [row, cells.get(cellKey)].concat(ck ? [ck] : [])) {
        acc.n++; acc.set.add(keyOf(v));
        if (typeof v === 'number') { acc.total += v; acc.min = Math.min(acc.min, v); acc.max = Math.max(acc.max, v); }
      }
    }
    // rows: when using a second field the top-level map also contains single keys; keep only compound ones
    let rows = [...rowKeys.values()].filter(x => (def.row2 != null ? !!x.parts : true));
    const aggOf = acc => { switch (def.agg) { case 'sum': return acc.total; case 'count': return acc.n; case 'avg': return acc.n ? acc.total / acc.n : 0; case 'min': return acc.min === Infinity ? 0 : acc.min; case 'max': return acc.max === -Infinity ? 0 : acc.max; case 'unique': return acc.set.size; } return 0; };
    if (def.sort === 'desc') rows.sort((a, b) => aggOf(b) - aggOf(a)); else if (def.sort === 'asc') rows.sort((a, b) => aggOf(a) - aggOf(b));
    else rows.sort((a, b) => { const pa = a.parts || [a], pb = b.parts || [b]; for (let i = 0; i < pa.length; i++) { const c = cmpVals(pa[i].v, pb[i].v, 1); if (c) return c; } return 0; });
    const cols = [...colKeys.values()].sort((a, b) => cmpVals(a.v, b.v, 1));
    if (!rows.length) { ui.toast('No data rows found under the header.', { type: 'error' }); return; }
    if (rows.length * Math.max(1, cols.length) > 200000) { ui.toast('That summary would be too large. Choose fewer columns.', { type: 'error' }); return; }
    const head = c => String(disp(src, R.t, c) || 'Column ' + X.numToCol(c));
    const [aggLabel, fn] = AGG[def.agg];
    const live = def.live && fn;
    const sheetRef = X.quoteSheet(src.name) + '!';
    const colRange = c => sheetRef + '$' + X.numToCol(c) + '$' + (t0 + 1) + ':$' + X.numToCol(c) + '$' + (B + 1);
    const valNf = (() => { const cell = src.cells[K(t0, def.val)]; return def.agg === 'count' || def.agg === 'unique' ? '#,##0' : (cell && cell.s && cell.s.nf) || '#,##0.00'; })();
    const nRowFields = def.row2 != null ? 2 : 1;
    const out = IS.newSheet(into ? into.name : IS.uniqueSheetName(('Summary – ' + head(def.val)).slice(0, 28)));
    const title = aggLabel + ' of ' + head(def.val) + ' by ' + head(def.row) + (def.row2 != null ? ' & ' + head(def.row2) : '') + (def.col != null ? ' and ' + head(def.col) : '');
    const put = (r, c, v, s) => { const cell = {}; if (v !== null && v !== undefined && v !== '') cell.v = v; if (s) cell.s = s; if (cell.v !== undefined || cell.s) out.cells[K(r, c)] = cell; };
    out.cells = {}; out.merges = []; out.cf = []; out.dv = []; out.filter = null;
    put(0, 0, title, { b: true, fs: 13 });
    put(1, 0, 'Source: ' + src.name + '!' + A1R({ t: R.t, l: R.l, b: B, r: R.r }) + (live ? ' · updates automatically' : ' · snapshot ' + new Date().toLocaleString('en-IN')), { color: '#5f6b65', i: true });
    const H = 3; const HS = { b: true, bg: '#0f7a3d', color: '#ffffff', va: 'middle', wrap: true, bd: { bb: 'thin', c: '#0a5c2d' } };
    put(H, 0, head(def.row), HS); if (nRowFields === 2) put(H, 1, head(def.row2), HS);
    cols.forEach((ck, j) => put(H, nRowFields + j, ck.v === null ? '(blank)' : ck.v, Object.assign({}, HS, { al: 'right' }, ck.v !== null && typeof ck.v === 'number' ? { nf: (src.cells[K(t0, def.col)] || {}).s?.nf } : null)));
    const totCol = nRowFields + cols.length;
    put(H, totCol, cols.length ? 'Grand total' : aggLabel + ' of ' + head(def.val), Object.assign({}, HS, { al: 'right' }));
    const crit = (fieldCol, keyCell, isBlankKey) => colRange(fieldCol) + ',' + (isBlankKey ? '""' : '"="&' + keyCell);
    const formula = (rowParts, ck) => {
      const parts = [];
      rowParts.forEach(([fieldCol, keyCell, blankKey]) => parts.push(crit(fieldCol, keyCell, blankKey)));
      if (ck) parts.push(crit(def.col, ck.cell, ck.v === null));
      if (def.agg === 'count') return '=COUNTIFS(' + (parts.length ? parts.join(',') : colRange(def.val) + ',"<>"') + ')';
      const inner = fn + '(' + colRange(def.val) + (parts.length ? ',' + parts.join(',') : ',' + colRange(def.val) + ',"<>"') + ')';
      return def.agg === 'avg' ? '=IFERROR(' + inner + ',"")' : '=' + inner;
    };
    cols.forEach((ck, j) => { ck.cell = X.numToCol(nRowFields + j) + '$' + (H + 1); });
    rows.forEach((row, i) => {
      const r = H + 1 + i; const parts = row.parts || [row];
      parts.forEach((p, j) => put(r, j, p.v === null ? '(blank)' : p.v, p.v !== null && typeof p.v === 'number' ? { nf: (src.cells[K(t0, j === 0 ? def.row : def.row2)] || {}).s?.nf || null } : (i % 2 ? { bg: '#f4f8f6' } : null)));
      const rowParts = parts.map((p, j) => [j === 0 ? def.row : def.row2, '$' + X.numToCol(j) + (r + 1), p.v === null]);
      const band = i % 2 ? { bg: '#f4f8f6' } : {};
      cols.forEach((ck, j) => {
        const acc = cells.get((row.parts ? row.k : row.k) + '\u0003' + ck.k);
        put(r, nRowFields + j, live ? formula(rowParts, ck) : (acc ? aggOf(acc) : null), Object.assign({ nf: valNf }, band));
      });
      put(r, totCol, live ? formula(rowParts, null) : aggOf(row), Object.assign({ nf: valNf, b: true }, band));
      if (band.bg) for (let j = 0; j < nRowFields; j++) { const cell = out.cells[K(r, j)] || {}; cell.s = Object.assign({}, cell.s, band); out.cells[K(r, j)] = cell; }
    });
    const tr = H + 1 + rows.length; const TS = { b: true, bd: { bt: 'thin', bb: 'double', c: '#0a5c2d' } };
    put(tr, 0, 'Grand total', TS); if (nRowFields === 2) put(tr, 1, '', TS);
    const sumCol = c => '=' + (def.agg === 'sum' || def.agg === 'count' ? 'SUM' : def.agg === 'avg' ? 'AVERAGE' : def.agg === 'min' ? 'MIN' : def.agg === 'max' ? 'MAX' : 'SUM') + '(' + X.numToCol(c) + (H + 2) + ':' + X.numToCol(c) + tr + ')';
    cols.forEach((ck, j) => put(tr, nRowFields + j, live ? (def.agg === 'avg' ? formula([], ck) : sumCol(nRowFields + j)) : aggOf(ck), Object.assign({ nf: valNf }, TS)));
    const grandAcc = { total: 0, n: 0, set: new Set(), min: Infinity, max: -Infinity }; rows.forEach(rw => { grandAcc.total += rw.total; grandAcc.n += rw.n; rw.set.forEach(x => grandAcc.set.add(x)); grandAcc.min = Math.min(grandAcc.min, rw.min); grandAcc.max = Math.max(grandAcc.max, rw.max); });
    put(tr, totCol, live ? (def.agg === 'avg' ? formula([], null) : sumCol(totCol)) : aggOf(grandAcc), Object.assign({ nf: valNf }, TS));
    const wFor = (r, c) => { const cell = out.cells[K(r, c)]; const t = cell && cell.v != null ? String(cell.v) : ''; return Math.min(240, Math.max(110, t.length * 7.4 + 24)); };
    out.colW = { 0: Math.max(160, wFor(H, 0)) }; if (nRowFields === 2) out.colW[1] = Math.max(140, wFor(H, 1));
    for (let j = 0; j <= cols.length; j++) out.colW[nRowFields + j] = wFor(H, nRowFields + j);
    out.rowH[H] = 30;
    out.freezeR = H + 1; out.rows = Math.max(1000, tr + 100); out.cols = Math.max(26, totCol + 5);
    out.pivot = Object.assign({}, def, { range: R });
    if (into) {
      // rebuild an existing summary sheet in place, as one undo step
      IS.tx('Refresh summary', () => {
        IS.rec.sheet(into);
        ['cells', 'merges', 'cf', 'dv', 'filter', 'colW', 'freezeR', 'rows', 'cols', 'pivot'].forEach(k => { into[k] = out[k]; });
        IS.invalidateHidden(into);
      }, { full: true });
    } else IS.addSheet(out);
    ui.toast('Summary table ' + (into ? 'refreshed' : 'ready') + (live ? ' – it updates automatically.' : '.'), { ms: 3000 });
  }
  function refreshPivot() {
    const sh = IS.sheet; if (!sh.pivot) { ui.toast('This sheet is not a summary table.'); return; }
    buildPivot(JSON.parse(JSON.stringify(sh.pivot)), sh);
  }

  // =================================================================== named ranges
  function namedRanges() {
    const wb = IS.wb;
    const body = document.createElement('div');
    const render = () => {
      const names = Object.keys(wb.names).sort();
      const R = IS.selRect();
      const cur = X.quoteSheet(IS.sheet.name) + '!' + X.a1(R.t, R.l, true, true) + (R.t !== R.b || R.l !== R.r ? ':' + X.a1(R.b, R.r, true, true) : '');
      body.innerHTML = `<p class="hint">Give a range a name (like <code>GST_RATE</code> or <code>Items</code>) and use it in formulas: <code>=SUM(Sales)</code></p>
        <table class="table">${names.length ? names.map(n => `<tr><td class="mono"><b>${esc(wb.names[n].name || n)}</b></td><td class="mono">${esc(wb.names[n].ref)}</td><td style="white-space:nowrap"><button type="button" class="btn small" data-go="${esc(n)}">Go</button> <button type="button" class="btn small" data-del="${esc(n)}">Delete</button></td></tr>`).join('') : '<tr><td class="hint">No names yet.</td></tr>'}</table>
        <h3>Add a name</h3>
        <div class="row"><label class="field"><span>Name</span><input id="nmName" placeholder="Sales"></label><label class="field" style="flex:2"><span>Refers to</span><input id="nmRef" class="mono" value="${esc(cur)}"></label></div>
        <button type="button" class="btn primary" id="nmAdd">Add name</button>`;
      body.querySelectorAll('[data-go]').forEach(b => b.onclick = () => { ui.closeModal(); IS.goTo(b.dataset.go); });
      body.querySelectorAll('[data-del]').forEach(b => b.onclick = () => { IS.tx('Delete name', () => { IS.rec.book(); delete wb.names[b.dataset.del]; }, { full: true }); render(); });
      body.querySelector('#nmAdd').onclick = () => {
        const name = body.querySelector('#nmName').value.trim(), ref = body.querySelector('#nmRef').value.trim().replace(/^=/, '');
        if (!/^[A-Za-z_\\][A-Za-z0-9_.]*$/.test(name) || /^[A-Za-z]{1,3}\d+$/.test(name) || /^(TRUE|FALSE|R|C)$/i.test(name)) { ui.toast('Names must start with a letter, have no spaces and must not look like a cell (e.g. A1).', { type: 'error' }); return; }
        if (X.F[name.toUpperCase()]) { ui.toast('"' + name + '" is a function name – choose another.', { type: 'error' }); return; }
        const p = X.parseRef(ref); if (!p) { ui.toast('"Refers to" must be a range like Sheet1!$A$1:$A$10', { type: 'error' }); return; }
        const full = p.sheet ? ref : X.quoteSheet(IS.sheet.name) + '!' + ref;
        IS.tx('Add name', () => { IS.rec.book(); wb.names[name.toUpperCase()] = { name, ref: full }; }, { full: true });
        render();
      };
    };
    render();
    ui.modal({ title: 'Named ranges', body });
  }

  // =================================================================== fill series
  function fillSeries() {
    const sh = IS.sheet, R = IS.selRect(), s = IS.state.sel;
    const start = val(sh, s.r, s.c);
    const isDate = (() => { const cell = sh.cells[K(s.r, s.c)]; return cell && cell.s && X.isDateFormat(cell.s.nf); })();
    const body = document.createElement('div');
    body.innerHTML = `<div class="row"><label class="field"><span>Series in</span><select id="fsDir"><option value="down">Columns (down)</option><option value="right">Rows (across)</option></select></label>
      <label class="field"><span>Type</span><select id="fsType"><option value="linear">Numbers (add the step)</option><option value="growth">Numbers (multiply by step)</option><option value="day">Dates – every day</option><option value="weekday">Dates – working days (Mon–Fri)</option><option value="month">Dates – every month</option><option value="year">Dates – every year</option></select></label></div>
      <div class="row"><label class="field"><span>Start value</span><input id="fsStart" value="${esc(typeof start === 'number' ? (isDate ? X.formatValue(start, 'dd-mm-yyyy').text : String(start)) : '1')}"></label>
      <label class="field"><span>Step</span><input id="fsStep" type="number" value="1"></label>
      <label class="field"><span>Stop at (optional)</span><input id="fsStop" placeholder="${R.t === R.b && R.l === R.r ? 'e.g. 100' : 'fills the selection'}"></label></div>
      <p class="hint">${R.t === R.b && R.l === R.r ? 'Enter a stop value, or select the cells to fill first.' : 'Fills the selected cells.'}</p>`;
    if (isDate) body.querySelector('#fsType').value = 'day';
    if (R.l !== R.r && R.t === R.b) body.querySelector('#fsDir').value = 'right';
    ui.modal({
      title: 'Fill series', body, actions: [{ label: 'Cancel', value: null }, {
        label: 'Fill', primary: true, onClick: () => {
          const g = id => body.querySelector(id).value;
          const type = g('#fsType'), dir = g('#fsDir'), step = +g('#fsStep') || 1;
          const st = X.parseInput(g('#fsStart')).value; if (typeof st !== 'number') { ui.toast('Start value must be a number or a date.', { type: 'error' }); return false; }
          const stopRaw = g('#fsStop').trim(); const stop = stopRaw ? X.parseInput(stopRaw).value : null;
          let count = dir === 'down' ? R.b - R.t + 1 : R.r - R.l + 1;
          const dateType = ['day', 'weekday', 'month', 'year'].includes(type);
          const seq = []; let v = st; let guard = 0;
          const next = (x) => {
            if (type === 'linear') return x + step; if (type === 'growth') return x * step;
            if (type === 'day') return x + step;
            if (type === 'weekday') { let d = x, n = Math.abs(step); while (n > 0) { d += Math.sign(step) || 1; const w = X.fromSerial(d).getUTCDay(); if (w !== 0 && w !== 6) n--; } return d; }
            if (type === 'month') return X.F.EDATE([x, step]); return X.F.EDATE([x, step * 12]);
          };
          if (stop !== null && typeof stop === 'number') { while ((step > 0 ? v <= stop : v >= stop) && guard++ < 100000) { seq.push(v); v = next(v); } }
          else { for (let i = 0; i < Math.max(count, 1); i++) { seq.push(v); v = next(v); } }
          if (!seq.length) return true;
          const area = dir === 'down' ? { t: s.r, l: s.c, b: s.r + seq.length - 1, r: s.c } : { t: s.r, l: s.c, b: s.r, r: s.c + seq.length - 1 };
          if (!IS.guardEdit(area)) return false;
          IS.tx('Fill series', () => seq.forEach((x, i) => { const r = dir === 'down' ? s.r + i : s.r, c = dir === 'down' ? s.c : s.c + i; IS.editCell(sh, r, c, cl => { cl.v = Math.round(x * 1e10) / 1e10; delete cl.t; if (dateType && !(cl.s && cl.s.nf)) cl.s = Object.assign({}, cl.s, { nf: 'dd-mm-yyyy' }); }); }));
          IS.setSel(area.t, area.l, area.b, area.r, { scroll: false });
          return true;
        }
      }]
    });
  }

  Object.assign(IS.cmd, {
    sortAsc: () => quickSort(1), sortDesc: () => quickSort(-1), sortDialog,
    filterToggle, filterMenu, filterByValue, filterClear,
    removeDuplicates, textToColumns, cleanup, pivot: pivotDialog, refreshPivot, namedRanges, fillSeries
  });
  IS.buildPivot = buildPivot;
})(window);
