/* India Sheets – floating objects: charts and images (move, resize, live update, print) */
(function (global) {
  'use strict';
  const IS = global.IS, ui = IS.ui, X = global.Formula, esc = ui.esc, K = IS.K;
  const $ = id => document.getElementById(id);
  const CHART_URL = 'vendor/chart.umd.js';
  const PALETTES = {
    India: ['#0f7a3d', '#ff9933', '#1a3c8f', '#c62828', '#7b1fa2', '#00838f', '#f9a825', '#5d4037', '#2e7d32', '#ef6c00'],
    Ocean: ['#1565c0', '#00838f', '#26a69a', '#5c6bc0', '#29b6f6', '#00695c', '#7986cb', '#4dd0e1'],
    Warm: ['#e64a19', '#f9a825', '#c2185b', '#ff7043', '#ffb300', '#8d6e63', '#d81b60', '#fb8c00'],
    Grey: ['#37474f', '#78909c', '#90a4ae', '#546e7a', '#b0bec5', '#263238']
  };
  const TYPES = [['column', 'Column', '▮▮▮'], ['bar', 'Bar', '☰'], ['line', 'Line', '📈'], ['area', 'Area', '◢'], ['pie', 'Pie', '◔'], ['doughnut', 'Doughnut', '◎'], ['scatter', 'Scatter', '⁘'], ['combo', 'Column + line', '▮📈'], ['radar', 'Radar', '✶']];
  let chartReady = null;
  function loadChart() { if (global.Chart) return Promise.resolve(); if (!chartReady) chartReady = ui.loadScript(CHART_URL).catch(e => { chartReady = null; throw e; }); return chartReady; }
  const live = new Map(); // object id -> {el, chart}

  // ------------------------------------------------------------ chart data from the sheet
  function chartData(o) {
    const p = X.parseRef(o.chart.src || ''); if (!p) return null;
    const sh = p.sheet ? IS.sheetByName(p.sheet) : IS.sheetById(o.sheetId) || IS.sheet; if (!sh) return null;
    const used = IS.usedRange(sh);
    const b = Math.min(p.r2 === Infinity ? used.b : p.r2, used.b), r = Math.min(p.c2 === Infinity ? used.r : p.c2, used.r);
    const grid = [];
    for (let i = p.r1; i <= b; i++) { if (!IS.rowVisible(sh, i)) continue; const row = []; for (let j = p.c1; j <= r; j++) row.push(X.norm(IS.calc.value(sh, i, j))); grid.push(row); }
    if (!grid.length || !grid[0].length) return { labels: [], sets: [] };
    let rows = grid;
    if (o.chart.byRow) rows = grid[0].map((_, j) => grid.map(rw => rw[j]));
    const head = o.chart.header !== undefined ? o.chart.header : rows.length > 1 && rows[0].every(v => v === null || typeof v === 'string') && rows[0].some(v => typeof v === 'string') && rows.slice(1).some(rw => rw.some(v => typeof v === 'number'));
    const body = head ? rows.slice(1) : rows;
    const labelCol = o.chart.labelCol !== undefined ? o.chart.labelCol : (rows[0].length > 1 && body.filter(rw => typeof rw[0] === 'string' || (rw[0] !== null && isDateCol(sh, p, o))).length >= Math.max(1, body.length / 2));
    const labelNf = (() => { const cell = sh.cells[K(p.r1 + (head ? 1 : 0), p.c1)]; return cell && cell.s && cell.s.nf; })();
    const fmtLabel = v => { if (v === null || v === undefined) return ''; if (typeof v === 'number' && isDateCol(sh, p, o)) return X.formatValue(v, labelNf && X.isDateFormat(labelNf) ? labelNf : 'd mmm yy').text; return String(X.toStr(v)); };
    const labels = body.map((rw, i) => (labelCol ? fmtLabel(rw[0]) : String(i + 1)));
    const sets = [];
    for (let j = labelCol ? 1 : 0; j < rows[0].length; j++) sets.push({ name: head ? String(X.toStr(rows[0][j]) || 'Series ' + (sets.length + 1)) : 'Series ' + (sets.length + 1), data: body.map(rw => (typeof rw[j] === 'number' ? rw[j] : null)) });
    return { labels, sets, xNums: body.map(rw => rw[0]) };
  }
  function isDateCol(sh, p, o) { if (o.chart.byRow) return false; const cell = sh.cells[K(p.r1 + 1, p.c1)]; return !!(cell && cell.s && X.isDateFormat(cell.s.nf)); }
  function chartConfig(o, d, opts = {}) {
    const c = o.chart, pal = PALETTES[c.palette || 'India'];
    const dark = !opts.print && document.documentElement.dataset.themeResolved === 'dark';
    const text = dark ? '#d5ded9' : '#33403a', grid = dark ? 'rgba(255,255,255,.08)' : 'rgba(0,0,0,.08)';
    const kind = c.type || 'column';
    const pieLike = kind === 'pie' || kind === 'doughnut';
    let type = { column: 'bar', bar: 'bar', area: 'line', combo: 'bar' }[kind] || kind;
    const datasets = (pieLike ? d.sets.slice(0, 1) : d.sets).map((s, i) => {
      const col = pal[i % pal.length];
      const ds = { label: s.name, data: s.data, backgroundColor: pieLike ? d.labels.map((_, k) => pal[k % pal.length]) : col + (kind === 'area' ? '55' : ''), borderColor: pieLike ? (dark ? '#1b2220' : '#fff') : col, borderWidth: pieLike ? 2 : kind === 'line' || kind === 'area' || (kind === 'combo' && i > 0) ? 2.5 : 0, tension: 0.25, fill: kind === 'area', pointRadius: kind === 'line' || kind === 'area' ? 2.5 : 3, borderRadius: kind === 'column' || kind === 'bar' || (kind === 'combo' && !i) ? 3 : 0 };
      if (kind === 'combo' && i > 0) { ds.type = 'line'; ds.backgroundColor = col; }
      if (kind === 'scatter') ds.data = s.data.map((y, k) => ({ x: typeof d.xNums[k] === 'number' ? d.xNums[k] : k + 1, y }));
      return ds;
    });
    const fmt = v => (typeof v === 'number' ? (Math.abs(v) >= 1e7 ? (v / 1e7).toLocaleString('en-IN', { maximumFractionDigits: 2 }) + ' Cr' : Math.abs(v) >= 1e5 ? (v / 1e5).toLocaleString('en-IN', { maximumFractionDigits: 2 }) + ' L' : v.toLocaleString('en-IN', { maximumFractionDigits: 2 })) : v);
    const valuesPlugin = { id: 'isValues', afterDatasetsDraw(ch) {
      if (!c.showValues) return; const g = ch.ctx; g.save(); g.fillStyle = text; g.font = '11px "Segoe UI", sans-serif'; g.textAlign = 'center'; g.textBaseline = 'bottom';
      ch.data.datasets.forEach((ds, i) => { const meta = ch.getDatasetMeta(i); if (meta.hidden) return; meta.data.forEach((el, k) => { const v = ds.data[k]; const n = typeof v === 'object' && v ? v.y : v; if (n === null || n === undefined) return; const pos = el.tooltipPosition ? el.tooltipPosition() : el; if (pieLike) { g.fillStyle = '#fff'; g.textBaseline = 'middle'; } g.fillText(fmt(n), pos.x, pos.y - (pieLike ? 0 : 4)); }); });
      g.restore(); } };
    const indexAxis = kind === 'bar' ? 'y' : 'x';
    return {
      type, data: { labels: kind === 'scatter' ? undefined : d.labels, datasets },
      options: {
        responsive: !opts.fixed, maintainAspectRatio: false, animation: false, indexAxis, devicePixelRatio: opts.dpr || global.devicePixelRatio || 1,
        layout: { padding: 8 },
        plugins: {
          legend: { display: c.legend !== 'none' && (datasets.length > 1 || pieLike), position: c.legend && c.legend !== 'none' ? c.legend : 'top', labels: { color: text, boxWidth: 12 } },
          title: { display: !!c.title, text: c.title, color: text, font: { size: 15, weight: '600' } },
          tooltip: { callbacks: { label: ctx => ' ' + (ctx.dataset.label ? ctx.dataset.label + ': ' : '') + fmt(ctx.parsed && typeof ctx.parsed === 'object' ? (indexAxis === 'y' ? ctx.parsed.x : ctx.parsed.y) : ctx.parsed) } }
        },
        scales: pieLike || kind === 'radar' ? (kind === 'radar' ? { r: { ticks: { color: text, backdropColor: 'transparent' }, grid: { color: grid }, angleLines: { color: grid }, pointLabels: { color: text } } } : {}) : {
          x: { stacked: !!c.stacked, ticks: { color: text, callback: function (v) { return indexAxis === 'y' || kind === 'scatter' ? fmt(v) : this.getLabelForValue(v); } }, grid: { color: indexAxis === 'y' || kind === 'scatter' ? grid : 'transparent' }, type: kind === 'scatter' ? 'linear' : undefined },
          y: { stacked: !!c.stacked, ticks: { color: text, callback: function (v) { return indexAxis === 'y' ? this.getLabelForValue(v) : fmt(v); } }, grid: { color: indexAxis === 'y' ? 'transparent' : grid }, beginAtZero: true }
        }
      },
      plugins: [valuesPlugin]
    };
  }

  // ------------------------------------------------------------ DOM objects on the active sheet
  const layer = () => IS.grid.objLayer;
  function screenPos(o) {
    const g = IS.grid, z = g.z;
    return { x: g.colX(o.c) - g.hw + (o.dx || 0) * z, y: g.rowY(o.r) - g.hh + (o.dy || 0) * z, w: o.w * z, h: o.h * z };
  }
  function place(o, el) { const p = screenPos(o); el.style.left = p.x + 'px'; el.style.top = p.y + 'px'; el.style.width = p.w + 'px'; el.style.height = p.h + 'px'; }
  function renderAll() {
    const sh = IS.sheet; const objs = sh.objects || [];
    const ids = new Set(objs.map(o => o.id));
    for (const [id, ent] of live) if (!ids.has(id) || ent.sheet !== sh.id) { if (ent.chart) ent.chart.destroy(); ent.el.remove(); live.delete(id); }
    objs.forEach(o => {
      let ent = live.get(o.id);
      if (!ent) ent = create(o, sh);
      else if (o.type === 'chart' && ent.sig !== JSON.stringify(o.chart)) { refreshChart(o, ent); }
      place(o, ent.el);
      ent.el.classList.toggle('sel', IS.state.selObj === o.id);
    });
  }
  function create(o, sh) {
    const el = document.createElement('div');
    el.className = 'obj ' + o.type; el.dataset.id = o.id;
    el.innerHTML = '<div class="obj-tools">' + (o.type === 'chart' ? '<button type="button" class="btn small" data-act="edit">' + ui.icon('edit', 14) + ' Edit</button>' : '') + '<button type="button" class="btn small" data-act="del">' + ui.icon('trash', 14) + '</button></div><div class="obj-handle"></div>';
    const ent = { el, sheet: sh.id, chart: null, sig: '' };
    if (o.type === 'image') { const img = document.createElement('img'); img.src = o.src; img.alt = o.alt || 'Picture'; img.draggable = false; el.insertBefore(img, el.firstChild); }
    else { const cv = document.createElement('canvas'); el.insertBefore(cv, el.firstChild); }
    layer().appendChild(el);
    live.set(o.id, ent);
    bind(o.id, el);
    if (o.type === 'chart') refreshChart(o, ent);
    return ent;
  }
  function refreshChart(o, ent) {
    ent.sig = JSON.stringify(o.chart);
    loadChart().then(() => {
      const d = chartData(o) || { labels: [], sets: [] };
      const cv = ent.el.querySelector('canvas');
      const cfg = chartConfig(o, d);
      if (ent.chart && ent.chart.config.type === cfg.type) { ent.chart.data = cfg.data; ent.chart.options = cfg.options; ent.chart.update('none'); }
      else { if (ent.chart) ent.chart.destroy(); ent.chart = new global.Chart(cv, cfg); }
    }).catch(() => { ent.el.innerHTML = '<div class="hint" style="padding:10px">Chart engine could not load.</div>'; });
  }
  let dataTimer = null;
  function refreshData() { clearTimeout(dataTimer); dataTimer = setTimeout(() => { for (const [id, ent] of live) { const o = (IS.sheet.objects || []).find(x => x.id === id); if (o && o.type === 'chart' && ent.chart) { const d = chartData(o) || { labels: [], sets: [] }; const cfg = chartConfig(o, d); ent.chart.data = cfg.data; ent.chart.update('none'); } } }, 150); }
  function reposition() { const sh = IS.sheet; (sh.objects || []).forEach(o => { const ent = live.get(o.id); if (ent) place(o, ent.el); }); }

  function findObj(id) { return (IS.sheet.objects || []).find(o => o.id === id); }
  function selectObj(id) { IS.state.selObj = id; for (const [oid, ent] of live) ent.el.classList.toggle('sel', oid === id); }
  function bind(id, el) {
    el.addEventListener('pointerdown', e => {
      if (e.button !== 0) return;
      const act = e.target.closest('[data-act]');
      if (act) { e.stopPropagation(); if (act.dataset.act === 'del') deleteObj(id); else editChart(id); return; }
      e.preventDefault(); e.stopPropagation();
      if (IS.state.editing && !IS.commitEdit()) return;
      selectObj(id);
      const o = findObj(id); if (!o) return;
      const resize = e.target.classList.contains('obj-handle');
      const start = { x: e.clientX, y: e.clientY, pos: screenPos(o) };
      el.setPointerCapture(e.pointerId);
      const move = ev => {
        const dx = ev.clientX - start.x, dy = ev.clientY - start.y;
        if (resize) { el.style.width = Math.max(40, start.pos.w + dx) + 'px'; el.style.height = Math.max(30, start.pos.h + dy) + 'px'; }
        else { el.style.left = (start.pos.x + dx) + 'px'; el.style.top = (start.pos.y + dy) + 'px'; }
      };
      const up = ev => {
        el.removeEventListener('pointermove', move); el.removeEventListener('pointerup', up);
        const dx = ev.clientX - start.x, dy = ev.clientY - start.y;
        if (Math.abs(dx) < 2 && Math.abs(dy) < 2) return;
        if (!IS.guardEdit(null, { structure: !!(IS.sheet.protect && IS.sheet.protect.on) })) { reposition(); return; }
        const sh = IS.sheet, g = IS.grid, z = g.z;
        IS.tx(resize ? 'Resize ' + o.type : 'Move ' + o.type, () => {
          IS.rec.meta(sh);
          const ob = sh.objects.find(x => x.id === id);
          if (resize) { ob.w = Math.round(Math.max(40, start.pos.w + dx) / z); ob.h = Math.round(Math.max(30, start.pos.h + dy) / z); }
          else {
            const sx = Math.max(g.hw, start.pos.x + dx + g.hw), sy = Math.max(g.hh, start.pos.y + dy + g.hh);
            const c = g.colFromX(sx), r = g.rowFromY(sy);
            ob.c = c; ob.r = r; ob.dx = Math.round((sx - g.colX(c)) / z); ob.dy = Math.round((sy - g.rowY(r)) / z);
          }
        });
        reposition(); IS.state.selObj = id; renderAll();
      };
      el.addEventListener('pointermove', move); el.addEventListener('pointerup', up);
    });
    el.addEventListener('dblclick', e => { e.stopPropagation(); const o = findObj(id); if (o && o.type === 'chart') editChart(id); });
    el.addEventListener('contextmenu', e => { e.preventDefault(); e.stopPropagation(); selectObj(id); const o = findObj(id); ui.menu([o && o.type === 'chart' ? { label: 'Edit chart…', icon: 'edit', onClick: () => editChart(id) } : null, o && o.type === 'chart' ? { label: 'Download chart as picture', icon: 'download', onClick: () => downloadChart(id) } : null, { label: 'Bring to front', onClick: () => order(id, 1) }, { label: 'Send to back', onClick: () => order(id, -1) }, { sep: true }, { label: 'Delete', icon: 'trash', onClick: () => deleteObj(id) }], e.clientX, e.clientY); });
  }
  function order(id, dir) { const sh = IS.sheet; IS.tx('Arrange', () => { IS.rec.meta(sh); const i = sh.objects.findIndex(o => o.id === id); const [o] = sh.objects.splice(i, 1); if (dir > 0) sh.objects.push(o); else sh.objects.unshift(o); }); for (const ent of live.values()) ent.el.remove(); live.clear(); renderAll(); }
  function deleteObj(id) {
    const sh = IS.sheet; if (!IS.guardEdit(null, { structure: !!(sh.protect && sh.protect.on) })) return;
    IS.tx('Delete object', () => { IS.rec.meta(sh); sh.objects = sh.objects.filter(o => o.id !== id); });
    IS.state.selObj = null; renderAll(); IS.focusGrid();
  }
  IS.deleteSelectedObject = () => { if (!IS.state.selObj) return false; if (!findObj(IS.state.selObj)) { IS.state.selObj = null; return false; } deleteObj(IS.state.selObj); return true; };
  IS.objectAtCell = () => null;

  // ------------------------------------------------------------ insert / edit chart
  function chartDialog(o, onSave) {
    const c = Object.assign({ type: 'column', title: '', legend: 'top', stacked: false, showValues: false, palette: 'India', byRow: false }, o.chart);
    const body = document.createElement('div');
    body.innerHTML = `<div class="row"><label class="field" style="flex:2"><span>Data range</span><input id="chSrc" class="mono" value="${esc(c.src)}"></label><label class="field"><span>Title</span><input id="chTitle" value="${esc(c.title)}" placeholder="e.g. Monthly sales"></label></div>
      <div class="style-presets" id="chTypes">${TYPES.map(([k, l, ic]) => `<button type="button" data-t="${k}" class="${c.type === k ? 'on' : ''}">${ic} ${l}</button>`).join('')}</div>
      <div class="row" style="margin-top:8px"><label class="field"><span>Legend</span><select id="chLegend"><option value="top">Top</option><option value="bottom">Bottom</option><option value="right">Right</option><option value="none">Hidden</option></select></label>
      <label class="field"><span>Colours</span><select id="chPal">${Object.keys(PALETTES).map(k => `<option>${k}</option>`).join('')}</select></label></div>
      <label class="check"><input type="checkbox" id="chStack"> Stacked</label><label class="check"><input type="checkbox" id="chVals"> Show values on the chart</label><label class="check"><input type="checkbox" id="chRow"> Series are in rows (not columns)</label>
      <div style="position:relative;height:280px;margin-top:8px" class="preview-box"><canvas id="chPrev"></canvas></div>`;
    const q = s => body.querySelector(s);
    q('#chLegend').value = c.legend; q('#chPal').value = c.palette; q('#chStack').checked = c.stacked; q('#chVals').checked = c.showValues; q('#chRow').checked = c.byRow;
    let prev = null;
    const read = () => { c.src = q('#chSrc').value.trim(); c.title = q('#chTitle').value; c.legend = q('#chLegend').value; c.palette = q('#chPal').value; c.stacked = q('#chStack').checked; c.showValues = q('#chVals').checked; c.byRow = q('#chRow').checked; };
    const draw = () => {
      read();
      loadChart().then(() => {
        const tmp = { chart: c, sheetId: o.sheetId }; const d = chartData(tmp);
        if (prev) prev.destroy();
        if (!d) return;
        prev = new global.Chart(q('#chPrev'), chartConfig(tmp, d));
      }).catch(() => {});
    };
    q('#chTypes').onclick = e => { const b = e.target.closest('[data-t]'); if (!b) return; c.type = b.dataset.t; q('#chTypes').querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b)); draw(); };
    body.addEventListener('change', draw); q('#chTitle').addEventListener('input', draw);
    ui.modal({
      title: o.id ? 'Edit chart' : 'Insert chart', body, wide: true, onOpen: draw, onClose: () => { if (prev) prev.destroy(); },
      actions: [{ label: 'Cancel', value: null }, { label: o.id ? 'Save' : 'Insert', primary: true, onClick: () => { read(); if (!X.parseRef(c.src)) { ui.toast('Enter a data range like A1:D12', { type: 'error' }); return false; } onSave(Object.assign({}, c)); return true; } }]
    });
  }
  function insertChart() {
    const sh = IS.sheet; let R = IS.selRect();
    if (R.t === R.b && R.l === R.r) { const reg = IS.currentRegion(sh, R.t, R.l); if (!reg) { ui.toast('First type some data (labels + numbers), then insert a chart.'); return; } R = reg; }
    const used = IS.usedRange(sh); R = { t: R.t, l: R.l, b: Math.min(R.b, used.b), r: Math.min(R.r, used.r) };
    const src = X.numToCol(R.l) + (R.t + 1) + ':' + X.numToCol(R.r) + (R.b + 1);
    if (!IS.guardEdit(null, { structure: !!(sh.protect && sh.protect.on) })) return;
    chartDialog({ chart: { src }, sheetId: sh.id }, chart => {
      const o = { id: IS.rid('o'), type: 'chart', r: R.t, c: Math.min(sh.cols - 1, R.r + 2), dx: 0, dy: 0, w: 520, h: 310, chart };
      IS.tx('Insert chart', () => { IS.rec.meta(sh); sh.objects.push(o); });
      IS.state.selObj = o.id; renderAll();
      IS.grid.scrollIntoView(o.r, Math.min(sh.cols - 1, o.c + 3));
    });
  }
  function editChart(id) {
    const o = findObj(id); if (!o) return;
    if (!IS.guardEdit(null, { structure: !!(IS.sheet.protect && IS.sheet.protect.on) })) return;
    chartDialog(Object.assign({}, o, { sheetId: IS.sheet.id }), chart => { const sh = IS.sheet; IS.tx('Edit chart', () => { IS.rec.meta(sh); sh.objects.find(x => x.id === id).chart = chart; }); renderAll(); });
  }
  function downloadChart(id) { const ent = live.get(id); if (!ent || !ent.chart) return; const url = ent.chart.toBase64Image('image/png', 1); fetch(url).then(r => r.blob()).then(b => ui.download('chart.png', b)); }

  // ------------------------------------------------------------ images
  function shrinkImage(file, max = 1600) {
    return new Promise((resolve, reject) => {
      const rd = new FileReader();
      rd.onerror = () => reject(new Error('Could not read the picture'));
      rd.onload = () => {
        const img = new Image();
        img.onload = () => {
          let { naturalWidth: w, naturalHeight: h } = img;
          if (file.type === 'image/svg+xml' || (w <= max && h <= max && file.size < 600000)) { resolve({ src: rd.result, w, h }); return; }
          const k = Math.min(1, max / Math.max(w, h)); w = Math.round(w * k); h = Math.round(h * k);
          const cv = document.createElement('canvas'); cv.width = w; cv.height = h; cv.getContext('2d').drawImage(img, 0, 0, w, h);
          resolve({ src: cv.toDataURL(file.type === 'image/png' ? 'image/png' : 'image/jpeg', 0.88), w, h });
        };
        img.onerror = () => reject(new Error('This file is not a picture'));
        img.src = rd.result;
      };
      rd.readAsDataURL(file);
    });
  }
  async function insertImageFile(file) {
    const sh = IS.sheet; if (!IS.guardEdit(null, { structure: !!(sh.protect && sh.protect.on) })) return;
    try {
      const im = await shrinkImage(file);
      const k = Math.min(1, 360 / Math.max(im.w, 1), 260 / Math.max(im.h, 1));
      const s = IS.state.sel;
      const o = { id: IS.rid('o'), type: 'image', r: s.r, c: s.c, dx: 4, dy: 4, w: Math.round(im.w * k), h: Math.round(im.h * k), src: im.src, alt: file.name };
      IS.tx('Insert picture', () => { IS.rec.meta(sh); sh.objects.push(o); });
      IS.state.selObj = o.id; renderAll();
      ui.toast('Picture added – drag to move, drag the corner to resize.', { ms: 2500 });
    } catch (e) { ui.toast(e.message, { type: 'error' }); }
  }
  IS.insertImageFile = insertImageFile;
  function insertImage() { const inp = $('imageInput'); inp.value = ''; inp.onchange = () => { const f = inp.files[0]; if (f) insertImageFile(f); }; inp.click(); }

  // ------------------------------------------------------------ for printing / PDF
  /** Draw every object of a sheet that overlaps an area onto a print canvas. pos(r,c) gives page coordinates. */
  IS.paintObjects = async function (g, sh, colPos, rowPos, area, scale) {
    const objs = sh.objects || [];
    for (const o of objs) {
      if (o.r > area.b || o.c > area.r) continue;
      const x = colPos(o.c) + (o.dx || 0), y = rowPos(o.r) + (o.dy || 0);
      if (x === null || y === null || isNaN(x) || isNaN(y)) continue;
      if (o.type === 'image') {
        await new Promise(res => { const img = new Image(); img.onload = () => { g.drawImage(img, x, y, o.w, o.h); res(); }; img.onerror = res; img.src = o.src; });
      } else {
        try {
          await loadChart();
          const cv = document.createElement('canvas'); cv.width = Math.round(o.w * scale); cv.height = Math.round(o.h * scale);
          cv.style.width = o.w + 'px'; cv.style.height = o.h + 'px';
          const host = document.createElement('div'); host.style.cssText = 'position:fixed;left:-10000px;top:0;width:' + o.w + 'px;height:' + o.h + 'px'; host.appendChild(cv); document.body.appendChild(host);
          const d = chartData(Object.assign({}, o, { sheetId: sh.id })) || { labels: [], sets: [] };
          const ch = new global.Chart(cv, chartConfig(Object.assign({}, o, { sheetId: sh.id }), d, { print: true, fixed: true, dpr: scale }));
          g.fillStyle = '#ffffff'; g.fillRect(x, y, o.w, o.h);
          g.drawImage(cv, x, y, o.w, o.h);
          g.strokeStyle = '#d0d7d3'; g.lineWidth = 1; g.strokeRect(x + 0.5, y + 0.5, o.w - 1, o.h - 1);
          ch.destroy(); host.remove();
        } catch (e) { /* chart engine unavailable */ }
      }
    }
  };

  // ------------------------------------------------------------ wiring
  IS.on('scroll', reposition);
  IS.on('layout', reposition);
  IS.on('sheet', () => { IS.state.selObj = null; renderAll(); });
  IS.on('book', () => { for (const ent of live.values()) { if (ent.chart) ent.chart.destroy(); ent.el.remove(); } live.clear(); IS.state.selObj = null; renderAll(); });
  IS.on('change', () => renderAll());
  IS.on('recalc', refreshData);
  IS.on('theme', () => { for (const [id, ent] of live) { const o = findObj(id); if (o && o.type === 'chart') refreshChart(o, ent); } });
  IS.on('ready', () => {
    IS.grid.scroller.addEventListener('pointerdown', () => { if (IS.state.selObj) selectObj(null); }, true);
    renderAll();
  });
  Object.assign(IS.cmd, { insertChart, insertImage, editChart });
})(window);
