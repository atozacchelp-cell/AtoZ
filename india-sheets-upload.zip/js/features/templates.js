/* India Sheets – ready-made templates for Indian businesses */
(function (global) {
  'use strict';
  const IS = global.IS, ui = IS.ui, X = global.Formula, esc = ui.esc, K = IS.K;
  const INR = '"₹"#,##0.00', NUM = '#,##0.00', INT = '#,##0', DATE = 'dd-mm-yyyy', PCT = '0%';
  const GREEN = '#0f7a3d', LIGHT = '#e3f3e9', SAFFRON = '#ff9933', LINE = '#b7c4bd';
  const HEAD = { b: true, bg: GREEN, color: '#ffffff', al: 'center', va: 'middle', wrap: true };
  const BOX = { bd: { bt: 'thin', bb: 'thin', bl: 'thin', br: 'thin', c: LINE } };
  const TITLE = { b: true, fs: 16, color: GREEN };
  const today = () => X.todaySerial();
  function gstin(base14) { const CH = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'; let sum = 0; for (let i = 0; i < 14; i++) { const v = CH.indexOf(base14[i]); const p = v * (i % 2 ? 2 : 1); sum += Math.floor(p / 36) + (p % 36); } return base14 + CH[(36 - (sum % 36)) % 36]; }
  const rect = a1 => { const p = X.parseRef(a1); return { t: p.r1, l: p.c1, b: p.r2, r: p.c2 }; };

  function builder(name) {
    const sh = IS.newSheet(name);
    const b = {
      sh,
      v(a1, value, style) {
        const p = X.parseRef(a1); const key = K(p.r1, p.c1); const cell = sh.cells[key] || {};
        if (value !== undefined && value !== null && value !== '') {
          if (typeof value === 'string') {
            if (value[0] === '=') cell.v = IS.normalizeFormula(value);
            else { const e = IS.parseEntry(value, cell); cell.v = e.v; if (e.t) cell.t = e.t; if (e.nf && !(style && style.nf)) cell.s = Object.assign({}, cell.s, { nf: e.nf }); }
          } else cell.v = value;
        }
        if (style) cell.s = Object.assign({}, cell.s, style);
        sh.cells[key] = cell; return b;
      },
      row(a1, values, style) { const p = X.parseRef(a1); values.forEach((v, i) => { if (v !== undefined) b.v(X.numToCol(p.c1 + i) + (p.r1 + 1), v, typeof style === 'function' ? style(i) : style); }); return b; },
      style(range, style) { const g = rect(range); for (let r = g.t; r <= g.b; r++) for (let c = g.l; c <= g.r; c++) { const key = K(r, c); const cell = sh.cells[key] || {}; const s = typeof style === 'function' ? style(r - g.t, c - g.l) : style; if (s) cell.s = Object.assign({}, cell.s, s); sh.cells[key] = cell; } return b; },
      merge(range, value, style) { const g = rect(range); sh.merges.push({ r: g.t, c: g.l, r2: g.b, c2: g.r }); if (value !== undefined) b.v(X.numToCol(g.l) + (g.t + 1), value, style); return b; },
      widths(arr) { arr.forEach((w, i) => { if (w) sh.colW[i] = w; }); return b; },
      height(row1, h) { sh.rowH[row1 - 1] = h; return b; },
      dv(range, rule) { sh.dv.push(Object.assign({ id: IS.rid('dv'), ranges: [rect(range)], strict: true, arrow: true, allowBlank: true }, rule)); return b; },
      cf(range, rule) { sh.cf.push(Object.assign({ id: IS.rid('cf'), ranges: [rect(range)] }, rule)); return b; },
      freeze(r, c) { sh.freezeR = r || 0; sh.freezeC = c || 0; return b; },
      print(p) { sh.print = Object.assign({ paper: 'A4', orient: 'portrait', fit: 'width', margins: 'narrow', grid: false, headings: false, repeat: true, center: true, header: '', footer: 'Page {page} of {pages}' }, p); return b; },
      filter(range) { const g = rect(range); sh.filter = { t: g.t, l: g.l, b: g.b, r: g.r, crit: {}, hidden: [] }; return b; },
      chart(a1, w, h, chart) { const p = X.parseRef(a1); sh.objects.push({ id: IS.rid('o'), type: 'chart', r: p.r1, c: p.c1, dx: 0, dy: 0, w, h, chart }); return b; },
      rows(n) { sh.rows = Math.max(sh.rows, n); return b; }
    };
    return b;
  }
  const book = (name, sheets, names) => ({ name, version: 2, sheets, names: names || {}, active: 0 });

  // ---------------------------------------------------------------- GST tax invoice
  function gstInvoice() {
    const b = builder('Invoice');
    const seller = gstin('24ABCDE1234F1Z'), buyer = gstin('24AAACM4567K1Z');
    b.widths([64, 186, 66, 50, 54, 102, 92, 50, 84, 104]);
    b.merge('A1:J1', 'TAX INVOICE', { b: true, fs: 16, al: 'center', va: 'middle', bg: GREEN, color: '#ffffff' }).height(1, 34);
    b.merge('A2:E2', 'Your Company Name', { b: true, fs: 14 }).merge('F2:J2', 'ORIGINAL FOR RECIPIENT', { al: 'right', color: '#5f6b65', fs: 8 });
    b.merge('A3:E3', 'Shop No. 12, Industrial Estate, Ahmedabad – 380 001', { color: '#33403a' });
    b.v('A4', 'GSTIN', { b: true }).merge('B4:E4', seller, { b: true });
    b.v('A5', 'Phone', { b: true }).merge('B5:E5', "'+91 98765 43210");
    b.v('F3', 'Invoice No.', { b: true }).merge('G3:J3', 'INV/2026-27/001', { b: true });
    b.v('F4', 'Invoice Date', { b: true }).merge('G4:J4', today(), { nf: DATE, al: 'left' });
    b.v('F5', 'Due Date', { b: true }).merge('G5:J5', '=G4+15', { nf: DATE, al: 'left' });
    b.v('F6', 'Place of Supply', { b: true }).merge('G6:J6', '=IF(B9="","",STATENAME(LEFT(B9,2))&" ("&LEFT(B9,2)&")")');
    b.merge('A7:E7', 'BILL TO', { b: true, bg: LIGHT, color: GREEN }).merge('F7:J7', 'SHIP TO', { b: true, bg: LIGHT, color: GREEN });
    b.v('A8', 'Name', { b: true }).merge('B8:E8', 'Customer Pvt Ltd').v('F8', 'Name', { b: true }).merge('G8:J8', '=B8');
    b.v('A9', 'GSTIN', { b: true }).merge('B9:E9', buyer).v('F9', 'GSTIN', { b: true }).merge('G9:J9', '=B9');
    b.v('A10', 'Address', { b: true }).merge('B10:E10', 'Plot 45, GIDC, Vatva, Ahmedabad').v('F10', 'Address', { b: true }).merge('G10:J10', '=B10');
    b.v('A11', 'State', { b: true }).merge('B11:E11', '=IF(B9="","",STATENAME(LEFT(B9,2)))').v('F11', 'Supply type', { b: true }).merge('G11:J11', '=IF(B9="","",IF(LEFT(B4,2)=LEFT(B9,2),"Intra-state (CGST + SGST)","Inter-state (IGST)"))', { color: GREEN, b: true });
    b.row('A13', ['#', 'Description of goods / services', 'HSN/SAC', 'Qty', 'Unit', 'Rate (₹)', 'Taxable (₹)', 'GST %', 'GST (₹)', 'Amount (₹)'], HEAD).height(13, 32);
    const items = [['MS Round Bar 12 mm', '7214', 500, 'Kg', 62.5, 18], ['MS Plate 10 mm', '7208', 1200, 'Kg', 68, 18], ['Cutting & labour charges', '9988', 1, 'Nos', 2500, 18]];
    for (let i = 0; i < 12; i++) {
      const r = 14 + i, it = items[i];
      if (it) b.row('B' + r, [it[0], "'" + it[1], it[2], it[3], it[4], undefined, it[5]]);
      b.v('A' + r, '=IF(B' + r + '="","",ROW()-13)', { al: 'center' });
      b.v('G' + r, '=IF(OR(D' + r + '="",F' + r + '=""),"",ROUND(D' + r + '*F' + r + ',2))', { nf: NUM });
      b.v('I' + r, '=IF(G' + r + '="","",ROUND(G' + r + '*H' + r + '/100,2))', { nf: NUM });
      b.v('J' + r, '=IF(G' + r + '="","",G' + r + '+I' + r + ')', { nf: NUM, b: true });
      b.style('D' + r + ':D' + r, { nf: '#,##0.###' }).style('F' + r + ':F' + r, { nf: NUM }).style('H' + r + ':H' + r, { al: 'center' });
    }
    b.style('A13:J25', BOX);
    b.dv('E14:E25', { type: 'list', list: ['Nos', 'Kg', 'MT', 'Qtl', 'Mtr', 'Ft', 'Pcs', 'Box', 'Set', 'Ltr', 'Hrs'] });
    b.dv('H14:H25', { type: 'list', list: [0, 0.25, 3, 5, 12, 18, 28, 40], msg: 'Choose the GST rate' });
    b.dv('B4:E4', { type: 'gstin', strict: false, arrow: false }).dv('B9:E9', { type: 'gstin', strict: false, arrow: false });
    const T = (row, label, f, s) => { b.merge('F' + row + ':I' + row, label, Object.assign({ al: 'right', b: true }, s)); b.v('J' + row, f, Object.assign({ nf: INR, b: true }, s)); };
    T(27, 'Taxable value', '=SUM(G14:G25)');
    T(28, 'CGST', '=IF(LEFT(B4,2)=LEFT(B9,2),ROUND(SUM(I14:I25)/2,2),0)');
    T(29, 'SGST', '=IF(LEFT(B4,2)=LEFT(B9,2),ROUND(SUM(I14:I25)/2,2),0)');
    T(30, 'IGST', '=IF(LEFT(B4,2)<>LEFT(B9,2),SUM(I14:I25),0)');
    T(31, 'Round off', '=ROUND(SUM(J27:J30),0)-SUM(J27:J30)');
    T(32, 'GRAND TOTAL', '=SUM(J27:J31)', { bg: GREEN, color: '#ffffff', fs: 12 });
    b.style('F27:J31', { bd: { bb: 'thin', c: LINE } });
    b.v('A27', 'Amount in words', { b: true, color: GREEN });
    b.merge('A28:E29', '=RUPEEWORDS(J32)', { wrap: true, va: 'top', b: true });
    b.merge('A30:E30', '=HINDIWORDS(J32)', { wrap: true, color: '#5f6b65', fs: 9 });
    b.v('A33', 'Bank details', { b: true, color: GREEN });
    b.merge('A34:E34', 'Bank: State Bank of India · A/c No: 12345678901');
    b.merge('A35:E35', 'IFSC: SBIN0001234 · Branch: Ahmedabad Main');
    b.v('A36', 'UPI ID', { b: true }).merge('B36:E36', 'yourshop@okaxis');
    b.v('A38', 'Terms & conditions', { b: true, color: GREEN });
    b.merge('A39:E42', '1. Goods once sold will not be taken back.\n2. Interest @18% p.a. will be charged if payment is not made by the due date.\n3. Subject to Ahmedabad jurisdiction.', { wrap: true, va: 'top', fs: 9, color: '#33403a' });
    b.merge('G34:J34', 'Scan & pay with any UPI app', { al: 'center', fs: 9, color: '#5f6b65' });
    b.merge('G35:J41', '=UPIQR(B36,A2,J32,G3)');
    b.merge('G43:J43', '="For "&A2', { al: 'center', b: true });
    b.merge('G46:J46', 'Authorised Signatory', { al: 'center', bd: { bt: 'thin', c: '#33403a' } });
    b.merge('A48:J48', 'This is a computer generated invoice.', { al: 'center', fs: 8, color: '#8a958f' });
    b.print({ footer: '' });
    b.sh.showGrid = false;
    return book('GST Tax Invoice', [b.sh]);
  }

  // ---------------------------------------------------------------- quotation
  function quotation() {
    const b = builder('Quotation');
    b.widths([34, 260, 70, 60, 90, 110]);
    b.merge('A1:F1', 'QUOTATION', { b: true, fs: 16, al: 'center', bg: SAFFRON, color: '#ffffff' }).height(1, 32);
    b.merge('A2:C2', 'Your Company Name', { b: true, fs: 13 }).v('D2', 'Quote No.', { b: true }).merge('E2:F2', 'QT-2026-014');
    b.merge('A3:C3', 'Address · Phone · GSTIN').v('D3', 'Date', { b: true }).merge('E3:F3', today(), { nf: DATE, al: 'left' });
    b.v('D4', 'Valid till', { b: true }).merge('E4:F4', '=E3+30', { nf: DATE, al: 'left' });
    b.v('A5', 'To', { b: true }).merge('B5:C5', 'Customer name & address');
    b.row('A7', ['#', 'Item / description', 'Qty', 'Unit', 'Rate (₹)', 'Amount (₹)'], HEAD);
    const items = [['MS Angle 50×50×5 mm', 300, 'Kg', 66], ['SS 304 Sheet 2 mm', 150, 'Kg', 245], ['Transport', 1, 'Trip', 3500]];
    for (let i = 0; i < 10; i++) {
      const r = 8 + i, it = items[i];
      if (it) b.row('B' + r, it);
      b.v('A' + r, '=IF(B' + r + '="","",ROW()-7)', { al: 'center' });
      b.v('F' + r, '=IF(OR(C' + r + '="",E' + r + '=""),"",C' + r + '*E' + r + ')', { nf: NUM });
      b.style('E' + r + ':E' + r, { nf: NUM });
    }
    b.style('A7:F17', BOX);
    b.merge('D19:E19', 'Sub-total', { al: 'right', b: true }).v('F19', '=SUM(F8:F17)', { nf: INR });
    b.merge('D20:E20', 'GST @ 18%', { al: 'right', b: true }).v('F20', '=GST(F19,18)', { nf: INR });
    b.merge('D21:E21', 'Total', { al: 'right', b: true, bg: LIGHT }).v('F21', '=F19+F20', { nf: INR, b: true, bg: LIGHT });
    b.merge('A19:C20', '=RUPEEWORDS(F21)', { wrap: true, va: 'top', i: true });
    b.v('A23', 'Terms', { b: true }).merge('A24:F26', '• Prices are ex-works. • Delivery within 7 days of order confirmation. • 50% advance with purchase order.', { wrap: true, va: 'top', color: '#33403a' });
    b.merge('D29:F29', '="For "&A2', { al: 'center', b: true });
    b.print({}); b.sh.showGrid = false;
    return book('Quotation', [b.sh]);
  }

  // ---------------------------------------------------------------- stock register
  function stockRegister() {
    const b = builder('Stock');
    b.widths([80, 220, 60, 90, 80, 80, 100, 90, 90, 90, 120]);
    b.merge('A1:K1', 'Stock Register', TITLE).v('A2', 'Updated', { color: '#5f6b65' }).v('B2', '=TODAY()', { nf: 'd mmm yyyy', al: 'left', color: '#5f6b65' });
    b.row('A4', ['Item code', 'Item name', 'Unit', 'Opening stock', 'Stock in', 'Stock out', 'Closing stock', 'Re-order level', 'Status', 'Rate (₹)', 'Stock value (₹)'], HEAD).height(4, 36);
    const items = [['MS-RB-08', 'MS Round Bar 8 mm', 'Kg', 1200, 800, 950, 500, 61], ['MS-RB-12', 'MS Round Bar 12 mm', 'Kg', 2500, 1000, 3100, 800, 62.5], ['MS-PL-06', 'MS Plate 6 mm', 'Kg', 900, 0, 650, 400, 67], ['MS-PL-10', 'MS Plate 10 mm', 'Kg', 1800, 1500, 1200, 600, 68], ['MS-AN-50', 'MS Angle 50×50×5', 'Kg', 700, 300, 820, 300, 66], ['MS-CH-100', 'MS Channel 100×50', 'Kg', 1100, 0, 300, 400, 69], ['SS-SH-2', 'SS 304 Sheet 2 mm', 'Kg', 350, 200, 120, 150, 245], ['SS-PI-25', 'SS 304 Pipe 25 NB', 'Mtr', 420, 0, 390, 100, 520], ['GI-PI-25', 'GI Pipe 25 NB', 'Mtr', 600, 600, 450, 200, 210], ['AL-SH-1', 'Aluminium Sheet 1 mm', 'Kg', 260, 100, 300, 80, 310], ['CU-WR-2', 'Copper Wire 2 mm', 'Kg', 90, 50, 70, 40, 860], ['HB-12', 'Hex Bolt M12×50', 'Pcs', 5000, 2000, 6100, 1500, 9.5]];
    items.forEach((it, i) => {
      const r = 5 + i;
      b.row('A' + r, [it[0], it[1], it[2], it[3], it[4], it[5]]);
      b.v('G' + r, '=D' + r + '+E' + r + '-F' + r, { nf: INT, b: true });
      b.v('H' + r, it[6], { nf: INT });
      b.v('I' + r, '=IF(G' + r + '<=H' + r + ',"Re-order","OK")', { al: 'center' });
      b.v('J' + r, it[7], { nf: NUM });
      b.v('K' + r, '=G' + r + '*J' + r, { nf: INR });
      b.style('D' + r + ':F' + r, { nf: INT });
    });
    const last = 4 + items.length;
    b.v('B' + (last + 2), 'Total stock value (visible rows)', { b: true }).v('K' + (last + 2), '=SUBTOTAL(9,K5:K' + last + ')', { nf: INR, b: true, bd: { bt: 'thin', bb: 'double', c: GREEN } });
    b.style('A4:K' + last, BOX);
    b.cf('I5:I' + last, { type: 'text', op: 'exact', text: 'Re-order', style: { bg: '#ffc7ce', color: '#9c0006', b: true } });
    b.cf('I5:I' + last, { type: 'text', op: 'exact', text: 'OK', style: { color: '#2e7d32' } });
    b.cf('G5:G' + last, { type: 'bar', color: '#4a86e8' });
    b.filter('A4:K' + last).freeze(4, 2);
    // chart data: item names + closing stock picked with one dynamic-array formula
    b.v('N22', 'Chart data (auto)', { color: '#8a958f', fs: 8 });
    b.v('N23', '=CHOOSECOLS(B4:G' + last + ',1,6)', { color: '#8a958f', fs: 8 });
    b.chart('M4', 480, 300, { src: 'N23:O' + (23 + items.length), type: 'bar', title: 'Closing stock by item', legend: 'none' });
    b.print({ orient: 'landscape' });
    return book('Stock Register', [b.sh]);
  }

  // ---------------------------------------------------------------- sales register with GST summary
  function salesRegister() {
    const s = builder('Sales');
    s.widths([90, 110, 190, 150, 90, 110, 60, 90, 90, 90, 120]);
    s.merge('A1:K1', 'Sales Register', TITLE);
    s.row('A3', ['Date', 'Invoice no.', 'Customer', 'GSTIN', 'Supply', 'Taxable (₹)', 'GST %', 'CGST', 'SGST', 'IGST', 'Invoice total'], HEAD).height(3, 32);
    const y = new Date().getFullYear(), fyStart = new Date().getMonth() >= 3 ? y : y - 1;
    const rows = [[1, 4, 'Customer Pvt Ltd', '24AAACM4567K1Z', 'Intra', 45000, 18], [12, 4, 'Shree Engineering', '27AABCS1234L1Z', 'Inter', 128000, 18], [3, 5, 'Patel Fabricators', '24AAFFP8888Q1Z', 'Intra', 76500, 18], [20, 5, 'Sai Traders', '', 'Intra', 18200, 5], [9, 6, 'Om Industries', '29AAACO7777R1Z', 'Inter', 210000, 18], [25, 6, 'Customer Pvt Ltd', '24AAACM4567K1Z', 'Intra', 33400, 18], [5, 7, 'Shree Engineering', '27AABCS1234L1Z', 'Inter', 99000, 18], [18, 7, 'Patel Fabricators', '24AAFFP8888Q1Z', 'Intra', 54000, 12]];
    rows.forEach((d, i) => {
      const r = 4 + i;
      s.v('A' + r, X.toSerial(fyStart, d[1], d[0]), { nf: DATE });
      s.row('B' + r, ['INV/' + fyStart + '-' + String((fyStart + 1) % 100).padStart(2, '0') + '/' + String(i + 1).padStart(3, '0'), d[2], d[3] ? gstin(d[3]) : '', d[4], d[5], d[6]]);
      s.style('F' + r + ':F' + r, { nf: NUM });
      s.v('H' + r, '=IF(E' + r + '="Intra",ROUND(F' + r + '*G' + r + '/200,2),0)', { nf: NUM });
      s.v('I' + r, '=H' + r, { nf: NUM });
      s.v('J' + r, '=IF(E' + r + '="Inter",ROUND(F' + r + '*G' + r + '/100,2),0)', { nf: NUM });
      s.v('K' + r, '=F' + r + '+H' + r + '+I' + r + '+J' + r, { nf: INR, b: true });
    });
    const last = 3 + rows.length;
    s.style('A3:K' + (last + 40), (r) => (r ? BOX : null));
    for (let r = last + 1; r <= last + 40; r++) { s.v('H' + r, '=IF(F' + r + '="","",IF(E' + r + '="Intra",ROUND(F' + r + '*G' + r + '/200,2),0))', { nf: NUM }); s.v('I' + r, '=H' + r, { nf: NUM }); s.v('J' + r, '=IF(F' + r + '="","",IF(E' + r + '="Inter",ROUND(F' + r + '*G' + r + '/100,2),0))', { nf: NUM }); s.v('K' + r, '=IF(F' + r + '="","",F' + r + '+H' + r + '+I' + r + '+J' + r + ')', { nf: INR }); s.style('A' + r + ':A' + r, { nf: DATE }).style('F' + r + ':F' + r, { nf: NUM }); }
    s.dv('E4:E' + (last + 40), { type: 'list', list: ['Intra', 'Inter'], msg: 'Intra = same state (CGST+SGST), Inter = other state (IGST)' });
    s.dv('G4:G' + (last + 40), { type: 'list', list: [0, 5, 12, 18, 28, 40] });
    s.dv('D4:D' + (last + 40), { type: 'gstin', strict: false, arrow: false });
    s.filter('A3:K' + (last + 40)).freeze(3, 0);
    // summary
    const g = builder('GST Summary');
    g.widths([120, 130, 110, 110, 110, 140]);
    g.merge('A1:F1', '="GST Summary – FY "&FY(TODAY())', TITLE);
    g.row('A3', ['Month', 'Taxable value', 'CGST', 'SGST', 'IGST', 'Total with tax'], HEAD);
    for (let i = 0; i < 12; i++) {
      const r = 4 + i;
      const mon = 4 + i; // April … March of the financial year
      g.v('A' + r, mon > 12 ? X.toSerial(fyStart + 1, mon - 12, 1) : X.toSerial(fyStart, mon, 1), { nf: 'mmm yyyy', al: 'left' });
      const crit = 'Sales!$A$4:$A$1000,">="&$A' + r + ',Sales!$A$4:$A$1000,"<="&EOMONTH($A' + r + ',0)';
      g.v('B' + r, '=SUMIFS(Sales!$F$4:$F$1000,' + crit + ')', { nf: NUM });
      g.v('C' + r, '=SUMIFS(Sales!$H$4:$H$1000,' + crit + ')', { nf: NUM });
      g.v('D' + r, '=SUMIFS(Sales!$I$4:$I$1000,' + crit + ')', { nf: NUM });
      g.v('E' + r, '=SUMIFS(Sales!$J$4:$J$1000,' + crit + ')', { nf: NUM });
      g.v('F' + r, '=SUM(B' + r + ':E' + r + ')', { nf: INR, b: true });
    }
    g.v('A16', 'Total', { b: true }); ['B', 'C', 'D', 'E', 'F'].forEach(c => g.v(c + '16', '=SUM(' + c + '4:' + c + '15)', { nf: c === 'F' ? INR : NUM, b: true, bd: { bt: 'thin', bb: 'double', c: GREEN } }));
    g.style('A3:F15', BOX);
    g.row('A19', ['GST rate', 'Taxable value', 'Tax amount'], HEAD);
    [0, 5, 12, 18, 28, 40].forEach((rt, i) => { const r = 20 + i; g.v('A' + r, rt / 100, { nf: PCT, al: 'center' }); g.v('B' + r, '=SUMIFS(Sales!$F$4:$F$1000,Sales!$G$4:$G$1000,' + rt + ')', { nf: NUM }); g.v('C' + r, '=SUMIFS(Sales!$H$4:$H$1000,Sales!$G$4:$G$1000,' + rt + ')+SUMIFS(Sales!$I$4:$I$1000,Sales!$G$4:$G$1000,' + rt + ')+SUMIFS(Sales!$J$4:$J$1000,Sales!$G$4:$G$1000,' + rt + ')', { nf: NUM }); });
    g.style('A19:C25', BOX);
    g.chart('H3', 520, 300, { src: 'A3:B15', type: 'column', title: 'Monthly sales (taxable)', legend: 'none', showValues: false });
    return book('Sales Register & GST Summary', [s.sh, g.sh]);
  }

  // ---------------------------------------------------------------- expenses
  function expenses() {
    const b = builder('Expenses');
    b.widths([95, 140, 230, 110, 110]);
    b.merge('A1:E1', 'Expense Tracker', TITLE);
    b.row('A3', ['Date', 'Category', 'Description', 'Paid by', 'Amount (₹)'], HEAD);
    const cats = ['Rent', 'Salary', 'Electricity', 'Transport', 'Raw material', 'Office', 'Food', 'Phone & internet', 'Repairs', 'Other'];
    const y = new Date().getFullYear(), m = new Date().getMonth() + 1;
    const data = [[1, 'Rent', 'Shop rent', 'Bank', 25000], [2, 'Electricity', 'Electricity bill', 'UPI', 6840], [3, 'Transport', 'Tempo for delivery', 'Cash', 1800], [5, 'Raw material', 'Welding rods', 'UPI', 4200], [7, 'Phone & internet', 'Broadband + mobile', 'Card', 1499], [9, 'Food', 'Staff tea & snacks', 'Cash', 950], [12, 'Repairs', 'Cutting machine service', 'UPI', 3500], [15, 'Salary', 'Helper salary', 'Bank', 14000], [18, 'Office', 'Stationery & printer ink', 'Cash', 760], [21, 'Transport', 'Courier', 'UPI', 420]];
    data.forEach((d, i) => { const r = 4 + i; b.v('A' + r, X.toSerial(y, m, d[0]), { nf: DATE }); b.row('B' + r, [d[1], d[2], d[3], d[4]]); b.style('E' + r + ':E' + r, { nf: NUM }); });
    for (let r = 14; r <= 200; r++) b.style('A' + r + ':A' + r, { nf: DATE }).style('E' + r + ':E' + r, { nf: NUM });
    b.dv('B4:B200', { type: 'list', list: cats }).dv('D4:D200', { type: 'list', list: ['Cash', 'UPI', 'Card', 'Bank', 'Cheque'] });
    b.style('A3:E13', BOX).filter('A3:E200').freeze(3, 0);
    b.row('G3', ['Category', 'Spent (₹)', 'Budget (₹)', 'Left (₹)'], HEAD);
    const budgets = [25000, 15000, 7000, 3000, 6000, 1500, 1500, 1500, 3000, 2000];
    cats.forEach((c, i) => { const r = 4 + i; b.v('G' + r, c); b.v('H' + r, '=SUMIF($B$4:$B$200,G' + r + ',$E$4:$E$200)', { nf: NUM }); b.v('I' + r, budgets[i], { nf: NUM }); b.v('J' + r, '=I' + r + '-H' + r, { nf: NUM }); });
    b.v('G14', 'Total', { b: true }).v('H14', '=SUM(H4:H13)', { nf: INR, b: true }).v('I14', '=SUM(I4:I13)', { nf: INR, b: true }).v('J14', '=I14-H14', { nf: INR, b: true });
    b.style('G3:J14', BOX).widths([95, 140, 230, 110, 110, 20, 150, 110, 110, 110]);
    b.cf('J4:J14', { type: 'cell', op: 'lt', v1: '0', style: { bg: '#ffc7ce', color: '#9c0006', b: true } });
    b.cf('H4:H13', { type: 'bar', color: '#fb8c00' });
    b.chart('G17', 460, 300, { src: 'G3:H13', type: 'doughnut', title: 'Where the money went', legend: 'right' });
    return book('Expense Tracker', [b.sh]);
  }

  // ---------------------------------------------------------------- salary sheet
  function salary() {
    const b = builder('Salary');
    b.widths([140, 110, 60, 60, 90, 90, 90, 100, 80, 70, 70, 70, 100, 110, 260]);
    b.merge('A1:O1', '="Salary Sheet – "&TEXT(TODAY(),"mmmm yyyy")', TITLE);
    b.merge('A2:O2', 'Check the latest PF (12% of basic up to ₹15,000), ESI (0.75% when gross ≤ ₹21,000) and Professional Tax rules for your state before paying.', { color: '#8a5a00', fs: 9, wrap: true }).height(2, 30);
    b.row('A4', ['Employee', 'Designation', 'Days in month', 'Days present', 'Basic (₹)', 'HRA (₹)', 'Other (₹)', 'Gross earned', 'PF (12%)', 'ESI', 'Prof. tax', 'TDS / adv.', 'Deductions', 'Net pay (₹)', 'Net pay in words'], HEAD).height(4, 40);
    const emp = [['Ramesh Patel', 'Supervisor', 26, 18000, 7200, 2000, 0], ['Suresh Kumar', 'Welder', 24, 13000, 5200, 1000, 0], ['Anita Sharma', 'Accountant', 26, 16000, 6400, 1500, 500], ['Mohammed Irfan', 'Helper', 22, 9500, 3800, 500, 0], ['Priya Desai', 'Sales', 25, 15000, 6000, 3000, 1000]];
    emp.forEach((e, i) => {
      const r = 5 + i;
      b.row('A' + r, [e[0], e[1], '=DAY(EOMONTH(TODAY(),0))', e[2], e[3], e[4], e[5]]);
      b.style('E' + r + ':G' + r, { nf: INT });
      b.v('H' + r, '=ROUND((E' + r + '+F' + r + '+G' + r + ')*D' + r + '/C' + r + ',0)', { nf: INT, b: true });
      b.v('I' + r, '=ROUND(MIN(E' + r + '*D' + r + '/C' + r + ',15000)*12%,0)', { nf: INT });
      b.v('J' + r, '=IF(H' + r + '<=21000,ROUNDUP(H' + r + '*0.75%,0),0)', { nf: INT });
      b.v('K' + r, '=IF(H' + r + '>=12000,200,0)', { nf: INT });
      b.v('L' + r, e[6], { nf: INT });
      b.v('M' + r, '=SUM(I' + r + ':L' + r + ')', { nf: INT });
      b.v('N' + r, '=H' + r + '-M' + r, { nf: INR, b: true, bg: LIGHT });
      b.v('O' + r, '=RUPEEWORDS(N' + r + ')', { fs: 9, color: '#33403a' });
    });
    const last = 4 + emp.length;
    b.v('A' + (last + 1), 'Total', { b: true });
    ['E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N'].forEach(c => b.v(c + (last + 1), '=SUM(' + c + '5:' + c + last + ')', { nf: c === 'N' ? INR : INT, b: true, bd: { bt: 'thin', bb: 'double', c: GREEN } }));
    b.style('A4:O' + last, BOX).freeze(4, 1);
    b.dv('D5:D' + last, { type: 'number', op: 'between', v1: 0, v2: 31, msg: 'Days present must be between 0 and 31' });
    b.print({ orient: 'landscape' });
    return book('Salary Sheet', [b.sh]);
  }

  // ---------------------------------------------------------------- EMI schedule (dynamic arrays)
  function emi() {
    const b = builder('Loan EMI');
    b.widths([200, 130, 20, 80, 110, 120, 120, 120, 130]);
    b.merge('A1:I1', 'Loan EMI Calculator & Repayment Schedule', TITLE);
    b.v('A3', 'Loan amount (₹)', { b: true }).v('B3', 1000000, { nf: INR, bg: '#fff8e1' });
    b.v('A4', 'Interest rate (% per year)', { b: true }).v('B4', 9.5, { nf: '0.00', bg: '#fff8e1' });
    b.v('A5', 'Tenure (months)', { b: true }).v('B5', 60, { nf: INT, bg: '#fff8e1' });
    b.v('A6', 'First EMI date', { b: true }).v('B6', X.F.EOMONTH([today(), 0]) + 5, { nf: DATE, bg: '#fff8e1' });
    b.v('A8', 'Monthly EMI', { b: true }).v('B8', '=ROUND(EMI(B3,B4,B5),0)', { nf: INR, b: true, bg: LIGHT, fs: 12 });
    b.v('A9', 'Total interest', { b: true }).v('B9', '=B8*B5-B3', { nf: INR });
    b.v('A10', 'Total payment', { b: true }).v('B10', '=B8*B5', { nf: INR });
    b.v('A11', 'EMI in words', { b: true, va: 'top' }).merge('B11:B12', '=RUPEEWORDS(B8)', { fs: 9, color: '#33403a', wrap: true, va: 'top' });
    b.merge('A13:B14', 'Change the yellow cells – the whole schedule on the right resizes automatically (dynamic array formulas).', { wrap: true, fs: 9, color: '#5f6b65', va: 'top' });
    b.row('D3', ['#', 'Due date', 'EMI (₹)', 'Interest (₹)', 'Principal (₹)', 'Balance (₹)'], HEAD);
    b.v('D4', '=SEQUENCE(B5)', { al: 'center' });
    b.v('E4', '=EDATE(B6,SEQUENCE(B5)-1)', { nf: DATE });
    b.v('F4', '=SEQUENCE(B5,1,-PMT(B4/1200,B5,B3),0)', { nf: NUM });
    b.v('G4', '=-IPMT(B4/1200,SEQUENCE(B5),B5,B3)', { nf: NUM });
    b.v('H4', '=-PPMT(B4/1200,SEQUENCE(B5),B5,B3)', { nf: NUM });
    b.v('I4', '=ROUND(FV(B4/1200,SEQUENCE(B5),PMT(B4/1200,B5,-B3),-B3),2)', { nf: NUM });
    for (let r = 5; r <= 363; r++) { b.style('E' + r + ':E' + r, { nf: DATE }); b.style('F' + r + ':I' + r, { nf: NUM }); b.style('D' + r + ':D' + r, { al: 'center' }); }
    b.cf('I4:I363', { type: 'bar', color: '#2e7d32' });
    b.freeze(3, 0).rows(1000);
    b.v('A20', 'Principal'); b.v('B20', '=B3', { nf: INR }); b.v('A21', 'Interest'); b.v('B21', '=B9', { nf: INR });
    b.chart('A23', 300, 230, { src: 'A20:B21', type: 'pie', title: 'Interest vs principal', legend: 'bottom' });
    return book('Loan EMI Schedule', [b.sh]);
  }

  // ---------------------------------------------------------------- attendance
  function attendance() {
    const b = builder('Attendance');
    const y = new Date().getFullYear(), m = new Date().getMonth() + 1;
    b.widths([150].concat(Array(31).fill(30)).concat([60, 60, 60, 60]));
    b.merge('A1:J1', 'Attendance Register', TITLE);
    b.v('A2', 'Month', { b: true }).v('B2', X.toSerial(y, m, 1), { nf: 'mmmm yyyy', al: 'left', b: true, bg: '#fff8e1' }).merge('B2:F2');
    b.v('A4', 'Employee', HEAD); b.v('A5', 'Day', { b: true, al: 'center', bg: LIGHT });
    for (let d = 1; d <= 31; d++) {
      const col = X.numToCol(d);
      b.v(col + '4', '=IF(' + d + '>DAY(EOMONTH($B$2,0)),"",' + d + ')', Object.assign({}, HEAD, { fs: 9 }));
      b.v(col + '5', '=IF(' + col + '4="","",LEFT(TEXT($B$2+' + (d - 1) + ',"ddd"),2))', { al: 'center', fs: 8, bg: LIGHT, color: '#5f6b65' });
    }
    const tot = X.numToCol(32), ab = X.numToCol(33), lv = X.numToCol(34), pay = X.numToCol(35);
    b.v(tot + '4', 'Present', HEAD).v(ab + '4', 'Absent', HEAD).v(lv + '4', 'Leave', HEAD).v(pay + '4', 'Paid days', HEAD);
    const people = ['Ramesh Patel', 'Suresh Kumar', 'Anita Sharma', 'Mohammed Irfan', 'Priya Desai', 'Vikram Singh'];
    const marks = 'PPPPPAPPPPPPWPPPPHPPPPPPLPPPPPP';
    people.forEach((p, i) => {
      const r = 6 + i; b.v('A' + r, p);
      for (let d = 1; d <= 31; d++) { const ch = marks[(d + i * 3) % marks.length]; b.v(X.numToCol(d) + r, ch === 'W' ? 'WO' : ch, { al: 'center' }); }
      const rg = 'B' + r + ':AF' + r;
      b.v(tot + r, '=COUNTIF(' + rg + ',"P")+COUNTIF(' + rg + ',"H")*0.5', { al: 'center', b: true });
      b.v(ab + r, '=COUNTIF(' + rg + ',"A")', { al: 'center' });
      b.v(lv + r, '=COUNTIF(' + rg + ',"L")', { al: 'center' });
      b.v(pay + r, '=' + tot + r + '+' + lv + r + '+COUNTIF(' + rg + ',"WO")', { al: 'center', b: true, bg: LIGHT });
    });
    const last = 5 + people.length;
    b.style('A4:' + pay + last, BOX);
    b.dv('B6:AF' + (last + 20), { type: 'list', list: ['P', 'A', 'H', 'L', 'WO'], arrow: false, msg: 'P = present, A = absent, H = half day, L = leave, WO = weekly off' });
    b.cf('B6:AF' + (last + 20), { type: 'text', op: 'exact', text: 'A', style: { bg: '#ffc7ce', color: '#9c0006', b: true } });
    b.cf('B6:AF' + (last + 20), { type: 'text', op: 'exact', text: 'L', style: { bg: '#ffeb9c', color: '#9c5700' } });
    b.cf('B6:AF' + (last + 20), { type: 'text', op: 'exact', text: 'H', style: { bg: '#cfe2f3', color: '#1a3c8f' } });
    b.cf('B6:AF' + (last + 20), { type: 'text', op: 'exact', text: 'WO', style: { color: '#9aa3a0' } });
    b.cf('B6:AF' + (last + 20), { type: 'text', op: 'exact', text: 'P', style: { color: '#2e7d32' } });
    b.merge('A' + (last + 2) + ':Q' + (last + 2), 'P = Present · A = Absent · H = Half day · L = Leave · WO = Weekly off', { color: '#5f6b65', fs: 9 });
    b.freeze(5, 1).print({ orient: 'landscape', fit: 'page' });
    return book('Attendance Register', [b.sh]);
  }

  // ---------------------------------------------------------------- cash book
  function cashBook() {
    const b = builder('Cash Book');
    b.widths([95, 260, 90, 110, 110, 130]);
    b.merge('A1:F1', 'Cash Book', TITLE);
    b.row('A3', ['Date', 'Particulars', 'Voucher', 'Receipt (₹)', 'Payment (₹)', 'Balance (₹)'], HEAD);
    const y = new Date().getFullYear(), m = new Date().getMonth() + 1;
    b.v('A4', X.toSerial(y, m, 1), { nf: DATE }).v('B4', 'Opening balance', { b: true }).v('D4', 25000, { nf: NUM }).v('F4', '=D4-E4', { nf: INR, b: true });
    const rows = [[2, 'Cash sale – counter', 'R-101', 8600, 0], [3, 'Tea & snacks', 'P-201', 0, 450], [5, 'Received from Sai Traders', 'R-102', 12000, 0], [8, 'Courier charges', 'P-202', 0, 380], [10, 'Deposited in bank', 'C-01', 0, 30000], [14, 'Cash sale – counter', 'R-103', 5400, 0]];
    rows.forEach((d, i) => { const r = 5 + i; b.v('A' + r, X.toSerial(y, m, d[0]), { nf: DATE }); b.row('B' + r, [d[1], d[2], d[3] || undefined, d[4] || undefined]); b.style('D' + r + ':E' + r, { nf: NUM }); });
    for (let r = 5; r <= 300; r++) { b.v('F' + r, '=IF(AND(D' + r + '="",E' + r + '=""),"",F' + (r - 1) + '+N(D' + r + ')-N(E' + r + '))', { nf: INR }); if (r > 10) b.style('A' + r + ':A' + r, { nf: DATE }).style('D' + r + ':E' + r, { nf: NUM }); }
    b.style('A3:F10', BOX).freeze(3, 0);
    b.cf('F4:F300', { type: 'cell', op: 'lt', v1: '0', style: { bg: '#ffc7ce', color: '#9c0006', b: true } });
    b.v('H3', 'Closing balance', { b: true }).v('H4', '=XLOOKUP(TRUE,F4:F300<>"",F4:F300,"",0,-1)', { nf: INR, b: true, fs: 13, color: GREEN });
    b.widths([95, 260, 90, 110, 110, 130, 20, 160]);
    return book('Cash Book', [b.sh]);
  }

  // ---------------------------------------------------------------- party ledger with ageing
  function ledger() {
    const b = builder('Ledger');
    b.widths([95, 240, 120, 110, 110, 130, 50, 95, 90, 100]);
    b.merge('A1:J1', 'Party Ledger – Customer Pvt Ltd', TITLE);
    b.row('A3', ['Date', 'Particulars', 'Ref no.', 'Debit (₹)', 'Credit (₹)', 'Balance (₹)', 'Dr/Cr', 'Due date', 'Status', 'Ageing'], HEAD);
    const y = new Date().getFullYear(), t = today();
    const rows = [[t - 95, 'Opening balance', '', 15000, 0, t - 95, 'Paid'], [t - 80, 'Sales invoice', 'INV/001', 53100, 0, t - 65, 'Paid'], [t - 62, 'Payment received – NEFT', 'UTR 88123', 0, 68100, '', ''], [t - 50, 'Sales invoice', 'INV/014', 39412, 0, t - 35, 'Unpaid'], [t - 20, 'Sales invoice', 'INV/027', 26786, 0, t - 5, 'Unpaid'], [t - 6, 'Sales invoice', 'INV/033', 11800, 0, t + 9, 'Unpaid']];
    rows.forEach((d, i) => {
      const r = 4 + i;
      b.v('A' + r, d[0], { nf: DATE }); b.row('B' + r, [d[1], d[2], d[3] || undefined, d[4] || undefined]); b.style('D' + r + ':E' + r, { nf: NUM });
      b.v('F' + r, i === 0 ? '=D4-E4' : '=F' + (r - 1) + '+N(D' + r + ')-N(E' + r + ')', { nf: INR });
      b.v('G' + r, '=IF(F' + r + '>=0,"Dr","Cr")', { al: 'center' });
      if (d[5] !== '') b.v('H' + r, d[5], { nf: DATE }); if (d[6]) b.v('I' + r, d[6], { al: 'center' });
      b.v('J' + r, '=IF(I' + r + '="Unpaid",AGEING(H' + r + '),"")', { al: 'center' });
    });
    const last = 3 + rows.length;
    b.style('A3:J' + last, BOX);
    b.dv('I4:I200', { type: 'list', list: ['Paid', 'Unpaid', 'Part paid'] });
    b.cf('J4:J200', { type: 'text', op: 'begins', text: 'Over', style: { bg: '#ffc7ce', color: '#9c0006', b: true } });
    b.cf('J4:J200', { type: 'text', op: 'begins', text: '31', style: { bg: '#ffeb9c', color: '#9c5700' } });
    b.cf('I4:I200', { type: 'text', op: 'exact', text: 'Unpaid', style: { color: '#c62828', b: true } });
    b.v('B' + (last + 2), 'Balance due', { b: true }).v('F' + (last + 2), '=F' + last, { nf: INR, b: true, fs: 12, bg: LIGHT });
    b.v('B' + (last + 3), '=RUPEEWORDS(F' + (last + 2) + ')', { i: true, color: '#33403a' });
    b.freeze(3, 0);
    return book('Party Ledger', [b.sh]);
  }

  // ---------------------------------------------------------------- metal weight calculator
  function metalWeight() {
    const b = builder('Weight Calc');
    b.widths([150, 110, 80, 80, 80, 90, 60, 110, 120, 100, 120]);
    b.merge('A1:K1', 'Metal Weight & Price Calculator', TITLE);
    b.merge('A2:K2', 'Dimensions in mm, length in metres. round: A = diameter · square: A = side · flat: A = width, B = thickness · hex: A = across flats · pipe: A = outside dia, B = thickness · sqpipe: A × B outside, C = thickness · angle: A × B legs, C = thickness · channel: A = height, B = flange, C = thickness · plate: A = length, B = width, C = thickness (mm)', { wrap: true, fs: 9, color: '#5f6b65', va: 'top' }).height(2, 44);
    b.row('A4', ['Material', 'Shape', 'A (mm)', 'B (mm)', 'C (mm)', 'Length (m)', 'Qty', 'Weight / pc (kg)', 'Total weight (kg)', 'Rate (₹/kg)', 'Amount (₹)'], HEAD).height(4, 36);
    const rows = [['MS', 'round', 12, '', '', 6, 50, 62.5], ['MS', 'flat', 50, 6, '', 6, 20, 64], ['MS', 'pipe', 48.3, 3.2, '', 6, 10, 72], ['MS', 'angle', 50, 50, 5, 6, 15, 66], ['MS', 'plate', 2500, 1250, 10, '', 2, 68], ['SS', 'sqpipe', 40, 40, 1.5, 6, 8, 260], ['Aluminium', 'sheet', 2440, 1220, 1, '', 5, 310], ['Copper', 'round', 10, '', '', 3, 4, 860]];
    rows.forEach((d, i) => {
      const r = 5 + i;
      b.row('A' + r, d.slice(0, 7));
      b.v('J' + r, d[7], { nf: NUM });
    });
    for (let r = 5; r <= 60; r++) {
      b.v('H' + r, '=IF(OR(B' + r + '="",C' + r + '=""),"",METALWEIGHT(B' + r + ',C' + r + ',D' + r + ',E' + r + ',IF(F' + r + '="",1,F' + r + '),A' + r + '))', { nf: '#,##0.000' });
      b.v('I' + r, '=IF(H' + r + '="","",H' + r + '*G' + r + ')', { nf: '#,##0.000', b: true });
      b.v('K' + r, '=IF(OR(I' + r + '="",J' + r + '=""),"",I' + r + '*J' + r + ')', { nf: INR });
    }
    b.style('A4:K12', BOX);
    b.dv('A5:A60', { type: 'list', list: ['MS', 'SS', 'SS316', 'Aluminium', 'Copper', 'Brass', 'Bronze', 'Cast iron', 'GI', 'Titanium', 'Lead', 'Zinc'] });
    b.dv('B5:B60', { type: 'list', list: ['round', 'square', 'flat', 'hex', 'pipe', 'sqpipe', 'angle', 'channel', 'plate', 'sheet'] });
    b.v('H62', 'Total', { b: true, al: 'right' }).v('I62', '=SUM(I5:I60)', { nf: '#,##0.000', b: true }).v('K62', '=SUM(K5:K60)', { nf: INR, b: true, bd: { bt: 'thin', bb: 'double', c: GREEN } });
    b.v('I63', '=CONVERT(I62,"kg","t")', { nf: '#,##0.000" MT"', color: '#5f6b65' });
    b.freeze(4, 0).print({ orient: 'landscape' });
    return book('Metal Weight Calculator', [b.sh]);
  }

  // ---------------------------------------------------------------- to-do
  function todo() {
    const b = builder('Tasks');
    b.widths([50, 320, 110, 95, 120, 220]);
    b.merge('A1:F1', 'Task Tracker', TITLE);
    b.row('A3', ['Done', 'Task', 'Priority', 'Due date', 'Owner', 'Notes'], HEAD);
    const t = today();
    const tasks = [[true, 'File GSTR-1 for last month', 'High', t - 2, 'Anita'], [false, 'Follow up payment – Om Industries', 'High', t + 1, 'Priya'], [false, 'Order MS plates 10 mm', 'Medium', t + 3, 'Ramesh'], [false, 'Service cutting machine', 'Low', t + 10, 'Suresh'], [false, 'Renew shop insurance', 'Medium', t - 1, 'Owner']];
    tasks.forEach((d, i) => { const r = 4 + i; b.v('A' + r, d[0], { al: 'center' }); b.row('B' + r, [d[1], d[2]]); b.v('D' + r, d[3], { nf: DATE }); b.v('E' + r, d[4]); });
    for (let r = 4; r <= 100; r++) { if (r > 8) b.v('A' + r, false, { al: 'center' }); b.style('D' + r + ':D' + r, { nf: DATE }); }
    b.dv('A4:A100', { type: 'checkbox' }).dv('C4:C100', { type: 'list', list: ['High', 'Medium', 'Low'] });
    b.cf('A4:F100', { type: 'formula', formula: '=$A4=TRUE', style: { st: true, color: '#9aa3a0' }, stop: true });
    b.cf('D4:D100', { type: 'date', op: 'past', style: { bg: '#ffc7ce', color: '#9c0006', b: true } });
    b.cf('C4:C100', { type: 'text', op: 'exact', text: 'High', style: { color: '#c62828', b: true } });
    b.style('A3:F8', BOX);
    b.v('H3', 'Done', { b: true }).v('I3', '=COUNTIF(A4:A100,TRUE)&" of "&COUNTA(B4:B100)', { b: true, color: GREEN });
    b.freeze(3, 0);
    return book('Task Tracker', [b.sh]);
  }

  const T = [
    { id: 'gst-invoice', cat: 'Business & GST', icon: '🧾', name: 'GST Tax Invoice', desc: 'CGST/SGST or IGST worked out from GSTINs, amount in words (English + Hindi), UPI payment QR.', make: gstInvoice, star: true },
    { id: 'quotation', cat: 'Business & GST', icon: '📄', name: 'Quotation / Estimate', desc: 'Items, GST, total in words, validity date and terms.', make: quotation },
    { id: 'sales-gst', cat: 'Business & GST', icon: '📊', name: 'Sales Register + GST Summary', desc: 'Every invoice with tax split, month-wise and rate-wise GST summary with chart.', make: salesRegister },
    { id: 'ledger', cat: 'Business & GST', icon: '📒', name: 'Party Ledger with Ageing', desc: 'Debit, credit, running balance, Dr/Cr and overdue ageing buckets.', make: ledger },
    { id: 'cash-book', cat: 'Business & GST', icon: '💵', name: 'Cash Book', desc: 'Receipts, payments and running balance with closing cash.', make: cashBook },
    { id: 'stock', cat: 'Stock & metals', icon: '📦', name: 'Stock Register', desc: 'Opening, in, out, closing stock, re-order alerts and stock value.', make: stockRegister },
    { id: 'metal-weight', cat: 'Stock & metals', icon: '⚙️', name: 'Metal Weight Calculator', desc: 'Weight of bars, pipes, angles, channels and plates in MS, SS, aluminium, copper.', make: metalWeight, star: true },
    { id: 'salary', cat: 'People', icon: '👷', name: 'Salary Sheet', desc: 'Attendance-based pay with PF, ESI, professional tax and net pay in words.', make: salary },
    { id: 'attendance', cat: 'People', icon: '🗓️', name: 'Attendance Register', desc: 'Monthly P/A/H/L/WO marking with colour coding and paid days.', make: attendance },
    { id: 'expenses', cat: 'Money', icon: '💸', name: 'Expense Tracker', desc: 'Category budget vs spent, warnings when over budget, doughnut chart.', make: expenses },
    { id: 'emi', cat: 'Money', icon: '🏦', name: 'Loan EMI Schedule', desc: 'EMI, total interest and a full repayment schedule that resizes itself.', make: emi },
    { id: 'todo', cat: 'Money', icon: '✅', name: 'Task Tracker', desc: 'Checkboxes, priorities and overdue highlighting.', make: todo }
  ];
  async function newFromTemplate(id) {
    const t = T.find(x => x.id === id); if (!t) { ui.toast('Template not found'); return; }
    ui.busy('Creating "' + t.name + '"…'); await ui.nextFrame();
    try {
      const b = t.make(); b.template = t.id;
      await IS.openBook(IS.normalizeBook(Object.assign(IS.newBook(b.name), b, { id: IS.store.newId(), created: Date.now(), updated: Date.now() })), { save: true });
      ui.toast('"' + t.name + '" is ready – change the sample data to your own.', { ms: 3500 });
    } catch (e) { console.error(e); ui.toast('Could not create the template: ' + e.message, { type: 'error' }); }
    finally { ui.done(); }
  }
  function gallery() {
    const cats = [...new Set(T.map(t => t.cat))];
    const body = document.createElement('div');
    body.innerHTML = '<div class="cards" style="margin-bottom:14px"><button type="button" class="card" data-blank="1"><span class="card-ic">➕</span><b>Blank workbook</b><span>Start from an empty sheet.</span></button></div>' +
      cats.map(c => '<h3 style="margin:14px 0 8px;font-size:13px;color:var(--muted);text-transform:uppercase">' + esc(c) + '</h3><div class="cards">' + T.filter(t => t.cat === c).map(t => '<button type="button" class="card" data-t="' + t.id + '"><span class="card-ic">' + t.icon + '</span><b>' + esc(t.name) + (t.star ? ' <span class="tag">India</span>' : '') + '</b><span>' + esc(t.desc) + '</span></button>').join('') + '</div>').join('');
    body.addEventListener('click', e => {
      const b = e.target.closest('.card'); if (!b) return;
      ui.closeModal();
      if (b.dataset.blank) IS.run('newBook'); else newFromTemplate(b.dataset.t);
    });
    ui.modal({ title: 'Templates', body, wide: true });
  }
  IS.templates = T;
  Object.assign(IS.cmd, { templates: gallery, newFromTemplate });
})(window);
