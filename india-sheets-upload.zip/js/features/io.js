/* India Sheets – open / import, download / export (xlsx, xls, ods, csv, tsv, html, json, md, png, pdf, isheet), print */
(function (global) {
  'use strict';
  const IS = global.IS, ui = IS.ui, X = global.Formula, esc = ui.esc, K = IS.K;
  const $ = id => document.getElementById(id);
  const XLSX_URL = 'vendor/xlsx.bundle.js';
  const safeName = s => String(s || 'workbook').replace(/[\\/:*?"<>|]+/g, '_').trim().slice(0, 120) || 'workbook';
  async function ensureXLSX() {
    if (global.XLSX) return global.XLSX;
    await ui.loadScript(XLSX_URL);
    if (!global.XLSX) throw new Error('Excel engine missing');
    return global.XLSX;
  }
  const val = (sh, r, c) => X.norm(IS.calc.value(sh, r, c));

  // =================================================================== OPEN / IMPORT
  function openFile(opts = {}) {
    const inp = $('fileInput'); inp.value = ''; inp.multiple = !!opts.into;
    inp.onchange = () => { if (inp.files.length) openFiles([...inp.files], opts); };
    inp.click();
  }
  async function openFiles(files, opts = {}) {
    const images = files.filter(f => /^image\//.test(f.type));
    const docs = files.filter(f => !/^image\//.test(f.type));
    for (const f of images) await IS.insertImageFile(f);
    if (!docs.length) return;
    ui.busy('Opening ' + docs[0].name + '…');
    await ui.nextFrame();
    try {
      let book = null; const sheets = [];
      for (const f of docs) {
        const b = await readFile(f);
        if (!b) continue;
        if (!book) book = b;
        sheets.push(...b.sheets);
      }
      if (!book) return;
      if (opts.into) {
        ui.done();
        sheets.forEach(s => { s.id = IS.rid('s'); s.name = IS.uniqueSheetName(s.name); IS.addSheet(s, IS.wb.sheets.length); });
        ui.toast('Added ' + sheets.length + ' sheet' + (sheets.length > 1 ? 's' : '') + ' from ' + docs.map(d => d.name).join(', '));
        return;
      }
      if (docs.length > 1) { const names = new Set(); book.sheets = sheets.map(s => { let n = s.name, i = 2; while (names.has(n.toUpperCase())) n = s.name.slice(0, 27) + ' (' + i++ + ')'; names.add(n.toUpperCase()); s.name = n; return s; }); }
      book.id = IS.store.newId(); book.created = book.created || Date.now(); book.updated = Date.now();
      await IS.openBook(book, { save: true });
      ui.toast('Opened "' + book.name + '" – it is saved in My workbooks.', { ms: 3500 });
    } catch (e) {
      console.error(e);
      ui.toast('Sorry, this file could not be opened: ' + (e.message || e), { type: 'error', ms: 7000 });
    } finally { ui.done(); }
  }
  IS.openFiles = openFiles;
  async function readFile(file) {
    const name = file.name.replace(/\.[^.]+$/, '');
    const ext = (file.name.match(/\.([^.]+)$/) || [])[1] || '';
    const e = ext.toLowerCase();
    if (e === 'isheet' || e === 'json') {
      const text = await file.text(); let obj;
      try { obj = JSON.parse(text); } catch (err) { throw new Error('The file is damaged or not a valid ' + e + ' file'); }
      if (obj && obj.format === 'india-sheets') {
        if (obj.enc) {
          const pass = await ui.prompt('Password needed', '"' + file.name + '" is locked. Enter its password', '', { type: 'password', ok: 'Unlock' });
          if (pass === null) return null;
          try { obj = JSON.parse(await decrypt(obj, pass)); } catch (err) { throw new Error('Wrong password'); }
        }
        const b = obj.book || obj; b.name = b.name || name; return IS.normalizeBook(b);
      }
      if (obj && Array.isArray(obj.sheets)) { obj.name = obj.name || name; return IS.normalizeBook(obj); }
      if (Array.isArray(obj)) return IS.normalizeBook({ name, sheets: [sheetFromRows(name, jsonToRows(obj))], version: 2 });
      throw new Error('This JSON file does not contain a table');
    }
    if (e === 'csv' || e === 'tsv' || e === 'txt') {
      const text = (await file.text()).replace(/^﻿/, '');
      const first = text.slice(0, 2000).split(/\r?\n/)[0] || '';
      const counts = { '\t': first.split('\t').length, ',': first.split(',').length, ';': first.split(';').length, '|': first.split('|').length };
      const delim = e === 'tsv' ? '\t' : Object.keys(counts).sort((a, b) => counts[b] - counts[a])[0];
      return IS.normalizeBook({ name, sheets: [sheetFromRows(name.slice(0, 31), parseCSV(text, delim))], version: 2 });
    }
    const XL = await ensureXLSX();
    const buf = await file.arrayBuffer();
    const wbx = XL.read(buf, { type: 'array', cellFormula: true, cellStyles: true, cellNF: true, cellDates: false, sheetStubs: false });
    return bookFromXLSX(XL, wbx, name);
  }
  function jsonToRows(arr) {
    if (!arr.length) return [];
    if (Array.isArray(arr[0])) return arr;
    const keys = []; arr.forEach(o => { if (o && typeof o === 'object') Object.keys(o).forEach(k => { if (!keys.includes(k)) keys.push(k); }); });
    return [keys].concat(arr.map(o => keys.map(k => (o && o[k] !== undefined ? o[k] : ''))));
  }
  function sheetFromRows(name, rows) {
    const sh = IS.newSheet(String(name || 'Sheet1').slice(0, 31));
    let maxC = 0;
    rows.forEach((row, r) => row.forEach((v, c) => {
      if (v === '' || v === null || v === undefined) return;
      const cell = {};
      if (typeof v === 'number' || typeof v === 'boolean') cell.v = v;
      else { const e = IS.parseEntry(String(v), null); if (e.v === null) return; cell.v = e.v; if (e.t) cell.t = e.t; if (e.nf) cell.s = { nf: e.nf }; }
      sh.cells[K(r, c)] = cell; if (c > maxC) maxC = c;
    }));
    if (rows.length > 1 && rows[0].every(v => typeof v === 'string' && v !== '')) for (let c = 0; c < rows[0].length; c++) { const cell = sh.cells[K(0, c)]; if (cell) cell.s = Object.assign({}, cell.s, { b: true, bg: '#e3f3e9' }); }
    sh.rows = Math.max(1000, rows.length + 100); sh.cols = Math.max(26, maxC + 5);
    if (rows.length > 1) sh.freezeR = 1;
    autoWidths(sh, rows);
    return sh;
  }
  function autoWidths(sh, rows) {
    const n = Math.min(rows.length, 300); const w = {};
    for (let r = 0; r < n; r++) (rows[r] || []).forEach((v, c) => { const len = String(v == null ? '' : v).length; w[c] = Math.max(w[c] || 0, len); });
    for (const c in w) sh.colW[c] = Math.max(60, Math.min(320, Math.round(w[c] * 7.6 + 18)));
  }
  function parseCSV(text, delim) {
    const rows = []; let row = [], f = '', q = false;
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (q) { if (ch === '"') { if (text[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += ch; }
      else if (ch === '"' && f === '') q = true;
      else if (ch === delim) { row.push(f); f = ''; }
      else if (ch === '\n' || ch === '\r') { if (ch === '\r' && text[i + 1] === '\n') i++; row.push(f); rows.push(row); row = []; f = ''; }
      else f += ch;
    }
    if (f !== '' || row.length) { row.push(f); rows.push(row); }
    return rows;
  }
  IS.parseCSV = parseCSV;
  function rgbHex(c) { if (!c) return null; const v = c.rgb || c; if (typeof v !== 'string') return null; const h = v.slice(-6); return /^[0-9a-f]{6}$/i.test(h) ? '#' + h.toLowerCase() : null; }
  function bookFromXLSX(XL, wbx, name) {
    const book = { name, version: 2, sheets: [], names: {} };
    const wbMeta = (wbx.Workbook && wbx.Workbook.Sheets) || [];
    wbx.SheetNames.forEach((sn, idx) => {
      const ws = wbx.Sheets[sn]; const sh = IS.newSheet(String(sn).slice(0, 31));
      if (wbMeta[idx] && wbMeta[idx].Hidden) sh.hidden = true;
      const ref = ws['!ref'] ? XL.utils.decode_range(ws['!ref']) : { s: { r: 0, c: 0 }, e: { r: 0, c: 0 } };
      for (const addr in ws) {
        if (addr[0] === '!') continue;
        const c = ws[addr]; const pos = XL.utils.decode_cell(addr);
        const cell = {}; const s = {};
        if (c.f) cell.v = '=' + String(c.f).replace(/_xlfn\._xlws\.|_xlfn\.|_xlws\./gi, '');
        else if (c.t === 'n') cell.v = c.v;
        else if (c.t === 'b') cell.v = !!c.v;
        else if (c.t === 'd') { const d = new Date(c.v); cell.v = X.toSerial(d.getFullYear(), d.getMonth() + 1, d.getDate()); s.nf = 'dd-mm-yyyy'; }
        else if (c.t === 'e') cell.v = c.w || '#N/A';
        else if (c.t === 's' || c.t === 'str') { if (c.v !== '' && c.v != null) { cell.v = String(c.v); if (typeof X.parseInput(cell.v).value !== 'string') cell.t = 's'; } }
        const z = typeof c.z === 'string' ? c.z : null;
        if (z && !/^general$/i.test(z)) s.nf = z.replace(/\\/g, '');
        const cs = c.s || {};
        const font = cs.font || {};
        if (font.bold) s.b = true; if (font.italic) s.i = true; if (font.underline) s.u = true; if (font.strike) s.st = true;
        if (font.sz && +font.sz !== 11 && +font.sz !== 10) s.fs = +font.sz;
        if (font.name && !/^(calibri|arial)$/i.test(font.name)) s.ff = font.name;
        const fcol = rgbHex(font.color); if (fcol && fcol !== '#000000') s.color = fcol;
        const fg = (cs.fill && cs.fill.fgColor) || cs.fgColor;
        const patt = (cs.fill && cs.fill.patternType) || cs.patternType;
        const bg = rgbHex(fg); if (bg && patt !== 'none' && bg !== '#ffffff') s.bg = bg;
        const al = cs.alignment || {};
        if (['left', 'center', 'right'].includes(al.horizontal)) s.al = al.horizontal;
        if (al.vertical === 'top') s.va = 'top'; else if (al.vertical === 'center') s.va = 'middle';
        if (al.wrapText) s.wrap = true; if (al.indent) s.ind = +al.indent;
        const bd = cs.border; if (bd) { const o = {}; [['top', 'bt'], ['bottom', 'bb'], ['left', 'bl'], ['right', 'br']].forEach(([a, b]) => { const x = bd[a]; if (x && x.style) { o[b] = ['thin', 'medium', 'thick', 'dashed', 'dotted', 'double'].includes(x.style) ? x.style : 'thin'; const col = rgbHex(x.color); if (col && col !== '#000000') o.c = col; } }); if (Object.keys(o).length) s.bd = o; }
        if (c.l && c.l.Target) s.link = c.l.Target;
        if (Object.keys(s).length) cell.s = s;
        if (c.c && c.c.length) cell.n = c.c.map(x => x.t).filter(Boolean).join('\n');
        if (cell.v !== undefined || cell.s || cell.n) sh.cells[K(pos.r, pos.c)] = cell;
      }
      (ws['!merges'] || []).forEach(m => { if (m.e.r > m.s.r || m.e.c > m.s.c) sh.merges.push({ r: m.s.r, c: m.s.c, r2: m.e.r, c2: m.e.c }); });
      (ws['!cols'] || []).forEach((ci, i) => { if (!ci) return; if (ci.hidden) sh.hiddenCols.push(i); const w = ci.wpx || (ci.wch ? ci.wch * 7.5 + 5 : ci.width ? ci.width * 7.5 : null); if (w) sh.colW[i] = Math.round(w); });
      (ws['!rows'] || []).forEach((ri, i) => { if (!ri) return; if (ri.hidden) sh.hiddenRows.push(i); const h = ri.hpx || (ri.hpt ? ri.hpt * 4 / 3 : null); if (h && Math.abs(h - 20) > 2) sh.rowH[i] = Math.round(h); });
      if (ws['!autofilter'] && ws['!autofilter'].ref) { try { const ar = XL.utils.decode_range(ws['!autofilter'].ref); sh.filter = { t: ar.s.r, l: ar.s.c, b: ar.e.r, r: ar.e.c, crit: {}, hidden: [] }; } catch (e) { /* ignore */ } }
      sh.rows = Math.max(1000, ref.e.r + 100); sh.cols = Math.max(26, ref.e.c + 5);
      book.sheets.push(sh);
    });
    ((wbx.Workbook && wbx.Workbook.Names) || []).forEach(n => {
      if (!n || !n.Name || !n.Ref || /^_xlnm\./i.test(n.Name) || n.Hidden) return;
      if (!X.parseRef(n.Ref)) return;
      book.names[n.Name.toUpperCase()] = { name: n.Name, ref: n.Ref };
    });
    if (!book.sheets.length) book.sheets.push(IS.newSheet('Sheet1'));
    return IS.normalizeBook(book);
  }

  async function importUrl() {
    const url = await ui.prompt('Import from a web link', 'Link to a CSV or Excel file (for Google Sheets: File → Share → Publish to web → CSV link)', '', { placeholder: 'https://…', ok: 'Import' });
    if (!url) return;
    if (!/^https?:\/\//i.test(url.trim())) { ui.toast('Please enter a link that starts with https://', { type: 'error' }); return; }
    ui.busy('Downloading…');
    try {
      const res = await fetch(url.trim(), { mode: 'cors' });
      if (!res.ok) throw new Error('The website answered ' + res.status);
      const type = res.headers.get('content-type') || '';
      const nameFromUrl = decodeURIComponent((url.split('?')[0].split('/').pop() || 'Imported data')).replace(/\.[^.]+$/, '') || 'Imported data';
      let file;
      if (/csv|text\/plain|tab-separated/.test(type) || /output=csv|\.csv(\?|$)/i.test(url)) file = new File([await res.text()], nameFromUrl + '.csv', { type: 'text/csv' });
      else if (/json/.test(type)) file = new File([await res.text()], nameFromUrl + '.json');
      else file = new File([await res.arrayBuffer()], nameFromUrl + '.xlsx');
      ui.done();
      await openFiles([file]);
    } catch (e) {
      ui.done();
      ui.modal({ title: 'Could not import that link', body: '<p>' + esc(e.message || String(e)) + '</p><p class="hint">Many websites do not allow apps to read their files directly. Download the file to your computer, then use <b>File → Open</b>.</p>' });
    }
  }

  // =================================================================== EXPORT helpers
  const NON_EXCEL = new Set(['RUPEEWORDS', 'RUPEE', 'NUMWORDS', 'HINDIWORDS', 'GST', 'CGST', 'SGST', 'IGST', 'WITHGST', 'REMOVEGST', 'INR', 'LAKH', 'CRORE', 'FY', 'FYSTART', 'FYEND', 'FYQUARTER', 'EMI', 'UNIQUECOUNT', 'AVG', 'ISGSTIN', 'GSTINSTATE', 'GSTINPAN', 'ISPAN', 'ISIFSC', 'ISAADHAAR', 'ISMOBILE', 'ISPINCODE', 'STATENAME', 'STATECODE', 'AGEING', 'METALWEIGHT', 'DENSITY', 'CONVERT', 'QR', 'UPIQR', 'SPARKLINE', 'REGEXMATCH', 'REGEXEXTRACT', 'REGEXREPLACE', 'SPLIT', 'COUNTUNIQUE', 'IMAGE']);
  const XLFN = ['IFS', 'SWITCH', 'MAXIFS', 'MINIFS', 'CONCAT', 'TEXTJOIN', 'XLOOKUP', 'XMATCH', 'IFNA', 'DAYS', 'ISOWEEKNUM', 'SEQUENCE', 'UNIQUE', 'SORTBY', 'RANDARRAY', 'LET', 'TEXTBEFORE', 'TEXTAFTER', 'TEXTSPLIT', 'VSTACK', 'HSTACK', 'TAKE', 'DROP', 'CHOOSECOLS', 'CHOOSEROWS', 'TOCOL', 'TOROW', 'STDEV.S', 'STDEV.P', 'VAR.S', 'VAR.P', 'MODE.SNGL', 'PERCENTILE.INC', 'QUARTILE.INC', 'RANK.EQ', 'FORECAST.LINEAR', 'CEILING.MATH', 'FLOOR.MATH', 'NUMBERVALUE', 'UNICHAR', 'UNICODE', 'FORMULATEXT', 'ISFORMULA'];
  const fnNames = f => { const out = new Set(); f.replace(/("(?:[^"]|"")*")|([A-Za-z_][A-Za-z0-9_.]*)\s*\(/g, (m, s, n) => { if (n) out.add(n.toUpperCase()); return m; }); return out; };
  function excelFormula(f) {
    let body = f.slice(1);
    body = body.replace(/("(?:[^"]|"")*")|(^|[^A-Za-z0-9_.])([A-Za-z][A-Za-z0-9.]*)(\s*\()/g, (m, s, pre, n, p) => {
      if (s) return s; const u = n.toUpperCase();
      if (u === 'SORT' || u === 'FILTER') return pre + '_xlfn._xlws.' + u + p;
      if (XLFN.includes(u)) return pre + '_xlfn.' + u + p;
      return m;
    });
    return body;
  }
  function xlNumFmt(nf) { if (!nf) return undefined; if (nf === '[INRSHORT]') return '"₹"#,##0'; return nf; }
  const ERRCODES = { '#NULL!': 0x00, '#DIV/0!': 0x07, '#VALUE!': 0x0F, '#REF!': 0x17, '#NAME?': 0x1D, '#NUM!': 0x24, '#N/A': 0x2A };
  /** Build a SheetJS workbook from the current India Sheets workbook */
  async function toXLSXBook(opts = {}) {
    const XL = await ensureXLSX(); const wb = IS.wb; const book = XL.utils.book_new();
    let converted = 0;
    const sheets = opts.sheets || wb.sheets;
    sheets.forEach(sh => {
      const ws = {}; const used = IS.usedRange(sh); let maxR = used.b, maxC = used.r;
      const keys = new Set(Object.keys(sh.cells)); (IS.calc.vals.get(sh.id) || new Map()).forEach((v, k) => keys.add(k));
      for (const k of keys) {
        const i = k.indexOf(':'); const r = +k.slice(0, i), c = +k.slice(i + 1);
        const cell = sh.cells[k] || {}; const v = X.norm(IS.calc.value(sh, r, c)); const s = cell.s || {};
        const o = {};
        if (v === null || v === undefined || v === '') { if (!cell.s && !cell.n) continue; o.t = 'z'; }
        else if (X.isErr(v)) { o.t = 'e'; o.v = ERRCODES[v.code] !== undefined ? ERRCODES[v.code] : 0x0F; o.w = v.code; }
        else if (typeof v === 'number') { o.t = 'n'; o.v = v; }
        else if (typeof v === 'boolean') { o.t = 'b'; o.v = v; }
        else { o.t = 's'; o.v = String(v); }
        if (IS.isFormulaCell(cell)) {
          const used2 = fnNames(cell.v);
          if ([...used2].some(n => NON_EXCEL.has(n))) converted++;
          else o.f = excelFormula(cell.v);
        }
        const z = xlNumFmt(s.nf); if (z) o.z = z;
        const st = {};
        const font = {}; if (s.b) font.bold = true; if (s.i) font.italic = true; if (s.u) font.underline = true; if (s.st) font.strike = true; if (s.fs) font.sz = s.fs; if (s.ff) font.name = s.ff; if (s.color) font.color = { rgb: s.color.replace('#', '').toUpperCase() };
        if (s.link) { font.color = font.color || { rgb: '1565C0' }; font.underline = true; o.l = { Target: s.link }; }
        if (Object.keys(font).length) st.font = font;
        if (s.bg) st.fill = { patternType: 'solid', fgColor: { rgb: s.bg.replace('#', '').toUpperCase() } };
        const al = {}; if (s.al) al.horizontal = s.al; if (s.va) al.vertical = s.va === 'middle' ? 'center' : s.va; if (s.wrap) al.wrapText = true; if (s.ind) al.indent = s.ind;
        if (Object.keys(al).length) st.alignment = al;
        if (s.bd) { const b = {}; const col = { rgb: (s.bd.c || '#000000').replace('#', '').toUpperCase() }; [['bt', 'top'], ['bb', 'bottom'], ['bl', 'left'], ['br', 'right']].forEach(([a, n]) => { if (s.bd[a]) b[n] = { style: s.bd[a], color: col }; }); st.border = b; }
        if (z) st.numFmt = z;
        if (Object.keys(st).length) o.s = st;
        if (cell.n) { o.c = [{ a: 'India Sheets', t: cell.n }]; o.c.hidden = true; }
        ws[XL.utils.encode_cell({ r, c })] = o;
        if (r > maxR) maxR = r; if (c > maxC) maxC = c;
      }
      ws['!ref'] = XL.utils.encode_range({ s: { r: 0, c: 0 }, e: { r: Math.max(0, maxR), c: Math.max(0, maxC) } });
      const cols = []; const hc = new Set(sh.hiddenCols || []);
      for (let c = 0; c <= maxC; c++) { const ent = { wpx: sh.colW[c] != null ? sh.colW[c] : 100 }; if (hc.has(c)) ent.hidden = true; cols.push(ent); }
      ws['!cols'] = cols;
      const rows = []; const hr = new Set(sh.hiddenRows || []);
      for (let r = 0; r <= maxR; r++) { const h = sh.rowH[r] != null ? sh.rowH[r] : sh.rowHa && sh.rowHa[r]; if (h || hr.has(r)) rows[r] = Object.assign(h ? { hpx: h } : {}, hr.has(r) ? { hidden: true } : {}); }
      if (rows.length) ws['!rows'] = rows;
      if (sh.merges.length) ws['!merges'] = sh.merges.map(m => ({ s: { r: m.r, c: m.c }, e: { r: m.r2, c: m.c2 } }));
      if (sh.filter) ws['!autofilter'] = { ref: XL.utils.encode_range({ s: { r: sh.filter.t, c: sh.filter.l }, e: { r: sh.filter.b, c: sh.filter.r } }) };
      XL.utils.book_append_sheet(book, ws, sh.name.slice(0, 31).replace(/[\\/?*[\]:]/g, '_'));
    });
    book.Workbook = { Names: Object.values(wb.names || {}).map(n => ({ Name: n.name, Ref: n.ref })), Sheets: sheets.map(s => ({ Hidden: s.hidden ? 1 : 0 })) };
    return { XL, book, converted };
  }

  // ---- CSV / TSV / JSON / Markdown / HTML
  function cellText(sh, r, c, raw) {
    const cell = sh.cells[K(r, c)], v = val(sh, r, c);
    if (v === null || v === undefined) return '';
    if (X.isErr(v)) return v.code;
    if (typeof v === 'boolean') return v ? 'TRUE' : 'FALSE';
    const nf = cell && cell.s && cell.s.nf;
    if (raw && typeof v === 'number') { if (X.isDateFormat(nf)) return X.formatValue(v, X.isTimeOnlyFormat(nf) ? 'hh:mm:ss' : (v % 1 ? 'dd-mm-yyyy hh:mm' : 'dd-mm-yyyy')).text; return String(parseFloat(v.toPrecision(15))); }
    return X.formatValue(v, nf).text;
  }
  function sheetMatrix(sh, raw) {
    const u = IS.usedRange(sh); if (u.empty) return [];
    const out = [];
    for (let r = 0; r <= u.b; r++) { const row = []; for (let c = 0; c <= u.r; c++) row.push(cellText(sh, r, c, raw)); out.push(row); }
    return out;
  }
  const csvField = (t, d) => (t.includes(d) || /["\r\n]/.test(t) ? '"' + t.replace(/"/g, '""') + '"' : t);
  function toCSV(sh, d) { return sheetMatrix(sh, true).map(row => row.map(t => csvField(t, d)).join(d)).join('\r\n'); }
  function toJSON(sh) {
    const u = IS.usedRange(sh); if (u.empty) return '[]';
    const header = IS.detectHeader ? IS.detectHeader(sh, u) : true;
    const jv = (r, c) => { const v = val(sh, r, c); if (v === null || v === undefined || X.isErr(v)) return null; const cell = sh.cells[K(r, c)]; if (typeof v === 'number' && cell && cell.s && X.isDateFormat(cell.s.nf)) return X.formatValue(v, v % 1 ? 'yyyy-mm-dd"T"hh:mm:ss' : 'yyyy-mm-dd').text; return typeof v === 'object' ? String(v) : v; };
    const rows = [];
    if (header) {
      const keys = []; for (let c = 0; c <= u.r; c++) keys.push(String(cellText(sh, 0, c) || 'Column ' + X.numToCol(c)));
      for (let r = 1; r <= u.b; r++) { const o = {}; let any = false; keys.forEach((k, c) => { const v = jv(r, c); o[k] = v; if (v !== null) any = true; }); if (any) rows.push(o); }
    } else for (let r = 0; r <= u.b; r++) { const row = []; for (let c = 0; c <= u.r; c++) row.push(jv(r, c)); rows.push(row); }
    return JSON.stringify(rows, null, 2);
  }
  function toMarkdown(sh) {
    const m = sheetMatrix(sh, false); if (!m.length) return '';
    const e = t => String(t).replace(/\|/g, '\\|').replace(/\n/g, ' ');
    const w = m[0].length;
    return ['| ' + m[0].map(e).join(' | ') + ' |', '|' + Array(w).fill(' --- ').join('|') + '|'].concat(m.slice(1).map(row => '| ' + row.map(e).join(' | ') + ' |')).join('\n') + '\n';
  }
  function sheetHTML(sh) {
    const u = IS.usedRange(sh); if (u.empty) return '<p><em>(empty sheet)</em></p>';
    const src = IS.cellSource(sh);
    let html = '<table>';
    for (let r = 0; r <= u.b; r++) {
      if (!IS.rowVisible(sh, r)) continue;
      html += '<tr>';
      for (let c = 0; c <= u.r; c++) {
        if (!IS.colVisible(sh, c) || IS.isCovered(sh, r, c)) continue;
        const info = src.info(r, c); const s = (info && info.s) || {}; const m = IS.mergeAt(sh, r, c);
        let css = '';
        if (s.b) css += 'font-weight:700;'; if (s.i) css += 'font-style:italic;'; if (s.u || (info && info.link)) css += 'text-decoration:underline;'; if (s.st) css += 'text-decoration:line-through;';
        if (info && info.bg) css += 'background:' + info.bg + ';'; const col = (info && info.color) || s.color; if (col) css += 'color:' + col + ';';
        const al = s.al || (info && info.kind === 'num' ? 'right' : info && (info.kind === 'bool' || info.kind === 'err') ? 'center' : ''); if (al) css += 'text-align:' + al + ';';
        if (s.fs) css += 'font-size:' + s.fs + 'pt;'; if (s.wrap) css += 'white-space:pre-wrap;';
        if (s.bd) [['bt', 'top'], ['bb', 'bottom'], ['bl', 'left'], ['br', 'right']].forEach(([a, n]) => { if (s.bd[a]) css += 'border-' + n + ':' + (s.bd[a] === 'thick' ? 3 : s.bd[a] === 'medium' ? 2 : 1) + 'px ' + (s.bd[a] === 'dashed' ? 'dashed' : s.bd[a] === 'dotted' ? 'dotted' : s.bd[a] === 'double' ? 'double' : 'solid') + ' ' + (s.bd.c || '#000') + ';'; });
        let text = info ? esc(info.text || '') : '';
        if (info && info.link) text = '<a href="' + esc(info.link) + '">' + text + '</a>';
        if (info && info.checkbox) text = info.value === true ? '☑' : '☐';
        html += '<td' + (m ? ' rowspan="' + (m.r2 - m.r + 1) + '" colspan="' + (m.c2 - m.c + 1) + '"' : '') + (css ? ' style="' + css + '"' : '') + '>' + text + '</td>';
      }
      html += '</tr>';
    }
    return html + '</table>';
  }
  function toHTML() {
    const wb = IS.wb;
    const parts = wb.sheets.filter(s => !s.hidden).map(sh => '<section><h2>' + esc(sh.name) + '</h2>' + sheetHTML(sh) + '</section>').join('\n');
    return '<!doctype html><html lang="en-IN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>' + esc(wb.name) + '</title>' +
      '<style>body{font-family:"Segoe UI","Nirmala UI",Arial,sans-serif;margin:24px;color:#1c2420}h1{font-size:22px}h2{font-size:16px;margin:28px 0 8px;color:#0f7a3d}table{border-collapse:collapse;font-size:13px}td{border:1px solid #e2e5e3;padding:4px 8px;vertical-align:bottom;white-space:nowrap}section{overflow-x:auto}footer{margin-top:30px;color:#888;font-size:12px}</style></head><body>' +
      '<h1>' + esc(wb.name) + '</h1>' + parts + '<footer>Made with India Sheets · ' + new Date().toLocaleString('en-IN') + '</footer></body></html>';
  }

  // ---- password-protected files (AES-GCM, key from PBKDF2)
  const b64 = buf => { const b = new Uint8Array(buf); let s = ''; for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode.apply(null, b.subarray(i, i + 0x8000)); return btoa(s); };
  const unb64 = s => { const bin = atob(s); const out = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i); return out; };
  async function deriveKey(pass, salt, iter) {
    const base = await crypto.subtle.importKey('raw', new TextEncoder().encode(pass), 'PBKDF2', false, ['deriveKey']);
    return crypto.subtle.deriveKey({ name: 'PBKDF2', salt, iterations: iter, hash: 'SHA-256' }, base, { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']);
  }
  async function encrypt(text, pass) {
    const salt = crypto.getRandomValues(new Uint8Array(16)), iv = crypto.getRandomValues(new Uint8Array(12)), iter = 250000;
    const key = await deriveKey(pass, salt, iter);
    const data = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, new TextEncoder().encode(text));
    return { format: 'india-sheets', version: 2, enc: { alg: 'AES-GCM', kdf: 'PBKDF2-SHA256', iter, salt: b64(salt), iv: b64(iv) }, data: b64(data) };
  }
  async function decrypt(obj, pass) {
    const key = await deriveKey(pass, unb64(obj.enc.salt), obj.enc.iter);
    const plain = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: unb64(obj.enc.iv) }, key, unb64(obj.data));
    return new TextDecoder().decode(plain);
  }
  IS.crypto = { encrypt, decrypt };

  // =================================================================== DOWNLOAD
  async function download(fmt) {
    const wb = IS.wb, sh = IS.sheet, base = safeName(wb.name);
    try {
      switch (fmt) {
        case 'xlsx': case 'xls': case 'ods': case 'xlsb': {
          ui.busy('Preparing ' + fmt.toUpperCase() + ' file…'); await ui.nextFrame();
          const { XL, book, converted } = await toXLSXBook();
          const type = { xlsx: 'xlsx', xls: 'biff8', ods: 'ods', xlsb: 'xlsb' }[fmt];
          const data = XL.write(book, { bookType: type, type: 'array', compression: true, cellStyles: true });
          ui.done();
          ui.download(base + '.' + fmt, new Blob([data], { type: 'application/octet-stream' }));
          const lost = (wb.sheets.some(s => s.cf.length) ? ' Conditional formats, dropdowns and charts stay in India Sheets.' : '');
          ui.toast('Downloaded ' + base + '.' + fmt + (converted ? ' – ' + converted + ' cell(s) with India-only formulas were saved as values.' : '') + (fmt === 'xlsx' ? '' : lost), { ms: 6000 });
          break;
        }
        case 'csv': ui.download(safeName(base + ' - ' + sh.name) + '.csv', new Blob(['﻿' + toCSV(sh, ',')], { type: 'text/csv;charset=utf-8' })); break;
        case 'tsv': ui.download(safeName(base + ' - ' + sh.name) + '.tsv', new Blob(['﻿' + toCSV(sh, '\t')], { type: 'text/tab-separated-values;charset=utf-8' })); break;
        case 'json': ui.download(safeName(base + ' - ' + sh.name) + '.json', new Blob([toJSON(sh)], { type: 'application/json' })); break;
        case 'md': ui.download(safeName(base + ' - ' + sh.name) + '.md', new Blob([toMarkdown(sh)], { type: 'text/markdown;charset=utf-8' })); break;
        case 'html': ui.download(base + '.html', new Blob([toHTML()], { type: 'text/html;charset=utf-8' })); break;
        case 'isheet': ui.download(base + '.isheet', new Blob([JSON.stringify({ format: 'india-sheets', version: 2, book: wb })], { type: 'application/json' })); break;
        case 'locked': {
          const body = '<p>Only someone with the password can open this file (in India Sheets). Keep the password safe – it cannot be recovered.</p><label class="field"><span>Password</span><input id="pw1" type="password" autocomplete="new-password"></label><label class="field"><span>Type it again</span><input id="pw2" type="password" autocomplete="new-password"></label>';
          let pass = null;
          const ok = await ui.modal({ title: 'Download a password-protected file', body, actions: [{ label: 'Cancel', value: null }, { label: 'Download', primary: true, value: 'ok', onClick: b => { const a = b.querySelector('#pw1').value, c = b.querySelector('#pw2').value; if (a.length < 4) { ui.toast('Use at least 4 characters.', { type: 'error' }); return false; } if (a !== c) { ui.toast('The two passwords do not match.', { type: 'error' }); return false; } pass = a; return true; } }] });
          if (ok !== 'ok') return;
          ui.busy('Locking…');
          const enc = await encrypt(JSON.stringify({ format: 'india-sheets', version: 2, book: wb }), pass);
          ui.done(); ui.download(base + ' (locked).isheet', new Blob([JSON.stringify(enc)], { type: 'application/json' }));
          ui.toast('Password-protected file downloaded 🔒');
          break;
        }
        case 'png': await exportPNG(); break;
        case 'pdf': printDialog('pdf'); break;
        default: ui.toast('Unknown format ' + fmt);
      }
    } catch (e) { ui.done(); console.error(e); ui.toast('Download failed: ' + (e.message || e), { type: 'error' }); }
  }

  // =================================================================== PRINT / PDF ENGINE
  const PAPERS = { A4: [8.27, 11.69], A3: [11.69, 16.54], A5: [5.83, 8.27], Letter: [8.5, 11], Legal: [8.5, 14] };
  const MARGINS = { normal: { t: 0.75, b: 0.75, l: 0.6, r: 0.6 }, narrow: { t: 0.5, b: 0.5, l: 0.3, r: 0.3 }, wide: { t: 1, b: 1, l: 1, r: 1 } };
  const DPI = 96;
  function defaultSettings(sh) { return Object.assign({ what: 'sheet', paper: 'A4', orient: 'portrait', fit: 'width', scale: 100, margins: 'normal', grid: false, headings: false, repeat: true, center: true, header: '{sheet}', footer: 'Page {page} of {pages}' }, sh.print || {}); }
  function areaFor(sh, set) {
    if (set.what === 'selection') { const R = IS.selRect(); const u = IS.usedRange(sh); return { t: R.t, l: R.l, b: Math.min(R.b, Math.max(u.b, R.t)), r: Math.min(R.r, Math.max(u.r, R.l)) }; }
    if (set.what === 'range' && set.range) { const p = X.parseRef(set.range); if (p) return { t: p.r1, l: p.c1, b: p.r2 === Infinity ? IS.usedRange(sh).b : p.r2, r: p.c2 === Infinity ? IS.usedRange(sh).r : p.c2 }; }
    const u = IS.usedRange(sh);
    let b = u.b, r = u.r;
    (sh.objects || []).forEach(o => { // include charts / pictures
      let rr = o.r, h = (o.dy || 0) + o.h; while (h > 0 && rr < sh.rows) { h -= (sh.rowH[rr] || (sh.rowHa && sh.rowHa[rr]) || 24); rr++; } b = Math.max(b, rr - 1);
      let cc = o.c, w = (o.dx || 0) + o.w; while (w > 0 && cc < sh.cols) { w -= (sh.colW[cc] != null ? sh.colW[cc] : 100); cc++; } r = Math.max(r, cc - 1);
    });
    return { t: 0, l: 0, b, r };
  }
  function paginate(sh, set) {
    const area = areaFor(sh, set);
    let [W, H] = PAPERS[set.paper] || PAPERS.A4; if (set.orient === 'landscape') [W, H] = [H, W];
    const m = MARGINS[set.margins] || MARGINS.normal;
    const pageW = (W - m.l - m.r) * DPI, pageH = (H - m.t - m.b) * DPI;
    const colW = c => (IS.colVisible(sh, c) ? (sh.colW[c] != null ? sh.colW[c] : 100) : 0);
    const rowH = r => (IS.rowVisible(sh, r) ? (sh.rowH[r] != null ? sh.rowH[r] : (sh.rowHa && sh.rowHa[r]) || 24) : 0);
    const cols = [], rows = [];
    for (let c = area.l; c <= area.r; c++) { const w = colW(c); if (w > 0) cols.push({ c, w }); }
    for (let r = area.t; r <= area.b; r++) { const h = rowH(r); if (h > 0) rows.push({ r, h }); }
    const headW = set.headings ? 36 : 0, headH = set.headings ? 18 : 0;
    const totalW = cols.reduce((s, x) => s + x.w, 0) + headW, totalH = rows.reduce((s, x) => s + x.h, 0) + headH;
    let scale = set.fit === 'width' ? Math.min(1, pageW / totalW) : set.fit === 'page' ? Math.min(1, pageW / totalW, pageH / totalH) : Math.max(0.1, (+set.scale || 100) / 100);
    scale = Math.max(0.1, scale);
    const availW = pageW / scale - headW, availH = pageH / scale - headH;
    const colGroups = []; let cur = [], acc = 0;
    for (const col of cols) { if (acc + col.w > availW && cur.length) { colGroups.push(cur); cur = []; acc = 0; } cur.push(col); acc += col.w; }
    if (cur.length) colGroups.push(cur);
    const repeatRow = set.repeat && rows.length > 2 && sh.cells && (IS.detectHeader ? IS.detectHeader(sh, area) : false) ? rows[0] : null;
    const rowGroups = []; cur = []; acc = 0;
    for (const row of rows) {
      const limit = availH - (rowGroups.length && repeatRow ? repeatRow.h : 0);
      if (acc + row.h > limit && cur.length) { rowGroups.push(cur); cur = []; acc = 0; }
      cur.push(row); acc += row.h;
    }
    if (cur.length) rowGroups.push(cur);
    const pages = [];
    if (!cols.length || !rows.length) return { pages: [], W, H, m, scale, headW, headH, area, colW, rowH };
    colGroups.forEach(cg => rowGroups.forEach((rg, i) => pages.push({ cols: cg, rows: i && repeatRow ? [repeatRow].concat(rg) : rg })));
    return { pages, W, H, m, scale, headW, headH, area, colW, rowH, pageW, pageH };
  }
  async function renderPage(sh, L, page, idx, total, set, k) {
    const pxW = L.W * DPI, pxH = L.H * DPI;
    const cv = document.createElement('canvas'); cv.width = Math.round(pxW * k); cv.height = Math.round(pxH * k);
    const g = cv.getContext('2d'); g.scale(k, k);
    g.fillStyle = '#ffffff'; g.fillRect(0, 0, pxW, pxH);
    const tokens = s => String(s || '').replace(/\{page\}/g, idx + 1).replace(/\{pages\}/g, total).replace(/\{sheet\}/g, sh.name).replace(/\{file\}/g, IS.wb.name).replace(/\{date\}/g, new Date().toLocaleDateString('en-IN')).replace(/\{time\}/g, new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }));
    g.fillStyle = '#5f6b65'; g.font = '10px "Segoe UI", "Nirmala UI", Arial, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
    if (set.header) g.fillText(tokens(set.header), pxW / 2, L.m.t * DPI / 2);
    if (set.footer) g.fillText(tokens(set.footer), pxW / 2, pxH - L.m.b * DPI / 2);
    g.textAlign = 'left';
    const s = L.scale;
    const contentW = page.cols.reduce((a, x) => a + x.w, 0) + L.headW, contentH = page.rows.reduce((a, x) => a + x.h, 0) + L.headH;
    const ox = L.m.l * DPI + (set.center ? Math.max(0, (L.pageW - contentW * s) / 2) : 0), oy = L.m.t * DPI;
    g.save(); g.translate(ox, oy); g.scale(s, s);
    // positions for every column/row of the area, relative to this page
    const firstC = page.cols[0].c, firstR = page.rows[0].r;
    const colPos = new Map(), rowPos = new Map();
    let x = L.headW; page.cols.forEach(cl => { colPos.set(cl.c, { x, w: cl.w }); x += cl.w; });
    let y = L.headH; page.rows.forEach(rw => { rowPos.set(rw.r, { y, h: rw.h }); y += rw.h; });
    const colX = c => { if (colPos.has(c)) return colPos.get(c).x; if (c < firstC) { let xx = L.headW; for (let i = c; i < firstC; i++) xx -= L.colW(i); return xx; } let xx = x; const lastC = page.cols[page.cols.length - 1].c; for (let i = lastC + 1; i < c; i++) xx += L.colW(i); return xx; };
    const rowY = r => { if (rowPos.has(r)) return rowPos.get(r).y; if (r < firstR) { let yy = L.headH; for (let i = r; i < firstR; i++) yy -= L.rowH(i); return yy; } let yy = y; const lastR = page.rows[page.rows.length - 1].r; for (let i = lastR + 1; i < r; i++) yy += L.rowH(i); return yy; };
    const prevF = IS.state.showFormulas; IS.state.showFormulas = false;
    const src = IS.cellSource(sh);
    IS.state.showFormulas = prevF;
    const P = { src, z: 1, grid: !!set.grid, theme: IS.GridPaint.LIGHT, print: true, rows: page.rows.map(rw => ({ r: rw.r, y: rowPos.get(rw.r).y, h: rw.h })), cols: page.cols.map(cl => ({ c: cl.c, x: colPos.get(cl.c).x, w: cl.w })), colX, cw: L.colW, rowY, rh: L.rowH, maxCol: page.cols[page.cols.length - 1].c, minCol: page.cols[0].c };
    g.save(); g.beginPath(); g.rect(L.headW, L.headH, contentW - L.headW, contentH - L.headH); g.clip();
    IS.GridPaint.paintCells(g, P);
    // repeated header row: draw it again on top if it is not the natural first row on this page
    if (IS.paintObjects) await IS.paintObjects(g, sh, c => colX(c), r => rowY(r), L.area, k * s);
    g.restore();
    if (L.headW) {
      g.fillStyle = '#f3f5f4'; g.fillRect(0, 0, contentW, L.headH); g.fillRect(0, 0, L.headW, contentH);
      g.fillStyle = '#5f6b65'; g.font = '10px "Segoe UI", Arial'; g.textAlign = 'center'; g.textBaseline = 'middle'; g.strokeStyle = '#d5dbd8'; g.lineWidth = 1;
      P.cols.forEach(cl => { g.fillText(X.numToCol(cl.c), cl.x + cl.w / 2, L.headH / 2); g.strokeRect(cl.x + 0.5, 0.5, cl.w, L.headH); });
      P.rows.forEach(rw => { g.fillText(String(rw.r + 1), L.headW / 2, rw.y + rw.h / 2); g.strokeRect(0.5, rw.y + 0.5, L.headW, rw.h); });
      g.textAlign = 'left';
    }
    g.restore();
    return cv;
  }
  async function renderAll(set, k, onPage) {
    const wb = IS.wb;
    const sheets = set.what === 'all' ? wb.sheets.filter(s => !s.hidden) : [IS.sheet];
    const jobs = [];
    sheets.forEach(sh => { const L = paginate(sh, Object.assign({}, set, set.what === 'all' ? { what: 'sheet' } : {})); L.pages.forEach(p => jobs.push({ sh, L, p })); });
    const out = [];
    for (let i = 0; i < jobs.length; i++) {
      const j = jobs[i];
      const cv = await renderPage(j.sh, j.L, j.p, i, jobs.length, set, k);
      out.push({ canvas: cv, W: j.L.W, H: j.L.H });
      if (onPage) onPage(i, jobs.length, cv);
      if (i % 2) await ui.nextFrame();
    }
    return out;
  }
  // ---- minimal PDF writer (JPEG pages)
  function pdfString(s) { let hex = 'FEFF'; for (const ch of String(s)) { const cp = ch.codePointAt(0); if (cp > 0xFFFF) { const v = cp - 0x10000; hex += (0xD800 + (v >> 10)).toString(16).padStart(4, '0') + (0xDC00 + (v & 0x3FF)).toString(16).padStart(4, '0'); } else hex += cp.toString(16).padStart(4, '0'); } return '<' + hex.toUpperCase() + '>'; }
  async function buildPDF(pages, title) {
    const enc = new TextEncoder(); const chunks = []; let offset = 0; const offsets = [];
    const push = d => { const b = typeof d === 'string' ? enc.encode(d) : d; chunks.push(b); offset += b.length; };
    push(new Uint8Array([0x25, 0x50, 0x44, 0x46, 0x2D, 0x31, 0x2E, 0x34, 0x0A, 0x25, 0xE2, 0xE3, 0xCF, 0xD3, 0x0A]));
    const obj = (n, body) => { offsets[n] = offset; push(n + ' 0 obj\n' + body + '\nendobj\n'); };
    const n = pages.length;
    obj(1, '<< /Type /Catalog /Pages 2 0 R >>');
    obj(2, '<< /Type /Pages /Kids [' + pages.map((_, i) => (3 + 3 * i) + ' 0 R').join(' ') + '] /Count ' + n + ' >>');
    for (let i = 0; i < n; i++) {
      const p = pages[i], num = 3 + 3 * i;
      const W = (p.W * 72).toFixed(2), H = (p.H * 72).toFixed(2);
      obj(num, '<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ' + W + ' ' + H + '] /Resources << /XObject << /Im' + i + ' ' + (num + 2) + ' 0 R >> /ProcSet [/PDF /ImageC] >> /Contents ' + (num + 1) + ' 0 R >>');
      const content = 'q ' + W + ' 0 0 ' + H + ' 0 0 cm /Im' + i + ' Do Q';
      obj(num + 1, '<< /Length ' + content.length + ' >>\nstream\n' + content + '\nendstream');
      const blob = await new Promise(res => p.canvas.toBlob(res, 'image/jpeg', 0.92));
      const bytes = new Uint8Array(await blob.arrayBuffer());
      offsets[num + 2] = offset;
      push((num + 2) + ' 0 obj\n<< /Type /XObject /Subtype /Image /Width ' + p.canvas.width + ' /Height ' + p.canvas.height + ' /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ' + bytes.length + ' >>\nstream\n');
      push(bytes); push('\nendstream\nendobj\n');
    }
    const info = 3 + 3 * n;
    const d = new Date(), pad = x => String(x).padStart(2, '0');
    obj(info, '<< /Title ' + pdfString(title) + ' /Producer ' + pdfString('India Sheets') + ' /Creator ' + pdfString('India Sheets') + ' /CreationDate (D:' + d.getFullYear() + pad(d.getMonth() + 1) + pad(d.getDate()) + pad(d.getHours()) + pad(d.getMinutes()) + pad(d.getSeconds()) + ') >>');
    const xref = offset, size = info + 1;
    let x = 'xref\n0 ' + size + '\n0000000000 65535 f \n';
    for (let i = 1; i < size; i++) x += String(offsets[i]).padStart(10, '0') + ' 00000 n \n';
    push(x); push('trailer\n<< /Size ' + size + ' /Root 1 0 R /Info ' + info + ' 0 R >>\nstartxref\n' + xref + '\n%%EOF\n');
    return new Blob(chunks, { type: 'application/pdf' });
  }
  async function printPages(set) {
    ui.busy('Preparing pages…'); await ui.nextFrame();
    try {
      const pages = await renderAll(set, 2.2, (i, n) => { $('busyText').textContent = 'Preparing page ' + (i + 1) + ' of ' + n + '…'; });
      if (!pages.length) { ui.done(); ui.toast('Nothing to print – the sheet is empty.'); return; }
      const urls = await Promise.all(pages.map(p => new Promise(res => p.canvas.toBlob(b => res(URL.createObjectURL(b)), 'image/png'))));
      const W = pages[0].W, H = pages[0].H;
      const frame = document.createElement('iframe'); frame.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden';
      document.body.appendChild(frame);
      const doc = frame.contentDocument;
      doc.open();
      doc.write('<!doctype html><html><head><meta charset="utf-8"><title>' + esc(IS.wb.name) + '</title><style>@page{size:' + W + 'in ' + H + 'in;margin:0}html,body{margin:0;padding:0}img{display:block;width:' + W + 'in;height:' + H + 'in;page-break-after:always;break-after:page}img:last-child{page-break-after:auto;break-after:auto}</style></head><body>' + urls.map(u => '<img src="' + u + '">').join('') + '</body></html>');
      doc.close();
      await Promise.all([...doc.images].map(img => (img.complete ? Promise.resolve() : new Promise(r => { img.onload = r; img.onerror = r; }))));
      ui.done();
      frame.contentWindow.focus(); frame.contentWindow.print();
      setTimeout(() => { urls.forEach(u => URL.revokeObjectURL(u)); frame.remove(); }, 60000);
    } catch (e) { ui.done(); console.error(e); ui.toast('Printing failed: ' + (e.message || e), { type: 'error' }); }
  }
  async function savePDF(set) {
    ui.busy('Creating PDF…'); await ui.nextFrame();
    try {
      const pages = await renderAll(set, 2, (i, n) => { $('busyText').textContent = 'Creating PDF – page ' + (i + 1) + ' of ' + n + '…'; });
      if (!pages.length) { ui.done(); ui.toast('Nothing to export – the sheet is empty.'); return; }
      const blob = await buildPDF(pages, IS.wb.name + (set.what === 'all' ? '' : ' – ' + IS.sheet.name));
      ui.done();
      ui.download(safeName(IS.wb.name + (set.what === 'all' ? '' : ' - ' + IS.sheet.name)) + '.pdf', blob);
      ui.toast('PDF downloaded (' + pages.length + ' page' + (pages.length > 1 ? 's' : '') + ').');
    } catch (e) { ui.done(); console.error(e); ui.toast('PDF failed: ' + (e.message || e), { type: 'error' }); }
  }
  function printDialog(mode) {
    const sh = IS.sheet; const set = defaultSettings(sh);
    const R = IS.selRect(), s0 = IS.state.sel, m0 = IS.mergeAt(sh, s0.r, s0.c);
    const oneCell = (R.t === R.b && R.l === R.r) || (m0 && m0.r === R.t && m0.c === R.l && m0.r2 === R.b && m0.c2 === R.r);
    set.what = !oneCell && mode !== 'pdf' ? 'selection' : 'sheet';
    const body = document.createElement('div');
    body.innerHTML = `<div class="print-wrap"><div>
      <label class="field"><span>Print</span><select id="pWhat"><option value="sheet">This sheet</option><option value="selection">Selected cells</option><option value="all">All sheets</option><option value="range">A range…</option></select></label>
      <label class="field" id="pRangeWrap"><span>Range</span><input id="pRange" class="mono" placeholder="A1:H40" value="${esc(set.range || '')}"></label>
      <div class="row"><label class="field"><span>Paper</span><select id="pPaper">${Object.keys(PAPERS).map(p => `<option>${p}</option>`).join('')}</select></label>
      <label class="field"><span>Orientation</span><select id="pOrient"><option value="portrait">Portrait</option><option value="landscape">Landscape</option></select></label></div>
      <div class="row"><label class="field"><span>Scale</span><select id="pFit"><option value="width">Fit to page width</option><option value="page">Fit everything on one page</option><option value="custom">Custom %</option></select></label>
      <label class="field" id="pScaleWrap" style="max-width:90px"><span>%</span><input id="pScale" type="number" min="10" max="400" value="${set.scale}"></label></div>
      <label class="field"><span>Margins</span><select id="pMargins"><option value="normal">Normal</option><option value="narrow">Narrow</option><option value="wide">Wide</option></select></label>
      <label class="check"><input type="checkbox" id="pGrid"> Show gridlines</label>
      <label class="check"><input type="checkbox" id="pHead"> Row numbers & column letters</label>
      <label class="check"><input type="checkbox" id="pRepeat"> Repeat the header row on every page</label>
      <label class="check"><input type="checkbox" id="pCenter"> Centre on the page</label>
      <label class="field"><span>Header</span><input id="pHeader" value="${esc(set.header)}"></label>
      <label class="field"><span>Footer</span><input id="pFooter" value="${esc(set.footer)}"></label>
      <p class="hint">Codes: {page} {pages} {sheet} {file} {date} {time}</p>
    </div><div><div class="print-count" id="pCount">Preparing preview…</div><div class="print-pages" id="pPages"></div></div></div>`;
    const q = s => body.querySelector(s);
    q('#pWhat').value = set.what; q('#pPaper').value = set.paper; q('#pOrient').value = set.orient; q('#pFit').value = set.fit === 'width' || set.fit === 'page' ? set.fit : 'custom';
    q('#pMargins').value = set.margins; q('#pGrid').checked = !!set.grid; q('#pHead').checked = !!set.headings; q('#pRepeat').checked = set.repeat !== false; q('#pCenter').checked = set.center !== false;
    const read = () => { Object.assign(set, { what: q('#pWhat').value, range: q('#pRange').value.trim(), paper: q('#pPaper').value, orient: q('#pOrient').value, fit: q('#pFit').value, scale: +q('#pScale').value || 100, margins: q('#pMargins').value, grid: q('#pGrid').checked, headings: q('#pHead').checked, repeat: q('#pRepeat').checked, center: q('#pCenter').checked, header: q('#pHeader').value, footer: q('#pFooter').value }); q('#pRangeWrap').hidden = set.what !== 'range'; q('#pScaleWrap').hidden = set.fit !== 'custom'; };
    let token = 0;
    const preview = async () => {
      read(); const my = ++token;
      const box = q('#pPages'); box.innerHTML = '';
      const pages = await renderAll(set, 0.6, (i, n, cv) => { if (my !== token) return; cv.style.width = '100%'; cv.style.maxWidth = (set.orient === 'landscape' ? 520 : 380) + 'px'; const img = document.createElement('img'); img.src = cv.toDataURL('image/png'); img.alt = 'Page ' + (i + 1); img.style.width = cv.style.maxWidth; box.appendChild(img); });
      if (my !== token) return;
      q('#pCount').textContent = pages.length ? pages.length + ' page' + (pages.length > 1 ? 's' : '') + ' · ' + set.paper + ' ' + set.orient : 'Nothing to print';
    };
    let tm = null; const later = () => { clearTimeout(tm); tm = setTimeout(preview, 250); };
    body.addEventListener('change', later); body.addEventListener('input', e => { if (e.target.id === 'pHeader' || e.target.id === 'pFooter' || e.target.id === 'pScale' || e.target.id === 'pRange') later(); });
    const remember = () => { read(); const keep = Object.assign({}, set); delete keep.what; delete keep.range; sh.print = keep; IS.markDirty(true); };
    ui.modal({
      title: mode === 'pdf' ? 'Download PDF' : 'Print', body, wide: true, onOpen: () => { read(); preview(); },
      actions: [{ label: 'Cancel', value: null }, { label: 'Download PDF', primary: mode === 'pdf', onClick: () => { remember(); setTimeout(() => savePDF(Object.assign({}, set)), 50); return true; } }, { label: 'Print', primary: mode !== 'pdf', onClick: () => { remember(); setTimeout(() => printPages(Object.assign({}, set)), 50); return true; } }]
    });
  }
  async function exportPNG() {
    const sh = IS.sheet; let R = IS.selRect();
    if (R.t === R.b && R.l === R.r) { const u = IS.usedRange(sh); if (u.empty) { ui.toast('Nothing to export.'); return; } R = u; }
    const set = { what: 'range', range: X.numToCol(R.l) + (R.t + 1) + ':' + X.numToCol(R.r) + (R.b + 1), paper: 'A4', orient: 'portrait', fit: 'custom', scale: 100, margins: 'narrow', grid: true, headings: false, repeat: false, center: false, header: '', footer: '' };
    // one page as big as the range
    const L = paginate(sh, set); if (!L.pages.length) return;
    const allCols = [], allRows = []; L.pages.forEach(p => { p.cols.forEach(c => { if (!allCols.find(x => x.c === c.c)) allCols.push(c); }); p.rows.forEach(r => { if (!allRows.find(x => x.r === r.r)) allRows.push(r); }); });
    allCols.sort((a, b) => a.c - b.c); allRows.sort((a, b) => a.r - b.r);
    const w = allCols.reduce((s, c) => s + c.w, 0), h = allRows.reduce((s, r) => s + r.h, 0);
    if (w * h > 40e6) { ui.toast('That area is too large for a picture. Select a smaller range.', { type: 'error' }); return; }
    const L2 = Object.assign({}, L, { W: (w + 2) / DPI, H: (h + 2) / DPI, m: { t: 0, b: 0, l: 0, r: 0 }, scale: 1, headW: 0, headH: 0, pageW: w });
    ui.busy('Creating picture…'); await ui.nextFrame();
    const cv = await renderPage(sh, L2, { cols: allCols, rows: allRows }, 0, 1, set, 2);
    ui.done();
    cv.toBlob(b => ui.download(safeName(IS.wb.name + ' - ' + sh.name) + '.png', b), 'image/png');
  }
  IS.printTools = { paginate, renderAll, buildPDF };

  // =================================================================== drag & drop, launch from Windows "Open with"
  IS.on('ready', () => {
    const host = $('gridHost');
    host.addEventListener('dragover', e => { if (e.dataTransfer && [...e.dataTransfer.types].includes('Files')) { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; } });
    host.addEventListener('drop', e => { const files = [...(e.dataTransfer.files || [])]; if (!files.length) return; e.preventDefault(); openFiles(files); });
    if ('launchQueue' in global && global.launchQueue.setConsumer) {
      global.launchQueue.setConsumer(async params => {
        if (!params.files || !params.files.length) return;
        const files = await Promise.all(params.files.map(h => h.getFile()));
        openFiles(files);
      });
    }
  });
  Object.assign(IS.cmd, {
    openFile: () => openFile(), importSheet: () => openFile({ into: true }), importUrl,
    download, print: () => printDialog('print'), pageSetup: () => printDialog('print'), exportPDF: () => printDialog('pdf')
  });
  IS.io = { toXLSXBook, readFile, sheetFromRows, toCSV, toHTML, sheetHTML };
})(window);
