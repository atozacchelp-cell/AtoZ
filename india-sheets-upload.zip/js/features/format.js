/* India Sheets – Format cells dialog, conditional formatting, data validation, format as table */
(function (global) {
  'use strict';
  const IS = global.IS, ui = IS.ui, X = global.Formula, esc = ui.esc;
  const $ = id => document.getElementById(id);
  const A1R = R => X.numToCol(R.l) + (R.t + 1) + (R.t !== R.b || R.l !== R.r ? ':' + X.numToCol(R.r) + (R.b + 1) : '');
  function parseRanges(text) {
    const out = [];
    for (const part of String(text || '').split(/[,;]/)) {
      const p = X.parseRef(part.trim()); if (!p) return null;
      if (p.sheet && p.sheet.toUpperCase() !== IS.sheet.name.toUpperCase()) return null;
      out.push({ t: p.r1, l: p.c1, b: p.r2 === Infinity ? IS.sheet.rows - 1 : p.r2, r: p.c2 === Infinity ? IS.sheet.cols - 1 : p.c2 });
    }
    return out.length ? out : null;
  }
  const rangesText = ranges => ranges.map(A1R).join(', ');
  IS.parseRanges = parseRanges; IS.rangesText = rangesText;

  // =================================================================== Format cells (Ctrl+1)
  const DATE_PATTERNS = [['dd-mm-yyyy', '25-11-2026'], ['dd/mm/yyyy', '25/11/2026'], ['dd.mm.yyyy', '25.11.2026'], ['d mmm yyyy', '25 Nov 2026'], ['dd-mmm-yy', '25-Nov-26'], ['d mmmm yyyy', '25 November 2026'], ['dddd, d mmmm yyyy', 'Wednesday, 25 November 2026'], ['mmm-yy', 'Nov-26'], ['mmmm yyyy', 'November 2026'], ['yyyy-mm-dd', '2026-11-25'], ['mm/dd/yyyy', '11/25/2026 (US)'], ['dd-mm-yyyy hh:mm', '25-11-2026 15:45']];
  const TIME_PATTERNS = [['h:mm AM/PM', '3:45 PM'], ['h:mm:ss AM/PM', '3:45:30 PM'], ['hh:mm', '15:45'], ['hh:mm:ss', '15:45:30'], ['[h]:mm', '27:30 (over 24 h)']];
  function detectCategory(nf) {
    if (!nf) return { cat: 'general' };
    if (nf === '[INRSHORT]') return { cat: 'short' };
    if (nf === '@') return { cat: 'text' };
    if (X.isDateFormat(nf)) return X.isTimeOnlyFormat(nf) ? { cat: 'time', pat: nf } : { cat: 'date', pat: nf };
    const first = nf.split(';')[0];
    const dec = ((first.split('.')[1] || '').match(/[0#]/g) || []).length;
    const sep = first.includes(',');
    if (/E\+/i.test(first)) return { cat: 'sci', dec };
    if (/%/.test(first)) return { cat: 'pct', dec };
    const neg = /\[Red\]\(/.test(nf) ? 'redparen' : /\[Red\]/.test(nf) ? 'red' : /;\(/.test(nf) ? 'paren' : 'minus';
    if (/"-"\s*$/.test(nf) && /₹/.test(nf)) return { cat: 'acct', dec };
    if (/₹/.test(first)) return { cat: 'rupee', dec, sep, neg };
    if (/^[#0,.]+$/.test(first)) return { cat: 'number', dec, sep, neg };
    return { cat: 'custom', code: nf };
  }
  function buildCode(o) {
    const d = o.dec > 0 ? '.' + '0'.repeat(o.dec) : '';
    const base = (o.sep ? '#,##0' : '0') + d;
    const withNeg = b => (o.neg === 'paren' ? b + ';(' + b + ')' : o.neg === 'red' ? b + ';[Red]-' + b : o.neg === 'redparen' ? b + ';[Red](' + b + ')' : b);
    switch (o.cat) {
      case 'general': return null;
      case 'number': return withNeg(base);
      case 'rupee': return withNeg('"₹"' + base);
      case 'short': return '[INRSHORT]';
      case 'acct': return '"₹"' + base + ';[Red]("₹"' + base + ');"-"';
      case 'pct': return '0' + d + '%';
      case 'sci': return '0' + d + 'E+00';
      case 'date': return o.pat || 'dd-mm-yyyy';
      case 'time': return o.pat || 'h:mm AM/PM';
      case 'text': return '@';
      case 'custom': return o.code || null;
    }
    return null;
  }
  function formatCells(startTab) {
    const sh = IS.sheet, s = IS.state.sel, cell = sh.cells[IS.K(s.r, s.c)] || {}, st = cell.s || {};
    const v = IS.calc.value(sh, s.r, s.c);
    const sample = typeof X.norm(v) === 'number' ? X.norm(v) : (typeof X.norm(v) === 'string' && X.norm(v) ? X.norm(v) : 1234567.891);
    const det = Object.assign({ dec: 2, sep: true, neg: 'minus', pat: null, code: st.nf || '' }, detectCategory(st.nf));
    if (det.cat === 'general' && typeof sample === 'number') det.dec = 2;
    const ch = {}; // changed properties
    const body = document.createElement('div');
    body.innerHTML = `
      <div class="tabs-h" role="tablist">${['Number', 'Alignment', 'Font', 'Border', 'Fill', 'Protection'].map((t, i) => `<button type="button" data-tab="${i}">${t}</button>`).join('')}</div>
      <div data-pane="0">
        <div class="row">
          <label class="field" style="max-width:190px"><span>Category</span><select id="fcCat" size="11" style="height:auto">
            ${[['general', 'Automatic (General)'], ['number', 'Number'], ['rupee', 'Rupees ₹'], ['short', 'Short ₹ (K / L / Cr)'], ['acct', 'Accounting ₹'], ['pct', 'Percent %'], ['sci', 'Scientific'], ['date', 'Date'], ['time', 'Time'], ['text', 'Text'], ['custom', 'Custom code']].map(([k, l]) => `<option value="${k}">${l}</option>`).join('')}
          </select></label>
          <div style="flex:1;min-width:220px">
            <div class="field"><span>Preview</span><div id="fcPreview" class="preview-box mono"></div></div>
            <div id="fcNumOpts">
              <div class="row"><label class="field"><span>Decimal places</span><input id="fcDec" type="number" min="0" max="10"></label>
              <label class="check" id="fcSepWrap"><input type="checkbox" id="fcSep"> Use 1,00,000 separator</label></div>
              <label class="field" id="fcNegWrap"><span>Negative numbers</span><select id="fcNeg"><option value="minus">-1,234.10</option><option value="red">-1,234.10 in red</option><option value="paren">(1,234.10)</option><option value="redparen">(1,234.10) in red</option></select></label>
            </div>
            <label class="field" id="fcDateWrap"><span>Date style</span><select id="fcDate">${DATE_PATTERNS.map(([c, l]) => `<option value="${esc(c)}">${esc(l)}</option>`).join('')}</select></label>
            <label class="field" id="fcTimeWrap"><span>Time style</span><select id="fcTime">${TIME_PATTERNS.map(([c, l]) => `<option value="${esc(c)}">${esc(l)}</option>`).join('')}</select></label>
            <label class="field" id="fcCodeWrap"><span>Format code (Excel style)</span><input id="fcCode" class="mono" placeholder='e.g. "₹"#,##0.00;[Red]-"₹"#,##0.00'></label>
            <p class="hint" id="fcHint"></p>
          </div>
        </div>
      </div>
      <div data-pane="1">
        <div class="row">
          <label class="field"><span>Horizontal</span><select id="fcAl"><option value="">Automatic</option><option value="left">Left</option><option value="center">Centre</option><option value="right">Right</option></select></label>
          <label class="field"><span>Vertical</span><select id="fcVa"><option value="">Bottom</option><option value="middle">Middle</option><option value="top">Top</option></select></label>
          <label class="field"><span>Indent</span><input id="fcInd" type="number" min="0" max="10"></label>
        </div>
        <label class="check"><input type="checkbox" id="fcWrap"> Wrap text onto several lines</label>
      </div>
      <div data-pane="2">
        <div class="row">
          <label class="field"><span>Font</span><select id="fcFf"><option value="">Default (Segoe UI)</option>${['Arial', 'Calibri', 'Cambria', 'Georgia', 'Times New Roman', 'Verdana', 'Tahoma', 'Trebuchet MS', 'Courier New', 'Consolas', 'Comic Sans MS', 'Nirmala UI', 'Mangal', 'Shruti'].map(f => `<option>${f}</option>`).join('')}</select></label>
          <label class="field" style="max-width:110px"><span>Size</span><input id="fcFs" type="number" min="6" max="96"></label>
          <label class="field" style="max-width:110px"><span>Colour</span><input id="fcColor" type="color"></label>
        </div>
        <label class="check"><input type="checkbox" id="fcB"> <b>Bold</b></label>
        <label class="check"><input type="checkbox" id="fcI"> <i>Italic</i></label>
        <label class="check"><input type="checkbox" id="fcU"> <u>Underline</u></label>
        <label class="check"><input type="checkbox" id="fcSt"> <s>Strikethrough</s></label>
      </div>
      <div data-pane="3">
        <div class="style-presets" id="fcBorders">${[['all', 'All'], ['outer', 'Outside'], ['inner', 'Inside'], ['thickBox', 'Thick box'], ['top', 'Top'], ['bottom', 'Bottom'], ['doubleBottom', 'Double bottom'], ['left', 'Left'], ['right', 'Right'], ['none', 'None']].map(([k, l]) => `<button type="button" data-b="${k}">${l}</button>`).join('')}</div>
        <div class="row" style="margin-top:10px">
          <label class="field"><span>Line style</span><select id="fcBs"><option value="thin">Thin</option><option value="medium">Medium</option><option value="thick">Thick</option><option value="dashed">Dashed</option><option value="dotted">Dotted</option><option value="double">Double</option></select></label>
          <label class="field" style="max-width:110px"><span>Colour</span><input id="fcBc" type="color" value="#000000"></label>
        </div>
      </div>
      <div data-pane="4">
        <label class="field" style="max-width:140px"><span>Fill colour</span><input id="fcBg" type="color"></label>
        <label class="check"><input type="checkbox" id="fcNoFill"> No fill</label>
      </div>
      <div data-pane="5">
        <label class="check"><input type="checkbox" id="fcUnlock"> Unlocked – people can edit this cell even when the sheet is protected</label>
        <p class="hint">Protect the sheet from Data → Protect sheet. Locked cells (the default) cannot be changed while it is protected.</p>
      </div>`;
    const q = sel => body.querySelector(sel);
    const show = i => { body.querySelectorAll('[data-pane]').forEach(p => { p.hidden = p.dataset.pane !== String(i); }); body.querySelectorAll('[data-tab]').forEach(b => b.classList.toggle('on', b.dataset.tab === String(i))); };
    body.querySelectorAll('[data-tab]').forEach(b => b.onclick = () => show(+b.dataset.tab));
    show(startTab || 0);
    // number tab
    const num = Object.assign({}, det);
    const refresh = () => {
      const cat = num.cat;
      q('#fcNumOpts').hidden = !['number', 'rupee', 'pct', 'sci', 'acct'].includes(cat);
      q('#fcSepWrap').hidden = !['number', 'rupee'].includes(cat);
      q('#fcNegWrap').hidden = !['number', 'rupee'].includes(cat);
      q('#fcDateWrap').hidden = cat !== 'date'; q('#fcTimeWrap').hidden = cat !== 'time'; q('#fcCodeWrap').hidden = cat !== 'custom';
      const code = buildCode(num);
      const sv = cat === 'text' ? String(sample) : (typeof sample === 'number' ? (cat === 'date' || cat === 'time' ? (typeof X.norm(v) === 'number' ? X.norm(v) : X.nowSerial()) : sample) : sample);
      const f = X.formatValue(sv, code);
      q('#fcPreview').textContent = f.text || ' '; q('#fcPreview').style.color = f.color || '';
      q('#fcHint').textContent = code ? 'Code: ' + code : 'Shows numbers as typed, dates as dates.';
    };
    q('#fcCat').value = num.cat; q('#fcDec').value = num.dec; q('#fcSep').checked = num.sep !== false; q('#fcNeg').value = num.neg || 'minus';
    if (num.pat) { if (num.cat === 'date') q('#fcDate').value = num.pat; else q('#fcTime').value = num.pat; }
    q('#fcCode').value = st.nf || '';
    q('#fcCat').onchange = e => { num.cat = e.target.value; if (num.cat === 'custom' && !q('#fcCode').value) q('#fcCode').value = buildCode(Object.assign({}, det, { cat: det.cat === 'custom' ? 'number' : det.cat })) || '#,##0.00'; num.code = q('#fcCode').value; ch.nf = true; refresh(); };
    q('#fcDec').oninput = e => { num.dec = Math.max(0, Math.min(10, +e.target.value || 0)); ch.nf = true; refresh(); };
    q('#fcSep').onchange = e => { num.sep = e.target.checked; ch.nf = true; refresh(); };
    q('#fcNeg').onchange = e => { num.neg = e.target.value; ch.nf = true; refresh(); };
    q('#fcDate').onchange = e => { num.pat = e.target.value; ch.nf = true; refresh(); };
    q('#fcTime').onchange = e => { num.pat = e.target.value; ch.nf = true; refresh(); };
    q('#fcCode').oninput = e => { num.code = e.target.value; ch.nf = true; refresh(); };
    if (num.cat === 'date' && !num.pat) num.pat = q('#fcDate').value;
    if (num.cat === 'time' && !num.pat) num.pat = q('#fcTime').value;
    refresh();
    // other tabs
    q('#fcAl').value = st.al || ''; q('#fcVa').value = st.va || ''; q('#fcInd').value = st.ind || 0; q('#fcWrap').checked = !!st.wrap;
    q('#fcFf').value = st.ff || ''; q('#fcFs').value = st.fs || 10; q('#fcColor').value = st.color || '#1c2420';
    q('#fcB').checked = !!st.b; q('#fcI').checked = !!st.i; q('#fcU').checked = !!st.u; q('#fcSt').checked = !!st.st;
    q('#fcBg').value = st.bg || '#ffffff'; q('#fcNoFill').checked = !st.bg; q('#fcUnlock').checked = !!st.unlock;
    const track = (id, key) => q(id).addEventListener('change', () => { ch[key] = true; if (key === 'bg') q('#fcNoFill').checked = false; });
    [['#fcAl', 'al'], ['#fcVa', 'va'], ['#fcInd', 'ind'], ['#fcWrap', 'wrap'], ['#fcFf', 'ff'], ['#fcFs', 'fs'], ['#fcColor', 'color'], ['#fcB', 'b'], ['#fcI', 'i'], ['#fcU', 'u'], ['#fcSt', 'st'], ['#fcBg', 'bg'], ['#fcNoFill', 'bg'], ['#fcUnlock', 'unlock']].forEach(([id, k]) => track(id, k));
    q('#fcColor').addEventListener('input', () => { ch.color = true; });
    q('#fcBg').addEventListener('input', () => { ch.bg = true; q('#fcNoFill').checked = false; });
    let border = null;
    q('#fcBorders').addEventListener('click', e => { const b = e.target.closest('[data-b]'); if (!b) return; border = b.dataset.b; q('#fcBorders').querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b)); });
    ui.modal({
      title: 'Format cells', body, wide: true,
      actions: [{ label: 'Cancel', value: null }, {
        label: 'Apply', primary: true, onClick: () => {
          const code = buildCode(num);
          if (num.cat === 'custom' && code && X.getFmt(code) && !X.formatValue(1234.5, code).text && !/^;/.test(code)) { ui.toast('That format code does not show anything.', { type: 'error' }); return false; }
          const vals = {
            al: q('#fcAl').value || null, va: q('#fcVa').value || null, ind: +q('#fcInd').value || null, wrap: q('#fcWrap').checked || null,
            ff: q('#fcFf').value || null, fs: +q('#fcFs').value && +q('#fcFs').value !== 10 ? +q('#fcFs').value : null, color: q('#fcColor').value,
            b: q('#fcB').checked || null, i: q('#fcI').checked || null, u: q('#fcU').checked || null, st: q('#fcSt').checked || null,
            bg: q('#fcNoFill').checked ? null : q('#fcBg').value, unlock: q('#fcUnlock').checked || null, nf: code
          };
          if (Object.keys(ch).length) IS.applyStyle('Format cells', s2 => { for (const k in ch) { if (vals[k] === null || vals[k] === undefined) delete s2[k]; else s2[k] = vals[k]; } return s2; });
          if (border) { IS.state.borderStyle = q('#fcBs').value; IS.state.borderColor = q('#fcBc').value === '#000000' ? null : q('#fcBc').value; IS.setBorders(border, IS.state.borderColor, IS.state.borderStyle); }
          return true;
        }
      }]
    });
  }

  // =================================================================== conditional formatting
  const STYLE_PRESETS = [
    { name: 'Light red fill, dark red text', style: { bg: '#ffc7ce', color: '#9c0006' } },
    { name: 'Yellow fill, dark yellow text', style: { bg: '#ffeb9c', color: '#9c5700' } },
    { name: 'Green fill, dark green text', style: { bg: '#c6efce', color: '#006100' } },
    { name: 'Red text', style: { color: '#d32f2f' } },
    { name: 'Bold green text', style: { color: '#2e7d32', b: true } },
    { name: 'Blue fill', style: { bg: '#cfe2f3', color: '#1a3c8f' } },
    { name: 'Strike through', style: { st: true, color: '#8a8a8a' } }
  ];
  const SCALES = { 'Red → Yellow → Green': ['#f8696b', '#ffeb84', '#63be7b'], 'Green → Yellow → Red': ['#63be7b', '#ffeb84', '#f8696b'], 'White → Green': ['#ffffff', '#63be7b'], 'White → Red': ['#ffffff', '#f8696b'], 'Blue → White → Red': ['#5a8ac6', '#ffffff', '#f8696b'], 'White → Blue': ['#ffffff', '#5a8ac6'] };
  const BAR_COLORS = { Blue: '#4a86e8', Green: '#2e7d32', Red: '#e53935', Orange: '#fb8c00', Purple: '#8e24aa' };
  const TYPES = [
    ['cell:gt', 'Value is greater than'], ['cell:lt', 'Value is less than'], ['cell:gte', 'Value is greater than or equal'], ['cell:lte', 'Value is less than or equal'],
    ['cell:eq', 'Value is equal to'], ['cell:neq', 'Value is not equal to'], ['cell:between', 'Value is between'], ['cell:notBetween', 'Value is not between'],
    ['text:contains', 'Text contains'], ['text:notContains', 'Text does not contain'], ['text:begins', 'Text starts with'], ['text:ends', 'Text ends with'], ['text:exact', 'Text is exactly'],
    ['date:today', 'Date is today'], ['date:yesterday', 'Date is yesterday'], ['date:tomorrow', 'Date is tomorrow'], ['date:last7', 'Date in the last 7 days'], ['date:next7', 'Date in the next 7 days'], ['date:thisMonth', 'Date in this month'], ['date:lastMonth', 'Date in last month'], ['date:thisYear', 'Date in this year'], ['date:past', 'Date is overdue (in the past)'], ['date:future', 'Date is in the future'],
    ['blank:', 'Cell is empty'], ['notBlank:', 'Cell is not empty'], ['error:', 'Cell has an error'],
    ['dup:', 'Duplicate values'], ['unique:', 'Unique values'],
    ['top:n', 'Top N values'], ['bottom:n', 'Bottom N values'], ['top:pct', 'Top N %'], ['bottom:pct', 'Bottom N %'], ['above:', 'Above average'], ['below:', 'Below average'],
    ['formula:', 'Custom formula is true'],
    ['scale:', 'Colour scale'], ['bar:', 'Data bars'], ['icons:', 'Icon set']
  ];
  function describe(rule) {
    const t = TYPES.find(([k]) => { const [a, b] = k.split(':'); return a === rule.type && (b === '' || b === rule.op || (b === 'n' && !rule.pct && (rule.type === 'top' || rule.type === 'bottom')) || (b === 'pct' && rule.pct)); });
    let s = t ? t[1] : rule.type;
    if (rule.type === 'cell') s += ' ' + rule.v1 + (rule.op === 'between' || rule.op === 'notBetween' ? ' and ' + rule.v2 : '');
    if (rule.type === 'text') s += ' "' + rule.text + '"';
    if (rule.type === 'top' || rule.type === 'bottom') s = s.replace('N', rule.n);
    if (rule.type === 'formula') s += ': ' + rule.formula;
    return s;
  }
  function swatch(rule) {
    if (rule.type === 'scale') return `<span class="cf-swatch" style="background:linear-gradient(90deg,${(rule.colors || []).join(',')})"></span>`;
    if (rule.type === 'bar') return `<span class="cf-swatch" style="background:linear-gradient(90deg,${rule.color} 60%,transparent 60%)"></span>`;
    if (rule.type === 'icons') return `<span class="cf-swatch">${rule.set === 'traffic' ? '🔴🟡🟢' : '▼►▲'}</span>`;
    const st = rule.style || {};
    return `<span class="cf-swatch" style="background:${st.bg || 'transparent'};color:${st.color || 'inherit'};font-weight:${st.b ? 700 : 400};text-decoration:${st.st ? 'line-through' : 'none'}">Aa</span>`;
  }
  function addCfRule(rule, label) {
    const sh = IS.sheet; if (!IS.guardEdit(null, { structure: !!(sh.protect && sh.protect.on) })) return;
    rule.id = rule.id || IS.rid('cf');
    IS.tx(label || 'Conditional format', () => { IS.rec.meta(sh); const i = sh.cf.findIndex(r => r.id === rule.id); if (i >= 0) sh.cf[i] = rule; else sh.cf.push(rule); });
    IS.cfInvalidate(); IS.grid.invalidate();
  }
  IS.addCfRule = addCfRule;
  function cfPanel(editId) {
    const sh = IS.sheet; const R = IS.selRect();
    const wrap = document.createElement('div');
    const render = () => {
      const rules = sh.cf;
      wrap.innerHTML = `<p class="hint">Colour cells automatically based on their values. Rules at the top win.</p>
        <button type="button" class="btn primary" id="cfAdd">+ Add a rule</button>
        <h3>Rules on this sheet</h3>
        ${rules.length ? rules.map((r, i) => `<div class="cf-rule">${swatch(r)}<div class="grow"><b>${esc(describe(r))}</b><small>${esc(rangesText(r.ranges))}</small></div>
          <button type="button" class="icon-btn" data-up="${i}" title="Move up">↑</button><button type="button" class="icon-btn" data-edit="${i}" title="Edit">✎</button><button type="button" class="icon-btn" data-del="${i}" title="Delete">🗑</button></div>`).join('') : '<p class="hint">No rules yet.</p>'}`;
      wrap.querySelector('#cfAdd').onclick = () => editor(null);
      wrap.querySelectorAll('[data-del]').forEach(b => b.onclick = () => { const i = +b.dataset.del; IS.tx('Delete rule', () => { IS.rec.meta(sh); sh.cf.splice(i, 1); }); IS.cfInvalidate(); render(); });
      wrap.querySelectorAll('[data-edit]').forEach(b => b.onclick = () => editor(sh.cf[+b.dataset.edit]));
      wrap.querySelectorAll('[data-up]').forEach(b => b.onclick = () => { const i = +b.dataset.up; if (!i) return; IS.tx('Rule order', () => { IS.rec.meta(sh); const [x] = sh.cf.splice(i, 1); sh.cf.splice(i - 1, 0, x); }); IS.cfInvalidate(); render(); });
    };
    const editor = (rule) => {
      const r0 = rule ? JSON.parse(JSON.stringify(rule)) : { id: IS.rid('cf'), ranges: [R], type: 'cell', op: 'gt', v1: '', v2: '', style: STYLE_PRESETS[0].style };
      const key0 = r0.type + ':' + (r0.type === 'cell' || r0.type === 'text' || r0.type === 'date' ? r0.op : r0.type === 'top' || r0.type === 'bottom' ? (r0.pct ? 'pct' : 'n') : '');
      wrap.innerHTML = `
        <label class="field"><span>Apply to range</span><input id="cfRange" class="mono" value="${esc(rangesText(r0.ranges))}"></label>
        <label class="field"><span>Format cells if…</span><select id="cfType">${TYPES.map(([k, l]) => `<option value="${k}">${l}</option>`).join('')}</select></label>
        <div id="cfVals"></div>
        <div id="cfStyleBox"><span class="hint">Formatting style</span><div class="style-presets" id="cfPresets">${STYLE_PRESETS.map((p, i) => `<button type="button" data-p="${i}" style="background:${p.style.bg || 'transparent'};color:${p.style.color || 'inherit'};font-weight:${p.style.b ? 700 : 400};text-decoration:${p.style.st ? 'line-through' : 'none'}">${esc(p.name)}</button>`).join('')}</div>
          <div class="row" style="margin-top:8px"><label class="field"><span>Fill</span><input type="color" id="cfBg"></label><label class="field"><span>Text</span><input type="color" id="cfColor"></label></div>
          <label class="check"><input type="checkbox" id="cfBold"> Bold</label><label class="check"><input type="checkbox" id="cfNoFill"> No fill</label></div>
        <label class="check"><input type="checkbox" id="cfStop"> Stop checking lower rules when this one matches</label>
        <div class="row" style="margin-top:12px"><button type="button" class="btn" id="cfBack">Back</button><span style="flex:1"></span><button type="button" class="btn primary" id="cfSave">Save rule</button></div>`;
      const q = s => wrap.querySelector(s);
      q('#cfType').value = TYPES.some(t => t[0] === key0) ? key0 : 'cell:gt';
      const style = Object.assign({}, r0.style || {});
      const syncStyle = () => { q('#cfBg').value = style.bg || '#ffffff'; q('#cfColor').value = style.color || '#1c2420'; q('#cfBold').checked = !!style.b; q('#cfNoFill').checked = !style.bg; };
      syncStyle();
      q('#cfPresets').onclick = e => { const b = e.target.closest('[data-p]'); if (!b) return; Object.keys(style).forEach(k => delete style[k]); Object.assign(style, STYLE_PRESETS[+b.dataset.p].style); syncStyle(); q('#cfPresets').querySelectorAll('button').forEach(x => x.classList.toggle('on', x === b)); };
      q('#cfBg').oninput = e => { style.bg = e.target.value; q('#cfNoFill').checked = false; };
      q('#cfColor').oninput = e => { style.color = e.target.value; };
      q('#cfBold').onchange = e => { style.b = e.target.checked || undefined; };
      q('#cfNoFill').onchange = e => { if (e.target.checked) delete style.bg; };
      q('#cfStop').checked = !!r0.stop;
      const vals = () => {
        const [type, op] = q('#cfType').value.split(':'); const box = q('#cfVals');
        q('#cfStyleBox').hidden = ['scale', 'bar', 'icons'].includes(type);
        if (type === 'cell') box.innerHTML = `<div class="row"><label class="field"><span>Value</span><input id="cfV1" value="${esc(r0.v1 || '')}" placeholder="e.g. 1000 or =$B$1"></label>${op === 'between' || op === 'notBetween' ? `<label class="field"><span>and</span><input id="cfV2" value="${esc(r0.v2 || '')}"></label>` : ''}</div>`;
        else if (type === 'text') box.innerHTML = `<label class="field"><span>Text</span><input id="cfText" value="${esc(r0.text || '')}"></label>`;
        else if (type === 'top' || type === 'bottom') box.innerHTML = `<label class="field"><span>${op === 'pct' ? 'Percent' : 'How many'}</span><input id="cfN" type="number" min="1" value="${r0.n || 10}"></label>`;
        else if (type === 'formula') box.innerHTML = `<label class="field"><span>Formula (written for the first cell of the range)</span><input id="cfF" class="mono" value="${esc(r0.formula || '=')}" placeholder="=$D2>10000"></label><p class="hint">Example: <code>=$E2="Unpaid"</code> colours the whole row when column E says Unpaid.</p>`;
        else if (type === 'scale') box.innerHTML = `<label class="field"><span>Colours</span><select id="cfScale">${Object.keys(SCALES).map(k => `<option>${k}</option>`).join('')}</select></label>`;
        else if (type === 'bar') box.innerHTML = `<label class="field"><span>Bar colour</span><select id="cfBar">${Object.keys(BAR_COLORS).map(k => `<option>${k}</option>`).join('')}</select></label>`;
        else if (type === 'icons') box.innerHTML = `<label class="field"><span>Icons</span><select id="cfIcons"><option value="arrows">Arrows ▲ ► ▼ (high is good)</option><option value="reverse">Arrows (low is good)</option><option value="traffic">Traffic lights ● ● ●</option></select></label>`;
        else box.innerHTML = '';
        if (type === 'scale' && r0.colors) { const k = Object.keys(SCALES).find(k2 => SCALES[k2].join() === r0.colors.join()); if (k) q('#cfScale').value = k; }
        if (type === 'bar' && r0.color) { const k = Object.keys(BAR_COLORS).find(k2 => BAR_COLORS[k2] === r0.color); if (k) q('#cfBar').value = k; }
        if (type === 'icons' && r0.set) q('#cfIcons').value = r0.set;
      };
      vals(); q('#cfType').onchange = vals;
      q('#cfBack').onclick = render;
      q('#cfSave').onclick = () => {
        const ranges = parseRanges(q('#cfRange').value); if (!ranges) { ui.toast('Please enter a valid range like A2:A100', { type: 'error' }); return; }
        const [type, op] = q('#cfType').value.split(':');
        const rule = { id: r0.id, ranges, type, stop: q('#cfStop').checked || undefined };
        if (type === 'cell') { rule.op = op; rule.v1 = q('#cfV1').value.trim(); if (q('#cfV2')) rule.v2 = q('#cfV2').value.trim(); if (rule.v1 === '') { ui.toast('Enter a value to compare with.', { type: 'error' }); return; } }
        if (type === 'text') { rule.op = op; rule.text = q('#cfText').value; }
        if (type === 'date') rule.op = op;
        if (type === 'top' || type === 'bottom') { rule.n = Math.max(1, +q('#cfN').value || 10); rule.pct = op === 'pct'; }
        if (type === 'formula') { rule.formula = q('#cfF').value.trim(); if (!rule.formula.startsWith('=')) rule.formula = '=' + rule.formula; const chk = X.checkFormula(rule.formula); if (chk !== true) { ui.toast('Formula problem: ' + chk, { type: 'error' }); return; } }
        if (type === 'scale') rule.colors = SCALES[q('#cfScale').value];
        if (type === 'bar') rule.color = BAR_COLORS[q('#cfBar').value];
        if (type === 'icons') rule.set = q('#cfIcons').value;
        if (!['scale', 'bar', 'icons'].includes(type)) rule.style = IS.cleanStyle(style) || { bg: '#ffeb9c' };
        addCfRule(rule, rule === r0 ? 'Edit rule' : 'Conditional format');
        render();
      };
    };
    ui.side('Conditional formatting', wrap, { kind: 'cf' });
    if (editId === 'new') editor(null); else render();
  }

  // =================================================================== data validation
  const DV_TYPES = [['list', 'List of items (dropdown)'], ['range', 'List from a range of cells'], ['number', 'Number'], ['whole', 'Whole number'], ['date', 'Date'], ['textlen', 'Text length'], ['checkbox', 'Checkbox (tick box)'], ['custom', 'Custom formula'],
    ['gstin', '🇮🇳 Valid GSTIN'], ['pan', '🇮🇳 Valid PAN'], ['mobile', '🇮🇳 Indian mobile number'], ['pincode', '🇮🇳 PIN code'], ['ifsc', '🇮🇳 IFSC code'], ['aadhaar', '🇮🇳 Aadhaar number'], ['email', 'Email address']];
  const OPS = [['between', 'between'], ['notBetween', 'not between'], ['gt', 'greater than'], ['gte', 'greater than or equal to'], ['lt', 'less than'], ['lte', 'less than or equal to'], ['eq', 'equal to'], ['neq', 'not equal to']];
  function dataValidation(preset) {
    const sh = IS.sheet, R = IS.selRect(), s = IS.state.sel;
    const existing = IS.dvFor(sh, s.r, s.c);
    const r0 = existing ? JSON.parse(JSON.stringify(existing)) : { id: IS.rid('dv'), ranges: [R], type: preset || 'list', list: [], strict: true, arrow: true, allowBlank: true };
    if (preset && !existing) r0.type = preset;
    const body = document.createElement('div');
    body.innerHTML = `
      <label class="field"><span>Apply to range</span><input id="dvRange" class="mono" value="${esc(rangesText(existing ? existing.ranges : [R]))}"></label>
      <label class="field"><span>Allow</span><select id="dvType">${DV_TYPES.map(([k, l]) => `<option value="${k}">${l}</option>`).join('')}</select></label>
      <div id="dvVals"></div>
      <label class="check" id="dvArrowWrap"><input type="checkbox" id="dvArrow"> Show dropdown arrow in the cell</label>
      <label class="check"><input type="checkbox" id="dvBlank"> Allow empty cells</label>
      <div class="row"><label class="field"><span>If someone enters something else</span><select id="dvStrict"><option value="1">Reject it</option><option value="0">Allow it but mark it with a red corner</option></select></label></div>
      <label class="field"><span>Help message (optional)</span><input id="dvMsg" value="${esc(r0.msg || '')}" placeholder="e.g. Choose Paid or Unpaid"></label>`;
    const q = x => body.querySelector(x);
    q('#dvType').value = r0.type; q('#dvArrow').checked = r0.arrow !== false; q('#dvBlank').checked = r0.allowBlank !== false; q('#dvStrict').value = r0.strict === false ? '0' : '1';
    const vals = () => {
      const t = q('#dvType').value, box = q('#dvVals');
      q('#dvArrowWrap').hidden = !(t === 'list' || t === 'range');
      if (t === 'list') box.innerHTML = `<label class="field"><span>Items (separate with commas)</span><textarea id="dvList" rows="3" class="inp" placeholder="Paid, Unpaid, Partly paid">${esc((r0.list || []).join(', '))}</textarea></label>`;
      else if (t === 'range') box.innerHTML = `<label class="field"><span>Range with the items</span><input id="dvSrc" class="mono" value="${esc(r0.src || '')}" placeholder="Items!A2:A50"></label>`;
      else if (['number', 'whole', 'date', 'textlen'].includes(t)) box.innerHTML = `<div class="row"><label class="field"><span>Condition</span><select id="dvOp">${OPS.map(([k, l]) => `<option value="${k}">${l}</option>`).join('')}</select></label><label class="field"><span>${t === 'date' ? 'Date' : 'Value'}</span><input id="dvV1" value="${esc(r0.v1 == null ? '' : r0.v1)}" placeholder="${t === 'date' ? '01-04-2026' : '0'}"></label><label class="field" id="dvV2Wrap"><span>and</span><input id="dvV2" value="${esc(r0.v2 == null ? '' : r0.v2)}" placeholder="${t === 'date' ? '31-03-2027' : '100'}"></label></div>`;
      else if (t === 'custom') box.innerHTML = `<label class="field"><span>Formula that must be TRUE (for the first cell)</span><input id="dvF" class="mono" value="${esc(r0.formula || '=')}" placeholder="=B2<=C2"></label>`;
      else box.innerHTML = '<p class="hint">' + esc(IS.dvMessage({ type: t })) + '</p>';
      const op = q('#dvOp'); if (op) { op.value = r0.op || 'between'; const sync = () => { q('#dvV2Wrap').hidden = !['between', 'notBetween'].includes(op.value); }; op.onchange = sync; sync(); }
    };
    vals(); q('#dvType').onchange = vals;
    const actions = [{ label: 'Cancel', value: null }];
    if (existing) actions.unshift({ label: 'Remove rule', left: true, onClick: () => { IS.tx('Remove validation', () => { IS.rec.meta(sh); sh.dv = sh.dv.filter(x => x.id !== existing.id); }); IS.grid.invalidate(); return true; } });
    actions.push({
      label: 'Save', primary: true, onClick: () => {
        const ranges = parseRanges(q('#dvRange').value); if (!ranges) { ui.toast('Please enter a valid range like B2:B100', { type: 'error' }); return false; }
        const t = q('#dvType').value;
        const rule = { id: r0.id, ranges, type: t, strict: q('#dvStrict').value === '1', arrow: q('#dvArrow').checked, allowBlank: q('#dvBlank').checked, msg: q('#dvMsg').value.trim() || undefined };
        if (t === 'list') { rule.list = q('#dvList').value.split(/[,\n]/).map(x => x.trim()).filter(Boolean).map(x => { const p = X.parseInput(x); return typeof p.value === 'number' ? p.value : x; }); if (!rule.list.length) { ui.toast('Add at least one item.', { type: 'error' }); return false; } }
        if (t === 'range') { rule.src = q('#dvSrc').value.trim().replace(/^=/, ''); if (!X.parseRef(rule.src)) { ui.toast('Enter a range like Items!A2:A50', { type: 'error' }); return false; } }
        if (['number', 'whole', 'date', 'textlen'].includes(t)) { rule.op = q('#dvOp').value; rule.v1 = q('#dvV1').value.trim(); rule.v2 = q('#dvV2').value.trim(); if (t === 'date') { const a = X.parseInput(rule.v1), b = X.parseInput(rule.v2); rule.v1 = typeof a.value === 'number' ? a.value : rule.v1; rule.v2 = typeof b.value === 'number' ? b.value : rule.v2; } }
        if (t === 'custom') { rule.formula = q('#dvF').value.trim(); if (!rule.formula.startsWith('=')) rule.formula = '=' + rule.formula; }
        IS.tx('Data validation', () => {
          IS.rec.meta(sh);
          sh.dv = sh.dv.filter(x => x.id !== rule.id);
          // a newer rule replaces older rules on the same cells
          sh.dv.forEach(x => { x.ranges = x.ranges.filter(g => !ranges.some(n => g.t >= n.t && g.b <= n.b && g.l >= n.l && g.r <= n.r)); });
          sh.dv = sh.dv.filter(x => x.ranges.length);
          sh.dv.push(rule);
          if (t === 'checkbox') ranges.forEach(g => { for (let r = g.t; r <= Math.min(g.b, g.t + 5000); r++) for (let c = g.l; c <= g.r; c++) IS.editCell(sh, r, c, cell => { if (typeof cell.v !== 'boolean') { cell.v = false; delete cell.t; } cell.s = Object.assign({}, cell.s, { al: 'center' }); }); });
        });
        IS.grid.invalidate(); return true;
      }
    });
    ui.modal({ title: preset === 'list' ? 'Dropdown list' : 'Data validation', body, actions });
  }

  // =================================================================== format as table
  const THEMES = { Green: ['#0f7a3d', '#e3f3e9'], Blue: ['#1a3c8f', '#e6edf9'], Saffron: ['#e07b00', '#fff1df'], Grey: ['#455a64', '#eef2f4'], Purple: ['#6a1b9a', '#f3e8f8'], Red: ['#b71c1c', '#fdeaea'], Teal: ['#00796b', '#e0f2f1'] };
  function formatAsTable() {
    const sh = IS.sheet; let R = IS.selRect();
    if (R.t === R.b && R.l === R.r) { const reg = IS.currentRegion(sh, R.t, R.l); if (reg) R = reg; }
    const body = document.createElement('div');
    body.innerHTML = `<label class="field"><span>Range</span><input id="ftRange" class="mono" value="${esc(A1R(R))}"></label>
      <span class="hint">Colour theme</span><div class="style-presets" id="ftThemes">${Object.entries(THEMES).map(([k, [d, l]], i) => `<button type="button" data-k="${k}" class="${i ? '' : 'on'}" style="background:linear-gradient(180deg,${d} 40%,${l} 40%);color:#fff;min-width:70px">${k}</button>`).join('')}</div>
      <label class="check"><input type="checkbox" id="ftHead" checked> First row is a header</label>
      <label class="check"><input type="checkbox" id="ftBand" checked> Alternating row colours</label>
      <label class="check"><input type="checkbox" id="ftBorder" checked> Light borders</label>
      <label class="check"><input type="checkbox" id="ftFilter" checked> Add filter buttons</label>
      <label class="check"><input type="checkbox" id="ftTotal"> Add a total row (SUBTOTAL)</label>`;
    let theme = 'Green';
    body.querySelector('#ftThemes').onclick = e => { const b = e.target.closest('[data-k]'); if (!b) return; theme = b.dataset.k; body.querySelectorAll('#ftThemes button').forEach(x => x.classList.toggle('on', x === b)); };
    ui.modal({
      title: 'Format as table', body, actions: [{ label: 'Cancel', value: null }, {
        label: 'Apply', primary: true, onClick: () => {
          const rs = parseRanges(body.querySelector('#ftRange').value); if (!rs) { ui.toast('Enter a valid range', { type: 'error' }); return false; }
          const G = rs[0]; const [dark, light] = THEMES[theme];
          const head = body.querySelector('#ftHead').checked, band = body.querySelector('#ftBand').checked, bord = body.querySelector('#ftBorder').checked, total = body.querySelector('#ftTotal').checked, filt = body.querySelector('#ftFilter').checked;
          IS.tx('Format as table', () => {
            for (let r = G.t; r <= G.b; r++) for (let c = G.l; c <= G.r; c++) IS.editCell(sh, r, c, cell => {
              const s = Object.assign({}, cell.s); delete s.bg; delete s.color;
              if (head && r === G.t) { s.bg = dark; s.color = '#ffffff'; s.b = true; }
              else if (band && (r - G.t - (head ? 1 : 0)) % 2 === 1) s.bg = light;
              if (bord) s.bd = { bt: 'thin', bb: 'thin', bl: 'thin', br: 'thin', c: '#c9d3ce' };
              cell.s = s;
            });
            if (total) {
              const tr = G.b + 1;
              for (let c = G.l; c <= G.r; c++) {
                const hasNum = (() => { for (let r = G.t + (head ? 1 : 0); r <= G.b; r++) if (typeof X.norm(IS.calc.value(sh, r, c)) === 'number') return true; return false; })();
                IS.editCell(sh, tr, c, cell => {
                  if (c === G.l && !hasNum) cell.v = 'Total';
                  else if (hasNum) { cell.v = '=SUBTOTAL(9,' + X.numToCol(c) + (G.t + (head ? 2 : 1)) + ':' + X.numToCol(c) + (G.b + 1) + ')'; const src = sh.cells[IS.K(G.b, c)]; if (src && src.s && src.s.nf) cell.s = Object.assign({}, cell.s, { nf: src.s.nf }); }
                  cell.s = Object.assign({}, cell.s, { b: true, bd: { bt: 'thin', bb: 'double', c: dark } });
                });
              }
            }
          });
          if (filt && head && IS.applyFilter) IS.applyFilter({ t: G.t, l: G.l, b: G.b, r: G.r });
          return true;
        }
      }]
    });
  }

  Object.assign(IS.cmd, {
    formatCells: () => formatCells(0),
    customFormat: () => { formatCells(0); setTimeout(() => { const sel = $('dlgBody').querySelector('#fcCat'); if (sel) { sel.value = 'custom'; sel.dispatchEvent(new Event('change')); } }, 30); },
    conditionalFormat: () => cfPanel(),
    conditionalFormatNew: () => cfPanel('new'),
    dataValidation: () => dataValidation(),
    dropdownList: () => dataValidation('list'),
    formatAsTable
  });
})(window);
