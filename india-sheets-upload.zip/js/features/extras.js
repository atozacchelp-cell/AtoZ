/* India Sheets – workbooks manager, version history, protection, settings, India tools, voice, help, install/offline */
(function (global) {
  'use strict';
  const IS = global.IS, ui = IS.ui, X = global.Formula, esc = ui.esc, K = IS.K;
  const $ = id => document.getElementById(id);
  const APP_VERSION = '2.0.0';
  IS.APP_VERSION = APP_VERSION;

  // =================================================================== workbooks (home)
  async function home() {
    const list = await IS.store.list();
    const body = document.createElement('div');
    const render = (q = '') => {
      const items = list.filter(b => b.name.toLowerCase().includes(q.toLowerCase()));
      body.innerHTML = `<div class="row" style="margin-bottom:10px"><input class="inp" id="hbSearch" placeholder="Search workbooks…" value="${esc(q)}" style="flex:1">
          <button type="button" class="btn" data-a="new">${ui.icon('filePlus', 16)} New</button><button type="button" class="btn" data-a="tpl">${ui.icon('table', 16)} Template</button><button type="button" class="btn" data-a="open">${ui.icon('folder', 16)} Open file</button></div>
        <div class="list-scroll"><table class="table"><tr><th>Name</th><th>Last edited</th><th>Sheets</th><th></th></tr>
        ${items.map(b => `<tr class="clickable" data-id="${b.id}"><td><b>${esc(b.name)}</b>${b.id === IS.wb.id ? ' <span class="tag">open</span>' : ''}</td><td>${esc(ui.ago(b.updated))}</td><td>${b.sheets} · ${b.cells.toLocaleString('en-IN')} cells</td>
          <td style="white-space:nowrap"><button type="button" class="btn small" data-act="dup" data-id="${b.id}" title="Make a copy">${ui.icon('copy', 14)}</button> <button type="button" class="btn small" data-act="del" data-id="${b.id}" title="Delete">${ui.icon('trash', 14)}</button></td></tr>`).join('') || '<tr><td colspan="4" class="hint">No workbooks found.</td></tr>'}
        </table></div>
        <p class="hint">Workbooks are saved automatically on this device${IS.store.persistent ? '' : ' (this browser window does not allow saving – download your work!)'}. Use File → Download to keep a file or share it.</p>`;
      const s = body.querySelector('#hbSearch'); s.oninput = () => { const pos = s.selectionStart; render(s.value); const s2 = body.querySelector('#hbSearch'); s2.focus(); s2.setSelectionRange(pos, pos); };
    };
    render();
    body.addEventListener('click', async e => {
      const a = e.target.closest('[data-a]');
      if (a) { ui.closeModal(); if (a.dataset.a === 'new') newBook(); else if (a.dataset.a === 'tpl') IS.run('templates'); else IS.run('openFile'); return; }
      const act = e.target.closest('[data-act]');
      if (act) {
        e.stopPropagation(); const id = act.dataset.id;
        if (act.dataset.act === 'dup') { const b = await IS.store.get(id); if (!b) return; b.id = IS.store.newId(); b.name = b.name + ' (copy)'; b.created = b.updated = Date.now(); await IS.store.put(b); ui.closeModal(); home(); }
        else if (act.dataset.act === 'del') { const meta = list.find(x => x.id === id); if (!(await ui.confirm('Delete "' + (meta ? meta.name : 'this workbook') + '" and its version history from this device? This cannot be undone. (Download a copy first if you might need it.)', { ok: 'Delete', danger: true }))) { home(); return; } await IS.store.remove(id); if (id === IS.wb.id) await openMostRecent(); ui.toast('Workbook deleted'); home(); }
        return;
      }
      const row = e.target.closest('tr[data-id]');
      if (row) { ui.closeModal(); if (row.dataset.id !== IS.wb.id) { ui.busy('Opening…'); const b = await IS.store.get(row.dataset.id); ui.done(); if (b) await IS.openBook(b); } }
    });
    ui.modal({ title: 'My workbooks', body, wide: true });
  }
  async function openMostRecent() {
    const list = await IS.store.list();
    const next = list.find(b => b.id !== IS.wb.id);
    if (next) { const b = await IS.store.get(next.id); if (b) { await IS.openBook(b); return; } }
    await IS.newBookAndOpen();
  }
  async function newBook() { await IS.newBookAndOpen(); ui.toast('New workbook created', { ms: 1500 }); }
  async function copyBook() { await IS.saveNow(); const b = JSON.parse(JSON.stringify(IS.wb)); b.id = IS.store.newId(); b.name = IS.wb.name + ' (copy)'; b.created = b.updated = Date.now(); await IS.openBook(b, { save: true }); ui.toast('Copy created – you are now editing "' + b.name + '"'); }
  async function deleteBook() {
    if (!(await ui.confirm('Delete "' + IS.wb.name + '" and its version history from this device? This cannot be undone.', { ok: 'Delete', danger: true }))) return;
    const id = IS.wb.id; await IS.store.remove(id); await openMostRecent(); ui.toast('Workbook deleted');
  }

  // =================================================================== version history
  async function versionHistory() {
    await IS.saveNow();
    const bookId = IS.wb.id;
    const list = await IS.store.versions(bookId);
    const wrap = document.createElement('div');
    wrap.innerHTML = '<p class="hint">India Sheets keeps a copy of this workbook every 10 minutes while you work (last 40 copies). Preview any copy and restore it if needed.</p><button type="button" class="btn small" id="vhSave">Save a named version now</button>' +
      (list.length ? '<table class="table" style="margin-top:10px">' + list.map(v => '<tr><td><b>' + esc(v.label) + '</b><br><span class="hint">' + esc(ui.fmtDateTime(v.at)) + ' · ' + v.cells.toLocaleString('en-IN') + ' cells</span></td><td style="white-space:nowrap;text-align:right"><button type="button" class="btn small" data-prev="' + v.vid + '">Preview</button> <button type="button" class="btn small primary" data-rest="' + v.vid + '">Restore</button></td></tr>').join('') + '</table>' : '<p class="hint" style="margin-top:12px">No saved versions yet. They appear after you have worked for a while.</p>');
    ui.side('Version history', wrap, { kind: 'versions' });
    wrap.querySelector('#vhSave').onclick = saveVersion;
    wrap.addEventListener('click', async e => {
      const p = e.target.closest('[data-prev]'), r = e.target.closest('[data-rest]');
      if (p) {
        const v = await IS.store.getVersion(+p.dataset.prev); if (!v) return;
        const current = JSON.parse(JSON.stringify(IS.wb));
        await IS.openBook(v.data, { readOnly: true, readOnlyMsg: 'You are previewing an old version. Use Restore or go back to the current version.' });
        const bar = document.createElement('div');
        bar.innerHTML = '<p><b>Previewing:</b> ' + esc(v.label) + ' – ' + esc(ui.fmtDateTime(v.at)) + '</p><p class="hint">This is read-only.</p><div class="row"><button type="button" class="btn primary" id="pvRestore">Restore this version</button><button type="button" class="btn" id="pvBack">Back to current</button></div>';
        ui.side('Old version', bar, { kind: 'preview' });
        bar.querySelector('#pvBack').onclick = async () => { await IS.openBook(current); ui.closeSide(); };
        bar.querySelector('#pvRestore').onclick = () => restore(v, current);
      }
      if (r) { const v = await IS.store.getVersion(+r.dataset.rest); if (v) restore(v, JSON.parse(JSON.stringify(IS.wb))); }
    });
  }
  async function restore(v, current) {
    if (!(await ui.confirm('Restore the version from ' + ui.fmtDateTime(v.at) + '? Your current workbook is saved as a version first, so you can come back to it.', { ok: 'Restore' }))) return;
    await IS.store.addVersion(current.id, 'Before restoring ' + ui.fmtDateTime(v.at), current);
    const b = JSON.parse(JSON.stringify(v.data)); b.id = current.id; b.name = current.name; b.updated = Date.now();
    await IS.openBook(b, { save: true });
    ui.closeSide(); ui.toast('Version restored ✓');
  }
  async function saveVersion() {
    const label = await ui.prompt('Save a named version', 'Name for this version', 'Before month-end changes');
    if (label === null) return;
    await IS.saveNow();
    await IS.store.addVersion(IS.wb.id, label || 'Named version', JSON.parse(JSON.stringify(IS.wb)));
    ui.toast('Version saved: ' + (label || 'Named version'));
    if (!$('sidePanel').hidden && $('sidePanel').dataset.kind === 'versions') versionHistory();
  }

  // =================================================================== protect sheet
  async function sha(text) { const d = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text)); return [...new Uint8Array(d)].map(b => b.toString(16).padStart(2, '0')).join(''); }
  async function protectSheet() {
    const sh = IS.sheet;
    if (sh.protect && sh.protect.on) {
      let ok = true;
      if (sh.protect.hash) {
        const pass = await ui.prompt('Unprotect sheet', 'Password for "' + sh.name + '"', '', { type: 'password', ok: 'Unprotect' });
        if (pass === null) return;
        ok = (await sha(sh.protect.salt + pass)) === sh.protect.hash;
      }
      if (!ok) { ui.toast('Wrong password', { type: 'error' }); return; }
      IS.tx('Unprotect sheet', () => { IS.rec.meta(sh); sh.protect = null; });
      IS.renderTabs(); ui.toast('Sheet unprotected 🔓'); return;
    }
    const body = '<p>Stop accidental changes. Locked cells cannot be edited, and rows/columns cannot be inserted or deleted.</p><p class="hint">To leave some cells editable (for example input cells), select them first and use Format → Format cells → Protection → Unlocked.</p><label class="field"><span>Password (optional)</span><input id="ppw" type="password" autocomplete="new-password"></label>';
    let pass = '';
    const r = await ui.modal({ title: 'Protect "' + sh.name + '"', body, actions: [{ label: 'Cancel', value: null }, { label: 'Protect', primary: true, value: 'ok', onClick: b => { pass = b.querySelector('#ppw').value; return true; } }] });
    if (r !== 'ok') return;
    const salt = Math.random().toString(36).slice(2, 10);
    const hash = pass ? await sha(salt + pass) : null;
    IS.tx('Protect sheet', () => { IS.rec.meta(sh); sh.protect = { on: true, salt, hash }; });
    IS.renderTabs(); ui.toast('Sheet protected 🔒' + (pass ? ' with a password' : ''));
  }

  // =================================================================== settings
  function applyPrefs() {
    X.settings.indian = IS.prefs.get('indian', true);
    X.settings.dayFirst = IS.prefs.get('dayFirst', true);
  }
  applyPrefs();
  async function settings() {
    const est = await IS.store.estimate();
    const st = IS.Licence.status();
    const body = document.createElement('div');
    body.innerHTML = `<div class="row"><label class="field"><span>Theme</span><select id="stTheme"><option value="light">Light (white) – default</option><option value="dark">Dark (black)</option><option value="system">Same as Windows</option></select></label>
      <label class="field"><span>Number grouping</span><select id="stGroup"><option value="1">Indian – 12,34,567.89</option><option value="0">International – 1,234,567.89</option></select></label></div>
      <div class="row"><label class="field"><span>Typing dates</span><select id="stDate"><option value="1">Day first – 25/11/2026</option><option value="0">Month first – 11/25/2026</option></select></label>
      <label class="field"><span>Voice typing language</span><select id="stVoice">${VOICE_LANGS.map(([k, l]) => `<option value="${k}">${l}</option>`).join('')}</select></label></div>
      <h3>Storage</h3><p class="hint">${est ? 'Using ' + (est.usage / 1048576).toFixed(1) + ' MB of ' + (est.quota / 1073741824).toFixed(1) + ' GB available on this device.' : ''} ${IS.store.persistent ? 'Your workbooks are saved on this device.' : '⚠️ This browser window does not allow saving.'}</p>
      <h3>Plan</h3><p class="hint">${st.state === 'paid' ? 'Pro – active until ' + st.until.toLocaleDateString('en-IN') : st.state === 'trial' ? 'Free trial – ' + st.daysLeft + ' days left' : 'Trial ended'} · <a href="#" data-cmd="plan">Plan & billing</a></p>
      <h3>About</h3><p class="hint">India Sheets ${APP_VERSION} · <a href="#" data-cmd="privacy">Privacy policy</a> · <a href="vendor/LICENSES.txt" target="_blank" rel="noopener">Open-source licences</a></p>
      <h3>Danger zone</h3><button type="button" class="btn danger" id="stWipe">Delete all India Sheets data on this device…</button>`;
    const q = s => body.querySelector(s);
    q('#stTheme').value = IS.prefs.get('theme', 'light'); q('#stGroup').value = X.settings.indian ? '1' : '0'; q('#stDate').value = X.settings.dayFirst ? '1' : '0'; q('#stVoice').value = IS.prefs.get('voiceLang', 'en-IN');
    q('#stWipe').onclick = async () => {
      if (!(await ui.confirm('This permanently deletes ALL workbooks, versions and settings stored by India Sheets on this device. Download anything you need first. Continue?', { ok: 'Delete everything', danger: true }))) return;
      const list = await IS.store.list(); for (const b of list) await IS.store.remove(b.id);
      ['isheets_lastBook', 'isheets_zoom'].forEach(k => { try { localStorage.removeItem(k); } catch (e) { /* ignore */ } });
      location.reload();
    };
    ui.modal({
      title: 'Settings', body, actions: [{ label: 'Close', value: null }, {
        label: 'Save', primary: true, onClick: () => {
          IS.applyTheme(q('#stTheme').value, true);
          IS.prefs.set('indian', q('#stGroup').value === '1'); IS.prefs.set('dayFirst', q('#stDate').value === '1'); IS.prefs.set('voiceLang', q('#stVoice').value);
          applyPrefs(); IS.calc.full(); IS.grid.invalidate(); IS.afterSel();
          ui.toast('Settings saved'); return true;
        }
      }]
    });
  }

  // =================================================================== India tools panel
  const F = X.F;
  const inr = n => (typeof n === 'number' && isFinite(n) ? '₹' + X.groupDigits(Math.abs(n).toFixed(2).split('.')[0]) + '.' + Math.abs(n).toFixed(2).split('.')[1] : '–');
  function indiaTools(tab) {
    const wrap = document.createElement('div');
    const TABS = [['gst', 'GST'], ['emi', 'EMI'], ['words', 'Words'], ['check', 'GSTIN/PAN'], ['metal', 'Metal wt'], ['units', 'Units']];
    wrap.innerHTML = '<div class="tabs-h">' + TABS.map(([k, l]) => '<button type="button" data-t="' + k + '">' + l + '</button>').join('') + '</div><div id="itBody"></div>';
    const bodyEl = wrap.querySelector('#itBody');
    const show = t => {
      wrap.querySelectorAll('[data-t]').forEach(b => b.classList.toggle('on', b.dataset.t === t));
      bodyEl.innerHTML = TOOLS[t].html; TOOLS[t].init(bodyEl);
    };
    wrap.querySelector('.tabs-h').onclick = e => { const b = e.target.closest('[data-t]'); if (b) show(b.dataset.t); };
    ui.side('India tools 🇮🇳', wrap, { kind: 'india' });
    const s = IS.state.sel; const v = X.norm(IS.calc.value(IS.sheet, s.r, s.c));
    show(tab || 'gst');
    if (typeof v === 'number') { const first = bodyEl.querySelector('input[type=number]'); if (first && !first.value) { first.value = v; first.dispatchEvent(new Event('input', { bubbles: true })); } }
  }
  const insertBtn = (label, f) => '<button type="button" class="btn small" data-f="' + esc(f) + '">' + esc(label) + '</button>';
  function wireInsert(el, makeFormula) {
    el.addEventListener('click', e => {
      const b = e.target.closest('[data-ins]'); if (!b) return;
      const f = makeFormula(b.dataset.ins); if (!f) return;
      const s = IS.state.sel, sh = IS.sheet; if (!IS.guardEdit({ t: s.r, l: s.c, b: s.r, r: s.c })) return;
      IS.tx('Insert from India tools', () => IS.writeText(sh, s.r, s.c, f));
      ui.toast('Put ' + f + ' in ' + X.numToCol(s.c) + (s.r + 1));
    });
  }
  const TOOLS = {
    gst: {
      html: `<label class="field"><span>Amount (₹)</span><input id="gA" type="number" step="any" placeholder="10000"></label>
        <div class="row"><label class="field"><span>GST rate</span><select id="gR">${[0.25, 3, 5, 12, 18, 28, 40].map(r => `<option ${r === 18 ? 'selected' : ''}>${r}</option>`).join('')}</select></label>
        <label class="field"><span>The amount is</span><select id="gM"><option value="ex">Before GST</option><option value="in">Including GST</option></select></label></div>
        <label class="field"><span>Supply</span><select id="gS"><option value="intra">Same state (CGST + SGST)</option><option value="inter">Other state (IGST)</option></select></label>
        <div class="result-box" id="gOut"></div><div class="row" style="gap:6px"><button type="button" class="btn small" data-ins="gst">Insert GST formula</button><button type="button" class="btn small" data-ins="total">Insert total formula</button></div>`,
      init(el) {
        const calc = () => {
          const a = +el.querySelector('#gA').value || 0, r = +el.querySelector('#gR').value, inc = el.querySelector('#gM').value === 'in', intra = el.querySelector('#gS').value === 'intra';
          const base = inc ? a / (1 + r / 100) : a, tax = base * r / 100;
          el.querySelector('#gOut').innerHTML = 'Taxable value: <b>' + inr(base) + '</b><br>' + (intra ? 'CGST ' + r / 2 + '%: <b>' + inr(tax / 2) + '</b><br>SGST ' + r / 2 + '%: <b>' + inr(tax / 2) + '</b>' : 'IGST ' + r + '%: <b>' + inr(tax) + '</b>') + '<br>Total GST: <b>' + inr(tax) + '</b><br>Invoice total: <b style="font-size:18px">' + inr(base + tax) + '</b><br><span class="hint">' + esc(F.RUPEEWORDS([Math.round((base + tax) * 100) / 100])) + '</span>';
        };
        el.addEventListener('input', calc); el.addEventListener('change', calc); calc();
        wireInsert(el, k => { const a = el.querySelector('#gA').value || 0, r = el.querySelector('#gR').value, inc = el.querySelector('#gM').value === 'in'; return k === 'gst' ? (inc ? '=' + a + '-REMOVEGST(' + a + ',' + r + ')' : '=GST(' + a + ',' + r + ')') : (inc ? '=' + a : '=WITHGST(' + a + ',' + r + ')'); });
      }
    },
    emi: {
      html: `<label class="field"><span>Loan amount (₹)</span><input id="eP" type="number" step="any" value="500000"></label>
        <div class="row"><label class="field"><span>Interest % per year</span><input id="eR" type="number" step="any" value="9.5"></label><label class="field"><span>Months</span><input id="eN" type="number" value="60"></label></div>
        <div class="result-box" id="eOut"></div><div class="row" style="gap:6px"><button type="button" class="btn small" data-ins="emi">Insert EMI formula</button><button type="button" class="btn small" id="eSched">Full schedule (new workbook)</button></div>`,
      init(el) {
        const calc = () => { const p = +el.querySelector('#eP').value || 0, r = +el.querySelector('#eR').value || 0, n = +el.querySelector('#eN').value || 1; const e = F.EMI([p, r, n]); el.querySelector('#eOut').innerHTML = 'Monthly EMI: <b style="font-size:18px">' + inr(e) + '</b><br>Total interest: <b>' + inr(e * n - p) + '</b><br>Total payment: <b>' + inr(e * n) + '</b><br><span class="hint">Interest is ' + (p ? Math.round((e * n - p) / p * 100) : 0) + '% of the loan.</span>'; };
        el.addEventListener('input', calc); calc();
        wireInsert(el, () => '=EMI(' + (el.querySelector('#eP').value || 0) + ',' + (el.querySelector('#eR').value || 0) + ',' + (el.querySelector('#eN').value || 1) + ')');
        el.querySelector('#eSched').onclick = async () => {
          const p = +el.querySelector('#eP').value, r = +el.querySelector('#eR').value, n = +el.querySelector('#eN').value;
          await IS.run('newFromTemplate', 'emi');
          setTimeout(() => { const sh = IS.sheet; IS.tx('Loan values', () => { IS.editCell(sh, 2, 1, c => { c.v = p; }); IS.editCell(sh, 3, 1, c => { c.v = r; }); IS.editCell(sh, 4, 1, c => { c.v = n; }); }); }, 400);
        };
      }
    },
    words: {
      html: `<label class="field"><span>Amount</span><input id="wA" type="number" step="any" placeholder="125430.50"></label><div class="result-box" id="wOut"></div>
        <div class="row" style="gap:6px"><button type="button" class="btn small" data-ins="en">Insert English words formula</button><button type="button" class="btn small" data-ins="hi">Insert Hindi words formula</button></div><p class="hint">Tip: the formula version updates when the amount changes – use a cell reference like <code>=RUPEEWORDS(J32)</code>.</p>`,
      init(el) {
        const calc = () => { const a = +el.querySelector('#wA').value || 0; el.querySelector('#wOut').innerHTML = '<b>' + esc(F.RUPEEWORDS([a])) + '</b><br><br><b>' + esc(F.HINDIWORDS([a])) + '</b><br><br><span class="hint">' + esc(F.INR([a])) + ' · ' + esc(F.NUMWORDS([a])) + '</span>'; };
        el.addEventListener('input', calc); calc();
        wireInsert(el, k => '=' + (k === 'hi' ? 'HINDIWORDS' : 'RUPEEWORDS') + '(' + (el.querySelector('#wA').value || 0) + ')');
      }
    },
    check: {
      html: `<label class="field"><span>GSTIN, PAN, IFSC, Aadhaar, mobile or PIN code</span><input id="cT" placeholder="24ABCDE1234F1Z5" style="text-transform:uppercase"></label><div class="result-box" id="cOut"><span class="hint">Type or paste a number to check it.</span></div>
        <p class="hint">Checks the format and the check-digit (GSTIN, Aadhaar) offline. It does not confirm registration with the government portal.</p>`,
      init(el) {
        const inp = el.querySelector('#cT');
        const s = IS.state.sel; const v = X.norm(IS.calc.value(IS.sheet, s.r, s.c)); if (typeof v === 'string' || typeof v === 'number') inp.value = String(v);
        const calc = () => {
          const t = inp.value.trim().toUpperCase().replace(/\s+/g, ''); const out = el.querySelector('#cOut');
          if (!t) { out.innerHTML = '<span class="hint">Type or paste a number to check it.</span>'; return; }
          const lines = [];
          const ok = b => (b ? '✅ Valid' : '❌ Not valid');
          if (/^\d{2}[A-Z0-9]{13}$/.test(t)) { const valid = F.ISGSTIN([t]); lines.push('<b>GSTIN</b>: ' + ok(valid)); try { lines.push('State: <b>' + esc(F.GSTINSTATE([t])) + '</b> (code ' + t.slice(0, 2) + ')'); } catch (e) { lines.push('Unknown state code ' + t.slice(0, 2)); } lines.push('PAN inside: <b>' + t.slice(2, 12) + '</b> ' + (F.ISPAN([t.slice(2, 12)]) ? '✅' : '❌')); const typ = { P: 'Individual', C: 'Company', H: 'HUF', F: 'Firm / LLP', A: 'Association of persons', T: 'Trust', B: 'Body of individuals', L: 'Local authority', J: 'Artificial juridical person', G: 'Government' }[t[5]]; if (typ) lines.push('Type: ' + typ); }
          else if (/^[A-Z]{5}\d{4}[A-Z]$/.test(t)) { lines.push('<b>PAN</b>: ' + ok(F.ISPAN([t]))); const typ = { P: 'Individual', C: 'Company', H: 'HUF', F: 'Firm / LLP', A: 'Association of persons', T: 'Trust', B: 'Body of individuals', L: 'Local authority', J: 'Artificial juridical person', G: 'Government' }[t[3]]; if (typ) lines.push('Holder type: ' + typ); }
          else if (/^[A-Z]{4}0[A-Z0-9]{6}$/.test(t) || /^[A-Z]{4}/.test(t) && t.length === 11) lines.push('<b>IFSC</b>: ' + ok(F.ISIFSC([t])) + '<br>Bank code: ' + t.slice(0, 4) + ' · Branch code: ' + t.slice(5));
          else if (/^\d{12}$/.test(t)) lines.push('<b>Aadhaar</b>: ' + ok(F.ISAADHAAR([t])) + ' (check-digit)');
          else if (/^(\+?91|0)?[6-9]\d{9}$/.test(t)) lines.push('<b>Mobile</b>: ' + ok(F.ISMOBILE([t])));
          else if (/^\d{6}$/.test(t)) lines.push('<b>PIN code</b>: ' + ok(F.ISPINCODE([t])));
          else lines.push('Not recognised. GSTIN has 15 characters, PAN 10, IFSC 11, Aadhaar 12 digits, mobile 10 digits, PIN 6 digits.');
          out.innerHTML = lines.join('<br>');
        };
        inp.addEventListener('input', calc); calc();
      }
    },
    metal: {
      html: `<div class="row"><label class="field"><span>Material</span><select id="mM">${['MS', 'SS', 'SS316', 'Aluminium', 'Copper', 'Brass', 'Bronze', 'Cast iron', 'GI', 'Titanium'].map(m => `<option>${m}</option>`).join('')}</select></label>
        <label class="field"><span>Shape</span><select id="mS">${[['round', 'Round bar'], ['square', 'Square bar'], ['flat', 'Flat / strip'], ['hex', 'Hex bar'], ['pipe', 'Round pipe'], ['sqpipe', 'Square / rect pipe'], ['angle', 'Angle'], ['channel', 'Channel'], ['plate', 'Plate / sheet']].map(([k, l]) => `<option value="${k}">${l}</option>`).join('')}</select></label></div>
        <div class="row"><label class="field"><span id="mLA">A (mm)</span><input id="mA" type="number" step="any" value="12"></label><label class="field"><span id="mLB">B (mm)</span><input id="mB" type="number" step="any"></label><label class="field"><span id="mLC">C (mm)</span><input id="mC" type="number" step="any"></label></div>
        <div class="row"><label class="field"><span>Length (m)</span><input id="mL" type="number" step="any" value="6"></label><label class="field"><span>Quantity</span><input id="mQ" type="number" value="1"></label><label class="field"><span>Rate ₹/kg</span><input id="mR" type="number" step="any" placeholder="62"></label></div>
        <div class="result-box" id="mOut"></div><button type="button" class="btn small" data-ins="w">Insert weight formula</button>`,
      init(el) {
        const LBL = { round: ['Diameter', '', ''], square: ['Side', '', ''], flat: ['Width', 'Thickness', ''], hex: ['Across flats', '', ''], pipe: ['Outside dia', 'Thickness', ''], sqpipe: ['Side A', 'Side B', 'Thickness'], angle: ['Leg A', 'Leg B', 'Thickness'], channel: ['Height', 'Flange', 'Thickness'], plate: ['Length', 'Width', 'Thickness'] };
        const g = id => el.querySelector(id);
        const calc = () => {
          const sh = g('#mS').value, L = LBL[sh];
          ['A', 'B', 'C'].forEach((k, i) => { g('#mL' + k).textContent = (L[i] || k) + ' (mm)'; g('#m' + k).parentElement.style.display = L[i] ? '' : 'none'; });
          g('#mL').parentElement.style.display = sh === 'plate' ? 'none' : '';
          let w = null; try { w = F.METALWEIGHT([sh, +g('#mA').value || 0, +g('#mB').value || 0, +g('#mC').value || 0, +g('#mL').value || 1, g('#mM').value]); } catch (e) { w = null; }
          const q = +g('#mQ').value || 1, rate = +g('#mR').value || 0;
          g('#mOut').innerHTML = w === null || !isFinite(w) ? 'Enter the sizes' : 'Weight per piece: <b>' + w.toLocaleString('en-IN', { maximumFractionDigits: 3 }) + ' kg</b>' + (sh !== 'plate' ? ' (' + (w / (+g('#mL').value || 1)).toLocaleString('en-IN', { maximumFractionDigits: 3 }) + ' kg/m)' : '') + '<br>Total for ' + q + ': <b style="font-size:18px">' + (w * q).toLocaleString('en-IN', { maximumFractionDigits: 3 }) + ' kg</b>' + (rate ? '<br>Amount: <b>' + inr(w * q * rate) + '</b>' : '') + '<br><span class="hint">Density used: ' + F.DENSITY([g('#mM').value]) + ' g/cm³</span>';
        };
        el.addEventListener('input', calc); el.addEventListener('change', calc); calc();
        wireInsert(el, () => '=METALWEIGHT("' + g('#mS').value + '",' + (+g('#mA').value || 0) + ',' + (+g('#mB').value || 0) + ',' + (+g('#mC').value || 0) + ',' + (+g('#mL').value || 1) + ',"' + g('#mM').value + '")' + ((+g('#mQ').value || 1) !== 1 ? '*' + g('#mQ').value : ''));
      }
    },
    units: {
      html: `<div class="row"><label class="field"><span>Value</span><input id="uV" type="number" step="any" value="1"></label><label class="field"><span>From</span><select id="uF"></select></label><label class="field"><span>To</span><select id="uT"></select></label></div><div class="result-box" id="uOut"></div><button type="button" class="btn small" data-ins="u">Insert CONVERT formula</button>`,
      init(el) {
        const groups = { Weight: ['kg', 'g', 'mg', 'quintal', 't', 'lb', 'oz', 'tola'], Length: ['mm', 'cm', 'm', 'km', 'in', 'ft', 'yd', 'mi'], Area: ['sqft', 'sqm', 'sqyd', 'gaj', 'acre', 'hectare', 'guntha', 'cent'], Volume: ['l', 'ml', 'm3', 'cuft', 'gal'], Temperature: ['C', 'F', 'K'] };
        const opts = Object.entries(groups).map(([g, us]) => '<optgroup label="' + g + '">' + us.map(u => '<option>' + u + '</option>').join('') + '</optgroup>').join('');
        el.querySelector('#uF').innerHTML = opts; el.querySelector('#uT').innerHTML = opts; el.querySelector('#uF').value = 'kg'; el.querySelector('#uT').value = 'quintal';
        const calc = () => { const v = +el.querySelector('#uV').value || 0, f = el.querySelector('#uF').value, t = el.querySelector('#uT').value; let r; try { r = F.CONVERT([v, f, t]); } catch (e) { r = null; } el.querySelector('#uOut').innerHTML = r === null || X.isErr(r) ? 'These units cannot be converted into each other.' : v + ' ' + f + ' = <b style="font-size:18px">' + (+r.toPrecision(10)).toLocaleString('en-IN', { maximumFractionDigits: 6 }) + ' ' + t + '</b>'; };
        el.addEventListener('input', calc); el.addEventListener('change', calc); calc();
        wireInsert(el, () => '=CONVERT(' + (el.querySelector('#uV').value || 0) + ',"' + el.querySelector('#uF').value + '","' + el.querySelector('#uT').value + '")');
      }
    }
  };

  // =================================================================== voice typing & read aloud
  const VOICE_LANGS = [['en-IN', 'English (India)'], ['hi-IN', 'हिन्दी Hindi'], ['gu-IN', 'ગુજરાતી Gujarati'], ['mr-IN', 'मराठी Marathi'], ['bn-IN', 'বাংলা Bengali'], ['ta-IN', 'தமிழ் Tamil'], ['te-IN', 'తెలుగు Telugu'], ['kn-IN', 'ಕನ್ನಡ Kannada'], ['ml-IN', 'മലയാളം Malayalam'], ['pa-IN', 'ਪੰਜਾਬੀ Punjabi']];
  let rec = null, voiceEl = null;
  const DEVANAGARI = s => String(s).replace(/[०-९]/g, d => String('०१२३४५६७८९'.indexOf(d))).replace(/[૦-૯]/g, d => String('૦૧૨૩૪૫૬૭૮૯'.indexOf(d)));
  function voiceTyping() {
    if (rec) { rec.stop(); return; }
    const SR = global.SpeechRecognition || global.webkitSpeechRecognition;
    if (!SR) { ui.modal({ title: 'Voice typing', body: '<p>Voice typing needs Microsoft Edge or Google Chrome with internet access (speech is recognised by the browser).</p>' }); return; }
    rec = new SR(); rec.lang = IS.prefs.get('voiceLang', 'en-IN'); rec.continuous = true; rec.interimResults = true;
    voiceEl = document.createElement('div'); voiceEl.className = 'voice-on'; voiceEl.innerHTML = '<span class="dot"></span><span id="voiceText">Listening… say a value, then “next”. Say “stop” to finish.</span><button type="button" class="btn small" id="voiceStop">Stop</button>';
    document.body.appendChild(voiceEl); voiceEl.querySelector('#voiceStop').onclick = () => rec && rec.stop();
    rec.onresult = e => {
      let interim = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        const res = e.results[i]; const text = DEVANAGARI(res[0].transcript.trim());
        if (!res.isFinal) { interim += text; continue; }
        const low = text.toLowerCase().replace(/[.,!?]/g, '').trim();
        if (/^(stop|band karo|bas|ruko|stop listening)$/.test(low)) { rec.stop(); return; }
        if (/^(next|agla|neeche|down|next row|enter)$/.test(low)) { IS._internal.move(1, 0); continue; }
        if (/^(right|next column|aage|daaye|tab)$/.test(low)) { IS._internal.move(0, 1); continue; }
        if (/^(up|upar|previous)$/.test(low)) { IS._internal.move(-1, 0); continue; }
        if (/^(left|peeche|baaye)$/.test(low)) { IS._internal.move(0, -1); continue; }
        if (/^(delete|clear|mitao|hatao)$/.test(low)) { IS.run('clearContents'); continue; }
        if (/^(undo|wapas)$/.test(low)) { IS.run('undo'); continue; }
        const s = IS.state.sel, sh = IS.sheet;
        if (!IS.guardEdit({ t: s.r, l: s.c, b: s.r, r: s.c })) { rec.stop(); return; }
        let value = text.replace(/^(\d[\d,.]*)\s*(rupees?|rs|₹)$/i, '$1');
        IS.tx('Voice: ' + value, () => IS.writeText(sh, s.r, s.c, value));
        IS._internal.move(1, 0);
      }
      const vt = document.getElementById('voiceText'); if (vt) vt.textContent = interim ? '“' + interim + '”' : 'Listening… (' + (VOICE_LANGS.find(l => l[0] === rec.lang) || [0, rec.lang])[1] + ')';
    };
    rec.onerror = e => { if (e.error === 'not-allowed' || e.error === 'service-not-allowed') ui.toast('Microphone permission was blocked. Allow the microphone for this app and try again.', { type: 'error', ms: 6000 }); else if (e.error !== 'no-speech' && e.error !== 'aborted') ui.toast('Voice typing: ' + e.error, { type: 'warn' }); };
    rec.onend = () => { rec = null; if (voiceEl) { voiceEl.remove(); voiceEl = null; } ui.toast('Voice typing stopped', { ms: 1500 }); };
    try { rec.start(); } catch (e) { rec = null; voiceEl.remove(); ui.toast('Could not start voice typing.', { type: 'error' }); }
  }
  let reading = false;
  function speakable(sh, r, c) {
    const v = X.norm(IS.calc.value(sh, r, c)); const cell = sh.cells[K(r, c)]; const nf = cell && cell.s && cell.s.nf;
    if (v === null || v === undefined || v === '') return 'blank';
    if (typeof v === 'number') {
      if (X.isDateFormat(nf)) return X.formatValue(v, 'd mmmm yyyy').text;
      const neg = v < 0, a = Math.abs(v), ip = Math.floor(a), dec = Math.round((a - ip) * 100);
      return (neg ? 'minus ' : '') + X.inWords(ip) + (dec ? ' point ' + String(Math.round((a - ip) * 100)).padStart(2, '0').split('').join(' ') : '') + (/₹/.test(nf || '') ? ' rupees' : '');
    }
    if (typeof v === 'boolean') return v ? 'ticked' : 'not ticked';
    return String(X.toStr(v));
  }
  function readAloud() {
    if (reading) { speechSynthesis.cancel(); reading = false; return; }
    if (!global.speechSynthesis) { ui.toast('Reading aloud is not supported here.'); return; }
    const sh = IS.sheet; let R = IS.selRect();
    if (R.t === R.b && R.l === R.r) { const reg = IS.currentRegion(sh, R.t, R.l); if (reg) R = reg; }
    const cells = []; const u = IS.usedRange(sh);
    for (let r = R.t; r <= Math.min(R.b, u.b); r++) for (let c = R.l; c <= Math.min(R.r, u.r); c++) if (IS.rowVisible(sh, r) && !IS.isCovered(sh, r, c)) cells.push([r, c]);
    if (!cells.length) return;
    const voices = speechSynthesis.getVoices(); const voice = voices.find(v => /en-IN/i.test(v.lang)) || voices.find(v => /hi-IN/i.test(v.lang)) || null;
    reading = true; let i = 0;
    ui.toast('Reading ' + cells.length + ' cells aloud – press Read aloud again (or Esc) to stop.', { ms: 3000 });
    const next = () => {
      if (!reading || i >= cells.length) { reading = false; return; }
      const [r, c] = cells[i++]; IS.setSel(r, c);
      const u2 = new SpeechSynthesisUtterance(speakable(sh, r, c)); if (voice) u2.voice = voice; u2.lang = voice ? voice.lang : 'en-IN'; u2.rate = 1;
      u2.onend = () => setTimeout(next, 120); u2.onerror = () => { reading = false; };
      speechSynthesis.speak(u2);
    };
    next();
  }
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && reading) { speechSynthesis.cancel(); reading = false; } });

  // =================================================================== insert QR / UPI / sparkline
  function ensureSize(sh, r, c, w, h) { IS.tx('Cell size', () => { IS.rec.meta(sh); if ((sh.colW[c] || 100) < w) sh.colW[c] = w; if ((sh.rowH[r] || 24) < h) sh.rowH[r] = h; }, { layout: true }); }
  async function insertQR() {
    const s = IS.state.sel, sh = IS.sheet; if (!IS.guardEdit({ t: s.r, l: s.c, b: s.r, r: s.c })) return;
    const t = await ui.prompt('Insert QR code', 'Text or link for the QR code (or a cell like B2)', 'https://', { ok: 'Insert' });
    if (!t) return;
    const arg = X.parseRef(t.trim()) && !/^https?:/i.test(t) ? t.trim() : '"' + t.replace(/"/g, '""') + '"';
    IS.tx('Insert QR', () => IS.writeText(sh, s.r, s.c, '=QR(' + arg + ')'));
    ensureSize(sh, s.r, s.c, 130, 130);
  }
  function insertUPI() {
    const s = IS.state.sel, sh = IS.sheet; if (!IS.guardEdit({ t: s.r, l: s.c, b: s.r, r: s.c })) return;
    const body = `<p class="hint">Creates a QR code that customers can scan with GPay, PhonePe, Paytm or BHIM to pay you. The amount can be a number or a cell (like J32) so it updates automatically.</p>
      <label class="field"><span>Your UPI ID</span><input id="uId" placeholder="yourshop@okaxis" value="${esc(IS.prefs.get('upiId', ''))}"></label>
      <label class="field"><span>Your business name</span><input id="uName" value="${esc(IS.prefs.get('upiName', ''))}" placeholder="Your Company Name"></label>
      <div class="row"><label class="field"><span>Amount (optional)</span><input id="uAmt" placeholder="1250 or J32"></label><label class="field"><span>Note (optional)</span><input id="uNote" placeholder="Invoice 001"></label></div>`;
    let vals = null;
    ui.modal({ title: 'UPI payment QR', body, actions: [{ label: 'Cancel', value: null }, { label: 'Insert', primary: true, onClick: b => {
      const id = b.querySelector('#uId').value.trim(); if (!/^[\w.\-]{2,}@[\w.\-]{2,}$/.test(id)) { ui.toast('Enter a valid UPI ID like name@okaxis', { type: 'error' }); return false; }
      vals = { id, name: b.querySelector('#uName').value.trim(), amt: b.querySelector('#uAmt').value.trim(), note: b.querySelector('#uNote').value.trim() }; return true;
    } }] }).then(() => {
      if (!vals) return;
      IS.prefs.set('upiId', vals.id); IS.prefs.set('upiName', vals.name);
      const q = s2 => '"' + s2.replace(/"/g, '""') + '"';
      const amt = !vals.amt ? '' : X.parseRef(vals.amt) ? vals.amt : String(+vals.amt || '');
      IS.tx('Insert UPI QR', () => IS.writeText(sh, s.r, s.c, '=UPIQR(' + q(vals.id) + ',' + q(vals.name) + (amt || vals.note ? ',' + amt : '') + (vals.note ? ',' + q(vals.note) : '') + ')'));
      ensureSize(sh, s.r, s.c, 150, 150);
    });
  }
  function insertSparkline() {
    const s = IS.state.sel, sh = IS.sheet; if (!IS.guardEdit({ t: s.r, l: s.c, b: s.r, r: s.c })) return;
    const guess = (() => { let c0 = s.c - 1; while (c0 >= 0 && typeof X.norm(IS.calc.value(sh, s.r, c0)) === 'number') c0--; return c0 < s.c - 1 ? X.numToCol(c0 + 1) + (s.r + 1) + ':' + X.numToCol(s.c - 1) + (s.r + 1) : ''; })();
    const body = `<label class="field"><span>Data range</span><input id="spR" class="mono" value="${esc(guess)}" placeholder="B2:M2"></label><label class="field"><span>Type</span><select id="spT"><option value="line">Line</option><option value="column">Columns</option><option value="winloss">Win / loss</option><option value="bar">Single bar</option></select></label>`;
    let v = null;
    ui.modal({ title: 'Insert sparkline (mini chart in a cell)', body, actions: [{ label: 'Cancel', value: null }, { label: 'Insert', primary: true, onClick: b => { const r = b.querySelector('#spR').value.trim(); if (!X.parseRef(r)) { ui.toast('Enter a range like B2:M2', { type: 'error' }); return false; } v = { r, t: b.querySelector('#spT').value }; return true; } }] }).then(() => {
      if (!v) return;
      IS.tx('Insert sparkline', () => IS.writeText(sh, s.r, s.c, '=SPARKLINE(' + v.r + (v.t !== 'line' ? ',"' + v.t + '"' : '') + ')'));
      ensureSize(sh, s.r, s.c, 140, 30);
    });
  }

  // =================================================================== help
  function shortcuts() {
    const k = (a, b) => '<tr><td>' + a + '</td><td>' + b.split(' / ').map(x => '<span class="kbd">' + esc(x) + '</span>').join(' / ') + '</td></tr>';
    const rows = [['Move / select', 'Arrows / Shift+Arrows'], ['Jump to edge of data', 'Ctrl+Arrows'], ['Edit cell', 'F2 / Double-click'], ['New line in a cell', 'Alt+Enter'], ['Fill the whole selection with an entry', 'Ctrl+Enter'], ['Absolute reference ($A$1)', 'F4'], ['Undo / Redo', 'Ctrl+Z / Ctrl+Y'], ['Copy / Cut / Paste', 'Ctrl+C / Ctrl+X / Ctrl+V'], ['Paste values only', 'Ctrl+Shift+V'], ['Fill down / right', 'Ctrl+D / Ctrl+R'], ['AutoSum', 'Alt+='], ['Bold / Italic / Underline / Strike', 'Ctrl+B / Ctrl+I / Ctrl+U / Ctrl+5'], ['Format cells', 'Ctrl+1'], ['Rupee / Percent / Number / Date', 'Ctrl+Shift+4 / Ctrl+Shift+5 / Ctrl+Shift+1 / Ctrl+Shift+3'], ["Today's date / time", 'Ctrl+; / Ctrl+Shift+;'], ['Find / Replace / Go to', 'Ctrl+F / Ctrl+H / Ctrl+G'], ['Insert link / note', 'Ctrl+K / Shift+F2'], ['Filter on/off', 'Ctrl+Shift+L'], ['Select column / row / all', 'Ctrl+Space / Shift+Space / Ctrl+A'], ['Hide rows / columns', 'Ctrl+9 / Ctrl+0'], ['Insert / delete cells', 'Ctrl++ / Ctrl+-'], ['Show formulas', 'Ctrl+`'], ['Next / previous sheet', 'Ctrl+PageDown / Ctrl+PageUp'], ['New sheet', 'Shift+F11'], ['Open dropdown list', 'Alt+Down'], ['Recalculate', 'F9'], ['Save / Download Excel', 'Ctrl+S / Ctrl+Shift+S'], ['Print / PDF', 'Ctrl+P'], ['Ask India Sheets', 'Ctrl+Shift+A'], ['Zoom', 'Ctrl+Mouse wheel']];
    ui.modal({ title: 'Keyboard shortcuts', body: '<div class="list-scroll"><table class="table">' + rows.map(r => k(r[0], r[1])).join('') + '</table></div>', wide: true });
  }
  function functions() {
    const info = X.FN_INFO; const cats = [...new Set(Object.values(info).map(i => i.cat))];
    const body = document.createElement('div');
    body.innerHTML = '<div class="row"><input class="inp" id="fnQ" placeholder="Search ' + Object.keys(info).length + ' formulas – e.g. lookup, gst, date, words" style="flex:1"><select class="inp" id="fnC" style="max-width:180px"><option value="">All categories</option>' + cats.map(c => '<option>' + esc(c) + '</option>').join('') + '</select></div><div class="list-scroll" style="margin-top:8px"><table class="table" id="fnT"></table></div><p class="hint">Click a formula to start it in the selected cell. Everything works offline.</p>';
    const render = () => {
      const q = body.querySelector('#fnQ').value.toLowerCase(), c = body.querySelector('#fnC').value;
      const list = Object.entries(info).filter(([n, i]) => (!c || i.cat === c) && (!q || (n + ' ' + i.desc + ' ' + i.cat).toLowerCase().includes(q)));
      body.querySelector('#fnT').innerHTML = list.map(([n, i]) => '<tr class="clickable" data-fn="' + n + '"><td class="mono" style="white-space:nowrap"><b>' + esc(i.sig) + '</b></td><td>' + esc(i.desc) + '</td><td class="hint">' + esc(i.cat) + '</td></tr>').join('') || '<tr><td class="hint">No formulas match.</td></tr>';
    };
    body.addEventListener('input', render); body.addEventListener('change', render);
    body.addEventListener('click', e => { const tr = e.target.closest('[data-fn]'); if (!tr) return; ui.closeModal(); setTimeout(() => IS.run('insertFunction', tr.dataset.fn), 30); });
    render();
    ui.modal({ title: 'Formulas', body, wide: true });
  }
  function welcome() {
    const body = `<p style="font-size:15px">Welcome to <b>India Sheets</b> – a spreadsheet made for India that works <b>online and offline</b>.</p>
      <ul class="perks"><li>Opens and saves <b>Excel</b> files (.xlsx, .xls), CSV, ODS – and <b>PDF</b> printing</li><li><b>280+ formulas</b> incl. <code>RUPEEWORDS</code>, <code>GST</code>, <code>ISGSTIN</code>, <code>EMI</code>, <code>UPIQR</code>, <code>METALWEIGHT</code></li><li>₹ formats with lakh/crore grouping, dates typed as 25-11-2026</li><li>Charts, pivot summaries, filters, conditional colours, dropdowns, checkboxes</li><li><b>✨ Ask</b> in plain English or Hinglish: “amount ka total”, “sort by date”</li><li>Voice typing in 10 Indian languages, read-aloud checking</li></ul>
      <p class="hint">Your ${IS.Licence.CONFIG.TRIAL_DAYS}-day free trial has started. After that it is just ₹${IS.Licence.CONFIG.PRICE_INR}. Everything is saved on this device.</p>`;
    ui.modal({ title: 'Namaste 🙏', body, actions: [{ label: 'Start with a blank sheet', value: null }, { label: 'Browse templates', primary: true, onClick: () => { setTimeout(() => IS.run('templates'), 50); return true; } }] });
  }
  function about() {
    ui.modal({ title: 'About India Sheets', body: '<p><b>India Sheets ' + APP_VERSION + '</b> – spreadsheet for India.</p><p class="hint">Works offline. Your data stays on your device unless you download or share it.</p><p>Built with: SheetJS-based xlsx-js-style (Apache 2.0), Chart.js (MIT), qrcode-generator (MIT). <a href="vendor/LICENSES.txt" target="_blank" rel="noopener">Licences</a></p><p><a href="#" data-cmd="privacy">Privacy policy</a> · Support: ' + esc(IS.Licence.CONFIG.SUPPORT_EMAIL) + '</p>' });
  }

  // =================================================================== install, offline, updates
  let installEvt = null;
  global.addEventListener('beforeinstallprompt', e => { e.preventDefault(); installEvt = e; const b = $('installBtn'); if (b) b.hidden = false; });
  global.addEventListener('appinstalled', () => { const b = $('installBtn'); if (b) b.hidden = true; ui.toast('India Sheets is installed. Open it from the Start menu – it works without internet. 🎉', { ms: 6000 }); });
  function registerSW() {
    if (!('serviceWorker' in navigator) || !/^https?:$/.test(location.protocol)) return;
    const hadController = !!navigator.serviceWorker.controller; // first install must not reload the page
    navigator.serviceWorker.register('sw.js').then(reg => {
      reg.addEventListener('updatefound', () => {
        const nw = reg.installing; if (!nw) return;
        nw.addEventListener('statechange', () => { if (nw.state === 'installed' && navigator.serviceWorker.controller) ui.toast('A new version of India Sheets is ready.', { ms: 15000, action: { label: 'Update now', onClick: async () => { await IS.saveNow(); nw.postMessage('skipWaiting'); } } }); });
      });
      setInterval(() => reg.update().catch(() => {}), 60 * 60 * 1000);
    }).catch(() => {});
    let reloading = false;
    navigator.serviceWorker.addEventListener('controllerchange', () => { if (reloading || !hadController) return; reloading = true; location.reload(); });
  }
  IS.on('ready', ({ first }) => {
    const ib = $('installBtn');
    if (ib) ib.onclick = async () => { if (!installEvt) return; installEvt.prompt(); await installEvt.userChoice; installEvt = null; ib.hidden = true; };
    if (matchMedia('(display-mode: standalone)').matches && ib) ib.hidden = true;
    registerSW();
    if (first || !IS.prefs.get('welcomed2')) { IS.prefs.set('welcomed2', true); setTimeout(welcome, 500); }
    // refresh TODAY()/NOW() after midnight or when coming back to the app
    let lastDay = X.todaySerial();
    setInterval(() => { const d = X.todaySerial(); if (d !== lastDay) { lastDay = d; IS.calc.recalcVolatile(); IS.grid.invalidate(); } }, 60000);
  });

  Object.assign(IS.cmd, {
    home, newBook, copyBook, deleteBook, versionHistory, saveVersion, protectSheet, settings,
    indiaTools, voiceTyping, readAloud, insertQR, insertUPI, insertSparkline,
    shortcuts, functions, welcome, about, privacy: () => global.open('privacy.html', '_blank', 'noopener')
  });
})(window);
