/* India Sheets – "Ask India Sheets": an offline assistant that understands simple English / Hinglish requests,
 * plus "Explain formula" and trace precedents / dependents. No internet or AI service needed. */
(function (global) {
  'use strict';
  const IS = global.IS, ui = IS.ui, X = global.Formula, esc = ui.esc, K = IS.K;
  const val = (sh, r, c) => X.norm(IS.calc.value(sh, r, c));
  const disp = (sh, r, c) => { const cell = sh.cells[K(r, c)]; return X.formatValue(IS.calc.value(sh, r, c), cell && cell.s && cell.s.nf).text; };
  const A1 = (r, c) => X.numToCol(c) + (r + 1);
  const colRef = c => X.numToCol(c) + ':' + X.numToCol(c);

  // ------------------------------------------------------------ context: the table around the cursor
  function context() {
    const sh = IS.sheet, s = IS.state.sel;
    let R = IS.currentRegion(sh, s.r, s.c);
    if (!R) { const u = IS.usedRange(sh); if (u.empty) return null; R = IS.currentRegion(sh, 0, 0) || u; }
    const header = IS.detectHeader(sh, R) || (R.b > R.t && [...Array(R.r - R.l + 1).keys()].every(i => { const v = val(sh, R.t, R.l + i); return v === null || typeof v === 'string'; }));
    // leave out a "Total" row at the bottom so totals are not counted twice
    R = { ...R };
    const isTotalRow = r => { for (let c = R.l; c <= R.r; c++) { const v = val(sh, r, c); const cell = sh.cells[K(r, c)]; if (typeof v === 'string' && /^(grand\s+)?(sub)?totals?\b|^kul\b/i.test(v.trim())) return true; if (cell && IS.isFormulaCell(cell) && /^=\s*(SUBTOTAL|SUM)\(/i.test(cell.v) && /:/.test(cell.v)) return true; } return false; };
    while (R.b > R.t + (header ? 1 : 0) && isTotalRow(R.b)) R.b--;
    const cols = [];
    for (let c = R.l; c <= R.r; c++) {
      const name = header ? String(disp(sh, R.t, c) || '').trim() : '';
      let nums = 0, texts = 0, dates = 0;
      for (let r = R.t + (header ? 1 : 0); r <= Math.min(R.b, R.t + 60); r++) { const v = val(sh, r, c); const cell = sh.cells[K(r, c)]; if (typeof v === 'number') { nums++; if (cell && cell.s && X.isDateFormat(cell.s.nf)) dates++; } else if (typeof v === 'string' && v) texts++; }
      cols.push({ c, name: name || 'Column ' + X.numToCol(c), letter: X.numToCol(c), numeric: nums > texts, date: dates > 0 && dates >= nums / 2 });
    }
    return { sh, R, header, cols, t0: R.t + (header ? 1 : 0) };
  }
  function lev(a, b) { const m = a.length, n = b.length; if (!m) return n; if (!n) return m; const d = Array.from({ length: m + 1 }, (_, i) => [i]); for (let j = 1; j <= n; j++) d[0][j] = j; for (let i = 1; i <= m; i++) for (let j = 1; j <= n; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); return d[m][n]; }
  function findCol(phrase, ctx) {
    if (!phrase || !ctx) return null;
    let p = phrase.toLowerCase().trim().replace(/^(the|column|col|field)\s+/, '').replace(/\s+(column|col|field)$/, '').replace(/[?.!]+$/, '').trim();
    if (!p) return null;
    const lm = p.match(/^([a-z]{1,2})$/i);
    if (lm) { const hit = ctx.cols.find(x => x.letter === lm[1].toUpperCase()); if (hit && p.length <= 2 && !ctx.cols.some(x => x.name.toLowerCase() === p)) return hit; }
    const norm = s => s.toLowerCase().replace(/[^a-z0-9ऀ-ॿ ]/g, ' ').replace(/\s+/g, ' ').trim();
    const q = norm(p);
    let best = null, score = 0;
    for (const col of ctx.cols) {
      const n = norm(col.name); if (!n) continue;
      let s = 0;
      if (n === q) s = 100; else if (n.startsWith(q) || q.startsWith(n)) s = 80; else if (n.includes(q) || q.includes(n)) s = 65;
      else { const qw = q.split(' '), nw = n.split(' '); const overlap = qw.filter(w => w.length > 1 && nw.some(x => x === w || (w.length > 3 && x.startsWith(w.slice(0, 4))))).length; if (overlap) s = 40 + overlap * 10; else if (q.length > 3 && lev(q, n) <= 2) s = 55; }
      if (s > score) { score = s; best = col; }
    }
    return score >= 40 ? best : null;
  }
  /** find which column contains a value, e.g. "for Steel" */
  function colWithValue(value, ctx) {
    const q = String(value).toLowerCase().trim();
    for (const col of ctx.cols) for (let r = ctx.t0; r <= ctx.R.b; r++) { const d = String(disp(ctx.sh, r, col.c)).toLowerCase().trim(); if (d === q) return col; }
    return null;
  }

  // ------------------------------------------------------------ conditions → criteria
  const OPS = [[/^(>=|greater than or equal to|at least|minimum of)\s*/, '>='], [/^(<=|less than or equal to|at most|maximum of|upto|up to)\s*/, '<='], [/^(<>|!=|is not|not equal to|isn't|is not equal to|nahi hai|not)\s*/, '<>'], [/^(>|greater than|more than|above|over|jyada|zyada)\s*/, '>'], [/^(<|less than|below|under|kam)\s*/, '<'], [/^(=|==|is|equals|equal to|hai)\s*/, '='], [/^(contains|includes|has)\s*/, 'contains'], [/^(starts with|begins with)\s*/, 'begins'], [/^(ends with)\s*/, 'ends']];
  function parseCondition(text, ctx) {
    text = text.trim().replace(/^(where|when|if|for|jaha|jahan|jab|with)\s+/, '');
    // "<column> <op> <value>"
    for (let cut = text.length; cut > 0; cut = text.lastIndexOf(' ', cut - 1)) {
      const left = text.slice(0, cut).trim(), right = text.slice(cut).trim();
      const col = findCol(left, ctx);
      if (!col || !right) continue;
      for (const [re, op] of OPS) { const m = right.match(re); if (m) { const v = right.slice(m[0].length).trim().replace(/^["']|["']$/g, ''); if (v) return { col, op, value: v }; } }
    }
    // "<value>" alone → find the column that contains it
    const v = text.replace(/^["']|["']$/g, '').trim();
    const col = colWithValue(v, ctx);
    if (col) return { col, op: '=', value: v };
    return null;
  }
  function critText(cond) {
    const v = cond.value; const num = X.parseInput(v).value;
    const isNum = typeof num === 'number';
    if (cond.op === 'contains') return '"*' + v.replace(/"/g, '""') + '*"';
    if (cond.op === 'begins') return '"' + v.replace(/"/g, '""') + '*"';
    if (cond.op === 'ends') return '"*' + v.replace(/"/g, '""') + '"';
    const o = cond.op === '=' ? '' : cond.op;
    return '"' + o + (isNum ? num : v.replace(/"/g, '""')) + '"';
  }

  // ------------------------------------------------------------ intents
  const AGG = [
    [/^(sum|total|totals|jod|jodo|kul|add up|addition of|grand total)\b/, 'sum'], [/^(average|avg|mean|ausat|ausatan)\b/, 'avg'],
    [/^(count|how many|kitne|kitni|number of|ginti|ginti karo)\b/, 'count'], [/^(max|maximum|highest|largest|biggest|top value|sabse zyada|sabse jyada|sabse bada|sabse adhik)\b/, 'max'],
    [/^(min|minimum|lowest|smallest|least|sabse kam|sabse chhota)\b/, 'min'], [/^(unique|distinct|different)\b/, 'unique']
  ];
  const FN = { sum: ['SUM', 'SUMIFS'], avg: ['AVERAGE', 'AVERAGEIFS'], count: ['COUNTA', 'COUNTIFS'], max: ['MAX', 'MAXIFS'], min: ['MIN', 'MINIFS'], unique: ['COUNTUNIQUE', null] };
  const LABEL = { sum: 'Total', avg: 'Average', count: 'Count', max: 'Highest', min: 'Lowest', unique: 'Unique' };
  function clean(t) {
    let s = ' ' + t.toLowerCase().replace(/[“”]/g, '"').replace(/[‘’]/g, "'").replace(/[?!.]+\s*$/, '').replace(/[०-९]/g, d => String('०१२३४५६७८९'.indexOf(d))) + ' ';
    const re = /\s(please|plz|pls|kindly|can you|could you|i want to|i want|show me|give me|tell me|find|calculate|what is|what's|whats|batao|bataiye|nikalo|nikaliye|karo|kariye|dikhao|dikhaiye|do|ki|ka|ke)\s/g;
    for (let i = 0; i < 3; i++) s = s.replace(re, m => (/\s(ki|ka|ke)\s/.test(m) ? ' of ' : ' '));
    return s.replace(/\s+/g, ' ').trim();
  }
  function interpret(raw) {
    const ctx = context();
    const t = clean(raw);
    if (!t) return null;
    let m;
    // help
    if (/^(help|what can you do|examples?)$/.test(t)) return { title: 'Things you can ask', html: examplesHtml() };
    // explain
    if (/explain|samjha|what does (this|the) formula|formula ka matlab/.test(t)) return explainResult();
    // insert date / time
    if (/^(today|today's date|todays date|aaj|aaj ki date|insert date)$/.test(t)) return { title: 'Insert today\'s date', html: 'Puts today\'s date in the selected cell.', run: () => IS.run('insertDate') };
    if (/^(time|now|current time|abhi ka time)$/.test(t)) return { title: 'Insert the current time', html: 'Puts the time in the selected cell.', run: () => IS.run('insertTime') };
    if (!ctx) return { title: 'There is no data here yet', html: 'Type a small table first (a header row and some rows), click inside it and ask again. Or start from a <a href="#" data-cmd="templates">template</a>.' };
    // freeze
    if (/^(freeze|lock) (the )?(top row|header|heading|first row)/.test(t) || /^freeze$/.test(t)) return { title: 'Freeze the header row', html: 'Keeps row ' + (ctx.t0) + ' visible while you scroll.', run: () => { IS.tx('Freeze', () => { IS.rec.meta(ctx.sh); ctx.sh.freezeR = ctx.t0; }, { layout: true }); } };
    if (/^(unfreeze|remove freeze)/.test(t)) return { title: 'Unfreeze', run: () => IS.run('freeze', 'none') };
    // remove duplicates
    if (/(remove|delete|hatao) (the )?duplicates?/.test(t)) return { title: 'Remove duplicate rows', html: 'Opens the remove-duplicates tool for ' + esc(IS.rangesText([ctx.R])) + '.', run: () => IS.run('removeDuplicates') };
    // clear filter
    if (/^(clear|remove|reset) (the )?filters?|^show all( rows)?$/.test(t)) return { title: 'Show all rows', run: () => { if (ctx.sh.filter) IS.run('filterClear'); } };
    // sort
    if ((m = t.match(/^(?:sort|arrange|order)(?: (?:the )?(?:data|table|rows|list))?(?: by| on| according to)? (.+?)(?: (asc|ascending|a to z|a-z|low to high|smallest first|oldest first|desc|descending|z to a|z-a|high to low|largest first|biggest first|highest first|newest first|latest first))?$/))) {
      const col = findCol(m[1], ctx); if (!col) return notFound(m[1], ctx);
      const dir = m[2] && /desc|z to a|z-a|high to low|largest|biggest|highest|newest|latest/.test(m[2]) ? -1 : 1;
      return { title: 'Sort by ' + col.name + (dir < 0 ? ' (largest / Z first)' : ' (smallest / A first)'), html: 'Sorts rows ' + (ctx.t0 + 1) + '–' + (ctx.R.b + 1) + (ctx.header ? ', keeping the header row.' : '.'), run: () => IS.sortRange(ctx.sh, ctx.R, [{ c: col.c, dir }], ctx.header) };
    }
    // filter
    if ((m = t.match(/^(?:filter|show only|only show|keep only|sirf|only)\s+(.+)$/))) {
      const cond = parseCondition(m[1], ctx); if (!cond) return notFound(m[1], ctx);
      return { title: 'Filter: ' + cond.col.name + ' ' + opWord(cond.op) + ' ' + cond.value, html: 'Hides the other rows. Clear it with Data → Show all rows.', run: () => applyFilterCond(ctx, cond) };
    }
    // highlight / colour
    if ((m = t.match(/^(?:highlight|colou?r|mark|show in (?:red|green))\s+(.+)$/))) return highlight(m[1], ctx);
    // add gst
    if ((m = t.match(/^(?:add|calculate|include|apply|lagao)\s+gst\s*(?:@|at|of)?\s*(\d+(?:\.\d+)?)\s*%?(?:\s+(?:on|to|for|in)\s+(.+))?$/)) || (m = t.match(/^gst\s*(\d+(?:\.\d+)?)\s*%?(?:\s+(?:on|of)\s+(.+))?$/))) {
      const rate = +m[1]; const col = m[2] ? findCol(m[2], ctx) : ctx.cols.filter(x => x.numeric).slice(-1)[0];
      if (!col) return notFound(m[2] || 'amount', ctx);
      return { title: 'Add GST ' + rate + '% on ' + col.name, html: 'Adds two columns after the table: <b>GST ' + rate + '%</b> and <b>' + esc(col.name) + ' with GST</b>.', run: () => addGstColumns(ctx, col, rate) };
    }
    // amount in words
    if (/(in words|shabdo|shabdon|words me|words mein|to words)/.test(t)) {
      const hindi = /hindi/.test(t); const s = IS.state.sel; const v = val(ctx.sh, s.r, s.c);
      if (typeof v !== 'number') return { title: 'Select a number first', html: 'Click the cell with the amount, then ask again.' };
      const f = '=' + (hindi ? 'HINDIWORDS' : 'RUPEEWORDS') + '(' + A1(s.r, s.c) + ')';
      return placeFormula(ctx, f, { r: s.r, c: s.c + 1 }, (hindi ? 'Hindi' : 'English') + ' words for ' + A1(s.r, s.c));
    }
    // change case / trim
    if ((m = t.match(/^(?:make|convert|change)?\s*(?:(.+?)\s+(?:to|in|into)\s+)?(upper ?case|capitals?|capital letters|lower ?case|small letters|proper ?case|title case)$/))) {
      const op = /upper|capital/.test(m[2]) ? 'upper' : /lower|small/.test(m[2]) ? 'lower' : 'proper';
      return { title: 'Change text to ' + m[2], html: 'Applies to the selected cells.', run: () => IS.run('cleanup', op) };
    }
    if (/^(trim|remove extra spaces|clean spaces)/.test(t)) return { title: 'Trim extra spaces', run: () => IS.run('cleanup', 'trim') };
    // chart
    if ((m = t.match(/(?:chart|graph|plot)(?: of| for| showing)?\s*(.*?)(?:\s+by\s+(.+))?$/)) && /chart|graph|plot/.test(t)) return chartIntent(m[1], m[2], ctx, t);
    // summary / pivot
    if ((m = t.match(/^(?:summary|summarise|summarize|pivot|group|breakdown|total)\s+(?:of\s+)?(.+?)\s+(?:by|per|for each|each)\s+(.+)$/)) || (m = t.match(/^(.+?)\s+(?:by|per)\s+(.+?)\s+(?:summary|pivot|total|wise)$/))) {
      const vcol = findCol(m[1], ctx), rcol = findCol(m[2], ctx);
      if (vcol && rcol) return { title: 'Summary of ' + vcol.name + ' by ' + rcol.name, html: 'Creates a new sheet with a live summary table (SUMIFS).', run: () => IS.buildPivot({ sheetId: ctx.sh.id, range: ctx.R, row: rcol.c, row2: null, col: null, val: vcol.c, agg: vcol.numeric ? 'sum' : 'count', sort: 'desc', live: true }) };
    }
    // aggregates
    for (const [re, kind] of AGG) {
      const mm = t.match(re); if (!mm) continue;
      let rest = t.slice(mm[0].length).trim().replace(/^(of|the|all|in|for)\s+/, '').replace(/^(the)\s+/, '');
      let condText = null;
      const lead = rest.match(/^(where|when|jaha|jahan|if|with|having)\s+(.+)$/);
      if (lead) { condText = lead[2]; rest = ''; }
      const sp = !lead && rest.match(/^(.*?)\s+(where|when|for|jaha|jahan|if|with|having)\s+(.+)$/);
      if (sp) { rest = sp[1]; condText = sp[3]; }
      if (kind === 'count' && /^(rows|records|entries|items|lines|invoices|customers)?$/.test(rest)) rest = '';
      let col = rest ? findCol(rest, ctx) : null;
      if (rest && !col) {
        // "total for Steel" – no column named, value given
        const cond = parseCondition(rest, ctx);
        if (cond) { condText = null; return aggregate(kind, ctx.cols.filter(x => x.numeric && x.c !== cond.col.c).slice(-1)[0] || cond.col, [cond], ctx); }
        return notFound(rest, ctx);
      }
      if (!col) col = kind === 'count' ? ctx.cols[0] : ctx.cols.filter(x => x.numeric && !x.date).slice(-1)[0];
      if (!col) return notFound(rest || 'a number column', ctx);
      const conds = [];
      if (condText) for (const part of condText.split(/\s+(?:and|aur|&)\s+/)) { const c = parseCondition(part, ctx); if (!c) return notFound(part, ctx); conds.push(c); }
      return aggregate(kind, col, conds, ctx);
    }
    // "<column> total" / "<column> ka total"
    if ((m = t.match(/^(.+?)\s+(total|sum|average|avg|count)$/))) { const col = findCol(m[1], ctx); if (col) return aggregate(m[2] === 'average' || m[2] === 'avg' ? 'avg' : m[2] === 'count' ? 'count' : 'sum', col, [], ctx); }
    return fallback(raw);
  }
  const opWord = op => ({ '>': 'greater than', '<': 'less than', '>=': 'at least', '<=': 'at most', '<>': 'is not', '=': 'is', contains: 'contains', begins: 'starts with', ends: 'ends with' }[op] || op);
  function notFound(what, ctx) {
    return { title: 'I could not find "' + what + '"', html: 'The columns in this table are: ' + ctx.cols.map(c => '<span class="chip" data-ask="total of ' + esc(c.name) + '">' + esc(c.name) + '</span>').join('') + '<p class="hint">Use one of these names in your question.</p>' };
  }
  function aggregate(kind, col, conds, ctx) {
    const [plain, ifs] = FN[kind];
    let f;
    if (!conds.length) {
      if (kind === 'count') f = '=COUNTA(' + X.numToCol(col.c) + (ctx.t0 + 1) + ':' + X.numToCol(col.c) + (ctx.R.b + 1) + ')';
      else if (kind === 'unique') f = '=COUNTUNIQUE(' + X.numToCol(col.c) + (ctx.t0 + 1) + ':' + X.numToCol(col.c) + (ctx.R.b + 1) + ')';
      else f = '=' + plain + '(' + X.numToCol(col.c) + (ctx.t0 + 1) + ':' + X.numToCol(col.c) + (ctx.R.b + 1) + ')';
    } else {
      if (!ifs) return { title: 'Not available with conditions', html: 'Unique counts with conditions are not supported yet – use a filter first.' };
      const crit = conds.map(c => colRef(c.col.c) + ',' + critText(c)).join(',');
      f = kind === 'count' ? '=COUNTIFS(' + crit + ')' : '=' + ifs + '(' + colRef(col.c) + ',' + crit + ')';
    }
    const label = LABEL[kind] + ' of ' + col.name + (conds.length ? ' where ' + conds.map(c => c.col.name + ' ' + opWord(c.op) + ' ' + c.value).join(' and ') : '');
    const target = { r: ctx.R.b + 2, c: col.c };
    return placeFormula(ctx, f, target, label, col);
  }
  function freeSpot(sh, r, c) { while (IS.hasContent(sh, r, c) && r < sh.rows - 1) r++; return { r, c }; }
  function placeFormula(ctx, f, target, label, col) {
    const sh = ctx.sh, s = IS.state.sel;
    const activeEmpty = !IS.hasContent(sh, s.r, s.c) && !(s.r >= ctx.R.t && s.r <= ctx.R.b && s.c >= ctx.R.l && s.c <= ctx.R.r);
    const pos = activeEmpty ? { r: s.r, c: s.c } : freeSpot(sh, target.r, target.c);
    const v = IS.calc.evalTemp(sh, f, pos.r, pos.c);
    const nf = col ? (sh.cells[K(ctx.t0, col.c)] || {}).s : null;
    const shown = X.formatValue(v, nf && nf.nf && !/COUNT/.test(f) ? nf.nf : null).text;
    return {
      title: label, formula: f, at: A1(pos.r, pos.c),
      html: '<div class="formula">' + esc(f) + '</div>Result: <b>' + esc(shown) + '</b> → will be put in <b>' + A1(pos.r, pos.c) + '</b>' + (pos.c > 0 && !IS.hasContent(sh, pos.r, pos.c - 1) ? ' with a label in ' + A1(pos.r, pos.c - 1) : ''),
      run: () => {
        if (!IS.guardEdit({ t: pos.r, l: pos.c, b: pos.r, r: pos.c })) return;
        IS.tx('Ask: ' + label, () => {
          IS.writeText(sh, pos.r, pos.c, f);
          if (nf && nf.nf && !/COUNT/.test(f)) IS.editCell(sh, pos.r, pos.c, cl => { cl.s = Object.assign({}, cl.s, { nf: nf.nf }); });
          IS.editCell(sh, pos.r, pos.c, cl => { cl.s = Object.assign({}, cl.s, { b: true }); });
          if (pos.c > 0 && !IS.hasContent(sh, pos.r, pos.c - 1)) IS.editCell(sh, pos.r, pos.c - 1, cl => { cl.v = label.length > 60 ? label.slice(0, 57) + '…' : label; cl.s = Object.assign({}, cl.s, { al: 'right', i: true, color: '#5f6b65' }); });
        });
        IS.setSel(pos.r, pos.c);
      }
    };
  }
  function applyFilterCond(ctx, cond) {
    const sh = ctx.sh;
    if (!sh.filter || sh.filter.t !== ctx.R.t) { if (sh.filter) IS.tx('Remove filter', () => { IS.rec.meta(sh); sh.filter = null; IS.invalidateHidden(sh); }, { full: true }); IS.tx('Create filter', () => { IS.rec.meta(sh); sh.filter = { t: ctx.R.t, l: ctx.R.l, b: ctx.R.b, r: ctx.R.r, crit: {}, hidden: [] }; }, { full: true }); }
    const map = { '=': 'eq', '<>': 'neq', '>': 'gt', '<': 'lt', '>=': 'gte', '<=': 'lte', contains: 'contains', begins: 'begins', ends: 'ends' };
    IS.tx('Filter', () => { IS.rec.meta(sh); sh.filter.crit = sh.filter.crit || {}; sh.filter.crit[cond.col.c] = { op: map[cond.op] || 'eq', v1: cond.value }; IS.refilter(sh); }, { full: true });
    const n = (sh.filter.hidden || []).length; ui.toast(n + ' row' + (n === 1 ? '' : 's') + ' hidden.');
  }
  function highlight(text, ctx) {
    let color = 'red';
    const cm = text.match(/\s+(?:in|with|as)?\s*(red|green|yellow|orange|blue)$/); if (cm) { color = cm[1]; text = text.slice(0, cm.index).trim(); }
    const STY = { red: { bg: '#ffc7ce', color: '#9c0006' }, green: { bg: '#c6efce', color: '#006100' }, yellow: { bg: '#ffeb9c', color: '#9c5700' }, orange: { bg: '#fce5cd', color: '#b45f06' }, blue: { bg: '#cfe2f3', color: '#1a3c8f' } }[color];
    let m, col, rule;
    const dataRange = c => ({ t: ctx.t0, l: c, b: ctx.R.b, r: c });
    if ((m = text.match(/^(?:the )?(duplicates?|duplicate values|repeated|same)(?: values)?(?: in| of)?\s*(.*)$/))) { col = m[2] ? findCol(m[2], ctx) : ctx.cols[0]; if (!col) return notFound(m[2], ctx); rule = { type: 'dup', style: STY }; }
    else if ((m = text.match(/^(?:the )?(blanks?|empty cells?)(?: in)?\s*(.*)$/))) { col = m[2] ? findCol(m[2], ctx) : null; rule = { type: 'blank', style: STY }; if (!col) { return { title: 'Highlight empty cells in the table', run: () => IS.addCfRule(Object.assign({ ranges: [{ t: ctx.t0, l: ctx.R.l, b: ctx.R.b, r: ctx.R.r }] }, rule)) }; } }
    else if ((m = text.match(/^(?:the )?(overdue|past|late)(?: dates?)?(?: in)?\s*(.*)$/))) { col = m[2] ? findCol(m[2], ctx) : ctx.cols.find(x => x.date); if (!col) return notFound(m[2] || 'date column', ctx); rule = { type: 'date', op: 'past', style: STY }; }
    else if ((m = text.match(/^(?:the )?(top|bottom|highest|lowest)\s+(\d+)\s*(%|percent)?\s*(?:values?)?(?: in| of)?\s*(.*)$/))) { col = m[4] ? findCol(m[4], ctx) : ctx.cols.filter(x => x.numeric).slice(-1)[0]; if (!col) return notFound(m[4], ctx); rule = { type: /top|highest/.test(m[1]) ? 'top' : 'bottom', n: +m[2], pct: !!m[3], style: STY }; }
    else {
      const cond = parseCondition(text, ctx); if (!cond) return notFound(text, ctx);
      col = cond.col;
      const num = X.parseInput(cond.value).value;
      if (['contains', 'begins', 'ends'].includes(cond.op)) rule = { type: 'text', op: cond.op, text: cond.value, style: STY };
      else if (cond.op === '=' && typeof num !== 'number') rule = { type: 'text', op: 'exact', text: cond.value, style: STY };
      else rule = { type: 'cell', op: { '>': 'gt', '<': 'lt', '>=': 'gte', '<=': 'lte', '<>': 'neq', '=': 'eq' }[cond.op], v1: String(typeof num === 'number' ? num : cond.value), style: STY };
    }
    return { title: 'Highlight in ' + color + ': ' + text, html: 'Adds a conditional-formatting rule on <b>' + esc(col.name) + '</b> (' + X.numToCol(col.c) + (ctx.t0 + 1) + ':' + X.numToCol(col.c) + (ctx.R.b + 1) + ').', run: () => IS.addCfRule(Object.assign({ ranges: [dataRange(col.c)] }, rule)) };
  }
  function addGstColumns(ctx, col, rate) {
    const sh = ctx.sh, c1 = ctx.R.r + 1, c2 = ctx.R.r + 2;
    if (!IS.guardEdit({ t: ctx.R.t, l: c1, b: ctx.R.b, r: c2 })) return;
    const nf = ((sh.cells[K(ctx.t0, col.c)] || {}).s || {}).nf || '#,##0.00';
    IS.tx('Add GST columns', () => {
      if (ctx.header) {
        const hs = (sh.cells[K(ctx.R.t, col.c)] || {}).s;
        IS.writeText(sh, ctx.R.t, c1, 'GST ' + rate + '%'); IS.writeText(sh, ctx.R.t, c2, col.name + ' with GST');
        if (hs) { IS.editCell(sh, ctx.R.t, c1, cl => { cl.s = Object.assign({}, hs); }); IS.editCell(sh, ctx.R.t, c2, cl => { cl.s = Object.assign({}, hs); }); }
      }
      for (let r = ctx.t0; r <= ctx.R.b; r++) {
        const ref = A1(r, col.c);
        IS.writeText(sh, r, c1, '=IF(' + ref + '="","",GST(' + ref + ',' + rate + '))');
        IS.writeText(sh, r, c2, '=IF(' + ref + '="","",' + ref + '+' + A1(r, c1) + ')');
        IS.editCell(sh, r, c1, cl => { cl.s = Object.assign({}, cl.s, { nf }); }); IS.editCell(sh, r, c2, cl => { cl.s = Object.assign({}, cl.s, { nf }); });
      }
    });
    IS.setSel(ctx.R.t, c1, ctx.R.b, c2);
  }
  function chartIntent(what, by, ctx, t) {
    const type = /pie/.test(t) ? 'pie' : /line|trend/.test(t) ? 'line' : /bar/.test(t) ? 'bar' : /donut|doughnut/.test(t) ? 'doughnut' : 'column';
    const vcol = what ? findCol(what.replace(/^(a|an|the)\s+/, '').replace(/^(pie|line|bar|column|donut|doughnut)\s*(chart|graph)?\s*(of)?\s*/, ''), ctx) : null;
    const value = vcol || ctx.cols.filter(x => x.numeric && !x.date).slice(-1)[0];
    let label = by ? findCol(by, ctx) : ctx.cols.find(x => !x.numeric || x.date);
    if (!value) return notFound(what || 'a number column', ctx);
    if (!label || label.c === value.c) label = ctx.cols.find(x => x.c !== value.c) || value;
    return {
      title: 'Insert a ' + type + ' chart of ' + value.name + ' by ' + label.name,
      html: 'The chart updates automatically when the numbers change.',
      run: () => {
        const sh = ctx.sh; let src;
        if (Math.abs(label.c - value.c) === 1 && label.c < value.c) src = X.numToCol(label.c) + (ctx.R.t + 1) + ':' + X.numToCol(value.c) + (ctx.R.b + 1);
        else {
          // pick the two columns with one dynamic-array formula next to the table
          const hc = ctx.R.r + 2;
          IS.tx('Chart data', () => { IS.writeText(sh, ctx.R.t, hc, '=CHOOSECOLS(' + X.numToCol(ctx.R.l) + (ctx.R.t + 1) + ':' + X.numToCol(ctx.R.r) + (ctx.R.b + 1) + ',' + (label.c - ctx.R.l + 1) + ',' + (value.c - ctx.R.l + 1) + ')'); });
          src = X.numToCol(hc) + (ctx.R.t + 1) + ':' + X.numToCol(hc + 1) + (ctx.R.b + 1);
        }
        const o = { id: IS.rid('o'), type: 'chart', r: ctx.R.t, c: ctx.R.r + 5, dx: 0, dy: 0, w: 520, h: 310, chart: { src, type, title: value.name + ' by ' + label.name, legend: type === 'pie' || type === 'doughnut' ? 'right' : 'none' } };
        IS.tx('Insert chart', () => { IS.rec.meta(sh); sh.objects.push(o); });
        IS.grid.scrollIntoView(o.r, o.c + 3);
      }
    };
  }
  function fallback(raw) {
    const words = raw.toLowerCase().split(/[^a-z0-9ऀ-ॿ]+/).filter(w => w.length > 2 && !['the', 'and', 'for', 'how', 'what', 'with', 'from', 'this', 'that', 'want', 'can', 'you', 'please'].includes(w));
    const scored = Object.entries(X.FN_INFO).map(([n, i]) => { const hay = (n + ' ' + i.desc + ' ' + i.cat).toLowerCase(); let s = 0; words.forEach(w => { if (hay.includes(w)) s += hay.indexOf(n.toLowerCase()) === 0 && n.toLowerCase().includes(w) ? 3 : 1; }); return [n, i, s]; }).filter(x => x[2] > 0).sort((a, b) => b[2] - a[2]).slice(0, 6);
    return {
      title: scored.length ? 'These formulas may help' : 'Sorry, I did not understand that',
      html: (scored.length ? '<table class="table">' + scored.map(([n, i]) => '<tr class="clickable" data-insert="' + n + '"><td class="mono"><b>' + esc(i.sig) + '</b></td><td>' + esc(i.desc) + '</td></tr>').join('') + '</table><p class="hint">Click one to start typing it in the selected cell.</p>' : '') + examplesHtml()
    };
  }
  function examplesHtml() {
    const ex = ['total of amount', 'average rate where item is steel', 'count where status is unpaid', 'highest amount', 'sort by date newest first', 'filter amount greater than 10000', 'highlight duplicates in invoice no', 'highlight amount above 50000 in green', 'add gst 18% on amount', 'summary of amount by customer', 'pie chart of amount by category', 'amount in words', 'amount ka total', 'explain this formula'];
    return '<h3>Try</h3>' + ex.map(e => '<span class="chip" data-ask="' + esc(e) + '">' + esc(e) + '</span>').join('');
  }

  // ------------------------------------------------------------ explain a formula
  function headerName(sh, r, c) {
    const ctx = context(); if (!ctx || !ctx.header || c < ctx.R.l || c > ctx.R.r) return null;
    if (r <= ctx.R.t) return null;
    return String(disp(sh, ctx.R.t, c) || '') || null;
  }
  function describeNode(n, sh) {
    switch (n.t) {
      case 'num': return String(n.v);
      case 'str': return '“' + n.v + '”';
      case 'bool': return n.v ? 'TRUE' : 'FALSE';
      case 'blank': return 'nothing';
      case 'errv': return n.v.code;
      case 'name': return 'the named range ' + n.v;
      case 'ref': { const h = !n.sheet ? headerName(sh, n.r, n.c) : null; return (n.sheet ? n.sheet + '!' : '') + A1(n.r, n.c) + (h ? ' (' + h + ')' : ''); }
      case 'range': {
        const r2 = n.r2 === Infinity ? null : n.r2, c2 = n.c2 === Infinity ? null : n.c2;
        const txt = (n.sheet ? n.sheet + '!' : '') + (r2 === null ? X.numToCol(n.c1) + ':' + X.numToCol(n.c2) : c2 === null ? (n.r1 + 1) + ':' + (n.r2 + 1) : A1(n.r1, n.c1) + ':' + A1(r2, c2));
        const h = !n.sheet && n.c1 === n.c2 ? headerName(sh, Math.max(n.r1, 1), n.c1) : null;
        return (h ? 'the ' + h + ' cells ' : 'cells ') + txt;
      }
      case 'neg': return 'minus ' + describeNode(n.e, sh);
      case 'pct': return describeNode(n.e, sh) + ' percent';
      case 'bin': {
        const w = { '+': 'plus', '-': 'minus', '*': 'times', '/': 'divided by', '^': 'to the power of', '&': 'joined with', '=': 'is equal to', '<>': 'is not equal to', '>': 'is greater than', '<': 'is less than', '>=': 'is at least', '<=': 'is at most' }[n.op];
        return describeNode(n.l, sh) + ' ' + w + ' ' + describeNode(n.r, sh);
      }
      case 'array': return 'the list {' + n.rows.map(r => r.map(x => describeNode(x, sh)).join(', ')).join('; ') + '}';
      case 'fn': {
        const a = n.args.map(x => describeNode(x, sh)), N = n.name;
        const D = {
          SUM: () => 'the total of ' + a.join(' and '), AVERAGE: () => 'the average of ' + a.join(' and '), COUNT: () => 'how many numbers are in ' + a.join(' and '), COUNTA: () => 'how many cells are filled in ' + a.join(' and '),
          MAX: () => 'the largest value in ' + a.join(' and '), MIN: () => 'the smallest value in ' + a.join(' and '), ROUND: () => a[0] + ' rounded to ' + (a[1] || 0) + ' decimal places',
          IF: () => 'if ' + a[0] + ', then ' + (a[1] || 'TRUE') + ', otherwise ' + (a[2] || 'FALSE'), IFERROR: () => a[0] + ' – or ' + a[1] + ' if that gives an error', IFS: () => 'the first matching choice among: ' + a.join(' / '),
          AND: () => 'all of these are true: ' + a.join('; '), OR: () => 'any of these is true: ' + a.join('; '), NOT: () => 'NOT (' + a[0] + ')',
          VLOOKUP: () => 'look up ' + a[0] + ' in the first column of ' + a[1] + ' and return column ' + a[2] + (n.args[3] && /FALSE|^0$/.test(a[3]) ? ' (exact match)' : ' (closest match)'),
          XLOOKUP: () => 'find ' + a[0] + ' in ' + a[1] + ' and return the matching value from ' + a[2] + (a[3] ? ' (or ' + a[3] + ' if not found)' : ''),
          INDEX: () => 'the value in ' + a[0] + ' at row ' + (a[1] || '1') + (a[2] ? ', column ' + a[2] : ''), MATCH: () => 'the position of ' + a[0] + ' in ' + a[1],
          SUMIF: () => 'the total of ' + (a[2] || a[0]) + ' where ' + a[0] + ' matches ' + a[1], COUNTIF: () => 'how many of ' + a[0] + ' match ' + a[1], AVERAGEIF: () => 'the average of ' + (a[2] || a[0]) + ' where ' + a[0] + ' matches ' + a[1],
          SUMIFS: () => 'the total of ' + a[0] + ' where ' + pairs(a.slice(1)), COUNTIFS: () => 'how many rows have ' + pairs(a), AVERAGEIFS: () => 'the average of ' + a[0] + ' where ' + pairs(a.slice(1)), MAXIFS: () => 'the largest of ' + a[0] + ' where ' + pairs(a.slice(1)), MINIFS: () => 'the smallest of ' + a[0] + ' where ' + pairs(a.slice(1)),
          TODAY: () => "today's date", NOW: () => 'the date and time now', RUPEEWORDS: () => a[0] + ' written in words as Indian rupees', HINDIWORDS: () => a[0] + ' written in Hindi words',
          GST: () => 'the GST at ' + a[1] + '% on ' + a[0], CGST: () => 'the CGST (half of ' + a[1] + '%) on ' + a[0], SGST: () => 'the SGST (half of ' + a[1] + '%) on ' + a[0], WITHGST: () => a[0] + ' plus GST at ' + a[1] + '%', EMI: () => 'the monthly EMI for a loan of ' + a[0] + ' at ' + a[1] + '% a year for ' + a[2] + ' months',
          CONCAT: () => a.join(' joined with '), TEXT: () => a[0] + ' shown in the format ' + a[1], LEFT: () => 'the first ' + (a[1] || 1) + ' characters of ' + a[0], RIGHT: () => 'the last ' + (a[1] || 1) + ' characters of ' + a[0],
          SUBTOTAL: () => 'a total of ' + a.slice(1).join(', ') + ' that ignores hidden (filtered) rows', UPIQR: () => 'a UPI payment QR code for ' + a[0] + (a[2] ? ' asking for ' + a[2] : ''), METALWEIGHT: () => 'the weight in kg of a ' + a[0] + ' piece'
        };
        if (D[N]) return D[N]();
        const info = X.FN_INFO[N];
        return N + '(' + a.join(', ') + ')' + (info ? ' – ' + info.desc.toLowerCase() : '');
      }
    }
    return '?';
  }
  const pairs = a => { const out = []; for (let i = 0; i + 1 < a.length; i += 2) out.push(a[i] + ' matches ' + a[i + 1]); return out.join(' and '); };
  function explainResult() {
    const sh = IS.sheet, s = IS.state.sel; const cell = sh.cells[K(s.r, s.c)];
    const f = IS.state.editing ? (document.getElementById('fx').value) : (cell && IS.isFormulaCell(cell) ? cell.v : null);
    if (!f || f[0] !== '=') return { title: 'Select a cell with a formula', html: 'Click a cell that has a formula (it starts with =) and ask again.' };
    const ast = X.getAst(f);
    if (ast.parseError) return { title: 'This formula has a problem', html: '<div class="formula">' + esc(f) + '</div>' + esc(ast.parseError) };
    const v = IS.calc.value(sh, s.r, s.c);
    const parts = [];
    const walk = n => { if (n.t === 'fn') { parts.push('<li><b>' + esc(n.name) + '</b>: ' + esc(X.FN_INFO[n.name] ? X.FN_INFO[n.name].desc : '') + '</li>'); n.args.forEach(walk); } else if (n.t === 'bin') { walk(n.l); walk(n.r); } else if (n.t === 'neg' || n.t === 'pct') walk(n.e); };
    walk(ast);
    const shown = X.formatValue(v, cell && cell.s && cell.s.nf).text;
    return { title: 'What ' + A1(s.r, s.c) + ' does', html: '<div class="formula">' + esc(f) + '</div><p>It calculates <b>' + esc(describeNode(ast, sh)) + '</b>.</p><p>Current result: <b>' + esc(shown) + '</b></p>' + (parts.length ? '<h3>Functions used</h3><ul class="explain-tree">' + parts.join('') + '</ul>' : '') };
  }

  // ------------------------------------------------------------ the panel
  function panel(prefill) {
    const wrap = document.createElement('div');
    wrap.innerHTML = '<p class="hint">Type what you want in plain words – English or Hinglish. Works offline.</p>' +
      '<input class="ask-input" id="askInput" placeholder="e.g. total of amount where item is steel" autocomplete="off">' +
      '<div id="askOut"></div><div id="askEx">' + examplesHtml() + '</div>';
    const body = ui.side('Ask India Sheets ✨', wrap, { kind: 'ask' });
    const inp = body.querySelector('#askInput'), out = body.querySelector('#askOut');
    let current = null;
    const ask = text => {
      inp.value = text;
      let res; try { res = interpret(text); } catch (e) { console.error(e); res = { title: 'Something went wrong', html: esc(e.message) }; }
      current = res;
      if (!res) { out.innerHTML = ''; return; }
      out.innerHTML = '<div class="ask-answer"><b>' + esc(res.title) + '</b><div style="margin-top:6px">' + (res.html || '') + '</div>' + (res.run ? '<div style="margin-top:10px;display:flex;gap:8px"><button type="button" class="btn primary" id="askDo">Do it</button>' + (res.formula ? '<button type="button" class="btn" id="askCopy">Copy formula</button>' : '') + '</div>' : '') + '</div>';
      const d = out.querySelector('#askDo'); if (d) d.onclick = () => { try { res.run(); ui.toast('Done ✓', { ms: 1500 }); } catch (e) { ui.toast(e.message, { type: 'error' }); } };
      const cp = out.querySelector('#askCopy'); if (cp) cp.onclick = () => { navigator.clipboard && navigator.clipboard.writeText(res.formula).then(() => ui.toast('Formula copied')); };
    };
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); if (current && current.run && inp.value === current._q && e.ctrlKey) current.run(); else { ask(inp.value); if (current) current._q = inp.value; } } e.stopPropagation(); });
    body.addEventListener('click', e => {
      const chip = e.target.closest('[data-ask]'); if (chip) { ask(chip.dataset.ask); return; }
      const ins = e.target.closest('[data-insert]'); if (ins) { IS.run('insertFunction', ins.dataset.insert); return; }
    });
    setTimeout(() => inp.focus(), 30);
    if (prefill) ask(prefill);
  }

  // ------------------------------------------------------------ trace precedents / dependents
  function trace(kind) {
    const sh = IS.sheet, s = IS.state.sel;
    const colors = ['#1e6fd9', '#d32f2f', '#7b1fa2', '#2e7d32', '#ef6c00'];
    let boxes = [], other = [];
    if (kind === 'pre') {
      const p = IS.calc.precedents(sh, s.r, s.c);
      p.cells.forEach(x => { if (x.sid === sh.id) boxes.push({ t: x.r, l: x.c, b: x.r, r: x.c }); else other.push((IS.sheetById(x.sid) || {}).name + '!' + A1(x.r, x.c)); });
      p.ranges.forEach(g => { if (g.sid === sh.id) boxes.push({ t: g.r1, l: g.c1, b: Math.min(g.r2, sh.rows - 1), r: Math.min(g.c2, sh.cols - 1) }); else other.push((IS.sheetById(g.sid) || {}).name + '!' + A1(g.r1, g.c1) + ':' + A1(g.r2 === Infinity ? 0 : g.r2, g.c2 === Infinity ? 0 : g.c2)); });
      if (!boxes.length && !other.length) { ui.toast('This cell does not use other cells.'); return; }
    } else {
      const d = IS.calc.dependentsOf(sh, s.r, s.c);
      d.forEach(x => { if (x.sid === sh.id) boxes.push({ t: x.r, l: x.c, b: x.r, r: x.c }); else other.push((IS.sheetById(x.sid) || {}).name + '!' + A1(x.r, x.c)); });
      if (!boxes.length && !other.length) { ui.toast('No formulas use this cell.'); return; }
    }
    IS.state.trace = { sheet: sh.id, boxes: boxes.map((b, i) => Object.assign(b, { color: colors[i % colors.length] })) };
    IS.grid.invalidate();
    ui.toast((kind === 'pre' ? 'Cells used by ' : 'Cells that use ') + A1(s.r, s.c) + ' are outlined' + (other.length ? '. On other sheets: ' + other.slice(0, 5).join(', ') : '') + '. Press Esc to clear.', { ms: 6000 });
  }

  Object.assign(IS.cmd, {
    assistant: q => panel(typeof q === 'string' ? q : null),
    explainFormula: () => { const res = explainResult(); ui.modal({ title: res.title, body: res.html }); },
    tracePrecedents: () => trace('pre'),
    traceDependents: () => trace('dep')
  });
  IS.assistant = { interpret };
})(window);
