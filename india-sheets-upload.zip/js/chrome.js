/* India Sheets – menu bar, toolbar and right-click menus */
(function (global) {
  'use strict';
  const IS = global.IS, ui = IS.ui, X = global.Formula;
  const $ = id => document.getElementById(id);
  const kb = s => (/Mac|iPhone|iPad/.test(navigator.platform) ? s.replace(/Ctrl\+/g, '⌘').replace(/Alt\+/g, '⌥') : s);

  const NUMBER_FORMATS = () => [
    { label: 'Automatic', onClick: () => IS.run('nf', null) },
    { label: 'Plain text', onClick: () => IS.run('nf', '@') },
    { sep: true },
    { html: 'Number <span class="mi-eg">1,23,456.00</span>', onClick: () => IS.run('nf', '#,##0.00') },
    { html: 'Whole number <span class="mi-eg">1,23,456</span>', onClick: () => IS.run('nf', '#,##0') },
    { html: 'Rupees <span class="mi-eg">₹1,23,456.00</span>', onClick: () => IS.run('nf', '"₹"#,##0.00') },
    { html: 'Rupees, no paise <span class="mi-eg">₹1,23,456</span>', onClick: () => IS.run('nf', '"₹"#,##0') },
    { html: 'Short rupees <span class="mi-eg">₹1.23 L · ₹2.5 Cr</span>', onClick: () => IS.run('nf', '[INRSHORT]') },
    { html: 'Accounting <span class="mi-eg">₹ (1,250.00)</span>', onClick: () => IS.run('nf', '"₹"#,##0.00;[Red]("₹"#,##0.00);"-"') },
    { html: 'Percent <span class="mi-eg">12.50%</span>', onClick: () => IS.run('nf', '0.00%') },
    { html: 'Scientific <span class="mi-eg">1.23E+05</span>', onClick: () => IS.run('nf', '0.00E+00') },
    { html: 'Dollar / other currency <span class="mi-eg">$1,234.00</span>', sub: [['$', '"$"#,##0.00'], ['€', '"€"#,##0.00'], ['£', '"£"#,##0.00'], ['AED', '"AED "#,##0.00'], ['¥', '"¥"#,##0']].map(([l, c]) => ({ label: l, onClick: () => IS.run('nf', c) })) },
    { sep: true },
    { html: 'Date <span class="mi-eg">25-11-2026</span>', onClick: () => IS.run('nf', 'dd-mm-yyyy') },
    { html: 'Date <span class="mi-eg">25/11/2026</span>', onClick: () => IS.run('nf', 'dd/mm/yyyy') },
    { html: 'Date <span class="mi-eg">25 Nov 2026</span>', onClick: () => IS.run('nf', 'd mmm yyyy') },
    { html: 'Long date <span class="mi-eg">Wednesday, 25 November 2026</span>', onClick: () => IS.run('nf', 'dddd, d mmmm yyyy') },
    { html: 'Month <span class="mi-eg">Nov-26</span>', onClick: () => IS.run('nf', 'mmm-yy') },
    { html: 'Time <span class="mi-eg">3:45 PM</span>', onClick: () => IS.run('nf', 'h:mm AM/PM') },
    { html: 'Time <span class="mi-eg">15:45:00</span>', onClick: () => IS.run('nf', 'hh:mm:ss') },
    { html: 'Date & time <span class="mi-eg">25-11-2026 15:45</span>', onClick: () => IS.run('nf', 'dd-mm-yyyy hh:mm') },
    { html: 'Hours over 24 <span class="mi-eg">[h]:mm</span>', onClick: () => IS.run('nf', '[h]:mm') },
    { sep: true },
    { label: 'Custom number format…', cmd: 'customFormat' }
  ];
  const BORDERS = () => [
    { label: 'All borders', onClick: () => IS.run('borders', 'all') }, { label: 'Outside border', onClick: () => IS.run('borders', 'outer') }, { label: 'Inside borders', onClick: () => IS.run('borders', 'inner') },
    { label: 'Thick box', onClick: () => IS.run('borders', 'thickBox') }, { sep: true },
    { label: 'Top', onClick: () => IS.run('borders', 'top') }, { label: 'Bottom', onClick: () => IS.run('borders', 'bottom') }, { label: 'Double bottom (totals)', onClick: () => IS.run('borders', 'doubleBottom') },
    { label: 'Left', onClick: () => IS.run('borders', 'left') }, { label: 'Right', onClick: () => IS.run('borders', 'right') },
    { label: 'Horizontal inside', onClick: () => IS.run('borders', 'horizontal') }, { label: 'Vertical inside', onClick: () => IS.run('borders', 'vertical') },
    { sep: true }, { label: 'No borders', onClick: () => IS.run('borders', 'none') },
    { sep: true },
    { label: 'Line style', sub: [['Thin', 'thin'], ['Medium', 'medium'], ['Thick', 'thick'], ['Dashed', 'dashed'], ['Dotted', 'dotted'], ['Double', 'double']].map(([l, v]) => ({ label: l, checked: (IS.state.borderStyle || 'thin') === v, onClick: () => { IS.state.borderStyle = v; } })) },
    { label: 'Line colour…', onClick: () => ui.palette(window.innerWidth / 2 - 120, 140, c => { IS.state.borderColor = c; }, { noneLabel: 'Black' }) }
  ];
  const FUNCTIONS = () => ['SUM', 'AVERAGE', 'COUNT', 'MAX', 'MIN', 'IF', 'SUMIF', 'VLOOKUP', 'XLOOKUP', 'IFERROR', 'ROUND', 'RUPEEWORDS', 'GST', 'EMI', 'TODAY'].map(n => ({ html: '<b>' + n + '</b> <span class="mi-eg">' + ui.esc((X.FN_INFO[n] || {}).desc || '') + '</span>', onClick: () => IS.run('insertFunction', n) }))
    .concat([{ sep: true }, { label: 'All formulas (' + Object.keys(X.FN_INFO).length + ')…', cmd: 'functions' }]);
  const ZOOMS = () => [50, 75, 90, 100, 110, 125, 150, 175, 200].map(z => ({ label: z + '%', checked: Math.round(IS.state.zoom * 100) === z, onClick: () => IS.run('zoomTo', z / 100) }));
  const SPECIAL = ['₹', '✓', '✗', '°', '×', '÷', '±', '≤', '≥', '≠', '€', '£', '$', '©', '®', '™', '•', '→', '←', '↑', '↓', '★', '½', '¼', '²', '³', 'µ', 'Ω', '∑', '√', '∞'];

  const MENUS = {
    File: () => [
      { label: 'New workbook', icon: 'filePlus', cmd: 'newBook' },
      { label: 'New from template…', icon: 'table', cmd: 'templates' },
      { label: 'Open file…', icon: 'folder', shortcut: kb('Ctrl+O'), cmd: 'openFile' },
      { label: 'My workbooks…', icon: 'folder', cmd: 'home' },
      { sep: true },
      { label: 'Save now', shortcut: kb('Ctrl+S'), cmd: 'saveNow' },
      { label: 'Download as', icon: 'download', sub: () => IS.menus.downloads() },
      { label: 'Make a copy', icon: 'copy', cmd: 'copyBook' },
      { label: 'Rename', cmd: 'rename' },
      { label: 'Delete this workbook…', icon: 'trash', cmd: 'deleteBook' },
      { sep: true },
      { label: 'Import from a web link…', icon: 'upload', cmd: 'importUrl' },
      { label: 'Version history…', icon: 'history', cmd: 'versionHistory' },
      { label: 'Save a named version…', cmd: 'saveVersion' },
      { sep: true },
      { label: 'Print or save as PDF…', icon: 'print', shortcut: kb('Ctrl+P'), cmd: 'print' },
      { sep: true },
      { label: 'Settings…', cmd: 'settings' }
    ],
    Edit: () => [
      { label: 'Undo', icon: 'undo', shortcut: kb('Ctrl+Z'), cmd: 'undo' },
      { label: 'Redo', icon: 'redo', shortcut: kb('Ctrl+Y'), cmd: 'redo' },
      { sep: true },
      { label: 'Cut', shortcut: kb('Ctrl+X'), cmd: 'cut' },
      { label: 'Copy', icon: 'copy', shortcut: kb('Ctrl+C'), cmd: 'copy' },
      { label: 'Paste', shortcut: kb('Ctrl+V'), cmd: 'paste' },
      { label: 'Paste special', sub: [{ label: 'Values only', shortcut: kb('Ctrl+Shift+V'), cmd: 'pasteValues' }, { label: 'Formats only', cmd: 'pasteFormats' }, { label: 'Formulas only', cmd: 'pasteFormulas' }, { label: 'Transposed (rows ↔ columns)', cmd: 'pasteTranspose' }, { label: 'Column widths only', cmd: 'pasteWidths' }] },
      { sep: true },
      { label: 'Find', icon: 'search', shortcut: kb('Ctrl+F'), cmd: 'find' },
      { label: 'Find and replace…', shortcut: kb('Ctrl+H'), cmd: 'findReplace' },
      { label: 'Go to cell or name', shortcut: kb('Ctrl+G'), cmd: 'goTo' },
      { sep: true },
      { label: 'Fill down', shortcut: kb('Ctrl+D'), cmd: 'fillDown' },
      { label: 'Fill right', shortcut: kb('Ctrl+R'), cmd: 'fillRight' },
      { label: 'Fill series…', cmd: 'fillSeries' },
      { sep: true },
      { label: 'Clear', icon: 'eraser', sub: [{ label: 'Everything', cmd: 'clearAll' }, { label: 'Contents', shortcut: 'Del', cmd: 'clearContents' }, { label: 'Formatting', shortcut: kb('Ctrl+\\'), cmd: 'clearFormats' }, { label: 'Notes', cmd: 'clearNotes' }] },
      { label: 'Delete', icon: 'trash', sub: [{ label: 'Selected rows', cmd: 'deleteRows' }, { label: 'Selected columns', cmd: 'deleteCols' }] },
      { sep: true },
      { label: 'Select all', shortcut: kb('Ctrl+A'), cmd: 'selectAll' }
    ],
    View: () => {
      const sh = IS.sheet, s = IS.state.sel;
      return [
        { label: 'Freeze', icon: 'snow', sub: [
          { label: 'No freeze', checked: !sh.freezeR && !sh.freezeC, onClick: () => IS.run('freeze', 'none') },
          { label: '1 row', checked: sh.freezeR === 1, onClick: () => IS.run('freeze', 'row1') }, { label: '2 rows', checked: sh.freezeR === 2, onClick: () => IS.run('freeze', 'row2') },
          { label: 'Up to row ' + (s.r), disabled: s.r < 1, onClick: () => IS.run('freeze', 'rowsHere') },
          { sep: true },
          { label: '1 column', checked: sh.freezeC === 1, onClick: () => IS.run('freeze', 'col1') }, { label: '2 columns', checked: sh.freezeC === 2, onClick: () => IS.run('freeze', 'col2') },
          { label: 'Up to column ' + X.numToCol(Math.max(0, s.c - 1)), disabled: s.c < 1, onClick: () => IS.run('freeze', 'colsHere') },
          { sep: true }, { label: 'Up to the current cell', disabled: s.r < 1 && s.c < 1, onClick: () => IS.run('freeze', 'here') }] },
        { label: 'Gridlines', checked: sh.showGrid !== false, cmd: 'toggleGrid' },
        { label: 'Formulas instead of results', checked: IS.state.showFormulas, shortcut: kb('Ctrl+`'), cmd: 'toggleFormulas' },
        { label: 'Zoom', sub: ZOOMS },
        { label: 'Theme', icon: 'moon', sub: [['Light (white) – default', 'light'], ['Dark (black)', 'dark'], ['Same as Windows', 'system']].map(([l, v]) => ({ label: l, checked: IS.prefs.get('theme', 'light') === v, onClick: () => IS.run('theme', v) })) },
        { label: 'Full screen', cmd: 'fullscreen' },
        { sep: true },
        { label: 'Hidden sheets', disabled: !IS.wb.sheets.some(x => x.hidden), sub: () => IS.wb.sheets.filter(x => x.hidden).map(x => ({ label: x.name, onClick: () => IS.run('unhideSheet', x.id) })) }
      ];
    },
    Insert: () => [
      { label: 'Rows above', cmd: 'insertRowsAbove' }, { label: 'Rows below', cmd: 'insertRowsBelow' },
      { label: 'Columns left', cmd: 'insertColsLeft' }, { label: 'Columns right', cmd: 'insertColsRight' },
      { label: 'Sheet', shortcut: 'Shift+F11', cmd: 'addSheet' },
      { sep: true },
      { label: 'Chart', icon: 'chart', cmd: 'insertChart' },
      { label: 'Image / logo', icon: 'image', cmd: 'insertImage' },
      { label: 'Checkbox', icon: 'check', cmd: 'insertCheckbox' },
      { label: 'Dropdown list', icon: 'chevronDown', cmd: 'dropdownList' },
      { label: 'Link', icon: 'link', shortcut: kb('Ctrl+K'), cmd: 'insertLink' },
      { label: 'Note', icon: 'note', shortcut: 'Shift+F2', cmd: 'editNote' },
      { sep: true },
      { label: 'Function', icon: 'sigma', sub: FUNCTIONS },
      { label: "Today's date", shortcut: kb('Ctrl+;'), cmd: 'insertDate' },
      { label: 'Current time', shortcut: kb('Ctrl+Shift+;'), cmd: 'insertTime' },
      { sep: true },
      { label: 'UPI payment QR code', icon: 'qr', cmd: 'insertUPI' },
      { label: 'QR code', icon: 'qr', cmd: 'insertQR' },
      { label: 'Sparkline (mini chart)', icon: 'chart', cmd: 'insertSparkline' },
      { label: 'Special character', sub: SPECIAL.map(ch => ({ label: ch, onClick: () => IS.run('insertText', ch) })) }
    ],
    Format: () => [
      { label: 'Number', icon: 'rupee', sub: NUMBER_FORMATS },
      { label: 'Text', icon: 'bold', sub: [{ label: 'Bold', shortcut: kb('Ctrl+B'), cmd: 'bold' }, { label: 'Italic', shortcut: kb('Ctrl+I'), cmd: 'italic' }, { label: 'Underline', shortcut: kb('Ctrl+U'), cmd: 'underline' }, { label: 'Strikethrough', shortcut: kb('Ctrl+5'), cmd: 'strike' }, { sep: true }, { label: 'Bigger', cmd: 'fontBigger' }, { label: 'Smaller', cmd: 'fontSmaller' }] },
      { label: 'Alignment', icon: 'alignLeft', sub: [{ label: 'Left', cmd: 'alignLeft' }, { label: 'Centre', shortcut: kb('Ctrl+Shift+E'), cmd: 'alignCenter' }, { label: 'Right', cmd: 'alignRight' }, { label: 'Automatic', cmd: 'alignAuto' }, { sep: true }, { label: 'Top', cmd: 'vTop' }, { label: 'Middle', cmd: 'vMiddle' }, { label: 'Bottom', cmd: 'vBottom' }, { sep: true }, { label: 'Increase indent', cmd: 'indentMore' }, { label: 'Decrease indent', cmd: 'indentLess' }] },
      { label: 'Wrapping', icon: 'wrap', sub: [{ label: 'Overflow', cmd: 'wrapOff' }, { label: 'Wrap', cmd: 'wrapOn' }] },
      { label: 'Merge cells', icon: 'merge', sub: [{ label: 'Merge all', cmd: 'mergeAll' }, { label: 'Merge horizontally', cmd: 'mergeRows' }, { label: 'Merge vertically', cmd: 'mergeCols' }, { label: 'Unmerge', cmd: 'unmerge' }] },
      { label: 'Borders', icon: 'borders', sub: BORDERS },
      { sep: true },
      { label: 'Format cells…', shortcut: kb('Ctrl+1'), cmd: 'formatCells' },
      { label: 'Conditional formatting…', cmd: 'conditionalFormat' },
      { label: 'Format as table (alternating colours)…', icon: 'table', cmd: 'formatAsTable' },
      { label: 'Format painter', icon: 'painter', cmd: 'formatPainter' },
      { sep: true },
      { label: 'Row height…', cmd: 'rowHeight' }, { label: 'Column width…', cmd: 'colWidth' },
      { label: 'Fit column width to text', cmd: 'autofitCols' }, { label: 'Fit row height to text', cmd: 'autofitRows' },
      { label: 'Hide / unhide', sub: [{ label: 'Hide rows', shortcut: kb('Ctrl+9'), cmd: 'hideRows' }, { label: 'Hide columns', shortcut: kb('Ctrl+0'), cmd: 'hideCols' }, { label: 'Unhide rows', cmd: 'unhideRows' }, { label: 'Unhide columns', cmd: 'unhideCols' }, { label: 'Unhide all rows', cmd: 'unhideAllRows' }, { label: 'Unhide all columns', cmd: 'unhideAllCols' }] },
      { sep: true },
      { label: 'Clear formatting', icon: 'eraser', shortcut: kb('Ctrl+\\'), cmd: 'clearFormats' }
    ],
    Data: () => [
      { label: 'Sort A → Z', icon: 'sort', cmd: 'sortAsc' }, { label: 'Sort Z → A', cmd: 'sortDesc' }, { label: 'Sort range (advanced)…', cmd: 'sortDialog' },
      { sep: true },
      { label: IS.sheet.filter ? 'Remove filter' : 'Create a filter', icon: 'filter', shortcut: kb('Ctrl+Shift+L'), cmd: 'filterToggle' },
      { label: 'Filter by this cell\'s value', cmd: 'filterByValue' },
      { label: 'Show all rows (clear filter)', disabled: !IS.sheet.filter, cmd: 'filterClear' },
      { sep: true },
      { label: 'Remove duplicates…', cmd: 'removeDuplicates' },
      { label: 'Split text to columns…', cmd: 'textToColumns' },
      { label: 'Data clean-up', sub: [{ label: 'Trim extra spaces', onClick: () => IS.run('cleanup', 'trim') }, { label: 'UPPER CASE', onClick: () => IS.run('cleanup', 'upper') }, { label: 'lower case', onClick: () => IS.run('cleanup', 'lower') }, { label: 'Proper Case', onClick: () => IS.run('cleanup', 'proper') }, { sep: true }, { label: 'Convert text to numbers', onClick: () => IS.run('cleanup', 'numbers') }, { label: 'Fill blank cells from above', onClick: () => IS.run('cleanup', 'fillBlanks') }, { label: 'Remove blank rows', onClick: () => IS.run('cleanup', 'blankRows') }, { label: 'Remove line breaks', onClick: () => IS.run('cleanup', 'breaks') }, { label: 'Formulas → values', onClick: () => IS.run('cleanup', 'values') }] },
      { sep: true },
      { label: 'Data validation…', cmd: 'dataValidation' },
      { label: 'Dropdown list…', cmd: 'dropdownList' },
      { sep: true },
      { label: 'Pivot / summary table…', icon: 'table', cmd: 'pivot' },
      IS.sheet.pivot ? { label: 'Refresh this summary table', cmd: 'refreshPivot' } : null,
      { label: 'Named ranges…', cmd: 'namedRanges' },
      { sep: true },
      { label: (IS.sheet.protect && IS.sheet.protect.on ? 'Unprotect sheet…' : 'Protect sheet…'), icon: 'lock', cmd: 'protectSheet' }
    ],
    Tools: () => [
      { label: 'Ask India Sheets (type what you want)', icon: 'sparkles', shortcut: kb('Ctrl+Shift+A'), cmd: 'assistant' },
      { label: 'Explain this formula', cmd: 'explainFormula' },
      { label: 'Trace precedents (cells used here)', cmd: 'tracePrecedents' },
      { label: 'Trace dependents (cells using this)', cmd: 'traceDependents' },
      { sep: true },
      { label: 'India tools', icon: 'rupee', sub: [{ label: 'GST calculator', onClick: () => IS.run('indiaTools', 'gst') }, { label: 'Loan EMI calculator', onClick: () => IS.run('indiaTools', 'emi') }, { label: 'Amount in words (English / Hindi)', onClick: () => IS.run('indiaTools', 'words') }, { label: 'GSTIN / PAN / IFSC checker', onClick: () => IS.run('indiaTools', 'check') }, { label: 'Metal weight calculator', onClick: () => IS.run('indiaTools', 'metal') }, { label: 'Unit converter', onClick: () => IS.run('indiaTools', 'units') }] },
      { sep: true },
      { label: 'Voice typing', icon: 'mic', cmd: 'voiceTyping' },
      { label: 'Read aloud (check entries)', icon: 'speaker', cmd: 'readAloud' },
      { sep: true },
      { label: 'Recalculate everything', shortcut: 'F9', cmd: 'recalc' }
    ],
    Help: () => [
      { label: 'Keyboard shortcuts', shortcut: kb('Ctrl+/'), cmd: 'shortcuts' },
      { label: 'All formulas', icon: 'sigma', cmd: 'functions' },
      { label: 'Templates', icon: 'table', cmd: 'templates' },
      { label: 'Quick tour', cmd: 'welcome' },
      { sep: true },
      { label: 'Plan & billing', icon: 'rupee', cmd: 'plan' },
      { label: 'Privacy policy', cmd: 'privacy' },
      { label: 'About India Sheets', cmd: 'about' }
    ]
  };

  IS.menus = {
    downloads: () => [
      { html: 'Excel workbook <span class="mi-eg">.xlsx</span>', onClick: () => IS.run('download', 'xlsx') },
      { html: 'Excel 97–2003 <span class="mi-eg">.xls</span>', onClick: () => IS.run('download', 'xls') },
      { html: 'OpenDocument / LibreOffice <span class="mi-eg">.ods</span>', onClick: () => IS.run('download', 'ods') },
      { html: 'PDF document <span class="mi-eg">.pdf</span>', onClick: () => IS.run('download', 'pdf') },
      { html: 'CSV – this sheet <span class="mi-eg">.csv</span>', onClick: () => IS.run('download', 'csv') },
      { html: 'Tab-separated <span class="mi-eg">.tsv</span>', onClick: () => IS.run('download', 'tsv') },
      { html: 'Web page <span class="mi-eg">.html</span>', onClick: () => IS.run('download', 'html') },
      { html: 'JSON data <span class="mi-eg">.json</span>', onClick: () => IS.run('download', 'json') },
      { html: 'Markdown table <span class="mi-eg">.md</span>', onClick: () => IS.run('download', 'md') },
      { html: 'Picture of selection <span class="mi-eg">.png</span>', onClick: () => IS.run('download', 'png') },
      { sep: true },
      { html: 'India Sheets file <span class="mi-eg">.isheet</span>', onClick: () => IS.run('download', 'isheet') },
      { html: 'Password-protected file <span class="mi-eg">.isheet</span>', icon: 'lock', onClick: () => IS.run('download', 'locked') }
    ],
    cellContext: () => {
      const sh = IS.sheet, s = IS.state.sel, cell = sh.cells[IS.K(s.r, s.c)];
      return [
        { label: 'Cut', shortcut: kb('Ctrl+X'), cmd: 'cut' }, { label: 'Copy', icon: 'copy', shortcut: kb('Ctrl+C'), cmd: 'copy' }, { label: 'Paste', shortcut: kb('Ctrl+V'), cmd: 'paste' },
        { label: 'Paste special', sub: [{ label: 'Values only', cmd: 'pasteValues' }, { label: 'Formats only', cmd: 'pasteFormats' }, { label: 'Formulas only', cmd: 'pasteFormulas' }, { label: 'Transposed', cmd: 'pasteTranspose' }] },
        { sep: true },
        { label: 'Insert rows above', cmd: 'insertRowsAbove' }, { label: 'Insert columns left', cmd: 'insertColsLeft' },
        { label: 'Delete rows', cmd: 'deleteRows' }, { label: 'Delete columns', cmd: 'deleteCols' },
        { label: 'Clear contents', shortcut: 'Del', cmd: 'clearContents' },
        { sep: true },
        { label: cell && cell.n ? 'Edit note' : 'Insert note', icon: 'note', cmd: 'editNote' },
        { label: cell && cell.s && cell.s.link ? 'Edit link' : 'Insert link', icon: 'link', cmd: 'insertLink' },
        { label: 'Dropdown list…', icon: 'chevronDown', cmd: 'dropdownList' },
        { label: 'Checkbox', icon: 'check', cmd: 'insertCheckbox' },
        { sep: true },
        { label: 'Sort A → Z', icon: 'sort', cmd: 'sortAsc' }, { label: 'Sort Z → A', cmd: 'sortDesc' },
        { label: 'Filter by this value', icon: 'filter', cmd: 'filterByValue' },
        { label: 'Conditional formatting…', cmd: 'conditionalFormat' },
        { label: 'Data validation…', cmd: 'dataValidation' },
        { label: 'Format cells…', shortcut: kb('Ctrl+1'), cmd: 'formatCells' },
        { sep: true },
        { label: 'Explain formula', icon: 'sparkles', cmd: 'explainFormula', disabled: !(cell && IS.isFormulaCell(cell)) },
        { label: 'Ask India Sheets…', icon: 'sparkles', cmd: 'assistant' }
      ];
    },
    rowContext: () => [
      { label: 'Cut', cmd: 'cut' }, { label: 'Copy', icon: 'copy', cmd: 'copy' }, { label: 'Paste', cmd: 'paste' }, { sep: true },
      { label: 'Insert rows above', cmd: 'insertRowsAbove' }, { label: 'Insert rows below', cmd: 'insertRowsBelow' }, { label: 'Delete rows', icon: 'trash', cmd: 'deleteRows' },
      { label: 'Clear rows', cmd: 'clearContents' }, { sep: true },
      { label: 'Hide rows', cmd: 'hideRows' }, { label: 'Unhide rows', cmd: 'unhideRows' },
      { label: 'Row height…', cmd: 'rowHeight' }, { label: 'Fit to text', cmd: 'autofitRows' }, { sep: true },
      { label: 'Freeze up to this row', onClick: () => { const R = IS.selRect(); IS.state.sel.r = R.b + 1; IS.run('freeze', 'rowsHere'); } }
    ],
    colContext: () => [
      { label: 'Cut', cmd: 'cut' }, { label: 'Copy', icon: 'copy', cmd: 'copy' }, { label: 'Paste', cmd: 'paste' }, { sep: true },
      { label: 'Insert columns left', cmd: 'insertColsLeft' }, { label: 'Insert columns right', cmd: 'insertColsRight' }, { label: 'Delete columns', icon: 'trash', cmd: 'deleteCols' },
      { label: 'Clear columns', cmd: 'clearContents' }, { sep: true },
      { label: 'Sort sheet A → Z', icon: 'sort', cmd: 'sortAsc' }, { label: 'Sort sheet Z → A', cmd: 'sortDesc' }, { sep: true },
      { label: 'Hide columns', cmd: 'hideCols' }, { label: 'Unhide columns', cmd: 'unhideCols' },
      { label: 'Column width…', cmd: 'colWidth' }, { label: 'Fit to text', cmd: 'autofitCols' }, { sep: true },
      { label: 'Freeze up to this column', onClick: () => { const R = IS.selRect(); IS.state.sel.c = R.r + 1; IS.run('freeze', 'colsHere'); } }
    ],
    sheetContext: i => [
      { label: 'Rename', onClick: () => IS.run('renameSheet', i) },
      { label: 'Duplicate', icon: 'copy', onClick: () => IS.run('duplicateSheet', i) },
      { label: 'Tab colour', onClick: () => IS.run('sheetColor', i) },
      { label: 'Move left', disabled: i === 0, onClick: () => IS.run('moveSheetLeft', i) },
      { label: 'Move right', disabled: i === IS.wb.sheets.length - 1, onClick: () => IS.run('moveSheetRight', i) },
      { label: 'Hide sheet', onClick: () => IS.run('hideSheet', i) },
      { label: (IS.wb.sheets[i].protect && IS.wb.sheets[i].protect.on ? 'Unprotect sheet…' : 'Protect sheet…'), icon: 'lock', onClick: () => { IS.activateSheet(i); IS.run('protectSheet'); } },
      { sep: true },
      { label: 'Delete sheet', icon: 'trash', onClick: () => IS.run('deleteSheet', i) }
    ]
  };

  // ---------------------------------------------------------------- toolbar
  const TB = [
    ['undo', 'undo', 'Undo (Ctrl+Z)'], ['redo', 'redo', 'Redo (Ctrl+Y)'], ['print', 'print', 'Print or PDF (Ctrl+P)'], ['formatPainter', 'painter', 'Format painter – copy formatting'], '|',
    ['zoomMenu', null, 'Zoom', '<span id="tbZoom">100%</span>' + ui.icon('chevronDown', 12)], '|',
    ['nf:"₹"#,##0.00', null, 'Rupee format (Ctrl+Shift+4)', '₹'], ['nf:0.00%', null, 'Percent format', '%'], ['decDown', null, 'Fewer decimal places', '.0<small>←</small>'], ['decUp', null, 'More decimal places', '.00<small>→</small>'],
    ['numberMenu', null, 'More number formats', '<span id="tbFormat">123</span>' + ui.icon('chevronDown', 12)], '|',
    ['fontMenu', null, 'Font', '<span id="tbFontLabel" class="tb-font">Default</span>' + ui.icon('chevronDown', 12)],
    ['sizeMenu', null, 'Font size', '<span id="tbSizeLabel">10</span>' + ui.icon('chevronDown', 12)], '|',
    ['bold', 'bold', 'Bold (Ctrl+B)'], ['italic', 'italic', 'Italic (Ctrl+I)'], ['strike', 'strike', 'Strikethrough (Ctrl+5)'],
    ['textColor', null, 'Text colour', '<span class="tb-color"><b>A</b><i id="tbTextColorBar"></i></span>', 'tbTextColor'], '|',
    ['fillColor', null, 'Fill colour', '<span class="tb-color">' + ui.icon('fill', 16) + '<i id="tbFillColorBar"></i></span>', 'tbFillColor'],
    ['bordersMenu', 'borders', 'Borders'], ['mergeToggle', 'merge', 'Merge / unmerge cells'], '|',
    ['alignMenu', 'alignLeft', 'Horizontal align'], ['valignMenu', 'vBottom', 'Vertical align'], ['wrapToggle', 'wrap', 'Wrap text'], '|',
    ['insertLink', 'link', 'Insert link (Ctrl+K)'], ['editNote', 'note', 'Insert note (Shift+F2)'], ['insertChart', 'chart', 'Insert chart'], ['filterToggle', 'filter', 'Create a filter (Ctrl+Shift+L)'],
    ['functionsMenu', 'sigma', 'Functions'], '|',
    ['voiceTyping', 'mic', 'Voice typing'], ['indiaToolsMenu', 'rupee', 'India tools: GST, EMI, words, GSTIN…']
  ];
  function buildToolbar() {
    const tb = $('toolbar'); tb.innerHTML = '';
    TB.forEach(item => {
      if (item === '|') { const s = document.createElement('span'); s.className = 'tb-sep'; tb.appendChild(s); return; }
      const [cmdArg, icon, title, html, id] = item;
      const b = document.createElement('button'); b.type = 'button'; b.className = 'tb-btn'; b.title = title; b.setAttribute('aria-label', title);
      const i = cmdArg.indexOf(':');
      if (i > 0) { b.dataset.cmd = cmdArg.slice(0, i); b.dataset.arg = cmdArg.slice(i + 1); } else b.dataset.cmd = cmdArg;
      if (id) b.id = id;
      b.innerHTML = html || ui.icon(icon);
      if (html && icon) b.innerHTML = ui.icon(icon) + html;
      tb.appendChild(b);
    });
  }
  const dropAt = (id, items) => { const b = document.querySelector('[data-cmd="' + id + '"]'); const r = b.getBoundingClientRect(); ui.menu(items, r.left, r.bottom + 4); };
  const FONTS = ['', 'Arial', 'Calibri', 'Cambria', 'Georgia', 'Times New Roman', 'Verdana', 'Tahoma', 'Trebuchet MS', 'Segoe UI', 'Courier New', 'Consolas', 'Comic Sans MS', 'Nirmala UI', 'Mangal', 'Shruti'];
  Object.assign(IS.cmd = IS.cmd || {}, {
    zoomMenu: () => dropAt('zoomMenu', ZOOMS()),
    numberMenu: () => dropAt('numberMenu', NUMBER_FORMATS()),
    fontMenu: () => dropAt('fontMenu', FONTS.map(f => ({ html: '<span style="font-family:' + (f ? "'" + f + "'" : 'inherit') + '">' + (f || 'Default (Segoe UI)') + '</span>' + (f === 'Nirmala UI' || f === 'Mangal' ? ' <span class="mi-eg">हिन्दी</span>' : f === 'Shruti' ? ' <span class="mi-eg">ગુજરાતી</span>' : ''), onClick: () => IS.run('fontFamily', f) }))),
    sizeMenu: () => dropAt('sizeMenu', [6, 7, 8, 9, 10, 11, 12, 14, 16, 18, 20, 24, 28, 32, 36, 48].map(n => ({ label: String(n), onClick: () => IS.run('fontSize', n) }))),
    bordersMenu: () => dropAt('bordersMenu', BORDERS()),
    alignMenu: () => dropAt('alignMenu', [{ label: 'Left', icon: 'alignLeft', cmd: 'alignLeft' }, { label: 'Centre', icon: 'alignCenter', cmd: 'alignCenter' }, { label: 'Right', icon: 'alignRight', cmd: 'alignRight' }, { label: 'Automatic', cmd: 'alignAuto' }, { sep: true }, { label: 'Increase indent', cmd: 'indentMore' }, { label: 'Decrease indent', cmd: 'indentLess' }]),
    valignMenu: () => dropAt('valignMenu', [{ label: 'Top', icon: 'vTop', cmd: 'vTop' }, { label: 'Middle', icon: 'vMiddle', cmd: 'vMiddle' }, { label: 'Bottom', icon: 'vBottom', cmd: 'vBottom' }]),
    functionsMenu: () => dropAt('functionsMenu', [{ label: 'SUM (AutoSum)', shortcut: 'Alt+=', onClick: () => IS.run('autosum', 'SUM') }, { label: 'AVERAGE', onClick: () => IS.run('autosum', 'AVERAGE') }, { label: 'COUNT', onClick: () => IS.run('autosum', 'COUNT') }, { label: 'MAX', onClick: () => IS.run('autosum', 'MAX') }, { label: 'MIN', onClick: () => IS.run('autosum', 'MIN') }, { sep: true }].concat(FUNCTIONS())),
    indiaToolsMenu: () => dropAt('indiaToolsMenu', MENUS.Tools()[5].sub.concat([{ sep: true }, { label: 'GST invoice template', onClick: () => IS.run('newFromTemplate', 'gst-invoice') }])),
    insertText: t => { if (IS.state.editing) { const inp = document.activeElement; if (inp && inp.setRangeText) { inp.setRangeText(t, inp.selectionStart, inp.selectionEnd, 'end'); inp.dispatchEvent(new Event('input')); } return; } IS.startEdit((IS.editText(IS.sheet, IS.state.sel.r, IS.state.sel.c) || '') + t, 'edit'); }
  });
  IS.on('select', () => {
    const sh = IS.sheet, s = IS.state.sel, cell = sh.cells[IS.K(s.r, s.c)], st = (cell && cell.s) || {};
    const f = $('tbFontLabel'); if (f) f.textContent = st.ff || 'Default';
    const z = $('tbSizeLabel'); if (z) z.textContent = String(st.fs || 10);
  });
  IS.on('ready', () => { const z = $('tbZoom'); if (z) z.textContent = Math.round(IS.state.zoom * 100) + '%'; });
  const origZoom = () => { const z = $('tbZoom'); if (z) z.textContent = Math.round(IS.state.zoom * 100) + '%'; };
  IS.on('layout', origZoom);

  // ---------------------------------------------------------------- menu bar
  let menuOpen = null;
  function buildMenubar() {
    const bar = $('menubar'); bar.innerHTML = '';
    Object.keys(MENUS).forEach(name => {
      const b = document.createElement('button'); b.type = 'button'; b.textContent = name; b.className = 'mb-btn';
      const open = () => {
        if (IS.state.editing && !IS.commitEdit()) return;
        const r = b.getBoundingClientRect();
        ui.menu(MENUS[name](), r.left, r.bottom + 2);
        document.querySelectorAll('.mb-btn.open').forEach(x => x.classList.remove('open'));
        b.classList.add('open'); menuOpen = name;
      };
      b.addEventListener('click', e => { e.stopPropagation(); if (menuOpen === name && ui.popupOpen) { ui.closePopups(); menuOpen = null; b.classList.remove('open'); } else open(); });
      b.addEventListener('mouseenter', () => { if (menuOpen && menuOpen !== name && ui.popupOpen) open(); });
      bar.appendChild(b);
    });
    document.addEventListener('mousedown', e => { if (!e.target.closest('.popup') && !e.target.closest('.mb-btn')) { menuOpen = null; document.querySelectorAll('.mb-btn.open').forEach(x => x.classList.remove('open')); } }, true);
  }
  IS.buildChrome = function () {
    buildMenubar(); buildToolbar();
    const keysEl = $('gridKeys');
    keysEl.addEventListener('focus', () => document.body.classList.add('grid-focus'));
    keysEl.addEventListener('blur', () => document.body.classList.remove('grid-focus'));
    document.addEventListener('keydown', e => {
      if ((e.ctrlKey || e.metaKey) && e.shiftKey && e.key.toLowerCase() === 'a') { e.preventDefault(); IS.run('assistant'); }
    });
  };
})(window);
