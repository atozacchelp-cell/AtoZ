/* India Sheets – function library (Excel / Google Sheets compatible + India extras) */
(function (global) {
  'use strict';
  const X = global.Formula;
  const { E, Range, Rich, isErr, isRange, isRich, scalar, norm, toNum, toStr, toBool, n1, s1, b1, opt, nums, allVals, toRange,
    compare, criteria, wildcard, lookupIndex, round, toSerial, fromSerial, todaySerial, nowSerial, inWords, hindiWords, parseInput, parseRef } = X;
  const F = X.F;
  const blank = v => v === undefined || v === null;
  const arg = (a, i, d) => (blank(a[i]) ? d : a[i]);
  const mean = v => v.reduce((x, y) => x + y, 0) / v.length;
  const R = rows => new Range(rows);
  const col = v => R(v.map(x => [x]));
  const rowR = v => R([v]);

  // ---------------------------------------------------------------- math
  Object.assign(F, {
    SUM: a => nums(a).reduce((x, y) => x + y, 0),
    SUMSQ: a => nums(a).reduce((s, x) => s + x * x, 0),
    PRODUCT: a => nums(a).reduce((x, y) => x * y, 1),
    AVERAGE: a => { const v = nums(a); if (!v.length) throw E.DIV0; return mean(v); },
    AVERAGEA: a => { const v = allVals(a).filter(x => !blank(x)).map(x => (typeof x === 'number' ? x : typeof x === 'boolean' ? +x : 0)); if (!v.length) throw E.DIV0; return mean(v); },
    MIN: a => { const v = nums(a); return v.length ? Math.min(...v) : 0; },
    MAX: a => { const v = nums(a); return v.length ? Math.max(...v) : 0; },
    COUNT: a => allVals(a).filter(v => typeof v === 'number').length,
    COUNTA: a => allVals(a).filter(v => v !== null && v !== undefined && v !== '').length,
    COUNTBLANK: a => allVals(a).filter(v => v === null || v === undefined || v === '').length,
    ABS: a => Math.abs(n1(a[0])),
    SQRT: a => { const n = n1(a[0]); if (n < 0) throw E.NUM; return Math.sqrt(n); },
    POWER: a => { const p = Math.pow(n1(a[0]), n1(a[1])); if (!isFinite(p)) throw E.NUM; return p; },
    EXP: a => Math.exp(n1(a[0])),
    LN: a => { const n = n1(a[0]); if (n <= 0) throw E.NUM; return Math.log(n); },
    LOG: a => { const n = n1(a[0]), b = blank(a[1]) ? 10 : n1(a[1]); if (n <= 0 || b <= 0 || b === 1) throw E.NUM; return Math.log(n) / Math.log(b); },
    LOG10: a => { const n = n1(a[0]); if (n <= 0) throw E.NUM; return Math.log10(n); },
    MOD: a => { const n = n1(a[0]), d = n1(a[1]); if (d === 0) throw E.DIV0; return n - d * Math.floor(n / d); },
    QUOTIENT: a => { const d = n1(a[1]); if (d === 0) throw E.DIV0; return Math.trunc(n1(a[0]) / d); },
    INT: a => Math.floor(n1(a[0])),
    TRUNC: a => { const d = blank(a[1]) ? 0 : n1(a[1]); const f = Math.pow(10, d); return Math.trunc(n1(a[0]) * f) / f; },
    ROUND: a => round(n1(a[0]), blank(a[1]) ? 0 : n1(a[1])),
    ROUNDUP: a => { const n = n1(a[0]), f = Math.pow(10, blank(a[1]) ? 0 : n1(a[1])); return (n < 0 ? -1 : 1) * Math.ceil(round(Math.abs(n) * f, 9)) / f; },
    ROUNDDOWN: a => { const n = n1(a[0]), f = Math.pow(10, blank(a[1]) ? 0 : n1(a[1])); return (n < 0 ? -1 : 1) * Math.floor(round(Math.abs(n) * f, 9)) / f; },
    CEILING: a => { const n = n1(a[0]), s = blank(a[1]) ? 1 : Math.abs(n1(a[1])); return s === 0 ? 0 : Math.ceil(round(n / s, 9)) * s; },
    FLOOR: a => { const n = n1(a[0]), s = blank(a[1]) ? 1 : Math.abs(n1(a[1])); if (s === 0) throw E.DIV0; return Math.floor(round(n / s, 9)) * s; },
    MROUND: a => { const n = n1(a[0]), s = n1(a[1]); if (s === 0) return 0; if (n * s < 0) throw E.NUM; return round(Math.round(n / s) * s, 10); },
    EVEN: a => { const n = n1(a[0]); const c = Math.ceil(Math.abs(n)); return Math.sign(n || 1) * (c % 2 ? c + 1 : c); },
    ODD: a => { const n = n1(a[0]); const c = Math.ceil(Math.abs(n)); return Math.sign(n || 1) * (c % 2 ? c : c + 1); },
    SIGN: a => Math.sign(n1(a[0])),
    PI: () => Math.PI,
    RAND: () => Math.random(),
    RANDBETWEEN: a => { const lo = Math.ceil(n1(a[0])), hi = Math.floor(n1(a[1])); if (hi < lo) throw E.NUM; return lo + Math.floor(Math.random() * (hi - lo + 1)); },
    RANDARRAY: a => {
      const r = n1(arg(a, 0, 1)), c = n1(arg(a, 1, 1)), lo = n1(arg(a, 2, 0)), hi = n1(arg(a, 3, 1)), int = b1(arg(a, 4, false));
      if (r < 1 || c < 1 || r * c > 1e6) throw E.VALUE;
      return R(Array.from({ length: r }, () => Array.from({ length: c }, () => int ? lo + Math.floor(Math.random() * (hi - lo + 1)) : lo + Math.random() * (hi - lo))));
    },
    SIN: a => Math.sin(n1(a[0])), COS: a => Math.cos(n1(a[0])), TAN: a => Math.tan(n1(a[0])),
    ASIN: a => Math.asin(n1(a[0])), ACOS: a => Math.acos(n1(a[0])), ATAN: a => Math.atan(n1(a[0])), ATAN2: a => Math.atan2(n1(a[1]), n1(a[0])),
    RADIANS: a => n1(a[0]) * Math.PI / 180, DEGREES: a => n1(a[0]) * 180 / Math.PI,
    GCD: a => { const v = nums(a).map(Math.floor); const g = (x, y) => (y ? g(y, x % y) : x); return v.reduce((x, y) => g(x, y), 0); },
    LCM: a => { const v = nums(a).map(Math.floor); const g = (x, y) => (y ? g(y, x % y) : x); return v.reduce((x, y) => (x && y ? x * y / g(x, y) : 0), 1); },
    FACT: a => { const n = Math.floor(n1(a[0])); if (n < 0 || n > 170) throw E.NUM; let f = 1; for (let i = 2; i <= n; i++) f *= i; return f; },
    COMBIN: a => { const n = Math.floor(n1(a[0])), k = Math.floor(n1(a[1])); if (k < 0 || n < k) throw E.NUM; let r = 1; for (let i = 1; i <= k; i++) r = r * (n - k + i) / i; return Math.round(r); },
    PERMUT: a => { const n = Math.floor(n1(a[0])), k = Math.floor(n1(a[1])); if (k < 0 || n < k) throw E.NUM; let r = 1; for (let i = 0; i < k; i++) r *= n - i; return r; },
    SUMPRODUCT: a => {
      const rs = a.map(x => (isRange(x) ? x.flat() : [x]));
      const len = rs[0].length; if (rs.some(r => r.length !== len)) throw E.VALUE;
      let s = 0;
      for (let i = 0; i < len; i++) { let p = 1; for (const r of rs) { const v = norm(r[i]); if (isErr(v)) throw v; p *= typeof v === 'number' ? v : typeof v === 'boolean' ? +v : 0; } s += p; }
      return s;
    },
    SEQUENCE: a => {
      const r = n1(arg(a, 0, 1)), c = n1(arg(a, 1, 1)), st = n1(arg(a, 2, 1)), step = n1(arg(a, 3, 1));
      if (r < 1 || c < 1 || r * c > 1e6) throw E.VALUE;
      return R(Array.from({ length: r }, (_, i) => Array.from({ length: c }, (_, j) => st + (i * c + j) * step)));
    }
  });
  F['CEILING.MATH'] = F.CEILING; F['FLOOR.MATH'] = F.FLOOR;

  // ---------------------------------------------------------------- statistics
  const sorted = a => nums(a).sort((x, y) => x - y);
  const stdev = (v, pop) => { const n = v.length; if (n < (pop ? 1 : 2)) throw E.DIV0; const m = mean(v); return Math.sqrt(v.reduce((s, x) => s + (x - m) ** 2, 0) / (n - (pop ? 0 : 1))); };
  const variance = (v, pop) => { const n = v.length; if (n < (pop ? 1 : 2)) throw E.DIV0; const m = mean(v); return v.reduce((s, x) => s + (x - m) ** 2, 0) / (n - (pop ? 0 : 1)); };
  const percentile = (v, k) => { if (!v.length || k < 0 || k > 1) throw E.NUM; const pos = k * (v.length - 1), lo = Math.floor(pos), hi = Math.ceil(pos); return v[lo] + (v[hi] - v[lo]) * (pos - lo); };
  const pairs = (ys, xs) => { const y = toRange(ys).flat(), x = toRange(xs).flat(); if (y.length !== x.length) throw E.NA; const out = []; for (let i = 0; i < y.length; i++) if (typeof y[i] === 'number' && typeof x[i] === 'number') out.push([x[i], y[i]]); return out; };
  const linreg = p => { const n = p.length; if (n < 2) throw E.DIV0; const mx = mean(p.map(q => q[0])), my = mean(p.map(q => q[1])); let sxy = 0, sxx = 0; p.forEach(([x, y]) => { sxy += (x - mx) * (y - my); sxx += (x - mx) ** 2; }); if (sxx === 0) throw E.DIV0; const slope = sxy / sxx; return { slope, intercept: my - slope * mx }; };
  Object.assign(F, {
    MEDIAN: a => { const v = sorted(a); if (!v.length) throw E.NUM; const m = Math.floor(v.length / 2); return v.length % 2 ? v[m] : (v[m - 1] + v[m]) / 2; },
    MODE: a => { const v = nums(a), c = new Map(); let best = null, bc = 1; v.forEach(x => { const k = (c.get(x) || 0) + 1; c.set(x, k); if (k > bc) { bc = k; best = x; } }); if (best === null) throw E.NA; return best; },
    STDEV: a => stdev(nums(a)), STDEVP: a => stdev(nums(a), true),
    VAR: a => variance(nums(a)), VARP: a => variance(nums(a), true),
    LARGE: a => { const v = nums([a[0]]).sort((x, y) => y - x); const k = Math.ceil(n1(a[1])); if (k < 1 || k > v.length) throw E.NUM; return v[k - 1]; },
    SMALL: a => { const v = nums([a[0]]).sort((x, y) => x - y); const k = Math.ceil(n1(a[1])); if (k < 1 || k > v.length) throw E.NUM; return v[k - 1]; },
    RANK: a => { const x = n1(a[0]); const asc = !blank(a[2]) && n1(a[2]) !== 0; const v = nums([a[1]]).sort((p, q) => (asc ? p - q : q - p)); const i = v.indexOf(x); if (i < 0) throw E.NA; return i + 1; },
    PERCENTILE: a => percentile(sorted([a[0]]), n1(a[1])),
    QUARTILE: a => { const q = Math.floor(n1(a[1])); if (q < 0 || q > 4) throw E.NUM; return percentile(sorted([a[0]]), q / 4); },
    CORREL: a => { const p = pairs(a[0], a[1]); const n = p.length; if (n < 2) throw E.DIV0; const mx = mean(p.map(q => q[0])), my = mean(p.map(q => q[1])); let sxy = 0, sxx = 0, syy = 0; p.forEach(([x, y]) => { sxy += (x - mx) * (y - my); sxx += (x - mx) ** 2; syy += (y - my) ** 2; }); if (!sxx || !syy) throw E.DIV0; return sxy / Math.sqrt(sxx * syy); },
    SLOPE: a => linreg(pairs(a[0], a[1])).slope,
    INTERCEPT: a => linreg(pairs(a[0], a[1])).intercept,
    FORECAST: a => { const l = linreg(pairs(a[1], a[2])); return l.intercept + l.slope * n1(a[0]); },
    COUNTUNIQUE: a => new Set(allVals(a).filter(v => v !== null && v !== '' && v !== undefined).map(v => String(norm(v)).toLowerCase())).size,
    GEOMEAN: a => { const v = nums(a); if (!v.length || v.some(x => x <= 0)) throw E.NUM; return Math.exp(v.reduce((s, x) => s + Math.log(x), 0) / v.length); }
  });
  Object.assign(F, { 'MODE.SNGL': F.MODE, 'STDEV.S': F.STDEV, 'STDEV.P': F.STDEVP, 'VAR.S': F.VAR, 'VAR.P': F.VARP, 'RANK.EQ': F.RANK, 'PERCENTILE.INC': F.PERCENTILE, 'QUARTILE.INC': F.QUARTILE, 'FORECAST.LINEAR': F.FORECAST, UNIQUECOUNT: F.COUNTUNIQUE });

  // ---------------------------------------------------------------- conditional aggregates
  function multiIf(pairsArgs, valRange, kind) {
    const tests = [];
    for (let i = 0; i < pairsArgs.length; i += 2) tests.push([toRange(pairsArgs[i]).flat(), criteria(pairsArgs[i + 1])]);
    const vals = valRange ? toRange(valRange).flat() : null;
    const len = tests.length ? tests[0][0].length : 0;
    if (tests.some(t => t[0].length !== len) || (vals && vals.length !== len)) throw E.VALUE;
    let s = 0, n = 0, mx = -Infinity, mn = Infinity;
    for (let i = 0; i < len; i++) {
      if (!tests.every(([rg, c]) => c(rg[i]))) continue;
      if (kind === 'count') { n++; continue; }
      const v = norm(vals[i]);
      if (typeof v === 'number') { s += v; n++; if (v > mx) mx = v; if (v < mn) mn = v; }
    }
    if (kind === 'count') return n;
    if (kind === 'sum') return s;
    if (kind === 'avg') { if (!n) throw E.DIV0; return s / n; }
    if (kind === 'max') return n ? mx : 0;
    return n ? mn : 0;
  }
  function ifAgg(a, kind) {
    const rg = toRange(a[0]), crit = criteria(a[1]), sr = !blank(a[2]) && isRange(a[2]) ? a[2] : rg;
    let s = 0, n = 0;
    rg.rows.forEach((row, i) => row.forEach((v, j) => { if (crit(v)) { const x = norm(sr.rows[i] && sr.rows[i][j]); if (kind === 'count') n++; else if (typeof x === 'number') { s += x; n++; } } }));
    if (kind === 'count') return n;
    if (kind === 'sum') return s;
    if (!n) throw E.DIV0; return s / n;
  }
  Object.assign(F, {
    SUMIF: a => ifAgg(a, 'sum'), COUNTIF: a => ifAgg([a[0], a[1]], 'count'), AVERAGEIF: a => ifAgg(a, 'avg'),
    SUMIFS: a => multiIf(a.slice(1), a[0], 'sum'), COUNTIFS: a => multiIf(a, null, 'count'), AVERAGEIFS: a => multiIf(a.slice(1), a[0], 'avg'),
    MAXIFS: a => multiIf(a.slice(1), a[0], 'max'), MINIFS: a => multiIf(a.slice(1), a[0], 'min'),
    SUBTOTAL: (a, ctx) => {
      const code = Math.floor(n1(a[0])); const base = code > 100 ? code - 100 : code, manual = code > 100;
      const vals = [];
      for (let k = 1; k < a.length; k++) {
        const x = a[k];
        if (isRange(x) && x.meta) {
          x.rows.forEach((row, i) => {
            const r = x.meta.r1 + i;
            if (ctx.rowHidden && ctx.rowHidden(x.meta.sheet, r, manual)) return;
            row.forEach((v, j) => { const raw = ctx.raw ? ctx.raw(x.meta.sheet, r, x.meta.c1 + j) : ''; if (/^=\s*(SUBTOTAL|AGGREGATE)\s*\(/i.test(raw || '')) return; vals.push(v); });
          });
        } else if (isRange(x)) vals.push(...x.flat()); else vals.push(x);
      }
      const rr = [R([vals])];
      const fn = { 1: 'AVERAGE', 2: 'COUNT', 3: 'COUNTA', 4: 'MAX', 5: 'MIN', 6: 'PRODUCT', 7: 'STDEV', 8: 'STDEVP', 9: 'SUM', 10: 'VAR', 11: 'VARP' }[base];
      if (!fn) throw E.VALUE;
      return F[fn](rr);
    }
  });

  // ---------------------------------------------------------------- logical & info
  Object.assign(F, {
    IFS: a => { for (let i = 0; i + 1 < a.length; i += 2) { if (isErr(a[i])) return a[i]; if (b1(a[i])) return a[i + 1]; } throw E.NA; },
    AND: a => { const v = allVals(a).filter(x => x !== null && x !== undefined && typeof norm(x) !== 'string'); if (!v.length) throw E.VALUE; return v.every(x => b1(x)); },
    OR: a => { const v = allVals(a).filter(x => x !== null && x !== undefined && typeof norm(x) !== 'string'); if (!v.length) throw E.VALUE; return v.some(x => b1(x)); },
    XOR: a => allVals(a).filter(x => x !== null && typeof norm(x) !== 'string').filter(x => b1(x)).length % 2 === 1,
    NOT: a => !b1(a[0]),
    TRUE: () => true, FALSE: () => false,
    SWITCH: a => { const v = scalar(a[0]); if (isErr(v)) return v; for (let i = 1; i + 1 < a.length; i += 2) if (compare(v, a[i]) === 0) return a[i + 1]; if (a.length % 2 === 0) return a[a.length - 1]; throw E.NA; },
    CHOOSE: a => { const i = Math.floor(n1(a[0])); if (i < 1 || i >= a.length) throw E.VALUE; return a[i]; },
    ISBLANK: a => { const v = scalar(a[0]); return v === null || v === undefined; },
    ISNUMBER: a => typeof norm(scalar(a[0])) === 'number',
    ISTEXT: a => typeof norm(scalar(a[0])) === 'string',
    ISNONTEXT: a => typeof norm(scalar(a[0])) !== 'string',
    ISLOGICAL: a => typeof scalar(a[0]) === 'boolean',
    ISERROR: a => isErr(scalar(a[0])),
    ISERR: a => isErr(scalar(a[0])) && scalar(a[0]) !== E.NA,
    ISNA: a => scalar(a[0]) === E.NA,
    ISEVEN: a => Math.floor(Math.abs(n1(a[0]))) % 2 === 0,
    ISODD: a => Math.floor(Math.abs(n1(a[0]))) % 2 === 1,
    NA: () => E.NA,
    TYPE: a => { const v = a[0]; if (isRange(v)) return 64; const s = norm(v); if (isErr(s)) return 16; if (typeof s === 'number' || s === null) return 1; if (typeof s === 'string') return 2; if (typeof s === 'boolean') return 4; return 1; },
    'ERROR.TYPE': a => { const v = scalar(a[0]); if (!isErr(v)) throw E.NA; return { '#NULL!': 1, '#DIV/0!': 2, '#VALUE!': 3, '#REF!': 4, '#NAME?': 5, '#NUM!': 6, '#N/A': 7 }[v.code] || 8; },
    N: a => { const v = norm(scalar(a[0])); return typeof v === 'number' ? v : typeof v === 'boolean' ? +v : 0; },
    T: a => { const v = norm(scalar(a[0])); return typeof v === 'string' ? v : ''; },
    ROW: (a, ctx, nodes) => {
      const nd = nodes[0];
      if (!nd || nd.t === 'blank') return ctx.cell ? ctx.cell.r + 1 : 1;
      if (nd.t === 'ref') return nd.r + 1;
      if (nd.t === 'range') { const r2 = nd.r2 === Infinity ? nd.r1 : nd.r2; if (r2 === nd.r1) return nd.r1 + 1; return col(Array.from({ length: r2 - nd.r1 + 1 }, (_, i) => nd.r1 + i + 1)); }
      throw E.VALUE;
    },
    COLUMN: (a, ctx, nodes) => {
      const nd = nodes[0];
      if (!nd || nd.t === 'blank') return ctx.cell ? ctx.cell.c + 1 : 1;
      if (nd.t === 'ref') return nd.c + 1;
      if (nd.t === 'range') { const c2 = nd.c2 === Infinity ? nd.c1 : nd.c2; if (c2 === nd.c1) return nd.c1 + 1; return rowR(Array.from({ length: c2 - nd.c1 + 1 }, (_, i) => nd.c1 + i + 1)); }
      throw E.VALUE;
    },
    ROWS: a => (isRange(a[0]) ? a[0].h : 1),
    COLUMNS: a => (isRange(a[0]) ? a[0].w : 1),
    ADDRESS: a => {
      const r = Math.floor(n1(a[0])), c = Math.floor(n1(a[1])), abs = Math.floor(n1(arg(a, 2, 1))), isA1 = b1(arg(a, 3, true));
      if (r < 1 || c < 1) throw E.VALUE;
      const sheet = blank(a[4]) ? '' : X.quoteSheet(s1(a[4])) + '!';
      if (!isA1) return sheet + 'R' + r + 'C' + c;
      return sheet + ((abs === 1 || abs === 3) ? '$' : '') + X.numToCol(c - 1) + ((abs === 1 || abs === 2) ? '$' : '') + r;
    },
    INDIRECT: (a, ctx) => {
      const t = s1(a[0]); const ref = parseRef(t);
      if (!ref) { const def = ctx.name && ctx.name(t.toUpperCase()); if (def) return X.evalNode(def, ctx); throw E.REF; }
      const sh = ref.sheet || ctx.sheet;
      if (ref.r1 === ref.r2 && ref.c1 === ref.c2) return ctx.get(sh, ref.r1, ref.c1);
      return ctx.getRange(sh, ref.r1, ref.c1, ref.r2, ref.c2);
    },
    OFFSET: (a, ctx, nodes) => {
      let nd = nodes[0];
      if (nd && nd.t === 'name' && ctx.name) nd = ctx.name(nd.v);
      if (!nd || (nd.t !== 'ref' && nd.t !== 'range')) throw E.VALUE;
      const sheet = nd.sheet || ctx.sheet;
      const r0 = nd.t === 'ref' ? nd.r : nd.r1, c0 = nd.t === 'ref' ? nd.c : nd.c1;
      const h0 = nd.t === 'ref' ? 1 : nd.r2 - nd.r1 + 1, w0 = nd.t === 'ref' ? 1 : nd.c2 - nd.c1 + 1;
      const r = r0 + Math.floor(n1(a[1])), c = c0 + Math.floor(n1(a[2]));
      const h = blank(a[3]) ? h0 : Math.floor(n1(a[3])), w = blank(a[4]) ? w0 : Math.floor(n1(a[4]));
      if (r < 0 || c < 0 || h < 1 || w < 1) throw E.REF;
      if (h === 1 && w === 1) return ctx.get(sheet, r, c);
      return ctx.getRange(sheet, r, c, r + h - 1, c + w - 1);
    },
    FORMULATEXT: (a, ctx, nodes) => { const nd = nodes[0]; if (!nd || nd.t !== 'ref') throw E.NA; const raw = ctx.raw ? ctx.raw(nd.sheet || ctx.sheet, nd.r, nd.c) : ''; if (!raw || raw[0] !== '=') throw E.NA; return raw; },
    ISFORMULA: (a, ctx, nodes) => { const nd = nodes[0]; if (!nd || nd.t !== 'ref') return false; const raw = ctx.raw ? ctx.raw(nd.sheet || ctx.sheet, nd.r, nd.c) : ''; return !!raw && raw[0] === '='; }
  });

  // ---------------------------------------------------------------- lookup & dynamic arrays
  function exactOrNear(val, list, mode, reverse) {
    // mode: 0 exact, -1 exact or next smaller, 1 exact or next larger, 2 wildcard
    const idx = reverse ? [...list.keys()].reverse() : [...list.keys()];
    val = norm(scalar(val));
    const wc = mode === 2 && typeof val === 'string' ? wildcard(val) : null;
    let best = -1;
    for (const i of idx) {
      const x = norm(list[i]); if (x === null || x === undefined) continue;
      if (wc) { if (typeof x === 'string' && wc.test(x)) return i; continue; }
      const c = compare(x, val);
      if (c === 0) return i;
      if (mode === -1 && c < 0 && (best < 0 || compare(x, list[best]) > 0)) best = i;
      if (mode === 1 && c > 0 && (best < 0 || compare(x, list[best]) < 0)) best = i;
    }
    return best;
  }
  const keyOf = row => row.map(v => { v = norm(v); return typeof v === 'string' ? 's:' + v.toLowerCase() : typeof v + ':' + String(v); }).join('\u0001');
  Object.assign(F, {
    VLOOKUP: a => {
      const rg = a[1]; if (!isRange(rg)) throw E.VALUE;
      const ci = Math.floor(n1(a[2])); if (ci < 1) throw E.VALUE; if (ci > rg.w) throw E.REF;
      const approx = blank(a[3]) ? true : b1(a[3]);
      const list = rg.rows.map(r => r[0]);
      const i = approx ? lookupIndex(a[0], list, 1) : lookupIndex(a[0], list, 0);
      if (i < 0) throw E.NA; return rg.rows[i][ci - 1];
    },
    HLOOKUP: a => {
      const rg = a[1]; if (!isRange(rg)) throw E.VALUE;
      const ri = Math.floor(n1(a[2])); if (ri < 1) throw E.VALUE; if (ri > rg.h) throw E.REF;
      const approx = blank(a[3]) ? true : b1(a[3]);
      const i = lookupIndex(a[0], rg.rows[0], approx ? 1 : 0);
      if (i < 0) throw E.NA; return rg.rows[ri - 1][i];
    },
    XLOOKUP: a => {
      if (isErr(scalar(a[0]))) return scalar(a[0]);
      const lk = toRange(a[1]), rt = toRange(a[2]);
      const vertical = lk.w === 1;
      const list = lk.flat();
      const mode = Math.floor(n1(arg(a, 4, 0))), search = Math.floor(n1(arg(a, 5, 1)));
      const i = exactOrNear(a[0], list, mode, search < 0);
      if (i < 0) { if (!blank(a[3])) return a[3]; throw E.NA; }
      if (vertical) { if (rt.w === 1) return rt.rows[i] ? rt.rows[i][0] : E.REF; return rt.rows[i] ? R([rt.rows[i].slice()]) : E.REF; }
      if (rt.h === 1) return rt.rows[0][i];
      return col(rt.rows.map(r => r[i]));
    },
    LOOKUP: a => { const lk = toRange(a[1]); const list = lk.w === 1 || lk.h === 1 ? lk.flat() : lk.rows.map(r => r[0]); const i = lookupIndex(a[0], list, 1); if (i < 0) throw E.NA; const rv = !blank(a[2]) ? toRange(a[2]).flat() : (lk.w === 1 || lk.h === 1 ? list : lk.rows.map(r => r[r.length - 1])); return rv[i]; },
    MATCH: a => { const t = blank(a[2]) ? 1 : Math.sign(n1(a[2])); const i = lookupIndex(a[0], toRange(a[1]).flat(), t > 0 ? 1 : t < 0 ? -1 : 0); if (i < 0) throw E.NA; return i + 1; },
    XMATCH: a => { const i = exactOrNear(a[0], toRange(a[1]).flat(), Math.floor(n1(arg(a, 2, 0))), n1(arg(a, 3, 1)) < 0); if (i < 0) throw E.NA; return i + 1; },
    INDEX: a => {
      const rg = a[0]; if (!isRange(rg)) return rg;
      let r = blank(a[1]) ? 0 : Math.floor(n1(a[1])), c = blank(a[2]) ? 0 : Math.floor(n1(a[2]));
      if (rg.h === 1 && blank(a[2])) { c = r; r = 1; }
      else if (rg.w === 1 && blank(a[2])) c = 1;
      if (r < 0 || c < 0 || r > rg.h || c > rg.w) throw E.REF;
      if (r === 0 && c === 0) return rg;
      if (r === 0) return col(rg.rows.map(x => x[c - 1]));
      if (c === 0) return R([rg.rows[r - 1].slice()]);
      return rg.rows[r - 1][c - 1];
    },
    TRANSPOSE: a => { const rg = toRange(a[0]); return R(Array.from({ length: rg.w }, (_, j) => rg.rows.map(r => r[j]))); },
    UNIQUE: a => {
      let rg = toRange(a[0]); const byCol = b1(arg(a, 1, false)), once = b1(arg(a, 2, false));
      if (byCol) rg = F.TRANSPOSE([rg]);
      const counts = new Map(); rg.rows.forEach(r => { const k = keyOf(r); counts.set(k, (counts.get(k) || 0) + 1); });
      const seen = new Set(), out = [];
      rg.rows.forEach(r => { const k = keyOf(r); if (seen.has(k)) return; seen.add(k); if (once && counts.get(k) > 1) return; out.push(r.slice()); });
      if (!out.length) throw E.CALC;
      const res = R(out); return byCol ? F.TRANSPOSE([res]) : res;
    },
    SORT: a => {
      let rg = toRange(a[0]); const idx = Math.floor(n1(arg(a, 1, 1))), ord = n1(arg(a, 2, 1)) < 0 ? -1 : 1, byCol = b1(arg(a, 3, false));
      if (byCol) rg = F.TRANSPOSE([rg]);
      if (idx < 1 || idx > rg.w) throw E.VALUE;
      const rows = rg.rows.map(r => r.slice()).sort((x, y) => sortCmp(x[idx - 1], y[idx - 1]) * ord);
      const res = R(rows); return byCol ? F.TRANSPOSE([res]) : res;
    },
    SORTBY: a => {
      const rg = toRange(a[0]); const keys = [];
      for (let i = 1; i < a.length; i += 2) { const k = toRange(a[i]).flat(); if (k.length !== rg.h) throw E.VALUE; keys.push([k, blank(a[i + 1]) ? 1 : (n1(a[i + 1]) < 0 ? -1 : 1)]); }
      const idx = rg.rows.map((_, i) => i).sort((x, y) => { for (const [k, o] of keys) { const c = sortCmp(k[x], k[y]); if (c) return c * o; } return x - y; });
      return R(idx.map(i => rg.rows[i].slice()));
    },
    FILTER: a => {
      const rg = toRange(a[0]), inc = toRange(a[1]).flat();
      if (inc.length === rg.h) { const rows = rg.rows.filter((_, i) => { const v = norm(inc[i]); return isErr(v) ? false : !!toBool(v) && toBool(v) !== E.VALUE; }); if (!rows.length) { if (!blank(a[2])) return a[2]; throw E.CALC; } return R(rows.map(r => r.slice())); }
      if (inc.length === rg.w) { const keep = inc.map(v => toBool(v) === true); const rows = rg.rows.map(r => r.filter((_, j) => keep[j])); if (!rows[0].length) { if (!blank(a[2])) return a[2]; throw E.CALC; } return R(rows); }
      throw E.VALUE;
    },
    TAKE: a => { const rg = toRange(a[0]); const r = blank(a[1]) ? rg.h : Math.floor(n1(a[1])), c = blank(a[2]) ? rg.w : Math.floor(n1(a[2])); const rows = (r >= 0 ? rg.rows.slice(0, r) : rg.rows.slice(r)).map(x => (c >= 0 ? x.slice(0, c) : x.slice(c))); if (!rows.length || !rows[0].length) throw E.CALC; return R(rows); },
    DROP: a => { const rg = toRange(a[0]); const r = blank(a[1]) ? 0 : Math.floor(n1(a[1])), c = blank(a[2]) ? 0 : Math.floor(n1(a[2])); const rows = (r >= 0 ? rg.rows.slice(r) : rg.rows.slice(0, r)).map(x => (c >= 0 ? x.slice(c) : x.slice(0, c))); if (!rows.length || !rows[0].length) throw E.CALC; return R(rows); },
    CHOOSECOLS: a => { const rg = toRange(a[0]); const cs = a.slice(1).map(x => Math.floor(n1(x))); return R(rg.rows.map(r => cs.map(c => { const j = c < 0 ? rg.w + c : c - 1; if (j < 0 || j >= rg.w) throw E.VALUE; return r[j]; }))); },
    CHOOSEROWS: a => { const rg = toRange(a[0]); const rs = a.slice(1).map(x => Math.floor(n1(x))); return R(rs.map(r => { const i = r < 0 ? rg.h + r : r - 1; if (i < 0 || i >= rg.h) throw E.VALUE; return rg.rows[i].slice(); })); },
    VSTACK: a => { const parts = a.map(toRange); const w = Math.max(...parts.map(p => p.w)); const rows = []; parts.forEach(p => p.rows.forEach(r => rows.push(r.concat(Array(w - r.length).fill(E.NA))))); return R(rows); },
    HSTACK: a => { const parts = a.map(toRange); const h = Math.max(...parts.map(p => p.h)); return R(Array.from({ length: h }, (_, i) => [].concat(...parts.map(p => (p.rows[i] ? p.rows[i] : Array(p.w).fill(E.NA)))))); },
    TOCOL: a => { const v = toRange(a[0]).flat().filter(x => !(Math.floor(n1(arg(a, 1, 0))) === 1 && (x === null || x === undefined))); return col(v); },
    TOROW: a => { const v = toRange(a[0]).flat().filter(x => !(Math.floor(n1(arg(a, 1, 0))) === 1 && (x === null || x === undefined))); return rowR(v); },
    HYPERLINK: a => { const url = s1(a[0]); return new Rich('link', blank(a[1]) ? url : toStr(a[1]), { url }); },
    IMAGE: a => new Rich('img', '', { url: s1(a[0]) })
  });
  function sortCmp(x, y) {
    x = norm(x); y = norm(y);
    const ex = x === null || x === undefined || x === '', ey = y === null || y === undefined || y === '';
    if (ex || ey) return ex === ey ? 0 : ex ? 1 : -1;
    if (typeof x === 'string' && typeof y === 'string') return x.localeCompare(y, 'en-IN', { numeric: true, sensitivity: 'base' });
    return compare(x, y);
  }
  X.sortCmp = sortCmp;

  // ---------------------------------------------------------------- text
  Object.assign(F, {
    CONCAT: a => allVals(a).map(s1).join(''),
    CONCATENATE: a => allVals(a).map(s1).join(''),
    TEXTJOIN: a => { const d = s1(a[0]), skip = b1(a[1]); return allVals(a.slice(2)).map(s1).filter(s => !(skip && s === '')).join(d); },
    LEFT: a => { const n = blank(a[1]) ? 1 : n1(a[1]); if (n < 0) throw E.VALUE; return [...s1(a[0])].slice(0, n).join(''); },
    RIGHT: a => { const n = blank(a[1]) ? 1 : n1(a[1]); if (n < 0) throw E.VALUE; const s = [...s1(a[0])]; return n === 0 ? '' : s.slice(-n).join(''); },
    MID: a => { const st = n1(a[1]), n = n1(a[2]); if (st < 1 || n < 0) throw E.VALUE; return [...s1(a[0])].slice(st - 1, st - 1 + n).join(''); },
    LEN: a => [...s1(a[0])].length,
    UPPER: a => s1(a[0]).toUpperCase(),
    LOWER: a => s1(a[0]).toLowerCase(),
    PROPER: a => s1(a[0]).toLowerCase().replace(/(^|[^a-zÀ-ɏ'])([a-zÀ-ɏ])/g, (m, p, c) => p + c.toUpperCase()),
    TRIM: a => s1(a[0]).replace(/[  ]+/g, ' ').trim(),
    CLEAN: a => s1(a[0]).replace(/[\x00-\x1F\x7F]/g, ''),
    REPT: a => { const n = Math.floor(n1(a[1])); if (n < 0) throw E.VALUE; const s = s1(a[0]); if (s.length * n > 32767) throw E.VALUE; return s.repeat(n); },
    SUBSTITUTE: a => { const s = s1(a[0]), o = s1(a[1]), n = s1(a[2]); if (o === '') return s; if (blank(a[3])) return s.split(o).join(n); let k = Math.floor(n1(a[3])), idx = -1; while (k-- > 0) { idx = s.indexOf(o, idx + 1); if (idx < 0) return s; } return s.slice(0, idx) + n + s.slice(idx + o.length); },
    REPLACE: a => { const s = s1(a[0]), st = n1(a[1]) - 1, n = n1(a[2]); if (st < 0 || n < 0) throw E.VALUE; return s.slice(0, st) + s1(a[3]) + s.slice(st + n); },
    FIND: a => { const st = (blank(a[2]) ? 1 : n1(a[2])) - 1; const i = s1(a[1]).indexOf(s1(a[0]), st); if (i < 0 || st < 0) throw E.VALUE; return i + 1; },
    SEARCH: a => { const st = (blank(a[2]) ? 1 : n1(a[2])) - 1; const t = s1(a[1]), q = s1(a[0]); if (/[*?~]/.test(q)) { const re = new RegExp(wildcard(q).source.slice(1, -1), 'i'); const m = re.exec(t.slice(st)); if (!m) throw E.VALUE; return st + m.index + 1; } const i = t.toLowerCase().indexOf(q.toLowerCase(), st); if (i < 0 || st < 0) throw E.VALUE; return i + 1; },
    EXACT: a => s1(a[0]) === s1(a[1]),
    VALUE: a => { const v = norm(scalar(a[0])); if (typeof v === 'number') return v; const n = toNum(v); if (isErr(n) || v === '' || v === null) throw E.VALUE; return n; },
    NUMBERVALUE: a => { let s = s1(a[0]); const ds = blank(a[1]) ? '.' : s1(a[1]), gs = blank(a[2]) ? ',' : s1(a[2]); s = s.split(gs).join('').replace(ds, '.').replace(/\s/g, ''); let pct = 0; while (s.endsWith('%')) { pct++; s = s.slice(0, -1); } const n = Number(s); if (s === '' || isNaN(n)) throw E.VALUE; return n / Math.pow(100, pct); },
    TEXT: a => { const v = norm(scalar(a[0])); const f = s1(a[1]); let x = v; if (typeof v === 'string') { const n = toNum(v); if (!isErr(n) && v.trim() !== '') x = n; } return X.formatValue(x, f).text; },
    FIXED: a => { const n = n1(a[0]), d = Math.floor(n1(arg(a, 1, 2))), noc = b1(arg(a, 2, false)); const r = round(n, d); const s = Math.abs(r).toFixed(Math.max(0, d)); const [ip, fp] = s.split('.'); return (r < 0 ? '-' : '') + (noc ? ip : X.groupDigits(ip)) + (fp ? '.' + fp : ''); },
    CHAR: a => { const n = Math.floor(n1(a[0])); if (n < 1 || n > 255) throw E.VALUE; return String.fromCharCode(n); },
    CODE: a => { const s = s1(a[0]); if (!s) throw E.VALUE; return s.charCodeAt(0); },
    UNICHAR: a => { const n = Math.floor(n1(a[0])); if (n < 1 || n > 0x10FFFF) throw E.VALUE; return String.fromCodePoint(n); },
    UNICODE: a => { const s = s1(a[0]); if (!s) throw E.VALUE; return s.codePointAt(0); },
    TEXTBEFORE: a => { const s = s1(a[0]), d = s1(a[1]); let n = Math.floor(n1(arg(a, 2, 1))); if (!d) return ''; const parts = s.split(d); if (n < 0) n = parts.length + n; if (n < 1 || n >= parts.length) { if (!blank(a[5])) return a[5]; throw E.NA; } return parts.slice(0, n).join(d); },
    TEXTAFTER: a => { const s = s1(a[0]), d = s1(a[1]); let n = Math.floor(n1(arg(a, 2, 1))); if (!d) return s; const parts = s.split(d); if (n < 0) n = parts.length + n; if (n < 1 || n >= parts.length) { if (!blank(a[5])) return a[5]; throw E.NA; } return parts.slice(n).join(d); },
    TEXTSPLIT: a => {
      const s = s1(a[0]); const cd = blank(a[1]) ? null : s1(a[1]), rd = blank(a[2]) ? null : s1(a[2]); const ignore = b1(arg(a, 3, false));
      const rows = (rd ? s.split(rd) : [s]).map(line => { let p = cd ? line.split(cd) : [line]; if (ignore) p = p.filter(x => x !== ''); return p; });
      const w = Math.max(...rows.map(r => r.length));
      return R(rows.map(r => r.concat(Array(w - r.length).fill(E.NA))));
    },
    SPLIT: a => { const s = s1(a[0]), d = s1(a[1]); const each = b1(arg(a, 2, true)), rmEmpty = b1(arg(a, 3, true)); let parts; if (each && d.length > 1) { const re = new RegExp('[' + d.replace(/[\]\\^-]/g, '\\$&') + ']'); parts = s.split(re); } else parts = s.split(d); if (rmEmpty) parts = parts.filter(x => x !== ''); return rowR(parts.map(p => { const v = parseInput(p).value; return v === null ? '' : v; })); },
    REGEXMATCH: a => { try { return new RegExp(s1(a[1])).test(s1(a[0])); } catch (e) { throw E.VALUE; } },
    REGEXEXTRACT: a => { let m; try { m = new RegExp(s1(a[1])).exec(s1(a[0])); } catch (e) { throw E.VALUE; } if (!m) throw E.NA; return m.length > 1 ? (m.length > 2 ? rowR(m.slice(1)) : m[1]) : m[0]; },
    REGEXREPLACE: a => { try { return s1(a[0]).replace(new RegExp(s1(a[1]), 'g'), s1(a[2]).replace(/\\(\d)/g, '$$$1')); } catch (e) { throw E.VALUE; } }
  });

  // ---------------------------------------------------------------- date & time
  const dParts = s => { const d = fromSerial(s); return { y: d.getUTCFullYear(), m: d.getUTCMonth() + 1, d: d.getUTCDate(), w: d.getUTCDay() }; };
  const holidaySet = h => new Set(blank(h) ? [] : toRange(h).flat().filter(v => typeof v === 'number').map(Math.floor));
  Object.assign(F, {
    TODAY: () => todaySerial(),
    NOW: () => nowSerial(),
    DATE: a => { let y = Math.floor(n1(a[0])); if (y < 1900) y += 1900; const s = toSerial(y, Math.floor(n1(a[1])), Math.floor(n1(a[2]))); if (s < 0) throw E.NUM; return s; },
    TIME: a => { const t = (n1(a[0]) * 3600 + n1(a[1]) * 60 + n1(a[2])) / 86400; if (t < 0) throw E.NUM; return t - Math.floor(t); },
    DATEVALUE: a => { const v = norm(scalar(a[0])); if (typeof v === 'number') return Math.floor(v); const d = X.parseDateTime(s1(v)); if (!d) throw E.VALUE; return Math.floor(d.value); },
    TIMEVALUE: a => { const v = norm(scalar(a[0])); if (typeof v === 'number') return v - Math.floor(v); const d = X.parseDateTime(s1(v)); if (!d) throw E.VALUE; return d.value - Math.floor(d.value); },
    YEAR: a => dParts(n1(a[0])).y,
    MONTH: a => dParts(n1(a[0])).m,
    DAY: a => dParts(n1(a[0])).d,
    HOUR: a => { const v = n1(a[0]); return Math.floor(round((v - Math.floor(v)) * 24, 9)); },
    MINUTE: a => { const v = n1(a[0]); return Math.floor(round((v - Math.floor(v)) * 1440, 9)) % 60; },
    SECOND: a => { const v = n1(a[0]); return Math.round((v - Math.floor(v)) * 86400) % 60; },
    WEEKDAY: a => { const w = dParts(n1(a[0])).w; const t = Math.floor(n1(arg(a, 1, 1))); if (t === 2) return ((w + 6) % 7) + 1; if (t === 3) return (w + 6) % 7; return w + 1; },
    WEEKNUM: a => { const s = Math.floor(n1(a[0])); const p = dParts(s); const jan1 = toSerial(p.y, 1, 1); const t = Math.floor(n1(arg(a, 1, 1))); const startDay = t === 2 ? 1 : 0; const jw = dParts(jan1).w; const off = (jw - startDay + 7) % 7; return Math.floor((s - jan1 + off) / 7) + 1; },
    ISOWEEKNUM: a => { const d = fromSerial(Math.floor(n1(a[0]))); const t = new Date(Date.UTC(d.getUTCFullYear(), d.getUTCMonth(), d.getUTCDate())); const day = t.getUTCDay() || 7; t.setUTCDate(t.getUTCDate() + 4 - day); const y0 = new Date(Date.UTC(t.getUTCFullYear(), 0, 1)); return Math.ceil(((t - y0) / 86400000 + 1) / 7); },
    DAYS: a => Math.floor(n1(a[0])) - Math.floor(n1(a[1])),
    EDATE: a => { const p = dParts(n1(a[0])); const m = p.m + Math.trunc(n1(a[1])); const y = p.y + Math.floor((m - 1) / 12), mm = ((m - 1) % 12 + 12) % 12 + 1; return toSerial(y, mm, Math.min(p.d, X.daysIn(y, mm))); },
    EOMONTH: a => { const p = dParts(n1(a[0])); const m = p.m + Math.trunc(n1(a[1])); const y = p.y + Math.floor((m - 1) / 12), mm = ((m - 1) % 12 + 12) % 12 + 1; return toSerial(y, mm, X.daysIn(y, mm)); },
    DATEDIF: a => {
      const s0 = Math.floor(n1(a[0])), e0 = Math.floor(n1(a[1])), u = s1(a[2]).toUpperCase();
      if (e0 < s0) throw E.NUM;
      const s = dParts(s0), e = dParts(e0);
      let m = (e.y - s.y) * 12 + e.m - s.m; if (e.d < s.d) m--;
      switch (u) {
        case 'D': return e0 - s0;
        case 'M': return m;
        case 'Y': return Math.floor(m / 12);
        case 'YM': return m % 12;
        case 'MD': { let d = e.d - s.d; if (d < 0) { const pm = e.m === 1 ? 12 : e.m - 1, py = e.m === 1 ? e.y - 1 : e.y; d += X.daysIn(py, pm); } return d; }
        case 'YD': { let ys = toSerial(e.y, s.m, Math.min(s.d, X.daysIn(e.y, s.m))); if (ys > e0) ys = toSerial(e.y - 1, s.m, Math.min(s.d, X.daysIn(e.y - 1, s.m))); return e0 - ys; }
      }
      throw E.NUM;
    },
    NETWORKDAYS: a => { const s = Math.floor(n1(a[0])), e = Math.floor(n1(a[1])), hol = holidaySet(a[2]); const lo = Math.min(s, e), hi = Math.max(s, e); let c = 0; for (let d = lo; d <= hi; d++) { const w = dParts(d).w; if (w !== 0 && w !== 6 && !hol.has(d)) c++; } return s <= e ? c : -c; },
    WORKDAY: a => { let d = Math.floor(n1(a[0])); let n = Math.floor(n1(a[1])); const hol = holidaySet(a[2]); const step = n < 0 ? -1 : 1; while (n !== 0) { d += step; const w = dParts(d).w; if (w !== 0 && w !== 6 && !hol.has(d)) n -= step; } return d; },
    YEARFRAC: a => {
      let s = Math.floor(n1(a[0])), e = Math.floor(n1(a[1])); const basis = Math.floor(n1(arg(a, 2, 0))); if (s > e) [s, e] = [e, s];
      if (basis === 0) { const p = dParts(s), q = dParts(e); let d1 = p.d, d2 = q.d; if (d1 === 31) d1 = 30; if (d2 === 31 && d1 >= 30) d2 = 30; return ((q.y - p.y) * 360 + (q.m - p.m) * 30 + (d2 - d1)) / 360; }
      if (basis === 2) return (e - s) / 360;
      if (basis === 3) return (e - s) / 365;
      const y1 = dParts(s).y, y2 = dParts(e).y; let days = 0; for (let y = y1; y <= y2; y++) days += (y % 4 === 0 && (y % 100 !== 0 || y % 400 === 0)) ? 366 : 365; return (e - s) / (days / (y2 - y1 + 1));
    }
  });

  // ---------------------------------------------------------------- finance
  const fvCalc = (r, n, pmt, pv, t) => (r === 0 ? -(pv + pmt * n) : -(pv * Math.pow(1 + r, n) + pmt * (1 + r * t) * (Math.pow(1 + r, n) - 1) / r));
  const pmtCalc = (r, n, pv, fv, t) => { if (n === 0) throw E.NUM; if (r === 0) return -(pv + fv) / n; const p = Math.pow(1 + r, n); return -(r * (pv * p + fv)) / ((1 + r * t) * (p - 1)); };
  const ipmtCalc = (r, per, n, pv, fv, t) => { const pmt = pmtCalc(r, n, pv, fv, t); let ip; if (per === 1) ip = t ? 0 : -pv; else ip = t ? fvCalc(r, per - 2, pmt, pv, 1) - pmt : fvCalc(r, per - 1, pmt, pv, 0); return ip * r; };
  function solve(f, guess) { let x = guess; for (let i = 0; i < 100; i++) { const y = f(x); const h = 1e-6 * Math.max(1, Math.abs(x)); const d = (f(x + h) - y) / h; if (!isFinite(d) || d === 0) break; const nx = x - y / d; if (Math.abs(nx - x) < 1e-10) return nx; x = nx; } if (Math.abs(f(x)) < 1e-6) return x; throw E.NUM; }
  Object.assign(F, {
    PMT: a => pmtCalc(n1(a[0]), n1(a[1]), n1(a[2]), n1(arg(a, 3, 0)), n1(arg(a, 4, 0)) ? 1 : 0),
    IPMT: a => { const per = n1(a[1]), n = n1(a[2]); if (per < 1 || per > n) throw E.NUM; return ipmtCalc(n1(a[0]), per, n, n1(a[3]), n1(arg(a, 4, 0)), n1(arg(a, 5, 0)) ? 1 : 0); },
    PPMT: a => { const r = n1(a[0]), per = n1(a[1]), n = n1(a[2]), pv = n1(a[3]), fv = n1(arg(a, 4, 0)), t = n1(arg(a, 5, 0)) ? 1 : 0; if (per < 1 || per > n) throw E.NUM; return pmtCalc(r, n, pv, fv, t) - ipmtCalc(r, per, n, pv, fv, t); },
    FV: a => fvCalc(n1(a[0]), n1(a[1]), n1(a[2]), n1(arg(a, 3, 0)), n1(arg(a, 4, 0)) ? 1 : 0),
    PV: a => { const r = n1(a[0]), n = n1(a[1]), pmt = n1(a[2]), fv = n1(arg(a, 3, 0)), t = n1(arg(a, 4, 0)) ? 1 : 0; if (r === 0) return -(fv + pmt * n); const p = Math.pow(1 + r, n); return -(fv + pmt * (1 + r * t) * (p - 1) / r) / p; },
    NPER: a => { const r = n1(a[0]), pmt = n1(a[1]), pv = n1(a[2]), fv = n1(arg(a, 3, 0)), t = n1(arg(a, 4, 0)) ? 1 : 0; if (r === 0) { if (pmt === 0) throw E.NUM; return -(pv + fv) / pmt; } const num = pmt * (1 + r * t) - fv * r, den = pmt * (1 + r * t) + pv * r; if (num / den <= 0) throw E.NUM; return Math.log(num / den) / Math.log(1 + r); },
    RATE: a => { const n = n1(a[0]), pmt = n1(a[1]), pv = n1(a[2]), fv = n1(arg(a, 3, 0)), t = n1(arg(a, 4, 0)) ? 1 : 0, g = n1(arg(a, 5, 0.1)); return solve(r => (Math.abs(r) < 1e-12 ? pv + pmt * n + fv : pv * Math.pow(1 + r, n) + pmt * (1 + r * t) * (Math.pow(1 + r, n) - 1) / r + fv), g); },
    NPV: a => { const r = n1(a[0]); return nums(a.slice(1)).reduce((s, v, i) => s + v / Math.pow(1 + r, i + 1), 0); },
    XNPV: a => { const r = n1(a[0]), v = toRange(a[1]).flat().map(n1), d = toRange(a[2]).flat().map(n1); if (v.length !== d.length) throw E.NUM; return v.reduce((s, x, i) => s + x / Math.pow(1 + r, (d[i] - d[0]) / 365), 0); },
    IRR: a => { const v = nums([a[0]]); if (!v.some(x => x > 0) || !v.some(x => x < 0)) throw E.NUM; return solve(r => v.reduce((s, x, i) => s + x / Math.pow(1 + r, i), 0), n1(arg(a, 1, 0.1))); },
    XIRR: a => { const v = toRange(a[0]).flat().map(n1), d = toRange(a[1]).flat().map(n1); if (v.length !== d.length) throw E.NUM; return solve(r => v.reduce((s, x, i) => s + x / Math.pow(1 + r, (d[i] - d[0]) / 365), 0), n1(arg(a, 2, 0.1))); },
    SLN: a => { const life = n1(a[2]); if (life === 0) throw E.DIV0; return (n1(a[0]) - n1(a[1])) / life; },
    EMI: a => { const p = n1(a[0]), r = n1(a[1]) / 1200, n = n1(a[2]); if (n <= 0) throw E.NUM; if (r === 0) return p / n; const x = Math.pow(1 + r, n); return p * r * x / (x - 1); }
  });

  // ---------------------------------------------------------------- India
  const STATES = {
    '01': 'Jammu and Kashmir', '02': 'Himachal Pradesh', '03': 'Punjab', '04': 'Chandigarh', '05': 'Uttarakhand', '06': 'Haryana', '07': 'Delhi', '08': 'Rajasthan',
    '09': 'Uttar Pradesh', '10': 'Bihar', '11': 'Sikkim', '12': 'Arunachal Pradesh', '13': 'Nagaland', '14': 'Manipur', '15': 'Mizoram', '16': 'Tripura', '17': 'Meghalaya',
    '18': 'Assam', '19': 'West Bengal', '20': 'Jharkhand', '21': 'Odisha', '22': 'Chhattisgarh', '23': 'Madhya Pradesh', '24': 'Gujarat', '25': 'Daman and Diu',
    '26': 'Dadra and Nagar Haveli and Daman and Diu', '27': 'Maharashtra', '28': 'Andhra Pradesh (Old)', '29': 'Karnataka', '30': 'Goa', '31': 'Lakshadweep', '32': 'Kerala',
    '33': 'Tamil Nadu', '34': 'Puducherry', '35': 'Andaman and Nicobar Islands', '36': 'Telangana', '37': 'Andhra Pradesh', '38': 'Ladakh', '97': 'Other Territory', '99': 'Centre Jurisdiction'
  };
  X.STATES = STATES;
  const GST_CHARS = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ';
  function gstinValid(g) {
    g = String(g || '').trim().toUpperCase();
    if (!/^[0-9]{2}[A-Z0-9]{13}$/.test(g) || !STATES[g.slice(0, 2)]) return false;
    let sum = 0;
    for (let i = 0; i < 14; i++) { const v = GST_CHARS.indexOf(g[i]); const p = v * (i % 2 ? 2 : 1); sum += Math.floor(p / 36) + (p % 36); }
    return GST_CHARS[(36 - (sum % 36)) % 36] === g[14];
  }
  const VD = [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9], [1, 2, 3, 4, 0, 6, 7, 8, 9, 5], [2, 3, 4, 0, 1, 7, 8, 9, 5, 6], [3, 4, 0, 1, 2, 8, 9, 5, 6, 7], [4, 0, 1, 2, 3, 9, 5, 6, 7, 8], [5, 9, 8, 7, 6, 0, 4, 3, 2, 1], [6, 5, 9, 8, 7, 1, 0, 4, 3, 2], [7, 6, 5, 9, 8, 2, 1, 0, 4, 3], [8, 7, 6, 5, 9, 3, 2, 1, 0, 4], [9, 8, 7, 6, 5, 4, 3, 2, 1, 0]];
  const VP = [[0, 1, 2, 3, 4, 5, 6, 7, 8, 9], [1, 5, 7, 6, 2, 8, 3, 0, 9, 4], [5, 8, 0, 3, 7, 9, 6, 1, 4, 2], [8, 9, 1, 6, 0, 4, 3, 5, 2, 7], [9, 4, 5, 3, 1, 2, 6, 8, 7, 0], [4, 2, 8, 6, 5, 7, 3, 9, 0, 1], [2, 7, 9, 3, 8, 0, 6, 4, 1, 5], [7, 0, 4, 6, 9, 1, 3, 2, 5, 8]];
  function aadhaarValid(s) { s = String(s || '').replace(/[\s-]/g, ''); if (!/^[2-9]\d{11}$/.test(s)) return false; let c = 0; [...s].reverse().forEach((d, i) => { c = VD[c][VP[i % 8][+d]]; }); return c === 0; }
  const DENS = { ms: 7.85, steel: 7.85, 'mild steel': 7.85, iron: 7.87, ci: 7.2, 'cast iron': 7.2, ss: 8.0, 'stainless': 8.0, 'stainless steel': 8.0, ss304: 7.93, ss316: 8.0, al: 2.7, aluminium: 2.7, aluminum: 2.7, cu: 8.96, copper: 8.96, brass: 8.5, bronze: 8.8, lead: 11.34, zinc: 7.14, titanium: 4.5, nickel: 8.9, gold: 19.32, silver: 10.49, gi: 7.85 };
  const density = v => { if (typeof norm(v) === 'number') return norm(v); const k = String(norm(v) || 'ms').toLowerCase().trim(); if (DENS[k] === undefined) throw E.VALUE; return DENS[k]; };
  const UNITS = {
    // mass → kg
    mg: ['m', 1e-6], g: ['m', 1e-3], gm: ['m', 1e-3], kg: ['m', 1], t: ['m', 1000], ton: ['m', 1000], tonne: ['m', 1000], mt: ['m', 1000], quintal: ['m', 100], qtl: ['m', 100], lb: ['m', 0.45359237], lbm: ['m', 0.45359237], oz: ['m', 0.028349523125], ozm: ['m', 0.028349523125], tola: ['m', 0.0116638038],
    // length → m
    mm: ['l', 0.001], cm: ['l', 0.01], m: ['l', 1], km: ['l', 1000], in: ['l', 0.0254], inch: ['l', 0.0254], ft: ['l', 0.3048], feet: ['l', 0.3048], yd: ['l', 0.9144], mi: ['l', 1609.344], mile: ['l', 1609.344],
    // area → m²
    m2: ['a', 1], sqm: ['a', 1], cm2: ['a', 1e-4], mm2: ['a', 1e-6], ft2: ['a', 0.09290304], sqft: ['a', 0.09290304], in2: ['a', 0.00064516], yd2: ['a', 0.83612736], sqyd: ['a', 0.83612736], gaj: ['a', 0.83612736], acre: ['a', 4046.8564224], ha: ['a', 10000], hectare: ['a', 10000], km2: ['a', 1e6], guntha: ['a', 101.17141056], cent: ['a', 40.468564224],
    // volume → litre
    ml: ['v', 0.001], l: ['v', 1], ltr: ['v', 1], litre: ['v', 1], liter: ['v', 1], m3: ['v', 1000], cuft: ['v', 28.316846592], ft3: ['v', 28.316846592], gal: ['v', 3.785411784], cm3: ['v', 0.001],
    // time → seconds
    sec: ['s', 1], s: ['s', 1], min: ['s', 60], hr: ['s', 3600], h: ['s', 3600], day: ['s', 86400], week: ['s', 604800],
    // temperature
    c: ['T', 'C'], f: ['T', 'F'], k: ['T', 'K']
  };
  const AREA = { round: a => Math.PI / 4 * a[0] * a[0], rod: a => Math.PI / 4 * a[0] * a[0], bar: a => Math.PI / 4 * a[0] * a[0], square: a => a[0] * a[0], flat: a => a[0] * a[1], strip: a => a[0] * a[1], hex: a => Math.sqrt(3) / 2 * a[0] * a[0], pipe: a => Math.PI / 4 * (a[0] * a[0] - Math.pow(a[0] - 2 * a[1], 2)), tube: a => Math.PI / 4 * (a[0] * a[0] - Math.pow(a[0] - 2 * a[1], 2)), sqpipe: a => { const b = a[1] || a[0]; return a[0] * b - (a[0] - 2 * a[2]) * (b - 2 * a[2]); }, rectpipe: a => { const b = a[1] || a[0]; return a[0] * b - (a[0] - 2 * a[2]) * (b - 2 * a[2]); }, angle: a => (a[0] + (a[1] || a[0]) - a[2]) * a[2], channel: a => a[0] * a[2] + 2 * (a[1] - a[2]) * a[2] };
  Object.assign(F, {
    RUPEEWORDS: a => {
      const n = n1(a[0]); const lang = String(norm(arg(a, 1, 'en')) || 'en').toLowerCase();
      const rs = Math.floor(Math.abs(round(n, 2))), ps = Math.round((Math.abs(round(n, 2)) - rs) * 100);
      if (lang.startsWith('hi')) return (n < 0 ? 'ऋण ' : '') + hindiWords(rs) + ' रुपये' + (ps ? ' और ' + hindiWords(ps) + ' पैसे' : '') + ' मात्र';
      return (n < 0 ? 'Minus ' : '') + 'Rupees ' + inWords(rs) + (ps ? ' and ' + inWords(ps) + ' Paise' : '') + ' Only';
    },
    NUMWORDS: a => { const n = n1(a[0]); const lang = String(norm(arg(a, 1, 'en')) || 'en').toLowerCase(); const w = lang.startsWith('hi') ? hindiWords(n) : inWords(n); const dec = Math.round((Math.abs(n) - Math.floor(Math.abs(n))) * 100); return (n < 0 ? (lang.startsWith('hi') ? 'ऋण ' : 'Minus ') : '') + w + (dec ? (lang.startsWith('hi') ? ' दशमलव ' + hindiWords(dec) : ' Point ' + inWords(dec)) : ''); },
    HINDIWORDS: a => F.RUPEEWORDS([a[0], 'hi']),
    GST: a => round(n1(a[0]) * n1(a[1]) / 100, 2),
    IGST: a => round(n1(a[0]) * n1(a[1]) / 100, 2),
    CGST: a => round(n1(a[0]) * n1(a[1]) / 200, 2),
    SGST: a => round(n1(a[0]) * n1(a[1]) / 200, 2),
    WITHGST: a => round(n1(a[0]) * (1 + n1(a[1]) / 100), 2),
    REMOVEGST: a => round(n1(a[0]) / (1 + n1(a[1]) / 100), 2),
    INR: a => { const n = n1(a[0]), d = Math.floor(n1(arg(a, 1, 2))); const s = Math.abs(round(n, d)).toFixed(Math.max(0, d)).split('.'); return (n < 0 ? '-' : '') + '₹' + X.groupDigits(s[0]) + (s[1] ? '.' + s[1] : ''); },
    LAKH: a => n1(a[0]) / 1e5,
    CRORE: a => n1(a[0]) / 1e7,
    FY: a => { const p = dParts(blank(a[0]) ? todaySerial() : n1(a[0])); const y = p.m >= 4 ? p.y : p.y - 1; return y + '-' + String((y + 1) % 100).padStart(2, '0'); },
    FYSTART: a => { const p = dParts(blank(a[0]) ? todaySerial() : n1(a[0])); return toSerial(p.m >= 4 ? p.y : p.y - 1, 4, 1); },
    FYEND: a => { const p = dParts(blank(a[0]) ? todaySerial() : n1(a[0])); return toSerial(p.m >= 4 ? p.y + 1 : p.y, 3, 31); },
    FYQUARTER: a => { const m = dParts(blank(a[0]) ? todaySerial() : n1(a[0])).m; return 'Q' + (m >= 4 ? Math.floor((m - 4) / 3) + 1 : 4); },
    ISGSTIN: a => gstinValid(toStr(a[0])),
    GSTINSTATE: a => { const g = s1(a[0]).trim(); const st = STATES[g.slice(0, 2)]; if (!st) throw E.VALUE; return st; },
    GSTINPAN: a => { const g = s1(a[0]).trim().toUpperCase(); if (g.length < 12) throw E.VALUE; return g.slice(2, 12); },
    ISPAN: a => /^[A-Z]{3}[ABCFGHLJPT][A-Z][0-9]{4}[A-Z]$/.test(s1(a[0]).trim().toUpperCase()),
    ISIFSC: a => /^[A-Z]{4}0[A-Z0-9]{6}$/.test(s1(a[0]).trim().toUpperCase()),
    ISAADHAAR: a => aadhaarValid(toStr(a[0])),
    ISMOBILE: a => /^(?:\+?91|0)?[6-9]\d{9}$/.test(s1(a[0]).replace(/[\s()-]/g, '')),
    ISPINCODE: a => /^[1-9][0-9]{5}$/.test(s1(a[0]).trim()),
    STATENAME: a => { const v = norm(scalar(a[0])); const k = typeof v === 'number' ? String(v).padStart(2, '0') : String(v).trim().padStart(2, '0'); const st = STATES[k]; if (!st) throw E.NA; return st; },
    STATECODE: a => { const q = s1(a[0]).trim().toLowerCase(); if (!q) throw E.NA; const hit = Object.entries(STATES).find(([, n]) => n.toLowerCase() === q) || Object.entries(STATES).find(([, n]) => n.toLowerCase().startsWith(q)); if (!hit) throw E.NA; return hit[0]; },
    AGEING: a => { const d = Math.floor(n1(a[0])), asOf = blank(a[1]) ? todaySerial() : Math.floor(n1(a[1])), b = Math.floor(n1(arg(a, 2, 30))); const days = asOf - d; if (days < 0) return 'Not due'; if (days <= b) return '0-' + b; if (days <= 2 * b) return (b + 1) + '-' + 2 * b; if (days <= 3 * b) return (2 * b + 1) + '-' + 3 * b; return 'Over ' + 3 * b; },
    DENSITY: a => density(a[0]),
    METALWEIGHT: a => {
      const shape = s1(a[0]).toLowerCase().replace(/[\s_-]/g, '');
      const dims = [a[1], a[2], a[3]].map(v => (blank(v) || v === '' ? 0 : n1(v)));
      const dens = density(arg(a, 5, 7.85));
      if (shape === 'plate' || shape === 'sheet') return round(dims[0] * dims[1] * dims[2] * dens / 1e6, 3);
      const fn = AREA[shape]; if (!fn) throw E.VALUE;
      const len = n1(arg(a, 4, 1));
      return round(fn(dims) * len * dens / 1000, 3);
    },
    CONVERT: a => {
      const n = n1(a[0]), f = UNITS[s1(a[1]).toLowerCase().replace(/\s/g, '')], t = UNITS[s1(a[2]).toLowerCase().replace(/\s/g, '')];
      if (!f || !t || f[0] !== t[0]) throw E.NA;
      if (f[0] === 'T') { const c = f[1] === 'C' ? n : f[1] === 'F' ? (n - 32) * 5 / 9 : n - 273.15; return t[1] === 'C' ? c : t[1] === 'F' ? c * 9 / 5 + 32 : c + 273.15; }
      return n * f[1] / t[1];
    },
    QR: a => new Rich('qr', '', { text: s1(a[0]) }),
    UPIQR: a => {
      const upi = s1(a[0]).trim(); if (!/^[\w.\-]{2,}@[\w.\-]{2,}$/.test(upi)) throw E.VALUE;
      const name = blank(a[1]) ? '' : s1(a[1]); const amt = blank(a[2]) || a[2] === '' ? null : n1(a[2]); const note = blank(a[3]) ? '' : s1(a[3]);
      const uri = 'upi://pay?pa=' + encodeURIComponent(upi) + (name ? '&pn=' + encodeURIComponent(name) : '') + (amt ? '&am=' + amt.toFixed(2) : '') + '&cu=INR' + (note ? '&tn=' + encodeURIComponent(note) : '');
      return new Rich('qr', '', { text: uri, upi: true });
    },
    SPARKLINE: a => {
      const vals = toRange(a[0]).flat().map(v => (typeof norm(v) === 'number' ? norm(v) : null));
      const o = { type: 'line', color: null, negColor: null, max: null, min: null };
      const opts = a[1];
      if (isRange(opts)) opts.rows.forEach(r => { const k = String(norm(r[0]) || '').toLowerCase(), v = norm(r[1]); if (k === 'charttype') o.type = String(v).toLowerCase(); else if (k === 'color' || k === 'color1') o.color = String(v); else if (k === 'negcolor' || k === 'color2') o.negColor = String(v); else if (k === 'max' || k === 'ymax') o.max = +v; else if (k === 'min' || k === 'ymin') o.min = +v; });
      else if (!blank(opts) && typeof norm(opts) === 'string') o.type = String(norm(opts)).toLowerCase();
      if (!blank(a[2]) && typeof norm(a[2]) === 'string') o.color = norm(a[2]);
      return new Rich('spark', '', { values: vals, ...o });
    }
  });

  // ---------------------------------------------------------------- catalogue (for help & autocomplete)
  const CAT = `Math|SUM|SUM(number1, [number2], …)|Adds numbers or ranges
Math|AVERAGE|AVERAGE(number1, …)|Average of numbers
Math|MIN|MIN(number1, …)|Smallest number
Math|MAX|MAX(number1, …)|Largest number
Math|COUNT|COUNT(value1, …)|Counts cells that contain numbers
Math|COUNTA|COUNTA(value1, …)|Counts cells that are not empty
Math|COUNTBLANK|COUNTBLANK(range)|Counts empty cells
Math|PRODUCT|PRODUCT(number1, …)|Multiplies numbers
Math|ROUND|ROUND(number, digits)|Rounds to given decimals
Math|ROUNDUP|ROUNDUP(number, digits)|Rounds away from zero
Math|ROUNDDOWN|ROUNDDOWN(number, digits)|Rounds towards zero
Math|MROUND|MROUND(number, multiple)|Rounds to the nearest multiple
Math|CEILING|CEILING(number, [step])|Rounds up to a multiple
Math|FLOOR|FLOOR(number, [step])|Rounds down to a multiple
Math|INT|INT(number)|Whole-number part (rounds down)
Math|TRUNC|TRUNC(number, [digits])|Cuts off decimals
Math|ABS|ABS(number)|Value without minus sign
Math|MOD|MOD(number, divisor)|Remainder after division
Math|QUOTIENT|QUOTIENT(number, divisor)|Whole-number result of division
Math|POWER|POWER(number, power)|Number raised to a power
Math|SQRT|SQRT(number)|Square root
Math|EXP|EXP(number)|e raised to a power
Math|LN|LN(number)|Natural logarithm
Math|LOG|LOG(number, [base])|Logarithm (default base 10)
Math|LOG10|LOG10(number)|Base-10 logarithm
Math|SIGN|SIGN(number)|1, 0 or -1
Math|EVEN|EVEN(number)|Rounds up to an even number
Math|ODD|ODD(number)|Rounds up to an odd number
Math|GCD|GCD(n1, n2, …)|Greatest common divisor
Math|LCM|LCM(n1, n2, …)|Least common multiple
Math|FACT|FACT(number)|Factorial
Math|COMBIN|COMBIN(n, k)|Number of combinations
Math|PERMUT|PERMUT(n, k)|Number of permutations
Math|PI|PI()|The number π
Math|RAND|RAND()|Random number 0–1
Math|RANDBETWEEN|RANDBETWEEN(low, high)|Random whole number
Math|SUMPRODUCT|SUMPRODUCT(range1, range2, …)|Multiplies ranges and adds the results
Math|SUMSQ|SUMSQ(number1, …)|Sum of squares
Math|SUBTOTAL|SUBTOTAL(function_no, range, …)|Total that ignores filtered rows (9 = SUM, 1 = AVERAGE, 2 = COUNT)
Math|SIN|SIN(angle)|Sine (radians)
Math|COS|COS(angle)|Cosine (radians)
Math|TAN|TAN(angle)|Tangent (radians)
Math|RADIANS|RADIANS(degrees)|Degrees to radians
Math|DEGREES|DEGREES(radians)|Radians to degrees
Statistics|MEDIAN|MEDIAN(number1, …)|Middle value
Statistics|MODE|MODE(number1, …)|Most frequent value
Statistics|STDEV|STDEV(number1, …)|Standard deviation (sample)
Statistics|STDEVP|STDEVP(number1, …)|Standard deviation (population)
Statistics|VAR|VAR(number1, …)|Variance (sample)
Statistics|LARGE|LARGE(range, k)|k-th largest value
Statistics|SMALL|SMALL(range, k)|k-th smallest value
Statistics|RANK|RANK(number, range, [ascending])|Rank of a number in a list
Statistics|PERCENTILE|PERCENTILE(range, k)|k-th percentile (0–1)
Statistics|QUARTILE|QUARTILE(range, quart)|Quartile (0–4)
Statistics|CORREL|CORREL(range1, range2)|Correlation between two lists
Statistics|SLOPE|SLOPE(known_y, known_x)|Slope of the trend line
Statistics|INTERCEPT|INTERCEPT(known_y, known_x)|Intercept of the trend line
Statistics|FORECAST|FORECAST(x, known_y, known_x)|Predicts a value with a straight-line trend
Statistics|COUNTUNIQUE|COUNTUNIQUE(range)|Number of different values
Conditional|SUMIF|SUMIF(range, criteria, [sum_range])|Adds cells that match, e.g. ">1000"
Conditional|SUMIFS|SUMIFS(sum_range, range1, criteria1, …)|Adds cells matching several conditions
Conditional|COUNTIF|COUNTIF(range, criteria)|Counts cells that match
Conditional|COUNTIFS|COUNTIFS(range1, criteria1, …)|Counts cells matching several conditions
Conditional|AVERAGEIF|AVERAGEIF(range, criteria, [avg_range])|Average of matching cells
Conditional|AVERAGEIFS|AVERAGEIFS(avg_range, range1, criteria1, …)|Average with several conditions
Conditional|MAXIFS|MAXIFS(max_range, range1, criteria1, …)|Largest value with conditions
Conditional|MINIFS|MINIFS(min_range, range1, criteria1, …)|Smallest value with conditions
Logical|IF|IF(test, value_if_true, [value_if_false])|Chooses a value based on a test
Logical|IFS|IFS(test1, value1, test2, value2, …)|First value whose test is TRUE
Logical|IFERROR|IFERROR(value, value_if_error)|Replaces errors with another value
Logical|IFNA|IFNA(value, value_if_na)|Replaces #N/A
Logical|AND|AND(test1, test2, …)|TRUE if all are TRUE
Logical|OR|OR(test1, test2, …)|TRUE if any is TRUE
Logical|XOR|XOR(test1, …)|TRUE if an odd number are TRUE
Logical|NOT|NOT(test)|Reverses TRUE/FALSE
Logical|SWITCH|SWITCH(value, case1, result1, …, [default])|Matches a value against cases
Logical|CHOOSE|CHOOSE(index, value1, value2, …)|Picks a value by position
Logical|LET|LET(name, value, …, calculation)|Gives names to parts of a formula
Info|ISBLANK|ISBLANK(value)|TRUE if empty
Info|ISNUMBER|ISNUMBER(value)|TRUE if a number
Info|ISTEXT|ISTEXT(value)|TRUE if text
Info|ISERROR|ISERROR(value)|TRUE if an error
Info|ISNA|ISNA(value)|TRUE if #N/A
Info|ISFORMULA|ISFORMULA(cell)|TRUE if the cell has a formula
Info|ISEVEN|ISEVEN(number)|TRUE if even
Info|ISODD|ISODD(number)|TRUE if odd
Info|ROW|ROW([cell])|Row number
Info|COLUMN|COLUMN([cell])|Column number
Info|ROWS|ROWS(range)|Number of rows
Info|COLUMNS|COLUMNS(range)|Number of columns
Info|ADDRESS|ADDRESS(row, column, [abs], [a1], [sheet])|Cell address as text
Info|INDIRECT|INDIRECT(text)|Reference from text like "B5" or "Sheet2!A1"
Info|OFFSET|OFFSET(cell, rows, cols, [height], [width])|Reference shifted from a cell
Info|FORMULATEXT|FORMULATEXT(cell)|Shows the formula of a cell
Info|TYPE|TYPE(value)|1 number, 2 text, 4 logical, 16 error
Lookup|VLOOKUP|VLOOKUP(value, table, column, [approx])|Finds a value in the first column and returns another column. Use FALSE for exact match
Lookup|HLOOKUP|HLOOKUP(value, table, row, [approx])|Like VLOOKUP but across rows
Lookup|XLOOKUP|XLOOKUP(value, lookup_range, return_range, [if_not_found], [match_mode], [search_mode])|Modern lookup – exact match by default
Lookup|INDEX|INDEX(range, row, [column])|Value at a position
Lookup|MATCH|MATCH(value, range, [type])|Position of a value (0 = exact)
Lookup|XMATCH|XMATCH(value, range, [match_mode], [search_mode])|Position of a value, exact by default
Lookup|LOOKUP|LOOKUP(value, lookup_range, [result_range])|Approximate lookup in sorted data
Lookup|HYPERLINK|HYPERLINK(url, [label])|Clickable link (Ctrl+click to open)
Lookup|IMAGE|IMAGE(url)|Shows a picture inside a cell
Arrays|FILTER|FILTER(range, condition, [if_empty])|Rows that meet a condition – spills results
Arrays|SORT|SORT(range, [column], [order], [by_col])|Sorted copy of a range
Arrays|SORTBY|SORTBY(range, by_range, [order], …)|Sorts by another range
Arrays|UNIQUE|UNIQUE(range, [by_col], [exactly_once])|List without duplicates
Arrays|SEQUENCE|SEQUENCE(rows, [cols], [start], [step])|List of numbers 1, 2, 3 …
Arrays|TRANSPOSE|TRANSPOSE(range)|Swaps rows and columns
Arrays|RANDARRAY|RANDARRAY(rows, cols, [min], [max], [whole])|Grid of random numbers
Arrays|TAKE|TAKE(range, rows, [cols])|First (or last) rows/columns
Arrays|DROP|DROP(range, rows, [cols])|Removes first (or last) rows/columns
Arrays|CHOOSECOLS|CHOOSECOLS(range, col1, …)|Picks columns
Arrays|CHOOSEROWS|CHOOSEROWS(range, row1, …)|Picks rows
Arrays|VSTACK|VSTACK(range1, range2, …)|Stacks ranges on top of each other
Arrays|HSTACK|HSTACK(range1, range2, …)|Places ranges side by side
Arrays|TOCOL|TOCOL(range)|Turns a range into one column
Arrays|TOROW|TOROW(range)|Turns a range into one row
Text|CONCAT|CONCAT(text1, text2, …)|Joins text
Text|TEXTJOIN|TEXTJOIN(separator, ignore_empty, text1, …)|Joins text with a separator
Text|LEFT|LEFT(text, [count])|First characters
Text|RIGHT|RIGHT(text, [count])|Last characters
Text|MID|MID(text, start, count)|Characters from the middle
Text|LEN|LEN(text)|Number of characters
Text|UPPER|UPPER(text)|CAPITAL LETTERS
Text|LOWER|LOWER(text)|small letters
Text|PROPER|PROPER(text)|First Letter Capital
Text|TRIM|TRIM(text)|Removes extra spaces
Text|CLEAN|CLEAN(text)|Removes hidden characters
Text|SUBSTITUTE|SUBSTITUTE(text, old, new, [which])|Replaces text
Text|REPLACE|REPLACE(text, start, count, new)|Replaces part of text by position
Text|FIND|FIND(find, text, [start])|Position of text (case-sensitive)
Text|SEARCH|SEARCH(find, text, [start])|Position of text (any case, wildcards)
Text|TEXTBEFORE|TEXTBEFORE(text, delimiter, [instance])|Text before a delimiter
Text|TEXTAFTER|TEXTAFTER(text, delimiter, [instance])|Text after a delimiter
Text|TEXTSPLIT|TEXTSPLIT(text, col_delimiter, [row_delimiter])|Splits text into cells
Text|SPLIT|SPLIT(text, delimiter)|Splits text into columns (Google Sheets style)
Text|EXACT|EXACT(text1, text2)|TRUE if exactly the same
Text|REPT|REPT(text, times)|Repeats text
Text|TEXT|TEXT(value, format)|Formats a value, e.g. TEXT(A1,"dd-mm-yyyy") or "#,##0.00"
Text|VALUE|VALUE(text)|Converts text to a number
Text|FIXED|FIXED(number, [decimals], [no_commas])|Number as text with commas
Text|REGEXMATCH|REGEXMATCH(text, pattern)|TRUE if text matches a pattern
Text|REGEXEXTRACT|REGEXEXTRACT(text, pattern)|Part of text that matches
Text|REGEXREPLACE|REGEXREPLACE(text, pattern, replacement)|Replaces matching text
Text|CHAR|CHAR(code)|Character from a code
Text|CODE|CODE(text)|Code of first character
Date|TODAY|TODAY()|Today's date
Date|NOW|NOW()|Date and time now
Date|DATE|DATE(year, month, day)|Makes a date
Date|TIME|TIME(hour, minute, second)|Makes a time
Date|DATEVALUE|DATEVALUE(text)|Converts text like 25-11-2026 to a date
Date|YEAR|YEAR(date)|Year of a date
Date|MONTH|MONTH(date)|Month (1–12)
Date|DAY|DAY(date)|Day of the month
Date|WEEKDAY|WEEKDAY(date, [type])|Day of the week (1 = Sunday)
Date|WEEKNUM|WEEKNUM(date)|Week number of the year
Date|HOUR|HOUR(time)|Hour
Date|MINUTE|MINUTE(time)|Minute
Date|SECOND|SECOND(time)|Second
Date|DAYS|DAYS(end, start)|Days between two dates
Date|DATEDIF|DATEDIF(start, end, unit)|Difference in "D", "M", "Y", "YM", "MD"
Date|EDATE|EDATE(date, months)|Same day some months later
Date|EOMONTH|EOMONTH(date, months)|Last day of a month
Date|NETWORKDAYS|NETWORKDAYS(start, end, [holidays])|Working days (Mon–Fri)
Date|WORKDAY|WORKDAY(start, days, [holidays])|Date after some working days
Date|YEARFRAC|YEARFRAC(start, end, [basis])|Fraction of a year between dates
Finance|PMT|PMT(rate, periods, amount, [fv], [type])|Loan payment per period
Finance|IPMT|IPMT(rate, period, periods, amount)|Interest part of a payment
Finance|PPMT|PPMT(rate, period, periods, amount)|Principal part of a payment
Finance|PV|PV(rate, periods, payment, [fv])|Present value
Finance|FV|FV(rate, periods, payment, [pv])|Future value (e.g. SIP maturity)
Finance|NPER|NPER(rate, payment, pv)|Number of payments
Finance|RATE|RATE(periods, payment, pv, [fv])|Interest rate per period
Finance|NPV|NPV(rate, value1, …)|Net present value
Finance|XNPV|XNPV(rate, values, dates)|NPV with dates
Finance|IRR|IRR(values)|Internal rate of return
Finance|XIRR|XIRR(values, dates)|Return with dates – used for mutual fund / SIP returns
Finance|SLN|SLN(cost, salvage, life)|Straight-line depreciation
India 🇮🇳|EMI|EMI(loan, yearly_rate_%, months)|Monthly loan EMI, e.g. EMI(500000, 9.5, 60)
India 🇮🇳|GST|GST(amount, rate_%)|GST amount, e.g. GST(1000, 18) = 180
India 🇮🇳|CGST|CGST(amount, rate_%)|Central GST (half of the rate)
India 🇮🇳|SGST|SGST(amount, rate_%)|State GST (half of the rate)
India 🇮🇳|IGST|IGST(amount, rate_%)|Integrated GST for inter-state sales
India 🇮🇳|WITHGST|WITHGST(amount, rate_%)|Amount including GST
India 🇮🇳|REMOVEGST|REMOVEGST(amount_with_gst, rate_%)|Amount before GST
India 🇮🇳|RUPEEWORDS|RUPEEWORDS(amount, ["hi"])|Amount in words – "Rupees One Lakh … Only". Add "hi" for Hindi
India 🇮🇳|HINDIWORDS|HINDIWORDS(amount)|Amount in Hindi words – "एक लाख … रुपये मात्र"
India 🇮🇳|NUMWORDS|NUMWORDS(number, ["hi"])|Number in words (lakh / crore system)
India 🇮🇳|INR|INR(amount, [decimals])|Text like ₹1,25,000.00
India 🇮🇳|LAKH|LAKH(number)|Number in lakhs
India 🇮🇳|CRORE|CRORE(number)|Number in crores
India 🇮🇳|FY|FY([date])|Financial year, e.g. 2026-27
India 🇮🇳|FYSTART|FYSTART([date])|1 April of the financial year
India 🇮🇳|FYEND|FYEND([date])|31 March of the financial year
India 🇮🇳|FYQUARTER|FYQUARTER([date])|Quarter of the financial year (Q1 = Apr–Jun)
India 🇮🇳|ISGSTIN|ISGSTIN(text)|TRUE if a GSTIN is valid (checks the check-digit)
India 🇮🇳|GSTINSTATE|GSTINSTATE(gstin)|State name from a GSTIN
India 🇮🇳|GSTINPAN|GSTINPAN(gstin)|PAN number inside a GSTIN
India 🇮🇳|STATENAME|STATENAME(code)|State name from GST state code, e.g. 24 → Gujarat
India 🇮🇳|STATECODE|STATECODE(state)|GST state code from a state name
India 🇮🇳|ISPAN|ISPAN(text)|TRUE if a PAN number is valid
India 🇮🇳|ISIFSC|ISIFSC(text)|TRUE if an IFSC code is valid
India 🇮🇳|ISAADHAAR|ISAADHAAR(text)|TRUE if an Aadhaar number is valid (Verhoeff check)
India 🇮🇳|ISMOBILE|ISMOBILE(text)|TRUE if an Indian mobile number is valid
India 🇮🇳|ISPINCODE|ISPINCODE(text)|TRUE if a 6-digit PIN code is valid
India 🇮🇳|AGEING|AGEING(due_date, [as_of], [days])|Overdue bucket: 0-30, 31-60, 61-90, Over 90
India 🇮🇳|UPIQR|UPIQR(upi_id, name, [amount], [note])|UPI payment QR code inside a cell
India 🇮🇳|QR|QR(text)|QR code for any text or link
India 🇮🇳|METALWEIGHT|METALWEIGHT(shape, a, [b], [c], [length_m], [material])|Weight in kg: round, square, flat, hex, pipe, sqpipe, angle, channel, plate
India 🇮🇳|DENSITY|DENSITY(material)|Density (g/cm³): MS, SS, AL, Cu, Brass …
India 🇮🇳|CONVERT|CONVERT(number, from, to)|Units: kg, quintal, tola, mm, inch, ft, sqft, gaj, acre, guntha, litre …
India 🇮🇳|SPARKLINE|SPARKLINE(range, [type])|Mini chart inside a cell: "line", "column", "winloss"`;
  CAT.split('\n').forEach(line => { const [cat, name, sig, desc] = line.split('|'); X.FN_INFO[name] = { cat, sig, desc }; });
})(typeof window !== 'undefined' ? window : globalThis);
