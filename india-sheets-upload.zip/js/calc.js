/* India Sheets – recalculation engine
 * Keeps computed values, tracks which cells depend on which, recalculates only what changed,
 * supports spilled (dynamic array) results, volatile functions and very long formula chains.
 */
(function (global) {
  'use strict';
  const IS = global.IS = global.IS || {};
  const X = global.Formula;
  const MAX_DEPTH = 350;
  const BIG_RANGE = 20000;
  const isFormulaCell = cell => cell && cell.t !== 's' && typeof cell.v === 'string' && cell.v.length > 1 && cell.v[0] === '=';
  const hasValue = cell => cell && cell.v !== undefined && cell.v !== null && cell.v !== '';
  const split = gk => { const i = gk.indexOf('!'), j = gk.indexOf(':', i); return { sid: gk.slice(0, i), r: +gk.slice(i + 1, j), c: +gk.slice(j + 1), key: gk.slice(i + 1) }; };

  class Calc {
    constructor() { this.wb = null; this.reset(); }
    reset() {
      this.vals = new Map();        // sheetId -> Map(key -> value)
      this.prec = new Map();        // formula gk -> {cells:Set, ranges:[]}
      this.dependents = new Map();  // gk -> Set(formula gk)
      this.rangeDeps = new Map();   // sheetId -> Map(formula gk -> [ranges])
      this.volatile = new Set();
      this.spills = new Map();      // anchor gk -> {sid, r, c, h, w}
      this.spillOwner = new Map();  // cell gk -> anchor gk
      this.blocked = new Map();     // anchor gk -> area that could not spill
      this.dirty = new Set();
      this.computing = new Set();
      this.stack = [];
      this.boundsC = new Map();
      this.spillCount = new Map();
      this.hints = null;
      this.byName = new Map(); this.byId = new Map();
    }
    attach(wb) { this.wb = wb; this.full(); }
    index() {
      this.byName = new Map(); this.byId = new Map();
      for (const sh of this.wb.sheets) { this.byName.set(sh.name.toUpperCase(), sh); this.byId.set(sh.id, sh); }
    }
    sheetByName(n) { return this.byName.get(String(n).toUpperCase()) || null; }
    bounds(sh) {
      let b = this.boundsC.get(sh.id);
      if (!b) {
        let rows = 0, cols = 0;
        for (const k in sh.cells) { const i = k.indexOf(':'); const r = +k.slice(0, i), c = +k.slice(i + 1); if (r >= rows) rows = r + 1; if (c >= cols) cols = c + 1; }
        for (const sp of this.spills.values()) if (sp.sid === sh.id) { rows = Math.max(rows, sp.r + sp.h); cols = Math.max(cols, sp.c + sp.w); }
        b = { rows: Math.max(rows, 1), cols: Math.max(cols, 1) };
        this.boundsC.set(sh.id, b);
      }
      return b;
    }
    growBounds(sid, r, c) { const b = this.boundsC.get(sid); if (b) { if (r >= b.rows) b.rows = r + 1; if (c >= b.cols) b.cols = c + 1; } }

    /** Recalculate everything (after opening a file or structural changes). */
    full() {
      if (!this.wb) return;
      const hints = this.spillOwner;
      this.reset(); this.index();
      this.hints = hints;
      const order = [];
      for (const sh of this.wb.sheets) {
        const m = new Map(); this.vals.set(sh.id, m);
        for (const k in sh.cells) {
          const cell = sh.cells[k];
          if (!hasValue(cell)) continue;
          if (isFormulaCell(cell)) { const gk = sh.id + '!' + k; order.push(gk); this.dirty.add(gk); }
          else m.set(k, literal(cell));
        }
      }
      this.compute(order);
      this.hints = null;
      IS.emit && IS.emit('recalc', { full: true });
    }

    /** Some cells were edited: [{sid, r, c}] */
    changed(list) {
      if (!this.wb) return;
      if (list.length > 4000) { this.full(); return; }
      const starts = [];
      for (const { sid, r, c } of list) {
        const sh = this.byId.get(sid); if (!sh) continue;
        const key = r + ':' + c, gk = sid + '!' + key;
        let m = this.vals.get(sid); if (!m) { m = new Map(); this.vals.set(sid, m); }
        const cell = sh.cells[key];
        this.growBounds(sid, r, c);
        if (this.prec.has(gk)) this.clearDeps(gk);
        if (this.spills.has(gk)) this.unspill(gk, starts);
        this.blocked.delete(gk);
        if (isFormulaCell(cell)) this.dirty.add(gk);
        else { this.dirty.delete(gk); if (hasValue(cell)) m.set(key, literal(cell)); else if (!this.spillOwner.has(gk)) m.delete(key); }
        starts.push(gk);
        const anchor = this.spillOwner.get(gk);
        if (anchor && hasValue(cell)) { this.dirty.add(anchor); starts.push(anchor); }
        for (const [a, area] of this.blocked) if (area.sid === sid && r >= area.r1 && r <= area.r2 && c >= area.c1 && c <= area.c2) { this.dirty.add(a); starts.push(a); }
      }
      this.markDependents(starts);
      for (const v of this.volatile) this.dirty.add(v);
      this.compute([...this.dirty]);
      IS.emit && IS.emit('recalc', { full: false });
    }
    recalcVolatile() { if (!this.volatile.size) return; const v = [...this.volatile]; v.forEach(gk => this.dirty.add(gk)); this.markDependents(v); this.compute([...this.dirty]); IS.emit && IS.emit('recalc', { full: false }); }

    markDependents(start) {
      const seen = new Set(); const stack = [...start];
      while (stack.length) {
        const gk = stack.pop(); if (seen.has(gk)) continue; seen.add(gk);
        const deps = this.dependents.get(gk);
        if (deps) for (const d of deps) { this.dirty.add(d); stack.push(d); }
        const { sid, r, c } = split(gk);
        const m = this.rangeDeps.get(sid);
        if (m) for (const [owner, ranges] of m) {
          if (seen.has(owner)) continue;
          for (const rg of ranges) if (r >= rg.r1 && r <= rg.r2 && c >= rg.c1 && c <= rg.c2) { this.dirty.add(owner); stack.push(owner); break; }
        }
        const sp = this.spills.get(gk);
        if (sp) for (let i = 0; i < sp.h; i++) for (let j = 0; j < sp.w; j++) if (i || j) stack.push(sp.sid + '!' + (sp.r + i) + ':' + (sp.c + j));
      }
    }

    compute(order) {
      this.spillCount = new Map();
      for (const gk of order) if (this.dirty.has(gk)) this.ensure(gk);
      let guard = 0;
      while (this.dirty.size && guard++ < 1e6) { const gk = this.dirty.values().next().value; this.ensure(gk); }
    }
    ensure(gk) {
      const work = [gk], inWork = new Set([gk]);
      while (work.length) {
        const top = work[work.length - 1];
        if (!this.dirty.has(top)) { work.pop(); inWork.delete(top); continue; }
        try { this.evalCell(top, 0); work.pop(); inWork.delete(top); }
        catch (e) {
          if (e && e.__defer) {
            if (inWork.has(e.key)) { this.setValue(e.key, X.E.CYCLE); this.dirty.delete(e.key); continue; }
            work.push(e.key); inWork.add(e.key);
          } else if (e instanceof RangeError) {
            // stack overflow despite deferral – fall back to the deepest pending cell
            this.setValue(top, X.E.CYCLE); this.dirty.delete(top); work.pop(); inWork.delete(top);
          } else {
            console.error('Calc error in', top, e);
            this.setValue(top, X.E.ERROR); this.dirty.delete(top); work.pop(); inWork.delete(top);
          }
        }
      }
    }
    evalCell(gk, depth) {
      const { sid, r, c, key } = split(gk);
      const sh = this.byId.get(sid); const cell = sh && sh.cells[key];
      if (!isFormulaCell(cell)) { this.dirty.delete(gk); const m = this.vals.get(sid); if (m) { if (hasValue(cell)) m.set(key, literal(cell)); } return; }
      this.clearDeps(gk);
      this.computing.add(gk);
      const dep = { cells: new Set(), ranges: [] };
      this.stack.push(dep);
      let v;
      try { v = X.run(cell.v, this.ctx(sh, r, c, depth, gk)); }
      finally { this.computing.delete(gk); this.stack.pop(); }
      this.dirty.delete(gk);
      this.saveDeps(gk, dep);
      if (X.isRange(v)) v = this.spill(gk, sh, r, c, v);
      else if (this.spills.has(gk) || this.blocked.has(gk)) { this.blocked.delete(gk); this.unspill(gk, null, true); }
      this.setValue(gk, v);
    }
    ctx(sh, r, c, depth, gk) {
      const self = this;
      return {
        sheet: sh.name, cell: { r, c },
        get(name, rr, cc) { const s = self.sheetByName(name); if (!s) return X.E.REF; return self.read(s, rr, cc, depth, true); },
        getRange(name, r1, c1, r2, c2) { return self.readRange(name, r1, c1, r2, c2, depth); },
        bounds(name) { const s = self.sheetByName(name); return s ? self.bounds(s) : null; },
        name(n) { return self.nameAst(n, sh); },
        raw(name, rr, cc) { const s = self.sheetByName(name); const cl = s && s.cells[rr + ':' + cc]; return cl && typeof cl.v === 'string' ? cl.v : ''; },
        rowHidden(name, rr, manual) { const s = self.sheetByName(name); return s && IS.isRowHidden ? IS.isRowHidden(s, rr, manual) : false; },
        volatile() { self.volatile.add(gk); }
      };
    }
    nameAst(n, sh) {
      const names = this.wb.names || {};
      const def = names[n] || names[String(n).toUpperCase()];
      if (!def) return null;
      return X.getAst('=' + def.ref);
    }
    record(gk) { const top = this.stack[this.stack.length - 1]; if (top) top.cells.add(gk); }
    read(sh, r, c, depth, record) {
      const key = r + ':' + c, gk = sh.id + '!' + key;
      if (record) this.record(gk);
      const cell = sh.cells[key];
      const m = this.vals.get(sh.id);
      if (hasValue(cell)) {
        if (isFormulaCell(cell)) {
          if (this.computing.has(gk)) return X.E.CYCLE;
          if (this.dirty.has(gk)) { if (depth >= MAX_DEPTH) throw new X.Defer(gk); this.evalCell(gk, depth + 1); }
        }
        return m && m.has(key) ? m.get(key) : null;
      }
      const anchor = this.spillOwner.get(gk) || (this.hints && this.hints.get(gk));
      if (anchor) {
        if (this.dirty.has(anchor) && !this.computing.has(anchor)) { if (depth >= MAX_DEPTH) throw new X.Defer(anchor); this.evalCell(anchor, depth + 1); }
        if (this.spillOwner.get(gk) === anchor) return m && m.has(key) ? m.get(key) : null;
      }
      return null;
    }
    readRange(name, r1, c1, r2, c2, depth) {
      const sh = this.sheetByName(name); if (!sh) return X.E.REF;
      const top = this.stack[this.stack.length - 1];
      if (top) top.ranges.push({ sid: sh.id, r1, c1, r2, c2 });
      const b = this.bounds(sh);
      let R2 = r2 === Infinity ? b.rows - 1 : r2, C2 = c2 === Infinity ? b.cols - 1 : c2;
      if (R2 - r1 > BIG_RANGE) R2 = Math.max(r1, Math.min(R2, b.rows - 1));
      if (C2 - c1 > BIG_RANGE) C2 = Math.max(c1, Math.min(C2, b.cols - 1));
      const rows = [];
      if (R2 < r1 || C2 < c1) rows.push([null]);
      else for (let r = r1; r <= R2; r++) { const row = new Array(C2 - c1 + 1); for (let c = c1; c <= C2; c++) row[c - c1] = this.read(sh, r, c, depth, false); rows.push(row); }
      return new X.Range(rows, { sheet: sh.name, r1, c1 });
    }
    saveDeps(gk, dep) {
      this.prec.set(gk, dep);
      for (const p of dep.cells) { let s = this.dependents.get(p); if (!s) this.dependents.set(p, s = new Set()); s.add(gk); }
      for (const rg of dep.ranges) { let m = this.rangeDeps.get(rg.sid); if (!m) this.rangeDeps.set(rg.sid, m = new Map()); let arr = m.get(gk); if (!arr) m.set(gk, arr = []); arr.push(rg); }
    }
    clearDeps(gk) {
      const dep = this.prec.get(gk); if (!dep) { this.volatile.delete(gk); return; }
      for (const p of dep.cells) { const s = this.dependents.get(p); if (s) { s.delete(gk); if (!s.size) this.dependents.delete(p); } }
      for (const rg of dep.ranges) { const m = this.rangeDeps.get(rg.sid); if (m) m.delete(gk); }
      this.prec.delete(gk); this.volatile.delete(gk);
    }
    setValue(gk, v) { const { sid, key } = split(gk); let m = this.vals.get(sid); if (!m) { m = new Map(); this.vals.set(sid, m); } m.set(key, v); }

    spill(gk, sh, r, c, range) {
      const h = range.h, w = range.w, sid = sh.id;
      const n = (this.spillCount.get(gk) || 0) + 1; this.spillCount.set(gk, n);
      if (n > 25) { this.unspill(gk, null, true); return X.E.CYCLE; }
      if (h * w > 2e6) { this.unspill(gk, null, true); return X.E.SPILL; }
      for (let i = 0; i < h; i++) for (let j = 0; j < w; j++) {
        if (!i && !j) continue;
        const key2 = (r + i) + ':' + (c + j);
        const own = this.spillOwner.get(sid + '!' + key2);
        if (hasValue(sh.cells[key2]) || (own && own !== gk)) {
          this.unspill(gk, null, true);
          this.blocked.set(gk, { sid, r1: r, c1: c, r2: r + h - 1, c2: c + w - 1 });
          return X.E.SPILL;
        }
      }
      this.blocked.delete(gk);
      const m = this.vals.get(sid);
      const old = this.spills.get(gk);
      let changed = !old || old.h !== h || old.w !== w;
      const touched = [];
      if (old && changed) {
        for (let i = 0; i < old.h; i++) for (let j = 0; j < old.w; j++) {
          if (!i && !j) continue;
          const g2 = sid + '!' + (old.r + i) + ':' + (old.c + j);
          if (i < h && j < w) continue;
          this.spillOwner.delete(g2); m.delete((old.r + i) + ':' + (old.c + j)); touched.push(g2);
        }
      }
      for (let i = 0; i < h; i++) for (let j = 0; j < w; j++) {
        if (!i && !j) continue;
        const key2 = (r + i) + ':' + (c + j), g2 = sid + '!' + key2;
        let v = range.rows[i][j]; if (v === undefined) v = null;
        if (X.isRange(v)) v = X.scalar(v);
        const prev = m.has(key2) ? m.get(key2) : undefined;
        if (!changed && prev !== v && !(X.isErr(prev) && X.isErr(v) && prev.code === v.code)) changed = true;
        if (prev !== v) touched.push(g2);
        this.spillOwner.set(g2, gk); m.set(key2, v);
      }
      this.spills.set(gk, { sid, r, c, h, w });
      this.growBounds(sid, r + h - 1, c + w - 1);
      if (changed && touched.length) this.markDependents(touched);
      const v0 = range.rows[0][0];
      return v0 === undefined ? null : v0;
    }
    unspill(gk, collect, mark) {
      const sp = this.spills.get(gk); if (!sp) return;
      const m = this.vals.get(sp.sid); const touched = [];
      for (let i = 0; i < sp.h; i++) for (let j = 0; j < sp.w; j++) {
        if (!i && !j) continue;
        const key2 = (sp.r + i) + ':' + (sp.c + j), g2 = sp.sid + '!' + key2;
        if (this.spillOwner.get(g2) === gk) { this.spillOwner.delete(g2); const sh = this.byId.get(sp.sid); if (m && !(sh && hasValue(sh.cells[key2]))) m.delete(key2); touched.push(g2); }
      }
      this.spills.delete(gk);
      if (collect) collect.push(...touched);
      if (mark && touched.length) this.markDependents(touched);
    }

    /** Evaluate a formula as if it were in (r,c) without storing anything. */
    evalTempRange(sh, formula, r, c) {
      const dep = { cells: new Set(), ranges: [] };
      this.stack.push(dep);
      try { return X.run(formula, this.ctx(sh, r, c, 0, '__tmp')); }
      catch (e) { return X.E.ERROR; }
      finally { this.stack.pop(); this.volatile.delete('__tmp'); }
    }
    evalTemp(sh, formula, r, c) { const v = this.evalTempRange(sh, formula, r, c); return X.isRange(v) ? X.scalar(v) : v; }

    // ---- queries used by the UI
    value(sh, r, c) { const m = this.vals.get(sh.id); if (!m) return null; const v = m.get(r + ':' + c); return v === undefined ? null : v; }
    spillAnchor(sh, r, c) { const a = this.spillOwner.get(sh.id + '!' + r + ':' + c); return a ? split(a) : null; }
    spillArea(sh, r, c) { const sp = this.spills.get(sh.id + '!' + r + ':' + c); return sp ? { t: sp.r, l: sp.c, b: sp.r + sp.h - 1, r: sp.c + sp.w - 1 } : null; }
    isSpillCell(sh, r, c) { return this.spillOwner.has(sh.id + '!' + r + ':' + c); }
    hasVolatile() { return this.volatile.size > 0; }
    /** Cells that the formula at (r,c) reads – for "trace precedents" */
    precedents(sh, r, c) { const dep = this.prec.get(sh.id + '!' + r + ':' + c); if (!dep) return { cells: [], ranges: [] }; return { cells: [...dep.cells].map(split), ranges: dep.ranges.slice() }; }
    dependentsOf(sh, r, c) {
      const gk = sh.id + '!' + r + ':' + c; const out = new Set(this.dependents.get(gk) || []);
      const m = this.rangeDeps.get(sh.id);
      if (m) for (const [owner, ranges] of m) if (ranges.some(rg => r >= rg.r1 && r <= rg.r2 && c >= rg.c1 && c <= rg.c2)) out.add(owner);
      return [...out].map(split);
    }
  }
  function literal(cell) { return cell.v; }

  IS.Calc = Calc;
  IS.isFormulaCell = isFormulaCell;
  IS.hasValue = hasValue;
})(window);
