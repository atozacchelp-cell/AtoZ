/* India Sheets – on-device storage (IndexedDB) for many workbooks + version history.
 * Falls back to memory if the browser blocks storage (private windows).
 */
(function (global) {
  'use strict';
  const DB_NAME = 'india-sheets', DB_VER = 1;
  let dbp = null, memory = null;

  function open() {
    if (dbp) return dbp;
    dbp = new Promise((resolve) => {
      if (!global.indexedDB) { memory = memStore(); resolve(null); return; }
      let req;
      try { req = indexedDB.open(DB_NAME, DB_VER); } catch (e) { memory = memStore(); resolve(null); return; }
      req.onupgradeneeded = () => {
        const db = req.result;
        if (!db.objectStoreNames.contains('books')) db.createObjectStore('books', { keyPath: 'id' });
        if (!db.objectStoreNames.contains('index')) db.createObjectStore('index', { keyPath: 'id' });
        if (!db.objectStoreNames.contains('versions')) { const v = db.createObjectStore('versions', { keyPath: 'vid', autoIncrement: true }); v.createIndex('bookId', 'bookId'); }
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => { memory = memStore(); resolve(null); };
      req.onblocked = () => { /* another tab is upgrading */ };
    });
    return dbp;
  }
  function memStore() { return { books: new Map(), index: new Map(), versions: new Map(), vid: 1 }; }
  const wrap = req => new Promise((res, rej) => { req.onsuccess = () => res(req.result); req.onerror = () => rej(req.error); });
  async function tx(stores, mode, fn) {
    const db = await open();
    if (!db) return fn(null);
    return new Promise((resolve, reject) => {
      const t = db.transaction(stores, mode); let out;
      Promise.resolve(fn(t)).then(v => { out = v; }, reject);
      t.oncomplete = () => resolve(out);
      t.onerror = () => reject(t.error);
      t.onabort = () => reject(t.error || new Error('Storage aborted'));
    });
  }
  function summary(book) {
    let cells = 0; (book.sheets || []).forEach(s => { cells += Object.keys(s.cells || {}).length; });
    return { id: book.id, name: book.name, updated: book.updated, created: book.created, sheets: (book.sheets || []).length, cells, locked: !!book.locked, template: book.template || null };
  }

  const Store = {
    async ready() { await open(); return !memory; },
    get persistent() { return !memory; },
    async requestPersist() { try { if (navigator.storage && navigator.storage.persist) return await navigator.storage.persist(); } catch (e) { /* ignore */ } return false; },
    async estimate() { try { return await navigator.storage.estimate(); } catch (e) { return null; } },
    async list() {
      if (memory || !(await open())) return [...memory.index.values()].sort((a, b) => b.updated - a.updated);
      const all = await tx(['index'], 'readonly', t => wrap(t.objectStore('index').getAll()));
      return (all || []).sort((a, b) => b.updated - a.updated);
    },
    async get(id) {
      if (memory) { const b = memory.books.get(id); return b ? JSON.parse(JSON.stringify(b)) : null; }
      return tx(['books'], 'readonly', t => wrap(t.objectStore('books').get(id)));
    },
    async put(book) {
      book.updated = book.updated || Date.now();
      const sum = summary(book);
      if (memory) { memory.books.set(book.id, JSON.parse(JSON.stringify(book))); memory.index.set(book.id, sum); return; }
      await tx(['books', 'index'], 'readwrite', t => { t.objectStore('books').put(book); t.objectStore('index').put(sum); });
    },
    async remove(id) {
      if (memory) { memory.books.delete(id); memory.index.delete(id); for (const [k, v] of memory.versions) if (v.bookId === id) memory.versions.delete(k); return; }
      const vids = await this.versionIds(id);
      await tx(['books', 'index', 'versions'], 'readwrite', t => { t.objectStore('books').delete(id); t.objectStore('index').delete(id); vids.forEach(v => t.objectStore('versions').delete(v)); });
    },
    async versionIds(bookId) {
      if (memory) return [...memory.versions.values()].filter(v => v.bookId === bookId).map(v => v.vid);
      return tx(['versions'], 'readonly', t => wrap(t.objectStore('versions').index('bookId').getAllKeys(bookId)));
    },
    async addVersion(bookId, label, data, keep = 40) {
      const rec = { bookId, at: Date.now(), label: label || 'Auto-save', data };
      if (memory) { rec.vid = memory.vid++; memory.versions.set(rec.vid, JSON.parse(JSON.stringify(rec))); }
      else await tx(['versions'], 'readwrite', t => { t.objectStore('versions').add(rec); });
      const list = await this.versions(bookId);
      if (list.length > keep) {
        const old = list.slice(keep);
        if (memory) old.forEach(v => memory.versions.delete(v.vid));
        else await tx(['versions'], 'readwrite', t => { old.forEach(v => t.objectStore('versions').delete(v.vid)); });
      }
    },
    /** Version list without the (large) data, newest first */
    async versions(bookId) {
      let all;
      if (memory) all = [...memory.versions.values()].filter(v => v.bookId === bookId);
      else {
        all = await tx(['versions'], 'readonly', t => new Promise((res, rej) => {
          const out = []; const req = t.objectStore('versions').index('bookId').openCursor(bookId);
          req.onsuccess = () => { const c = req.result; if (!c) { res(out); return; } const v = c.value; out.push({ vid: v.vid, bookId: v.bookId, at: v.at, label: v.label, cells: (v.data && v.data.sheets || []).reduce((s, sh) => s + Object.keys(sh.cells || {}).length, 0) }); c.continue(); };
          req.onerror = () => rej(req.error);
        }));
      }
      return all.sort((a, b) => b.at - a.at);
    },
    async getVersion(vid) {
      if (memory) { const v = memory.versions.get(vid); return v ? JSON.parse(JSON.stringify(v)) : null; }
      return tx(['versions'], 'readonly', t => wrap(t.objectStore('versions').get(vid)));
    },
    newId() { return 'b' + Date.now().toString(36) + Math.random().toString(36).slice(2, 8); }
  };

  // small settings store (synchronous, tiny values only)
  const Prefs = {
    get(k, d) { try { const v = localStorage.getItem('isheets_' + k); return v === null ? d : JSON.parse(v); } catch (e) { return d; } },
    set(k, v) { try { localStorage.setItem('isheets_' + k, JSON.stringify(v)); } catch (e) { /* ignore */ } }
  };

  global.IS = global.IS || {};
  global.IS.store = Store;
  global.IS.prefs = Prefs;
})(window);
