/* India Sheets – workbook model: structure, merges, hidden rows, conditional formats, validation, display info */
(function (global) {
  'use strict';
  const IS = global.IS = global.IS || {};
  const X = global.Formula;

  // ---------------------------------------------------------------- event bus
  const listeners = {};
  IS.on = (evt, fn) => { (listeners[evt] = listeners[evt] || []).push(fn); };
  IS.emit = (evt, data) => { (listeners[evt] || []).forEach(fn => { try { fn(data); } catch (e) { console.error('handler for ' + evt, e); } }); };

  const K = (r, c) => r + ':' + c;
  const rid = p => (p || 'x') + Date.now().toString(36).slice(-5) + Math.random().toString(36).slice(2, 7);
  IS.K = K; IS.rid = rid;

  // ---------------------------------------------------------------- structure
  function newSheet(name) {
    return { id: rid('s'), name, cells: {}, rows: 1000, cols: 26, colW: {}, rowH: {}, rowHa: {}, hiddenRows: [], hiddenCols: [], merges: [], freezeR: 0, freezeC: 0, cf: [], dv: [], filter: null, objects: [], showGrid: true, color: null, hidden: false, protect: null, print: {} };
  }
  function newBook(name) {
    return { id: IS.store ? IS.store.newId() : rid('b'), name: name || 'Untitled workbook', created: Date.now(), updated: Date.now(), version: 2, sheets: [newSheet('Sheet1')], active: 0, names: {} };
  }
  const V1_FMT = { number: dp => '#,##0' + (dp === 0 ? '' : '.' + '0'.repeat(dp == null ? 2 : dp)), inr: dp => '"₹"#,##0' + (dp === 0 ? '' : '.' + '0'.repeat(dp == null ? 2 : dp)), pct: dp => '0' + (dp ? '.' + '0'.repeat(dp) : '') + '%', date: () => 'dd-mm-yyyy', longdate: () => 'd mmmm yyyy', text: () => '@' };
  /** Make sure every field exists; upgrade version-1 workbooks. */
  function normalizeBook(b) {
    if (!b || !Array.isArray(b.sheets) || !b.sheets.length) return newBook();
    const v1 = !b.version || b.version < 2;
    b.version = 2;
    b.id = b.id || (IS.store ? IS.store.newId() : rid('b'));
    b.name = b.name || 'Untitled workbook';
    b.created = b.created || Date.now(); b.updated = b.updated || Date.now();
    b.names = b.names || {};
    const seen = new Set();
    b.sheets.forEach((sh, i) => {
      const base = newSheet(sh.name || 'Sheet' + (i + 1));
      for (const k in base) if (sh[k] === undefined) sh[k] = base[k];
      if (!sh.id || seen.has(sh.id)) sh.id = rid('s');
      seen.add(sh.id);
      if (v1) {
        sh.rows = Math.max(sh.rows || 0, 1000);
        if (sh.freeze) { sh.freezeR = 1; delete sh.freeze; }
        for (const k in sh.cells) {
          const cell = sh.cells[k];
          const s = cell.s;
          if (s) {
            if (s.fmt && V1_FMT[s.fmt]) s.nf = V1_FMT[s.fmt](s.dp);
            else if (s.dp !== undefined && s.dp !== null) s.nf = '0' + (s.dp ? '.' + '0'.repeat(s.dp) : '');
            delete s.fmt; delete s.dp;
            if (s.bd === true) s.bd = { bt: 'thin', bb: 'thin', bl: 'thin', br: 'thin' };
            if (!Object.keys(s).length) delete cell.s;
          }
          if (typeof cell.v === 'string' && cell.v !== '' && cell.v[0] !== '=') {
            if (cell.s && cell.s.nf === '@') { cell.t = 's'; continue; }
            if (cell.v[0] === "'") { cell.v = cell.v.slice(1); cell.t = 's'; continue; }
            const p = X.parseInput(cell.v);
            cell.v = p.value === null ? '' : p.value;
            if (p.nf && !(cell.s && cell.s.nf)) cell.s = Object.assign(cell.s || {}, { nf: p.nf });
          }
        }
      }
      if (sh.active !== undefined) delete sh.active;
    });
    b.active = Math.min(Math.max(0, b.active || 0), b.sheets.length - 1);
    if (b.sheets[b.active].hidden) b.active = Math.max(0, b.sheets.findIndex(s => !s.hidden));
    return b;
  }
  IS.newSheet = newSheet; IS.newBook = newBook; IS.normalizeBook = normalizeBook;

  // ---------------------------------------------------------------- hidden rows / cols
  function hiddenSets(sh) {
    if (!Object.prototype.hasOwnProperty.call(sh, '_hs')) Object.defineProperty(sh, '_hs', { value: null, writable: true, enumerable: false, configurable: true });
    if (!sh._hs) {
      const manual = new Set(sh.hiddenRows || []), filt = new Set((sh.filter && sh.filter.hidden) || []);
      sh._hs = { manual, filt, all: new Set([...manual, ...filt]), cols: new Set(sh.hiddenCols || []) };
    }
    return sh._hs;
  }
  IS.invalidateHidden = sh => { if (sh && Object.prototype.hasOwnProperty.call(sh, '_hs')) sh._hs = null; };
  IS.hiddenRowsSet = sh => hiddenSets(sh).all;
  IS.hiddenColsSet = sh => hiddenSets(sh).cols;
  IS.isRowHidden = (sh, r, manualToo) => { const h = hiddenSets(sh); return h.filt.has(r) || (!!manualToo && h.manual.has(r)); };
  IS.rowVisible = (sh, r) => !hiddenSets(sh).all.has(r);
  IS.colVisible = (sh, c) => !hiddenSets(sh).cols.has(c);

  // ---------------------------------------------------------------- merges
  IS.mergeAt = (sh, r, c) => { const ms = sh.merges; if (!ms || !ms.length) return null; for (let i = 0; i < ms.length; i++) { const m = ms[i]; if (r >= m.r && r <= m.r2 && c >= m.c && c <= m.c2) return m; } return null; };
  IS.isCovered = (sh, r, c) => { const m = IS.mergeAt(sh, r, c); return !!m && (m.r !== r || m.c !== c); };
  /** Grow a rectangle until it fully contains every merge it touches. */
  IS.expandRect = (sh, R) => {
    const ms = sh.merges; if (!ms || !ms.length) return R;
    let { t, l, b, r } = R, changed = true;
    while (changed) {
      changed = false;
      for (const m of ms) {
        if (m.r2 < t || m.r > b || m.c2 < l || m.c > r) continue;
        if (m.r < t) { t = m.r; changed = true; } if (m.r2 > b) { b = m.r2; changed = true; }
        if (m.c < l) { l = m.c; changed = true; } if (m.c2 > r) { r = m.c2; changed = true; }
      }
    }
    return { t, l, b, r };
  };

  // ---------------------------------------------------------------- used range
  IS.usedRange = sh => {
    let rows = 0, cols = 0;
    for (const k in sh.cells) { const cell = sh.cells[k]; if (!IS.hasValue(cell) && !cell.s) continue; const i = k.indexOf(':'); const r = +k.slice(0, i), c = +k.slice(i + 1); if (r >= rows) rows = r + 1; if (c >= cols) cols = c + 1; }
    if (IS.calc) { const b = IS.calc.bounds(sh); rows = Math.max(rows, b.rows === 1 && !rows ? 0 : b.rows); cols = Math.max(cols, b.cols === 1 && !cols ? 0 : b.cols); }
    (sh.merges || []).forEach(m => { rows = Math.max(rows, m.r2 + 1); cols = Math.max(cols, m.c2 + 1); });
    return { t: 0, l: 0, b: Math.max(0, rows - 1), r: Math.max(0, cols - 1), empty: rows === 0 };
  };

  // ---------------------------------------------------------------- entering values
  function normalizeFormula(f) {
    let depth = 0, inStr = false;
    for (const ch of f) { if (ch === '"') inStr = !inStr; else if (!inStr) { if (ch === '(') depth++; else if (ch === ')') depth--; } }
    if (inStr) f += '"';
    if (depth > 0) f += ')'.repeat(depth);
    f = f.replace(/("(?:[^"]|"")*")|([^"]+)/g, (m, str, code) => str || code.replace(/([A-Za-z_][A-Za-z0-9_.]*)(\s*\()/g, (a, n, p) => n.toUpperCase() + p));
    return X.transformRefs(f, ref => (ref.kind === 'cell' ? { row: ref.row, col: ref.col } : ref.kind === 'cols' ? { c1: ref.c1, c2: ref.c2 } : { r1: ref.r1, r2: ref.r2 }));
  }
  IS.normalizeFormula = normalizeFormula;
  /** Turn typed text into what is stored in the cell: {v, t?, nf?} */
  IS.parseEntry = (text, cell) => {
    if (text === null || text === undefined || text === '') return { v: null };
    text = String(text);
    if (text[0] === '=' && text.length > 1) return { v: normalizeFormula(text) };
    if (text[0] === "'") return { v: text.slice(1), t: 's' };
    const s = cell && cell.s;
    if (s && s.nf === '@') return { v: text, t: 's' };
    const p = X.parseInput(text);
    if (typeof p.value === 'number' && s && s.nf && /%/.test(s.nf.replace(/"[^"]*"/g, '')) && !/%/.test(text)) p.value = p.value / 100;
    return { v: p.value, nf: p.nf };
  };
  /** The text shown in the editor / formula bar for a cell. */
  IS.editText = (sh, r, c) => {
    const cell = sh.cells[K(r, c)];
    if (!cell || cell.v === undefined || cell.v === null) return '';
    const v = cell.v, nf = (cell.s && cell.s.nf) || '';
    if (typeof v === 'boolean') return v ? 'TRUE' : 'FALSE';
    if (typeof v === 'number') {
      if (X.isDateFormat(nf)) {
        if (X.isTimeOnlyFormat(nf)) return X.formatValue(v, v % 1 && /s/i.test(nf) ? 'hh:mm:ss' : 'hh:mm').text;
        return X.formatValue(v, v % 1 ? 'dd-mm-yyyy hh:mm' : 'dd-mm-yyyy').text;
      }
      if (/%/.test(nf.replace(/"[^"]*"/g, ''))) return String(parseFloat((v * 100).toPrecision(12))) + '%';
      return String(parseFloat(v.toPrecision(15)));
    }
    if (cell.t === 's' && typeof v === 'string' && (v[0] === '=' || typeof X.parseInput(v).value !== 'string')) return "'" + v;
    return String(v);
  };

  // ---------------------------------------------------------------- conditional formatting
  const inRanges = (ranges, r, c) => { for (const g of ranges) if (r >= g.t && r <= g.b && c >= g.l && c <= g.r) return true; return false; };
  IS.inRanges = inRanges;
  let calcEpoch = 0; IS.on('recalc', () => { calcEpoch++; });
  IS.bumpEpoch = () => { calcEpoch++; };
  const statCache = new Map();
  function ruleStats(sh, rule) {
    const key = sh.id + '|' + rule.id;
    let st = statCache.get(key);
    if (st && st.epoch === calcEpoch) return st;
    const nums = [], counts = new Map(); let sum = 0;
    const used = IS.usedRange(sh);
    for (const g of rule.ranges) {
      const b = Math.min(g.b, used.b), rr = Math.min(g.r, used.r);
      for (let r = g.t; r <= b; r++) for (let c = g.l; c <= rr; c++) {
        const v = X.norm(IS.calc.value(sh, r, c));
        if (v === null || v === undefined || v === '') continue;
        if (typeof v === 'number') { nums.push(v); sum += v; }
        const k = typeof v === 'string' ? 's' + v.toLowerCase() : typeof v + String(v);
        counts.set(k, (counts.get(k) || 0) + 1);
      }
    }
    nums.sort((a, b) => a - b);
    st = { epoch: calcEpoch, nums, counts, min: nums.length ? nums[0] : 0, max: nums.length ? nums[nums.length - 1] : 0, avg: nums.length ? sum / nums.length : 0 };
    statCache.set(key, st);
    return st;
  }
  function ruleValue(sh, rule, raw, r, c) {
    if (raw === undefined || raw === null || raw === '') return null;
    if (typeof raw === 'string' && raw[0] === '=') {
      const g = rule.ranges[0];
      const f = X.shiftFormula(raw, r - g.t, c - g.l);
      return X.norm(IS.calc.evalTemp(sh, f, r, c));
    }
    if (typeof raw === 'number') return raw;
    const p = X.parseInput(String(raw)); return p.value;
  }
  function mix(c1, c2, t) {
    const p = h => { const n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; };
    const a = p(c1), b = p(c2);
    return '#' + a.map((x, i) => Math.round(x + (b[i] - x) * t).toString(16).padStart(2, '0')).join('');
  }
  const ICON_SETS = {
    arrows: [{ shape: 'down', color: '#d32f2f' }, { shape: 'right', color: '#f9a825' }, { shape: 'up', color: '#2e7d32' }],
    traffic: [{ shape: 'dot', color: '#d32f2f' }, { shape: 'dot', color: '#f9a825' }, { shape: 'dot', color: '#2e7d32' }],
    reverse: [{ shape: 'up', color: '#d32f2f' }, { shape: 'right', color: '#f9a825' }, { shape: 'down', color: '#2e7d32' }]
  };
  function dateTest(kind, v) {
    if (typeof v !== 'number') return false;
    const t = X.todaySerial(), d = Math.floor(v);
    const today = X.fromSerial(t), dd = X.fromSerial(d);
    const ym = x => x.getUTCFullYear() * 12 + x.getUTCMonth();
    switch (kind) {
      case 'today': return d === t; case 'yesterday': return d === t - 1; case 'tomorrow': return d === t + 1;
      case 'last7': return d <= t && d > t - 7; case 'next7': return d >= t && d < t + 7;
      case 'thisMonth': return ym(dd) === ym(today); case 'lastMonth': return ym(dd) === ym(today) - 1; case 'nextMonth': return ym(dd) === ym(today) + 1;
      case 'thisYear': return dd.getUTCFullYear() === today.getUTCFullYear();
      case 'past': return d < t; case 'future': return d > t;
    }
    return false;
  }
  function evalRule(sh, rule, r, c, v0) {
    const v = X.norm(v0);
    const empty = v === null || v === undefined || v === '';
    switch (rule.type) {
      case 'cell': {
        if (empty && rule.op !== 'eq' && rule.op !== 'neq') return null;
        const a = ruleValue(sh, rule, rule.v1, r, c), b = ruleValue(sh, rule, rule.v2, r, c);
        const cmp = x => X.compare(v, x);
        let ok = false;
        switch (rule.op) {
          case 'gt': ok = cmp(a) > 0; break; case 'lt': ok = cmp(a) < 0; break; case 'gte': ok = cmp(a) >= 0; break; case 'lte': ok = cmp(a) <= 0; break;
          case 'eq': ok = cmp(a) === 0; break; case 'neq': ok = cmp(a) !== 0; break;
          case 'between': ok = cmp(a) >= 0 && cmp(b) <= 0; break; case 'notBetween': ok = cmp(a) < 0 || cmp(b) > 0; break;
        }
        return ok ? rule.style : null;
      }
      case 'text': {
        if (empty) return null;
        const t = String(X.toStr(v)).toLowerCase(), q = String(rule.text || '').toLowerCase();
        const ok = rule.op === 'contains' ? t.includes(q) : rule.op === 'notContains' ? !t.includes(q) : rule.op === 'begins' ? t.startsWith(q) : rule.op === 'ends' ? t.endsWith(q) : t === q;
        return ok ? rule.style : null;
      }
      case 'blank': return empty ? rule.style : null;
      case 'notBlank': return !empty ? rule.style : null;
      case 'error': return X.isErr(v) ? rule.style : null;
      case 'date': return dateTest(rule.op, v) ? rule.style : null;
      case 'dup': case 'unique': {
        if (empty) return null;
        const st = ruleStats(sh, rule); const k = typeof v === 'string' ? 's' + v.toLowerCase() : typeof v + String(v);
        const n = st.counts.get(k) || 0;
        return (rule.type === 'dup' ? n > 1 : n === 1) ? rule.style : null;
      }
      case 'top': case 'bottom': {
        if (typeof v !== 'number') return null;
        const st = ruleStats(sh, rule); if (!st.nums.length) return null;
        let n = rule.n || 10; if (rule.pct) n = Math.max(1, Math.round(st.nums.length * n / 100));
        n = Math.min(n, st.nums.length);
        return rule.type === 'top' ? (v >= st.nums[st.nums.length - n] ? rule.style : null) : (v <= st.nums[n - 1] ? rule.style : null);
      }
      case 'above': case 'below': {
        if (typeof v !== 'number') return null; const st = ruleStats(sh, rule);
        return (rule.type === 'above' ? v > st.avg : v < st.avg) ? rule.style : null;
      }
      case 'formula': {
        if (!rule.formula) return null;
        const res = ruleValue(sh, rule, rule.formula, r, c);
        return res === true || (typeof res === 'number' && res !== 0) ? rule.style : null;
      }
      case 'scale': {
        if (typeof v !== 'number') return null; const st = ruleStats(sh, rule);
        const cols = rule.colors || ['#f8696b', '#ffeb84', '#63be7b'];
        if (st.max === st.min) return { bg: cols[cols.length - 1] };
        const t = (v - st.min) / (st.max - st.min);
        if (cols.length === 3) return { bg: t < 0.5 ? mix(cols[0], cols[1], t * 2) : mix(cols[1], cols[2], (t - 0.5) * 2) };
        return { bg: mix(cols[0], cols[1], t) };
      }
      case 'bar': {
        if (typeof v !== 'number') return null; const st = ruleStats(sh, rule);
        const lo = Math.min(0, st.min), hi = Math.max(0, st.max);
        return { bar: { pct: hi === lo ? 1 : (v - lo) / (hi - lo), color: rule.color || '#4a86e8' } };
      }
      case 'icons': {
        if (typeof v !== 'number') return null; const st = ruleStats(sh, rule);
        const set = ICON_SETS[rule.set || 'arrows']; const t = st.max === st.min ? 1 : (v - st.min) / (st.max - st.min);
        return { icon: set[t >= 0.67 ? 2 : t >= 0.33 ? 1 : 0] };
      }
    }
    return null;
  }
  IS.cfFor = (sh, r, c, v) => {
    const rules = sh.cf; if (!rules || !rules.length) return null;
    let out = null;
    for (const rule of rules) {
      if (!inRanges(rule.ranges, r, c)) continue;
      let res; try { res = evalRule(sh, rule, r, c, v); } catch (e) { res = null; }
      if (!res) continue;
      out = out || {};
      for (const k of ['bg', 'color', 'b', 'i', 'u', 'st']) if (res[k] !== undefined && res[k] !== null && out[k] === undefined) out[k] = res[k];
      if (res.bar && !out.bar) out.bar = res.bar;
      if (res.icon && !out.icon) out.icon = res.icon;
      if (rule.stop) break;
    }
    return out;
  };
  IS.cfInvalidate = () => { statCache.clear(); calcEpoch++; };

  // ---------------------------------------------------------------- data validation
  IS.dvFor = (sh, r, c) => { const rules = sh.dv; if (!rules || !rules.length) return null; for (const rule of rules) if (inRanges(rule.ranges, r, c)) return rule; return null; };
  IS.dvItems = (sh, rule) => {
    if (rule.type === 'list') return (rule.list || []).slice();
    if (rule.type === 'range' && rule.src) {
      const v = IS.calc.evalTempRange(sh, '=' + rule.src, rule.ranges[0].t, rule.ranges[0].l);
      const seen = new Set(), out = [];
      (X.isRange(v) ? v.flat() : [v]).forEach(x => { x = X.norm(x); if (x === null || x === undefined || x === '' || X.isErr(x)) return; const k = String(x).toLowerCase(); if (seen.has(k)) return; seen.add(k); out.push(x); });
      return out;
    }
    return [];
  };
  const OPS = { between: (x, a, b) => x >= a && x <= b, notBetween: (x, a, b) => x < a || x > b, eq: (x, a) => x === a, neq: (x, a) => x !== a, gt: (x, a) => x > a, lt: (x, a) => x < a, gte: (x, a) => x >= a, lte: (x, a) => x <= a };
  const numOf = raw => { if (typeof raw === 'number') return raw; const p = X.parseInput(String(raw == null ? '' : raw)); return typeof p.value === 'number' ? p.value : NaN; };
  /** true when value v is allowed by the rule */
  IS.dvCheck = (sh, rule, v, r, c) => {
    v = X.norm(v);
    const empty = v === null || v === undefined || v === '';
    if (empty) return rule.allowBlank !== false || rule.type === 'checkbox';
    const F = X.F;
    switch (rule.type) {
      case 'list': case 'range': { const items = IS.dvItems(sh, rule).map(x => String(x).toLowerCase()); return items.includes(String(X.toStr(v)).toLowerCase()); }
      case 'number': case 'decimal': case 'whole': case 'date': {
        if (typeof v !== 'number') return false;
        if (rule.type === 'whole' && !Number.isInteger(v)) return false;
        const fn = OPS[rule.op || 'between']; if (!fn) return true;
        return fn(v, numOf(rule.v1), numOf(rule.v2));
      }
      case 'textlen': { const n = String(X.toStr(v)).length; const fn = OPS[rule.op || 'lte']; return fn(n, numOf(rule.v1), numOf(rule.v2)); }
      case 'checkbox': return typeof v === 'boolean';
      case 'gstin': return F.ISGSTIN([v]) === true;
      case 'pan': return F.ISPAN([v]) === true;
      case 'mobile': return F.ISMOBILE([v]) === true;
      case 'pincode': return F.ISPINCODE([v]) === true;
      case 'ifsc': return F.ISIFSC([v]) === true;
      case 'aadhaar': return F.ISAADHAAR([v]) === true;
      case 'email': return /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(String(v));
      case 'custom': {
        if (!rule.formula) return true;
        const g = rule.ranges[0]; const f = X.shiftFormula(rule.formula, r - g.t, c - g.l);
        const res = X.norm(IS.calc.evalTemp(sh, f, r, c));
        return res === true || (typeof res === 'number' && res !== 0);
      }
    }
    return true;
  };
  IS.dvMessage = rule => {
    if (rule.msg) return rule.msg;
    const n = { list: 'Choose a value from the list.', range: 'Choose a value from the list.', number: 'Enter a number', decimal: 'Enter a number', whole: 'Enter a whole number', date: 'Enter a date', textlen: 'Text length', checkbox: 'Tick or untick the box.', gstin: 'Enter a valid 15-character GSTIN.', pan: 'Enter a valid PAN (e.g. ABCPE1234F).', mobile: 'Enter a valid 10-digit Indian mobile number.', pincode: 'Enter a valid 6-digit PIN code.', ifsc: 'Enter a valid IFSC code (e.g. SBIN0001234).', aadhaar: 'Enter a valid 12-digit Aadhaar number.', email: 'Enter a valid email address.', custom: 'This value is not allowed here.' }[rule.type] || 'Invalid value.';
    if (['number', 'decimal', 'whole', 'date', 'textlen'].includes(rule.type)) {
      const op = { between: 'between ' + rule.v1 + ' and ' + rule.v2, notBetween: 'not between ' + rule.v1 + ' and ' + rule.v2, eq: 'equal to ' + rule.v1, neq: 'not equal to ' + rule.v1, gt: 'greater than ' + rule.v1, lt: 'less than ' + rule.v1, gte: 'at least ' + rule.v1, lte: 'at most ' + rule.v1 }[rule.op || 'between'];
      return n + ' ' + op + (rule.type === 'textlen' ? ' characters.' : '.');
    }
    return n;
  };

  // ---------------------------------------------------------------- display info for the renderer
  const EMPTY_STYLE = Object.freeze({});
  IS.cellSource = function (sh) {
    const memo = new Map();
    const calc = IS.calc;
    const showF = IS.state && IS.state.showFormulas;
    const filt = sh.filter;
    const src = {
      merges: sh.merges || [],
      mergeAt: (r, c) => IS.mergeAt(sh, r, c),
      covered: (r, c) => { if (!sh.merges || !sh.merges.length) return false; return IS.isCovered(sh, r, c); },
      hasContent: (r, c) => { const cell = sh.cells[K(r, c)]; if (IS.hasValue(cell)) return true; const v = calc.value(sh, r, c); return v !== null && v !== undefined && v !== ''; },
      bgOf: (r, c) => { const i = src.info(r, c); return i ? i.bg : null; },
      info(r, c) {
        const k = K(r, c);
        if (memo.has(k)) return memo.get(k);
        const cell = sh.cells[k];
        const hasVal = IS.hasValue(cell);
        let v = calc.value(sh, r, c);
        const spilled = !hasVal && v !== null && v !== undefined;
        const cf = sh.cf && sh.cf.length ? IS.cfFor(sh, r, c, v) : null;
        const dv = sh.dv && sh.dv.length ? IS.dvFor(sh, r, c) : null;
        const fb = filt && r === filt.t && c >= filt.l && c <= filt.r;
        if (!cell && !spilled && !cf && !dv && !fb) { memo.set(k, null); return null; }
        let s = (cell && cell.s) || EMPTY_STYLE;
        if (cf && (cf.b !== undefined || cf.i !== undefined || cf.u !== undefined || cf.st !== undefined)) s = Object.assign({}, s, cf.b !== undefined ? { b: cf.b } : null, cf.i !== undefined ? { i: cf.i } : null, cf.u !== undefined ? { u: cf.u } : null, cf.st !== undefined ? { st: cf.st } : null);
        const o = { s, value: v, nf: s.nf, bg: (cf && cf.bg) || s.bg || null, text: '', kind: 'empty' };
        if (hasVal || spilled) {
          if (showF && hasVal && IS.isFormulaCell(cell)) { o.text = cell.v; o.kind = 'text'; o.formula = true; }
          else if (X.isErr(v)) { o.text = v.code; o.kind = 'err'; }
          else if (X.isRich(v)) { o.rich = v; o.text = v.text; o.kind = v.kind === 'link' ? 'text' : 'rich'; if (v.kind === 'link') o.link = v.data.url; }
          else if (v !== null && v !== undefined) {
            const f = X.formatValue(v, s.nf);
            o.text = f.text; if (f.color) o.color = f.color;
            o.kind = typeof v === 'number' ? 'num' : typeof v === 'boolean' ? 'bool' : 'text';
            if (cell && cell.t === 's') o.kind = 'text';
          }
        }
        if (s.link) o.link = s.link;
        if (cf) { if (cf.color) o.color = cf.color; if (cf.bar) o.bar = cf.bar; if (cf.icon) o.icon = cf.icon; }
        if (dv) {
          if (dv.type === 'checkbox') o.checkbox = true;
          else if ((dv.type === 'list' || dv.type === 'range') && dv.arrow !== false) o.arrow = true;
          if ((hasVal || spilled) && dv.strict === false && !IS.dvCheck(sh, dv, v, r, c)) o.invalid = true;
        }
        if (s.cb) o.checkbox = true;
        if (cell && cell.n) o.note = true;
        if (fb) o.filterBtn = { active: !!(filt.crit && filt.crit[c]) };
        memo.set(k, o);
        return o;
      }
    };
    return src;
  };

  // ---------------------------------------------------------------- style helpers
  IS.cleanStyle = s => { if (!s) return undefined; const o = {}; for (const k in s) { const v = s[k]; if (v === undefined || v === null || v === false || v === '') continue; if (k === 'bd' && (!v || !Object.keys(v).some(x => x !== 'c' && v[x]))) continue; o[k] = v; } return Object.keys(o).length ? o : undefined; };
  IS.cloneCell = cell => (cell ? JSON.parse(JSON.stringify(cell)) : null);
})(window);
