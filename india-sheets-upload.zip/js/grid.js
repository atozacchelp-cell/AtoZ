/* India Sheets – canvas grid renderer.
 * Draws only what is visible, so sheets with a million rows stay fast.
 * The same cell painter is used for printing and PDF export.
 */
(function (global) {
  'use strict';
  const IS = global.IS = global.IS || {};
  const X = global.Formula;
  const DEF_W = 100, DEF_H = 24, HEAD_H = 24, MAXPX = 30000000;
  const FONT = '"Segoe UI", "Nirmala UI", system-ui, -apple-system, Roboto, "Noto Sans", Arial, sans-serif';
  const PT = 4 / 3;
  const MAX_ROWS = 1048576, MAX_COLS = 16384;

  const LIGHT = { gridBg: '#ffffff', gridLine: '#e2e5e3', headBg: '#f3f5f4', headText: '#5f6b65', headLine: '#d5dbd8', headSel: '#d5eadc', headSelText: '#0a5c2d', headSelStrong: '#0f7a3d',
    selFill: 'rgba(15,122,61,0.10)', selBorder: '#0f7a3d', cellText: '#1c2420', frozenLine: '#b8c3bd', link: '#1565c0', note: '#ef6c00', brand: '#0f7a3d', err: '#c62828', spill: '#1e6fd9' };
  function readTheme() {
    const cs = getComputedStyle(document.documentElement);
    const v = (n, d) => (cs.getPropertyValue(n) || '').trim() || d;
    return { gridBg: v('--grid-bg', LIGHT.gridBg), gridLine: v('--grid-line', LIGHT.gridLine), headBg: v('--head-bg', LIGHT.headBg), headText: v('--head-text', LIGHT.headText),
      headLine: v('--head-line', LIGHT.headLine), headSel: v('--head-sel', LIGHT.headSel), headSelText: v('--head-sel-text', LIGHT.headSelText), headSelStrong: v('--brand', LIGHT.headSelStrong),
      selFill: v('--sel-fill', LIGHT.selFill), selBorder: v('--sel-border', LIGHT.selBorder), cellText: v('--cell-text', LIGHT.cellText), frozenLine: v('--frozen-line', LIGHT.frozenLine),
      link: v('--link', LIGHT.link), note: '#ef6c00', brand: v('--brand', LIGHT.brand), err: '#d32f2f', spill: '#1e6fd9', dark: document.documentElement.dataset.themeResolved === 'dark' };
  }

  // ------------------------------------------------------------ measuring helpers
  const measureCanvas = document.createElement('canvas').getContext('2d');
  const widthCache = new Map();
  function textWidth(g, font, text) {
    const k = font + '\u0001' + text;
    let w = widthCache.get(k);
    if (w === undefined) { g.font = font; w = g.measureText(text).width; if (widthCache.size > 20000) widthCache.clear(); widthCache.set(k, w); }
    return w;
  }
  const wrapCache = new Map();
  function wrapLines(g, font, text, maxW) {
    const k = font + '\u0001' + maxW + '\u0001' + text;
    let lines = wrapCache.get(k);
    if (lines) return lines;
    g.font = font; lines = [];
    for (const para of String(text).split('\n')) {
      const words = para.split(/(\s+)/); let line = '';
      for (const w of words) {
        const test = line + w;
        if (g.measureText(test).width <= maxW || !line) {
          if (g.measureText(test).width > maxW && !line) {
            // very long word – break by characters
            let part = '';
            for (const ch of w) { if (g.measureText(part + ch).width > maxW && part) { lines.push(part); part = ch; } else part += ch; }
            line = part;
          } else line = test;
        } else { lines.push(line.trimEnd()); line = w.trimStart(); }
      }
      lines.push(line.trimEnd());
    }
    if (wrapCache.size > 5000) wrapCache.clear();
    wrapCache.set(k, lines);
    return lines;
  }
  function fontOf(s, z) {
    const px = ((s && s.fs) || 10) * PT * z;
    return (s && s.i ? 'italic ' : '') + (s && s.b ? 'bold ' : '') + px.toFixed(2) + 'px ' + (s && s.ff ? '"' + s.ff + '", ' + FONT : FONT);
  }
  function lighten(hex, t) {
    const m = /^#?([0-9a-f]{6})$/i.exec(hex || ''); if (!m) return hex;
    const n = parseInt(m[1], 16); const ch = [(n >> 16) & 255, (n >> 8) & 255, n & 255].map(v => Math.round(v + (255 - v) * t));
    return '#' + ch.map(v => v.toString(16).padStart(2, '0')).join('');
  }
  function lum(hex) {
    const m = /^#?([0-9a-f]{6})$/i.exec(hex || ''); if (!m) return 1;
    const n = parseInt(m[1], 16); const r = (n >> 16) & 255, g = (n >> 8) & 255, b = n & 255;
    return (0.299 * r + 0.587 * g + 0.114 * b) / 255;
  }

  // ------------------------------------------------------------ rich content (QR, sparkline, images)
  const qrCache = new Map();
  function qrMatrix(text) {
    let m = qrCache.get(text);
    if (m) return m;
    if (!global.qrcode) return null;
    try {
      if (global.qrcode.stringToBytesFuncs && global.qrcode.stringToBytesFuncs['UTF-8']) global.qrcode.stringToBytes = global.qrcode.stringToBytesFuncs['UTF-8'];
      const q = global.qrcode(0, 'M'); q.addData(text, 'Byte'); q.make();
      const n = q.getModuleCount(); m = { n, dark: [] };
      for (let r = 0; r < n; r++) { const row = []; for (let c = 0; c < n; c++) row.push(q.isDark(r, c)); m.dark.push(row); }
    } catch (e) { m = { error: true }; }
    if (qrCache.size > 200) qrCache.clear();
    qrCache.set(text, m);
    return m;
  }
  function drawQR(g, text, x, y, w, h, dark) {
    const m = qrMatrix(text); if (!m || m.error) return;
    const size = Math.max(0, Math.min(w, h) - 4); if (size < 10) return;
    const quiet = 2, cell = size / (m.n + quiet * 2);
    const ox = x + (w - size) / 2, oy = y + (h - size) / 2;
    g.fillStyle = '#ffffff'; g.fillRect(ox, oy, size, size);
    g.fillStyle = '#000000';
    for (let r = 0; r < m.n; r++) for (let c = 0; c < m.n; c++) if (m.dark[r][c]) g.fillRect(ox + (c + quiet) * cell, oy + (r + quiet) * cell, Math.ceil(cell * 100) / 100 + 0.3, Math.ceil(cell * 100) / 100 + 0.3);
  }
  function drawSpark(g, d, x, y, w, h, th) {
    const vals = (d.values || []).map(v => (typeof v === 'number' ? v : null)); const nums = vals.filter(v => v !== null);
    if (!nums.length) return;
    const pad = 3, X0 = x + pad, Y0 = y + pad, W = w - pad * 2, H = h - pad * 2;
    let lo = d.min != null && !isNaN(d.min) ? d.min : Math.min(...nums), hi = d.max != null && !isNaN(d.max) ? d.max : Math.max(...nums);
    const color = d.color || th.brand, neg = d.negColor || '#d32f2f';
    if (d.type === 'column' || d.type === 'winloss') {
      if (d.type === 'winloss') { lo = -1; hi = 1; }
      if (lo > 0) lo = 0; if (hi < 0) hi = 0; if (hi === lo) hi = lo + 1;
      const n = vals.length, bw = W / n, zeroY = Y0 + H * (hi / (hi - lo));
      vals.forEach((v, i) => {
        if (v === null) return;
        const val = d.type === 'winloss' ? Math.sign(v) : v;
        const top = Y0 + H * ((hi - Math.max(val, 0)) / (hi - lo)), bot = Y0 + H * ((hi - Math.min(val, 0)) / (hi - lo));
        g.fillStyle = val < 0 ? neg : color; g.fillRect(X0 + i * bw + bw * 0.12, Math.min(top, zeroY), bw * 0.76, Math.max(1, bot - top));
      });
      return;
    }
    if (d.type === 'bar') { const v = nums[0], max = d.max != null && !isNaN(d.max) ? d.max : Math.max(...nums, 1); g.fillStyle = color; g.fillRect(X0, Y0 + H * 0.2, Math.max(0, Math.min(1, v / max)) * W, H * 0.6); return; }
    if (hi === lo) { hi = lo + 1; }
    g.strokeStyle = color; g.lineWidth = 1.6; g.lineJoin = 'round'; g.beginPath();
    let started = false;
    vals.forEach((v, i) => { if (v === null) return; const px = X0 + (vals.length === 1 ? W / 2 : (i / (vals.length - 1)) * W), py = Y0 + H - ((v - lo) / (hi - lo)) * H; if (!started) { g.moveTo(px, py); started = true; } else g.lineTo(px, py); });
    g.stroke();
  }
  const imgCache = new Map();
  function getImage(url) {
    let e = imgCache.get(url);
    if (!e) {
      e = { img: new Image(), ok: false, err: false };
      e.img.onload = () => { e.ok = true; IS.grid && IS.grid.invalidate(); };
      e.img.onerror = () => { e.err = true; };
      e.img.src = url; imgCache.set(url, e);
    }
    return e;
  }

  // ------------------------------------------------------------ the shared cell painter
  /**
   * P = { src, rows:[{r,y,h}], cols:[{c,x,w}], z, grid, theme, colX(c), cw(c), rowY(r), rh(r), maxCol, clip:{x,y,w,h}, print }
   * src = IS.cellSource(sheet) (info(r,c), merges list, covered(r,c), mergeAt(r,c))
   */
  function paintCells(g, P) {
    const { src, rows, cols, z, theme: th } = P;
    if (!rows.length || !cols.length) return;
    const first = cols[0], last = cols[cols.length - 1];
    const x0 = first.x, x1 = last.x + last.w, y0 = rows[0].y, y1 = rows[rows.length - 1].y + rows[rows.length - 1].h;
    const pad = Math.max(2, 4 * z);
    // 1. grid lines
    if (P.grid) {
      g.beginPath(); g.strokeStyle = th.gridLine; g.lineWidth = 1;
      for (const C of cols) { if (!C.w) continue; const x = Math.round(C.x + C.w) - 0.5; g.moveTo(x, y0); g.lineTo(x, y1); }
      for (const R of rows) { if (!R.h) continue; const y = Math.round(R.y + R.h) - 0.5; g.moveTo(x0, y); g.lineTo(x1, y); }
      g.stroke();
    }
    // 2. backgrounds (cover grid lines like Excel)
    for (const R of rows) {
      if (!R.h) continue;
      for (const C of cols) {
        if (!C.w || src.covered(R.r, C.c)) continue;
        const info = src.info(R.r, C.c); if (!info) continue;
        const bg = info.bg;
        if (bg) { g.fillStyle = bg; g.fillRect(C.x, R.y, C.w, R.h); }
      }
    }
    // 3. merged blocks
    const r0 = rows[0].r, r1 = rows[rows.length - 1].r, c0 = first.c, c1 = last.c;
    const merges = src.merges.filter(m => m.r2 >= r0 && m.r <= r1 && m.c2 >= c0 && m.c <= c1);
    for (const m of merges) {
      const rx = P.colX(m.c), ry = P.rowY(m.r);
      const rw = P.colX(m.c2) + P.cw(m.c2) - rx, rh = P.rowY(m.r2) + P.rh(m.r2) - ry;
      const info = src.info(m.r, m.c);
      g.fillStyle = (info && info.bg) || th.gridBg;
      g.fillRect(rx, ry, rw - (P.grid ? 1 : 0), rh - (P.grid ? 1 : 0));
    }
    // 4. content
    const firstIdx = first.c;
    for (const R of rows) {
      if (!R.h) continue;
      // cells left of the visible area whose text may overflow into view
      for (let c = Math.max(P.minCol || 0, firstIdx - 12); c < firstIdx; c++) {
        const w = P.cw(c); if (!w || src.covered(R.r, c) || src.mergeAt(R.r, c)) continue;
        const info = src.info(R.r, c);
        if (info && info.text && info.kind === 'text' && !info.s.wrap) drawContent(g, info, P.colX(c), R.y, w, R.h, R.r, c, P, pad, true);
      }
      for (const C of cols) {
        if (!C.w || src.covered(R.r, C.c)) continue;
        const m = src.mergeAt(R.r, C.c);
        const info = src.info(R.r, C.c);
        if (!info) continue;
        if (m) {
          const rx = P.colX(m.c), ry = P.rowY(m.r);
          drawContent(g, info, rx, ry, P.colX(m.c2) + P.cw(m.c2) - rx, P.rowY(m.r2) + P.rh(m.r2) - ry, R.r, C.c, P, pad, false, true);
        } else drawContent(g, info, C.x, R.y, C.w, R.h, R.r, C.c, P, pad, false);
      }
    }
    // 5. borders
    for (const R of rows) {
      if (!R.h) continue;
      for (const C of cols) {
        if (!C.w || src.covered(R.r, C.c)) continue;
        const info = src.info(R.r, C.c); if (!info || !info.s.bd) continue;
        const m = src.mergeAt(R.r, C.c);
        let x = C.x, y = R.y, w = C.w, h = R.h;
        if (m) { x = P.colX(m.c); y = P.rowY(m.r); w = P.colX(m.c2) + P.cw(m.c2) - x; h = P.rowY(m.r2) + P.rh(m.r2) - y; }
        drawBorders(g, info.s, x, y, w, h, z);
      }
    }
    // 6. decorations (notes, dropdown arrows, filter buttons, invalid marks)
    if (!P.print) {
      for (const R of rows) {
        if (!R.h) continue;
        for (const C of cols) {
          if (!C.w || src.covered(R.r, C.c)) continue;
          const info = src.info(R.r, C.c); if (!info) continue;
          const m = src.mergeAt(R.r, C.c);
          let x = C.x, y = R.y, w = C.w, h = R.h;
          if (m) { x = P.colX(m.c); y = P.rowY(m.r); w = P.colX(m.c2) + P.cw(m.c2) - x; h = P.rowY(m.r2) + P.rh(m.r2) - y; }
          if (info.note) { g.fillStyle = th.note; g.beginPath(); g.moveTo(x + w - 7 * z, y + 1); g.lineTo(x + w - 1, y + 1); g.lineTo(x + w - 1, y + 7 * z); g.closePath(); g.fill(); }
          if (info.invalid) { g.fillStyle = th.err; g.beginPath(); g.moveTo(x + 1, y + 1); g.lineTo(x + 7 * z, y + 1); g.lineTo(x + 1, y + 7 * z); g.closePath(); g.fill(); }
          if (info.arrow) {
            const ax = x + w - 12 * z, ay = y + h / 2;
            g.fillStyle = th.headText; g.beginPath(); g.moveTo(ax - 3.5 * z, ay - 2 * z); g.lineTo(ax + 3.5 * z, ay - 2 * z); g.lineTo(ax, ay + 2.5 * z); g.closePath(); g.fill();
          }
          if (info.filterBtn) {
            const bs = Math.min(16 * z, h - 4), bx = x + w - bs - 2, by = y + (h - bs) / 2;
            g.fillStyle = info.filterBtn.active ? th.brand : th.gridBg; g.strokeStyle = info.filterBtn.active ? th.brand : th.headLine;
            g.fillRect(bx, by, bs, bs); g.lineWidth = 1; g.strokeRect(bx + 0.5, by + 0.5, bs - 1, bs - 1);
            g.fillStyle = info.filterBtn.active ? '#fff' : th.headText;
            g.beginPath(); g.moveTo(bx + bs * 0.25, by + bs * 0.35); g.lineTo(bx + bs * 0.75, by + bs * 0.35); g.lineTo(bx + bs * 0.5, by + bs * 0.68); g.closePath(); g.fill();
          }
        }
      }
    }
  }

  function drawBorders(g, s, x, y, w, h, z) {
    const sides = [['bt', x, y, x + w, y], ['bb', x, y + h, x + w, y + h], ['bl', x, y, x, y + h], ['br', x + w, y, x + w, y + h]];
    for (const [k, ax, ay, bx, by] of sides) {
      const st = s.bd[k]; if (!st) continue;
      g.strokeStyle = s.bd.c || '#000000';
      const lw = st === 'thick' ? 3 : st === 'medium' ? 2 : 1;
      g.lineWidth = lw; g.setLineDash(st === 'dashed' ? [4, 3] : st === 'dotted' ? [1, 2] : []);
      const off = lw % 2 ? 0.5 : 0;
      const horiz = ay === by;
      g.beginPath();
      if (st === 'double') {
        g.lineWidth = 1;
        if (horiz) { g.moveTo(ax, Math.round(ay) - 1.5); g.lineTo(bx, Math.round(by) - 1.5); g.moveTo(ax, Math.round(ay) + 0.5); g.lineTo(bx, Math.round(by) + 0.5); }
        else { g.moveTo(Math.round(ax) - 1.5, ay); g.lineTo(Math.round(bx) - 1.5, by); g.moveTo(Math.round(ax) + 0.5, ay); g.lineTo(Math.round(bx) + 0.5, by); }
      } else if (horiz) { const yy = Math.round(ay) - (k === 'bb' ? 1 : 0) + off; g.moveTo(ax - (k === 'bb' || k === 'bt' ? 0.5 : 0), yy); g.lineTo(bx, yy); }
      else { const xx = Math.round(ax) - (k === 'br' ? 1 : 0) + off; g.moveTo(xx, ay - 0.5); g.lineTo(xx, by); }
      g.stroke();
    }
    g.setLineDash([]);
  }

  function drawContent(g, info, x, y, w, h, r, c, P, pad, overflowOnly, merged) {
    const { z, theme: th, src } = P;
    const s = info.s;
    // conditional-format data bar & icons (behind text)
    let iconW = 0;
    if (info.bar && !overflowOnly) {
      const b = info.bar; const bw = Math.max(0, Math.min(1, b.pct)) * (w - 4);
      g.globalAlpha = 0.45; g.fillStyle = b.color; g.fillRect(x + 2, y + 3, bw, h - 6); g.globalAlpha = 1;
    }
    if (info.icon && !overflowOnly) {
      const ic = info.icon, cx = x + 4 * z + 6 * z, cy = y + h / 2; g.fillStyle = ic.color; g.beginPath();
      if (ic.shape === 'up') { g.moveTo(cx, cy - 5 * z); g.lineTo(cx + 5 * z, cy + 4 * z); g.lineTo(cx - 5 * z, cy + 4 * z); }
      else if (ic.shape === 'down') { g.moveTo(cx, cy + 5 * z); g.lineTo(cx + 5 * z, cy - 4 * z); g.lineTo(cx - 5 * z, cy - 4 * z); }
      else if (ic.shape === 'right') { g.moveTo(cx + 5 * z, cy); g.lineTo(cx - 4 * z, cy - 5 * z); g.lineTo(cx - 4 * z, cy + 5 * z); }
      else g.arc(cx, cy, 5 * z, 0, Math.PI * 2);
      g.closePath(); g.fill(); iconW = 16 * z;
    }
    // checkbox
    if (info.checkbox) {
      if (overflowOnly) return;
      const bs = Math.min(14 * z, h - 4), bx = x + (w - bs) / 2, by = y + (h - bs) / 2; const on = info.value === true || info.value === 1 || (typeof info.value === 'string' && info.value.toUpperCase() === 'TRUE');
      g.lineWidth = 1.5; g.strokeStyle = on ? th.brand : th.headText; g.fillStyle = on ? th.brand : 'transparent';
      roundRect(g, bx, by, bs, bs, 2.5 * z); if (on) g.fill(); g.stroke();
      if (on) { g.strokeStyle = '#fff'; g.lineWidth = 2 * z; g.beginPath(); g.moveTo(bx + bs * 0.22, by + bs * 0.52); g.lineTo(bx + bs * 0.42, by + bs * 0.72); g.lineTo(bx + bs * 0.78, by + bs * 0.3); g.stroke(); }
      return;
    }
    // rich content
    const rich = info.rich;
    if (rich && !overflowOnly) {
      if (rich.kind === 'qr') { drawQR(g, rich.data.text, x, y, w, h); return; }
      if (rich.kind === 'spark') { g.save(); g.beginPath(); g.rect(x, y, w, h); g.clip(); drawSpark(g, rich.data, x, y, w, h, th); g.restore(); return; }
      if (rich.kind === 'img') {
        const e = getImage(rich.data.url);
        if (e.ok) { const iw = e.img.naturalWidth, ih = e.img.naturalHeight; const k = Math.min((w - 4) / iw, (h - 4) / ih); const dw = iw * k, dh = ih * k; g.drawImage(e.img, x + (w - dw) / 2, y + (h - dh) / 2, dw, dh); }
        return;
      }
    }
    let text = info.text;
    if (!text) return;
    const font = fontOf(s, z);
    g.font = font;
    let color = info.color || (info.link ? th.link : null) || s.color || null;
    if (!color) color = info.bg && !s.color ? (lum(info.bg) > 0.55 ? '#1c2420' : '#ffffff') : th.cellText;
    else if (th.dark && !info.bg && lum(color) < 0.42) color = lighten(color, 0.62); // dark text on the dark theme
    if (info.kind === 'err') color = th.err;
    const fontPx = ((s.fs || 10) * PT) * z;
    let align = s.al || (info.kind === 'num' ? 'right' : (info.kind === 'bool' || info.kind === 'err') ? 'center' : 'left');
    if (P.showFormulas && info.formula) align = 'left';
    const indent = (s.ind || 0) * 12 * z;
    const rp = (info.arrow ? 15 : 0) * z + (info.filterBtn ? 18 : 0) * z; // keep text clear of dropdown / filter buttons
    const avail = w - pad * 2 - iconW - indent - rp;
    const va = s.va || 'bottom';
    // wrapped / multi-line
    if ((s.wrap || text.indexOf('\n') >= 0) && !overflowOnly) {
      const lines = s.wrap ? wrapLines(g, font, text, Math.max(4, avail)) : text.split('\n');
      const lh = fontPx * 1.28; const total = lines.length * lh;
      let sy = va === 'top' ? y + 3 * z : va === 'middle' ? y + (h - total) / 2 : y + h - total - 3 * z;
      g.save(); g.beginPath(); g.rect(x, y, w, h); g.clip();
      g.fillStyle = color; g.textBaseline = 'middle';
      lines.forEach((ln, i) => {
        const tw = textWidth(g, font, ln);
        const tx = align === 'right' ? x + w - pad - rp - tw : align === 'center' ? x + (w - rp - tw) / 2 : x + pad + iconW + indent;
        const ty = sy + i * lh + lh / 2;
        g.fillText(ln, tx, ty);
        if (s.u || info.link) underline(g, tx, ty + fontPx * 0.45, tw, color, z);
        if (s.st) underline(g, tx, ty, tw, color, z);
      });
      g.restore();
      return;
    }
    let tw = textWidth(g, font, text);
    // numbers that do not fit
    if (info.kind === 'num' && tw > avail && !overflowOnly) {
      if (!info.nf || /^general$/i.test(info.nf)) {
        const cw = textWidth(g, font, '0') || 7;
        const maxLen = Math.max(1, Math.floor(avail / cw));
        const t2 = X.formatValue(info.value, null, maxLen).text;
        text = t2; tw = textWidth(g, font, text);
      }
      if (tw > avail) { const hw = textWidth(g, font, '#') || 7; text = '#'.repeat(Math.max(1, Math.floor(avail / hw))); tw = textWidth(g, font, text); }
    }
    let ty = va === 'top' ? y + 3 * z + fontPx * 0.6 : va === 'middle' ? y + h / 2 : y + h - 3 * z - fontPx * 0.55;
    if (h < fontPx * 1.6) ty = y + h / 2;
    let clipX = x, clipW = w;
    let tx = align === 'right' ? x + w - pad - rp - tw : align === 'center' ? x + (w - rp - tw) / 2 : x + pad + iconW + indent;
    const canOverflow = info.kind === 'text' && !merged && !s.wrap;
    if (tw > avail && canOverflow && !P.noOverflow) {
      // extend into empty neighbours
      if (align === 'left' || align === 'center') {
        let ext = 0, cc = c + 1;
        const need = align === 'center' ? (tw - avail) / 2 : tw - avail;
        while (ext < need && cc <= (P.maxCol != null ? P.maxCol : cc) && cc < c + 40) {
          const nw = P.cw(cc); if (src.hasContent(r, cc) || src.covered(r, cc) || src.mergeAt(r, cc)) break;
          if (nw) { const nb = src.bgOf(r, cc); g.fillStyle = nb || th.gridBg; if (!nb) g.fillRect(x + w + ext - 1, y, nw + 1, h - 1); }
          ext += nw; cc++;
        }
        clipW = w + ext;
      }
      if (align === 'right' || align === 'center') {
        let ext = 0, cc = c - 1;
        const need = align === 'center' ? (tw - avail) / 2 : tw - avail;
        while (ext < need && cc >= 0 && cc > c - 40) {
          const nw = P.cw(cc); if (src.hasContent(r, cc) || src.covered(r, cc) || src.mergeAt(r, cc)) break;
          if (nw) { const nb = src.bgOf(r, cc); if (!nb) { g.fillStyle = th.gridBg; g.fillRect(x - ext - nw, y, nw, h - 1); } }
          ext += nw; cc--;
        }
        clipX = x - ext; clipW += ext;
      }
    } else if (overflowOnly) return;
    if (overflowOnly && clipW === w) return;
    const needClip = tw > clipW - pad * 2 || clipX !== x || clipW !== w || P.clipAll;
    if (needClip) { g.save(); g.beginPath(); g.rect(clipX, y, clipW - 1, h); g.clip(); }
    g.fillStyle = color; g.textBaseline = 'middle';
    g.fillText(text, tx, ty);
    if (s.u || info.link) underline(g, tx, ty + fontPx * 0.45, Math.min(tw, clipW), color, z);
    if (s.st) underline(g, tx, ty, tw, color, z);
    if (needClip) g.restore();
  }
  function underline(g, x, y, w, color, z) { g.fillStyle = color; g.fillRect(x, Math.round(y), w, Math.max(1, Math.round(z))); }
  function roundRect(g, x, y, w, h, r) { g.beginPath(); g.moveTo(x + r, y); g.arcTo(x + w, y, x + w, y + h, r); g.arcTo(x + w, y + h, x, y + h, r); g.arcTo(x, y + h, x, y, r); g.arcTo(x, y, x + w, y, r); g.closePath(); }

  // ------------------------------------------------------------ the on-screen grid
  class Grid {
    constructor(host) {
      this.host = host;
      const el = (t, cls) => { const e = document.createElement(t); e.className = cls; return e; };
      this.canvas = el('canvas', 'grid-canvas');
      this.scroller = el('div', 'grid-scroller'); this.scroller.tabIndex = -1;
      this.spacer = el('div', 'grid-spacer');
      this.layer = el('div', 'grid-layer');
      this.objLayer = el('div', 'grid-objects');
      this.scroller.appendChild(this.spacer);
      host.append(this.canvas, this.scroller, this.objLayer, this.layer);
      this.g = this.canvas.getContext('2d', { alpha: false });
      this.z = 1; this.sheet = null; this.dpr = 1;
      this.W = 0; this.H = 0; this.vw = 0; this.vh = 0; this.hw = 46; this.hh = HEAD_H;
      this.cx = new Float64Array(1); this.ry = new Float64Array(1);
      this.sl = 0; this.st = 0; this.fr = 0; this.fc = 0; this.frozenW = 0; this.frozenH = 0; this.scaleY = 1;
      this.theme = readTheme(); this.pending = false;
      this.scroller.addEventListener('scroll', () => { this.readScroll(); this.invalidate(); IS.emit && IS.emit('scroll'); this.maybeGrow(); }, { passive: true });
      if (global.ResizeObserver) new ResizeObserver(() => this.resize()).observe(host);
      window.addEventListener('resize', () => this.resize());
    }
    refreshTheme() { this.theme = readTheme(); this.invalidate(); }
    setSheet(sh) { this.sheet = sh; this.layout(); this.scroller.scrollTop = 0; this.scroller.scrollLeft = 0; this.readScroll(); this.invalidate(); }
    setZoom(z) {
      const r = this.firstVisibleRow(), c = this.firstVisibleCol();
      this.z = Math.max(0.25, Math.min(4, z)); widthCache.clear(); wrapCache.clear();
      this.layout();
      this.scrollTo(r, c);
    }
    resize() {
      const W = this.host.clientWidth, H = this.host.clientHeight;
      if (!W || !H) return;
      this.dpr = window.devicePixelRatio || 1;
      this.W = W; this.H = H;
      this.canvas.width = Math.round(W * this.dpr); this.canvas.height = Math.round(H * this.dpr);
      this.canvas.style.width = W + 'px'; this.canvas.style.height = H + 'px';
      this.vw = this.scroller.clientWidth || W; this.vh = this.scroller.clientHeight || H;
      this.layer.style.width = this.vw + 'px'; this.layer.style.height = this.vh + 'px';
      this.objLayer.style.left = this.hw + 'px'; this.objLayer.style.top = this.hh + 'px';
      this.objLayer.style.width = Math.max(0, this.vw - this.hw) + 'px'; this.objLayer.style.height = Math.max(0, this.vh - this.hh) + 'px';
      if (this.sheet) this.layout();
      this.draw();
      IS.emit && IS.emit('scroll');
    }
    layout() {
      const sh = this.sheet; if (!sh) return;
      const z = this.z;
      const hc = IS.hiddenColsSet ? IS.hiddenColsSet(sh) : new Set(), hr = IS.hiddenRowsSet ? IS.hiddenRowsSet(sh) : new Set();
      const cols = sh.cols, rows = sh.rows;
      const cx = new Float64Array(cols + 1);
      const cw = sh.colW || {};
      for (let c = 0; c < cols; c++) cx[c + 1] = cx[c] + (hc.has(c) ? 0 : Math.round((cw[c] != null ? cw[c] : DEF_W) * z));
      const ry = new Float64Array(rows + 1);
      const rh = sh.rowH || {}, ra = sh.rowHa || {};
      const dh = Math.round(DEF_H * z);
      const hasHidden = hr.size > 0;
      for (let r = 0; r < rows; r++) {
        let h;
        if (hasHidden && hr.has(r)) h = 0;
        else { const v = rh[r] != null ? rh[r] : ra[r]; h = v == null ? dh : Math.round(v * z); }
        ry[r + 1] = ry[r] + h;
      }
      this.cx = cx; this.ry = ry;
      this.hh = Math.max(16, Math.round(HEAD_H * Math.min(z, 1.6)));
      this.hw = Math.max(36, Math.round((String(rows).length * 7.4 + 18) * Math.min(Math.max(z, 0.8), 1.6)));
      this.fr = Math.min(sh.freezeR || 0, rows); this.fc = Math.min(sh.freezeC || 0, cols);
      this.frozenW = cx[this.fc]; this.frozenH = ry[this.fr];
      const totalW = this.hw + cx[cols], totalH = this.hh + ry[rows];
      this.spacer.style.width = totalW + 'px';
      if (totalH > MAXPX) { this.scaleY = (totalH - this.vh) / (MAXPX - this.vh); this.spacer.style.height = MAXPX + 'px'; }
      else { this.scaleY = 1; this.spacer.style.height = totalH + 'px'; }
      this.objLayer.style.left = this.hw + 'px'; this.objLayer.style.top = this.hh + 'px';
      this.readScroll();
      this.invalidate();
      IS.emit && IS.emit('layout');
    }
    readScroll() { this.sl = this.scroller.scrollLeft; this.st = this.scroller.scrollTop * this.scaleY; }
    maybeGrow() {
      const sh = this.sheet; if (!sh) return;
      let grew = false;
      if (this.st + this.vh > this.hh + this.ry[sh.rows] - 300 && sh.rows < MAX_ROWS) { sh.rows = Math.min(MAX_ROWS, sh.rows + 1000); grew = true; }
      if (this.sl + this.vw > this.hw + this.cx[sh.cols] - 200 && sh.cols < MAX_COLS) { sh.cols = Math.min(MAX_COLS, sh.cols + 26); grew = true; }
      if (grew) { this.layout(); IS.markDirty && IS.markDirty(true); }
    }
    invalidate() { if (this.pending) return; this.pending = true; requestAnimationFrame(() => this.draw()); }

    // ---- geometry
    colX(c) { return c < this.fc ? this.hw + this.cx[c] : this.hw + this.cx[c] - this.sl; }
    rowY(r) { return r < this.fr ? this.hh + this.ry[r] : this.hh + this.ry[r] - this.st; }
    cw(c) { return c < this.cx.length - 1 ? this.cx[c + 1] - this.cx[c] : Math.round(DEF_W * this.z); }
    rh(r) { return r < this.ry.length - 1 ? this.ry[r + 1] - this.ry[r] : Math.round(DEF_H * this.z); }
    colAt(x) { const cx = this.cx, n = cx.length - 1; if (x <= 0) return 0; if (x >= cx[n]) return n - 1; let lo = 0, hi = n - 1; while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (cx[mid] <= x) lo = mid; else hi = mid - 1; } while (lo < n - 1 && cx[lo + 1] - cx[lo] === 0) lo++; return lo; }
    rowAt(y) { const ry = this.ry, n = ry.length - 1; if (y <= 0) return 0; if (y >= ry[n]) return n - 1; let lo = 0, hi = n - 1; while (lo < hi) { const mid = (lo + hi + 1) >> 1; if (ry[mid] <= y) lo = mid; else hi = mid - 1; } while (lo < n - 1 && ry[lo + 1] - ry[lo] === 0) lo++; return lo; }
    colFromX(x) { const rel = x - this.hw; return this.colAt(rel < this.frozenW ? rel : rel + this.sl); }
    rowFromY(y) { const rel = y - this.hh; return this.rowAt(rel < this.frozenH ? rel : rel + this.st); }
    firstVisibleRow() { return this.rowAt(this.frozenH + this.st); }
    firstVisibleCol() { return this.colAt(this.frozenW + this.sl); }
    lastVisibleRow() { return this.rowAt(this.st + this.vh - this.hh - 1); }
    visibleRowCount() { return Math.max(1, this.lastVisibleRow() - this.firstVisibleRow()); }
    prevVisibleCol(c) { for (let i = c - 1; i >= 0; i--) if (this.cw(i) > 0) return i; return -1; }
    prevVisibleRow(r) { for (let i = r - 1; i >= 0; i--) if (this.rh(i) > 0) return i; return -1; }
    hit(x, y) {
      const { hw, hh } = this;
      if (x < 0 || y < 0 || x > this.vw || y > this.vh) return { area: 'none' };
      if (x < hw && y < hh) return { area: 'corner' };
      if (y < hh) {
        const c = this.colFromX(x), left = this.colX(c), right = left + this.cw(c);
        if (Math.abs(x - right) <= 4) return { area: 'colresize', c };
        if (Math.abs(x - left) <= 3) { const p = this.prevVisibleCol(c); if (p >= 0) return { area: 'colresize', c: p }; }
        return { area: 'colhead', c };
      }
      if (x < hw) {
        const r = this.rowFromY(y), top = this.rowY(r), bottom = top + this.rh(r);
        if (Math.abs(y - bottom) <= 3) return { area: 'rowresize', r };
        if (Math.abs(y - top) <= 2) { const p = this.prevVisibleRow(r); if (p >= 0) return { area: 'rowresize', r: p }; }
        return { area: 'rowhead', r };
      }
      return { area: 'cell', r: this.rowFromY(y), c: this.colFromX(x) };
    }
    rectScreen(t, l, b, r) {
      const x = this.colX(l), y = this.rowY(t);
      return { x, y, w: this.colX(r) + this.cw(r) - x, h: this.rowY(b) + this.rh(b) - y };
    }
    cellRect(r, c) {
      const m = IS.mergeAt ? IS.mergeAt(this.sheet, r, c) : null;
      if (m) return this.rectScreen(m.r, m.c, m.r2, m.c2);
      return this.rectScreen(r, c, r, c);
    }
    scrollTo(r, c) {
      if (r != null && r >= this.fr) this.scroller.scrollTop = Math.max(0, (this.ry[Math.min(r, this.ry.length - 1)] - this.frozenH)) / this.scaleY;
      if (c != null && c >= this.fc) this.scroller.scrollLeft = Math.max(0, this.cx[Math.min(c, this.cx.length - 1)] - this.frozenW);
      this.readScroll(); this.invalidate();
    }
    scrollIntoView(r, c) {
      const sh = this.sheet; if (!sh) return;
      if (r >= sh.rows || c >= sh.cols) { if (r >= sh.rows) sh.rows = Math.min(MAX_ROWS, r + 200); if (c >= sh.cols) sh.cols = Math.min(MAX_COLS, c + 10); this.layout(); }
      const viewH = this.vh - this.hh - this.frozenH, viewW = this.vw - this.hw - this.frozenW;
      if (r >= this.fr) {
        const top = this.ry[r] - this.frozenH, bot = this.ry[r + 1] - this.frozenH;
        if (top < this.st) this.scroller.scrollTop = top / this.scaleY;
        else if (bot > this.st + viewH) this.scroller.scrollTop = (bot - viewH) / this.scaleY;
      }
      if (c >= this.fc) {
        const left = this.cx[c] - this.frozenW, right = this.cx[c + 1] - this.frozenW;
        if (left < this.sl) this.scroller.scrollLeft = left;
        else if (right > this.sl + viewW) this.scroller.scrollLeft = right - viewW;
      }
      this.readScroll(); this.invalidate();
    }

    // ---- painting
    rowList(from, to) { const out = []; for (let r = from; r <= to; r++) { const h = this.rh(r); if (h > 0) out.push({ r, y: this.rowY(r), h }); } return out; }
    colList(from, to) { const out = []; for (let c = from; c <= to; c++) { const w = this.cw(c); if (w > 0) out.push({ c, x: this.colX(c), w }); } return out; }
    quadrants() {
      const sh = this.sheet; const q = [];
      const { hw, hh, frozenW, frozenH, vw, vh, fr, fc } = this;
      const sr0 = Math.max(fr, this.rowAt(frozenH + this.st)), sr1 = Math.min(sh.rows - 1, this.rowAt(this.st + vh - hh));
      const sc0 = Math.max(fc, this.colAt(frozenW + this.sl)), sc1 = Math.min(sh.cols - 1, this.colAt(this.sl + vw - hw));
      const fRows = fr ? this.rowList(0, fr - 1) : [], fCols = fc ? this.colList(0, fc - 1) : [];
      const sRows = this.rowList(sr0, sr1), sCols = this.colList(sc0, sc1);
      const add = (rows, cols, clip, minCol) => { if (rows.length && cols.length && clip.w > 0 && clip.h > 0) q.push({ rows, cols, clip, minCol }); };
      add(fRows, fCols, { x: hw, y: hh, w: frozenW, h: frozenH }, 0);
      add(fRows, sCols, { x: hw + frozenW, y: hh, w: vw - hw - frozenW, h: frozenH }, fc);
      add(sRows, fCols, { x: hw, y: hh + frozenH, w: frozenW, h: vh - hh - frozenH }, 0);
      add(sRows, sCols, { x: hw + frozenW, y: hh + frozenH, w: vw - hw - frozenW, h: vh - hh - frozenH }, fc);
      return q;
    }
    draw() {
      this.pending = false;
      const g = this.g, sh = this.sheet, th = this.theme;
      if (!sh || !this.W) return;
      g.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
      g.fillStyle = th.gridBg; g.fillRect(0, 0, this.W, this.H);
      const src = IS.cellSource(sh);
      const self = this;
      const P = {
        src, z: this.z, grid: sh.showGrid !== false, theme: th, showFormulas: !!IS.state.showFormulas,
        colX: c => self.colX(c), cw: c => self.cw(c), rowY: r => self.rowY(r), rh: r => self.rh(r), maxCol: sh.cols - 1
      };
      for (const q of this.quadrants()) {
        g.save(); g.beginPath(); g.rect(q.clip.x, q.clip.y, q.clip.w, q.clip.h); g.clip();
        P.rows = q.rows; P.cols = q.cols; P.minCol = q.minCol;
        paintCells(g, P);
        this.paintOverlay(g, q);
        g.restore();
      }
      this.paintHeaders(g);
      if (this.fr || this.fc) {
        g.fillStyle = th.frozenLine;
        if (this.fr) g.fillRect(0, this.hh + this.frozenH - 1, this.vw, 2);
        if (this.fc) g.fillRect(this.hw + this.frozenW - 1, 0, 2, this.vh);
      }
      IS.emit && IS.emit('drawn');
    }
    paintOverlay(g, q) {
      const th = this.theme, st = IS.state; const sel = st.sel; if (!sel) return;
      const R = IS.selRect();
      // find matches
      if (st.findHits && st.findHits.sheet === this.sheet.id) {
        g.fillStyle = 'rgba(255, 214, 0, 0.35)';
        for (const h of st.findHits.list) { if (h.r < q.rows[0].r - 1 || h.r > q.rows[q.rows.length - 1].r + 1) continue; const rr = this.cellRect(h.r, h.c); g.fillRect(rr.x, rr.y, rr.w, rr.h); }
      }
      // spill outline of the active cell
      const sp = IS.activeSpill && IS.activeSpill();
      if (sp) { const rr = this.rectScreen(sp.t, sp.l, sp.b, sp.r); g.strokeStyle = th.spill; g.lineWidth = 1; g.setLineDash([4, 3]); g.strokeRect(rr.x + 0.5, rr.y + 0.5, rr.w - 2, rr.h - 2); g.setLineDash([]); }
      // formula references while editing
      if (st.refBoxes) for (const b of st.refBoxes) {
        if (b.sheetId && b.sheetId !== this.sheet.id) continue;
        const rr = this.rectScreen(b.t, b.l, Math.min(b.b, this.sheet.rows - 1), Math.min(b.r, this.sheet.cols - 1));
        g.fillStyle = b.color + '22'; g.fillRect(rr.x, rr.y, rr.w, rr.h);
        g.strokeStyle = b.color; g.lineWidth = 2; g.setLineDash(b.dashed ? [5, 3] : []); g.strokeRect(rr.x + 1, rr.y + 1, rr.w - 2, rr.h - 2); g.setLineDash([]);
      }
      const multi = R.t !== R.b || R.l !== R.r;
      const rr = this.rectScreen(R.t, R.l, R.b, R.r);
      if (multi) {
        // shade the selection but leave the active cell clear (like Excel)
        const a = this.cellRect(sel.r, sel.c);
        g.fillStyle = th.selFill;
        g.fillRect(rr.x, rr.y, rr.w, Math.max(0, a.y - rr.y));
        g.fillRect(rr.x, a.y + a.h, rr.w, Math.max(0, rr.y + rr.h - a.y - a.h));
        g.fillRect(rr.x, a.y, Math.max(0, a.x - rr.x), a.h);
        g.fillRect(a.x + a.w, a.y, Math.max(0, rr.x + rr.w - a.x - a.w), a.h);
      }
      // copy marquee
      if (st.clipRect && st.clipRect.sheet === this.sheet.id) {
        const c = st.clipRect, cr = this.rectScreen(c.t, c.l, c.b, c.r);
        g.strokeStyle = th.selBorder; g.lineWidth = 2; g.setLineDash([6, 4]); g.lineDashOffset = -(st.antsOffset || 0); g.strokeRect(cr.x + 1, cr.y + 1, cr.w - 2, cr.h - 2); g.setLineDash([]); g.lineDashOffset = 0;
      }
      if (!st.editing || !st.editing.point) {
        g.strokeStyle = th.selBorder; g.lineWidth = multi ? 1.5 : 2;
        if (multi) g.strokeRect(rr.x + 0.75, rr.y + 0.75, rr.w - 1.5, rr.h - 1.5);
        const a = this.cellRect(sel.r, sel.c);
        g.lineWidth = 2; g.strokeRect(a.x + 1, a.y + 1, a.w - 2, a.h - 2);
        if (!st.editing && !st.readOnly) {
          const hx = rr.x + rr.w - 4, hy = rr.y + rr.h - 4;
          g.fillStyle = th.gridBg; g.fillRect(hx - 1, hy - 1, 8, 8); g.fillStyle = th.selBorder; g.fillRect(hx, hy, 6, 6);
        }
      }
      // fill drag preview
      if (st.fillPreview) { const f = st.fillPreview, fr = this.rectScreen(f.t, f.l, f.b, f.r); g.strokeStyle = th.selBorder; g.lineWidth = 1.5; g.setLineDash([4, 3]); g.strokeRect(fr.x + 1, fr.y + 1, fr.w - 2, fr.h - 2); g.setLineDash([]); }
      // trace arrows / precedents boxes
      if (st.trace && st.trace.sheet === this.sheet.id) for (const b of st.trace.boxes) { const tr = this.rectScreen(b.t, b.l, b.b, b.r); g.strokeStyle = b.color || '#1e6fd9'; g.lineWidth = 2; g.strokeRect(tr.x + 1, tr.y + 1, tr.w - 2, tr.h - 2); }
    }
    paintHeaders(g) {
      const th = this.theme, z = this.z, sh = this.sheet;
      const { hw, hh, vw, vh, fr, fc, frozenW, frozenH } = this;
      const R = IS.selRect();
      const fullCols = R.t === 0 && R.b >= sh.rows - 1, fullRows = R.l === 0 && R.r >= sh.cols - 1;
      const fontPx = Math.max(9, Math.min(15, 11.5 * Math.min(z, 1.3)));
      g.font = fontPx + 'px ' + FONT; g.textBaseline = 'middle'; g.textAlign = 'center';
      // column header
      g.fillStyle = th.headBg; g.fillRect(0, 0, vw, hh);
      const drawCols = (from, to, clipX, clipW) => {
        g.save(); g.beginPath(); g.rect(clipX, 0, clipW, hh); g.clip();
        for (let c = from; c <= to; c++) {
          const w = this.cw(c); if (!w) continue;
          const x = this.colX(c);
          const on = c >= R.l && c <= R.r;
          if (on) { g.fillStyle = th.headSel; g.fillRect(x, 0, w, hh); if (fullCols) { g.fillStyle = th.headSelStrong; g.fillRect(x, 0, w, hh); } g.fillStyle = th.headSelStrong; g.fillRect(x, hh - 2, w, 2); }
          g.fillStyle = on ? (fullCols ? '#ffffff' : th.headSelText) : th.headText;
          if (w > 14) g.fillText(X.numToCol(c), x + w / 2, hh / 2 + 0.5);
          g.fillStyle = th.headLine; g.fillRect(Math.round(x + w) - 1, 0, 1, hh);
          if (c + 1 < sh.cols && this.cw(c + 1) === 0) { g.fillStyle = th.headSelStrong; g.fillRect(Math.round(x + w) - 3, 3, 2, hh - 6); g.fillRect(Math.round(x + w) + 1, 3, 2, hh - 6); }
        }
        g.restore();
      };
      if (fc) drawCols(0, fc - 1, hw, frozenW);
      drawCols(Math.max(fc, this.colAt(frozenW + this.sl)), Math.min(sh.cols - 1, this.colAt(this.sl + vw - hw)), hw + frozenW, vw - hw - frozenW);
      g.fillStyle = th.headLine; g.fillRect(0, hh - 1, vw, 1);
      // row header
      g.fillStyle = th.headBg; g.fillRect(0, hh, hw, vh - hh);
      const drawRows = (from, to, clipY, clipH) => {
        g.save(); g.beginPath(); g.rect(0, clipY, hw, clipH); g.clip();
        for (let r = from; r <= to; r++) {
          const h = this.rh(r); if (!h) continue;
          const y = this.rowY(r);
          const on = r >= R.t && r <= R.b;
          if (on) { g.fillStyle = th.headSel; g.fillRect(0, y, hw, h); if (fullRows) { g.fillStyle = th.headSelStrong; g.fillRect(0, y, hw, h); } g.fillStyle = th.headSelStrong; g.fillRect(hw - 2, y, 2, h); }
          g.fillStyle = on ? (fullRows ? '#ffffff' : th.headSelText) : th.headText;
          if (h > 9) g.fillText(String(r + 1), hw / 2, y + h / 2 + 0.5);
          g.fillStyle = th.headLine; g.fillRect(0, Math.round(y + h) - 1, hw, 1);
          if (r + 1 < sh.rows && this.rh(r + 1) === 0) { g.fillStyle = th.headSelStrong; g.fillRect(3, Math.round(y + h) - 3, hw - 6, 2); g.fillRect(3, Math.round(y + h) + 1, hw - 6, 2); }
        }
        g.restore();
      };
      if (fr) drawRows(0, fr - 1, hh, frozenH);
      drawRows(Math.max(fr, this.rowAt(frozenH + this.st)), Math.min(sh.rows - 1, this.rowAt(this.st + vh - hh)), hh + frozenH, vh - hh - frozenH);
      g.fillStyle = th.headLine; g.fillRect(hw - 1, hh, 1, vh - hh);
      // corner
      g.fillStyle = th.headBg; g.fillRect(0, 0, hw, hh);
      g.fillStyle = th.headLine; g.beginPath(); g.moveTo(hw - 4, hh - 4); g.lineTo(hw - 4, hh - 12); g.lineTo(hw - 12, hh - 4); g.closePath(); g.fill();
      g.fillRect(hw - 1, 0, 1, hh); g.fillRect(0, hh - 1, hw, 1);
      g.textAlign = 'left';
    }
  }

  IS.Grid = Grid;
  IS.GridPaint = { paintCells, fontOf, textWidth, wrapLines, drawQR, qrMatrix, LIGHT, readTheme, DEF_W, DEF_H, PT, FONT, measureCanvas, getImage };
})(window);
