/* India Sheets – formula engine core
 * Parser + evaluator compatible with Excel / Google Sheets syntax,
 * dynamic arrays (spill), number-format engine and Indian input parsing.
 * The function library lives in functions.js.
 */
(function (global) {
  'use strict';

  // ---------------------------------------------------------------- values
  class FErr { constructor(code) { this.code = code; } toString() { return this.code; } }
  const E = {
    DIV0: new FErr('#DIV/0!'), VALUE: new FErr('#VALUE!'), REF: new FErr('#REF!'), NAME: new FErr('#NAME?'),
    NA: new FErr('#N/A'), NUM: new FErr('#NUM!'), NULL: new FErr('#NULL!'), CYCLE: new FErr('#CYCLE!'),
    ERROR: new FErr('#ERROR!'), SPILL: new FErr('#SPILL!'), CALC: new FErr('#CALC!')
  };
  const ERR_BY_CODE = {}; Object.values(E).forEach(e => { ERR_BY_CODE[e.code] = e; });
  const isErr = v => v instanceof FErr;

  /** Rich values: links, images, QR codes, sparklines. They behave like text in other formulas. */
  class Rich { constructor(kind, text, data) { this.kind = kind; this.text = text == null ? '' : String(text); this.data = data || {}; } toString() { return this.text; } }
  const isRich = v => v instanceof Rich;

  class Range {
    constructor(rows, meta) { this.rows = rows; this.meta = meta || null; }
    flat() { const out = []; for (const r of this.rows) for (const v of r) out.push(v); return out; }
    get h() { return this.rows.length; }
    get w() { return this.rows[0] ? this.rows[0].length : 0; }
    at(i, j) { const r = this.rows[i]; return r ? r[j] : undefined; }
  }
  const isRange = v => v instanceof Range;
  const scalar = v => (isRange(v) ? (v.rows[0] && v.rows[0].length ? v.rows[0][0] : null) : v);
  const norm = v => (isRich(v) ? v.text : v);

  /** Signal used by the calc engine to postpone a deep evaluation (never shown to users). */
  class Defer { constructor(key) { this.key = key; this.__defer = true; } }

  const settings = { indian: true, dayFirst: true };

  // ---------------------------------------------------------------- columns / refs
  function colToNum(s) { let n = 0; for (const ch of s.toUpperCase()) n = n * 26 + (ch.charCodeAt(0) - 64); return n - 1; }
  function numToCol(n) { let s = ''; n++; while (n > 0) { const m = (n - 1) % 26; s = String.fromCharCode(65 + m) + s; n = Math.floor((n - 1) / 26); } return s; }
  const unquote = s => (s && s[0] === "'" ? s.slice(1, -1).replace(/''/g, "'") : s);
  const quoteSheet = s => (/^[A-Za-z_][A-Za-z0-9_.]*$/.test(s) && !/^[A-Za-z]{1,3}[0-9]+$/.test(s) && !/^(TRUE|FALSE)$/i.test(s) ? s : "'" + String(s).replace(/'/g, "''") + "'");
  const a1 = (r, c, absR, absC) => (absC ? '$' : '') + numToCol(c) + (absR ? '$' : '') + (r + 1);

  /** Parse "A1", "$B$2", "Sheet1!A1:C9", "A:A", "3:5" → {sheet, r1, c1, r2, c2} (r2/c2 may be Infinity) */
  function parseRef(text) {
    const s = String(text).trim();
    const m = s.match(/^(?:('(?:[^']|'')+'|[^!:'"]+)!)?(.+)$/);
    if (!m) return null;
    const sheet = m[1] ? unquote(m[1]) : null, body = m[2];
    let x = body.match(/^\$?([A-Za-z]{1,3})\$?(\d+)(?::\$?([A-Za-z]{1,3})\$?(\d+))?$/);
    if (x) {
      const r1 = +x[2] - 1, c1 = colToNum(x[1]);
      const r2 = x[3] ? +x[4] - 1 : r1, c2 = x[3] ? colToNum(x[3]) : c1;
      if (r1 < 0 || r2 < 0) return null;
      return { sheet, r1: Math.min(r1, r2), c1: Math.min(c1, c2), r2: Math.max(r1, r2), c2: Math.max(c1, c2) };
    }
    x = body.match(/^\$?([A-Za-z]{1,3}):\$?([A-Za-z]{1,3})$/);
    if (x) { const c1 = colToNum(x[1]), c2 = colToNum(x[2]); return { sheet, r1: 0, c1: Math.min(c1, c2), r2: Infinity, c2: Math.max(c1, c2) }; }
    x = body.match(/^\$?(\d+):\$?(\d+)$/);
    if (x) { const r1 = +x[1] - 1, r2 = +x[2] - 1; return { sheet, r1: Math.min(r1, r2), c1: 0, r2: Math.max(r1, r2), c2: Infinity }; }
    return null;
  }

  // ---------------------------------------------------------------- dates
  const EPOCH = Date.UTC(1899, 11, 30);
  const toSerial = (y, m, d) => (Date.UTC(y, m - 1, d) - EPOCH) / 86400000;
  const fromSerial = s => new Date(EPOCH + Math.floor(s + 1e-9) * 86400000);
  const todaySerial = () => { const n = new Date(); return toSerial(n.getFullYear(), n.getMonth() + 1, n.getDate()); };
  const nowSerial = () => { const n = new Date(); return todaySerial() + (n.getHours() * 3600 + n.getMinutes() * 60 + n.getSeconds()) / 86400; };
  const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const MON_IDX = {}; MONTHS.forEach((m, i) => { MON_IDX[m.toLowerCase()] = i + 1; MON_IDX[m.slice(0, 3).toLowerCase()] = i + 1; }); MON_IDX.sept = 9;
  const daysIn = (y, m) => new Date(Date.UTC(y, m, 0)).getUTCDate();
  const fullYear = y => (y < 100 ? (y < 30 ? 2000 + y : 1900 + y) : y);

  function parseTime(t) {
    let m = t.match(/^(\d{1,2}):(\d{2})(?::(\d{2}(?:\.\d+)?))?\s*([ap]\.?m?\.?)?$/i);
    if (m) {
      let h = +m[1]; const mi = +m[2], s = m[3] ? +m[3] : 0, ap = m[4] ? m[4][0].toLowerCase() : null;
      if (mi > 59 || s >= 60) return null;
      if (ap) { if (h < 1 || h > 12) return null; if (ap === 'p' && h < 12) h += 12; if (ap === 'a' && h === 12) h = 0; }
      if (h > 23 && !ap) return null;
      return { frac: (h * 3600 + mi * 60 + s) / 86400, nf: ap ? 'h:mm AM/PM' : (m[3] ? 'hh:mm:ss' : 'hh:mm') };
    }
    m = t.match(/^(\d{1,2})\s*([ap])\.?m\.?$/i);
    if (m) { let h = +m[1]; if (h < 1 || h > 12) return null; const ap = m[2].toLowerCase(); if (ap === 'p' && h < 12) h += 12; if (ap === 'a' && h === 12) h = 0; return { frac: h / 24, nf: 'h:mm AM/PM' }; }
    return null;
  }
  function makeDate(y, m, d) { if (m < 1 || m > 12 || d < 1 || d > daysIn(y, m) || y < 1900 || y > 9999) return null; return toSerial(y, m, d); }
  /** Parse typed dates/times. Day comes first (Indian style) unless settings.dayFirst is false. */
  function parseDateTime(s) {
    s = s.trim();
    const tm = parseTime(s); if (tm) return { value: tm.frac, nf: tm.nf };
    let datePart = s, timePart = null;
    const sp = s.match(/^(.*?\d)[\sT]+(\d{1,2}:\d{2}.*)$/);
    if (sp) { datePart = sp[1]; timePart = parseTime(sp[2]); if (!timePart) return null; }
    let m, serial = null, nf = 'dd-mm-yyyy';
    if ((m = datePart.match(/^(\d{1,2})([-/.])(\d{1,2})\2(\d{2}|\d{4})$/))) {
      const a = +m[1], b = +m[3], y = fullYear(+m[4]);
      serial = settings.dayFirst ? makeDate(y, b, a) : makeDate(y, a, b);
      nf = m[2] === '/' ? 'dd/mm/yyyy' : m[2] === '.' ? 'dd.mm.yyyy' : 'dd-mm-yyyy';
      if (!settings.dayFirst) nf = 'mm/dd/yyyy';
    } else if ((m = datePart.match(/^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})$/))) {
      serial = makeDate(+m[1], +m[2], +m[3]); nf = 'yyyy-mm-dd';
    } else if ((m = datePart.match(/^(\d{1,2})(?:st|nd|rd|th)?[-\s/]+([A-Za-z]{3,9})\.?(?:[-\s/,]+(\d{2}|\d{4}))?$/))) {
      const mon = MON_IDX[m[2].toLowerCase()]; if (!mon) return null;
      serial = makeDate(m[3] ? fullYear(+m[3]) : new Date().getFullYear(), mon, +m[1]); nf = 'd mmm yyyy';
    } else if ((m = datePart.match(/^([A-Za-z]{3,9})\.?[\s-]+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})$/))) {
      const mon = MON_IDX[m[1].toLowerCase()]; if (!mon) return null;
      serial = makeDate(+m[3], mon, +m[2]); nf = 'd mmm yyyy';
    } else if ((m = datePart.match(/^([A-Za-z]{3,9})[-\s'](\d{2}|\d{4})$/))) {
      const mon = MON_IDX[m[1].toLowerCase()]; if (!mon) return null;
      serial = makeDate(fullYear(+m[2]), mon, 1); nf = 'mmm-yy';
    } else if ((m = datePart.match(/^(\d{1,2})\/(\d{1,2})$/))) {
      const a = +m[1], b = +m[2], y = new Date().getFullYear();
      serial = settings.dayFirst ? makeDate(y, b, a) : makeDate(y, a, b); nf = 'dd-mm-yyyy';
    }
    if (serial === null) return null;
    if (timePart) return { value: serial + timePart.frac, nf: nf + ' ' + (timePart.nf.includes('AM') ? 'h:mm AM/PM' : 'hh:mm') };
    return { value: serial, nf };
  }

  /** Convert what a user typed into a value (+ a suggested number format). */
  function parseInput(raw) {
    const s = String(raw).trim();
    if (s === '') return { value: null };
    if (/^(true|false)$/i.test(s)) return { value: s.toUpperCase() === 'TRUE' };
    if (/^0\d+$/.test(s) || /^\+\d{6,}$/.test(s)) return { value: String(raw) };           // keep leading zeros / phone numbers
    let m = s.match(/^([-+]?)(?:₹|rs\.?|inr)?\s*([\d,]*\.?\d+)\s*(lakhs?|lacs?|crores?|cr|k|thousand)$/i);
    if (m) {
      const n = Number(m[2].replace(/,/g, '')), u = m[3].toLowerCase();
      const mult = /^(lakh|lac)/.test(u) ? 1e5 : /^(crore|cr)/.test(u) ? 1e7 : 1e3;
      return { value: (m[1] === '-' ? -1 : 1) * n * mult, nf: /₹|rs|inr/i.test(s) ? '"₹"#,##0.00' : '#,##0' };
    }
    m = s.match(/^([-+]?)\s*(₹|rs\.?|inr|\$|€|£)?\s*([-+]?)([\d,]*\.?\d+(?:e[-+]?\d+)?)\s*(%?)$/i);
    if (m && /\d/.test(m[4]) && (!m[4].includes(',') || /^\d{1,3}(,\d{2,3})*(\.\d+)?$/.test(m[4]))) {
      const digits = m[4].replace(/,/g, '');
      if (digits.replace(/[^\d]/g, '').length > 15 && !digits.includes('.') && !/e/i.test(digits)) return { value: String(raw) };
      let n = Number(digits); if (isNaN(n)) return { value: String(raw) };
      if (m[1] === '-' || m[3] === '-') n = -n;
      const dec = (digits.split('.')[1] || '').replace(/e.*/i, '').length;
      let nf;
      if (m[2]) {
        const sym = /₹|rs|inr/i.test(m[2]) ? '₹' : m[2];
        nf = '"' + sym + '"#,##0' + (dec ? '.00' : '');
      }
      if (m[5]) { n /= 100; nf = dec ? '0.' + '0'.repeat(Math.min(dec, 4)) + '%' : '0%'; }
      else if (!nf && m[4].includes(',')) nf = '#,##0' + (dec ? '.' + '0'.repeat(Math.min(dec, 4)) : '');
      return { value: n, nf };
    }
    const d = parseDateTime(s); if (d) return d;
    return { value: String(raw) };
  }

  // ---------------------------------------------------------------- number formats
  const COLORS = { black: '#000000', white: '#ffffff', red: '#d32f2f', green: '#2e7d32', blue: '#1565c0', yellow: '#f9a825', magenta: '#ad1457', cyan: '#00838f' };
  function generalNum(n, maxLen) {
    if (!isFinite(n)) return '#NUM!';
    if (Object.is(n, -0)) n = 0;
    const a = Math.abs(n);
    if (Number.isInteger(n) && a < 1e15) return String(n);
    if (a !== 0 && (a < 1e-9 || a >= 1e15)) return n.toExponential(5).replace(/\.?0+e/, 'E').replace('e', 'E');
    let s = String(parseFloat(n.toPrecision(11)));
    if (maxLen && s.length > maxLen) {
      for (let p = 10; p > 1 && s.length > maxLen; p--) s = String(parseFloat(n.toPrecision(p)));
    }
    return s;
  }
  function groupDigits(intStr) {
    if (intStr.length <= 3) return intStr;
    if (settings.indian) {
      const last3 = intStr.slice(-3); let rest = intStr.slice(0, -3); const parts = [];
      while (rest.length > 2) { parts.unshift(rest.slice(-2)); rest = rest.slice(0, -2); }
      if (rest) parts.unshift(rest);
      return parts.join(',') + ',' + last3;
    }
    return intStr.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  }
  function splitSections(code) {
    const out = []; let cur = '', q = false, br = false;
    for (let i = 0; i < code.length; i++) {
      const ch = code[i];
      if (ch === '\\' && !q) { cur += ch + (code[i + 1] || ''); i++; continue; }
      if (ch === '"') q = !q; else if (!q && ch === '[') br = true; else if (!q && ch === ']') br = false;
      if (ch === ';' && !q && !br) { out.push(cur); cur = ''; continue; }
      cur += ch;
    }
    out.push(cur);
    return out;
  }
  function compileSection(src) {
    const S = { color: null, cond: null, toks: [], type: 'lit' };
    const T = S.toks;
    for (let i = 0; i < src.length;) {
      const ch = src[i], rest = src.slice(i);
      if (ch === '"') { const j = src.indexOf('"', i + 1); T.push({ k: 'lit', v: src.slice(i + 1, j < 0 ? src.length : j) }); i = j < 0 ? src.length : j + 1; continue; }
      if (ch === '\\') { T.push({ k: 'lit', v: src[i + 1] || '' }); i += 2; continue; }
      if (ch === '_') { T.push({ k: 'lit', v: ' ' }); i += 2; continue; }
      if (ch === '*') { i += 2; continue; }
      if (ch === '[') {
        const j = src.indexOf(']', i); const tag = src.slice(i + 1, j < 0 ? src.length : j).trim(); i = j < 0 ? src.length : j + 1;
        const tl = tag.toLowerCase();
        if (COLORS[tl]) S.color = COLORS[tl];
        else if (/^color\s*\d+$/i.test(tag)) { /* palette colour – ignore */ }
        else if (/^(<=|>=|<>|<|>|=)/.test(tag)) { const m = tag.match(/^(<=|>=|<>|<|>|=)\s*(-?[\d.]+)/); if (m) S.cond = { op: m[1], v: +m[2] }; }
        else if (tag[0] === '$') { const sym = tag.slice(1).split('-')[0]; if (sym) T.push({ k: 'lit', v: sym }); }
        else if (/^h+$/i.test(tag)) T.push({ k: 'dt', v: 'elapsedh' });
        continue;
      }
      let m;
      if ((m = rest.match(/^general/i))) { T.push({ k: 'gen' }); i += 7; continue; }
      if ((m = rest.match(/^(am\/pm|a\/p)/i))) { T.push({ k: 'dt', v: m[1].length > 3 ? 'ampm' : 'ap' }); i += m[1].length; continue; }
      if ((m = rest.match(/^(y+|m+|d+|h+|s+)/i))) { T.push({ k: 'dt', v: m[1].toLowerCase() }); i += m[1].length; continue; }
      if ((m = rest.match(/^[eE][+-]/))) { T.push({ k: 'exp', v: m[0][1] }); i += 2; continue; }
      if (ch === '0' || ch === '#' || ch === '?') { T.push({ k: 'dig', v: ch }); i++; continue; }
      if (ch === '.') { T.push({ k: 'dot' }); i++; continue; }
      if (ch === ',') { T.push({ k: 'comma' }); i++; continue; }
      if (ch === '%') { T.push({ k: 'pct' }); i++; continue; }
      if (ch === '@') { T.push({ k: 'text' }); i++; continue; }
      T.push({ k: 'lit', v: ch }); i++;
    }
    if (T.some(t => t.k === 'dt')) {
      S.type = 'date';
      // decide month vs minute for "m"/"mm"
      const dts = T.filter(t => t.k === 'dt');
      dts.forEach((t, idx) => {
        if (t.v === 'm' || t.v === 'mm') {
          const prev = dts[idx - 1], next = dts[idx + 1];
          if ((prev && prev.v[0] === 'h') || (next && next.v[0] === 's')) t.v = t.v === 'm' ? 'n' : 'nn';
        }
      });
      S.ampm = T.some(t => t.v === 'ampm' || t.v === 'ap');
      // treat '.' and digits inside date formats as literals
      T.forEach(t => { if (t.k === 'dot') { t.k = 'lit'; t.v = '.'; } else if (t.k === 'dig') { t.k = 'lit'; t.v = t.v === '0' ? '0' : ''; } else if (t.k === 'comma') { t.k = 'lit'; t.v = ','; } });
    } else if (T.some(t => t.k === 'dig')) {
      S.type = 'num';
      const first = T.findIndex(t => t.k === 'dig');
      let lastDig = -1; T.forEach((t, i) => { if (t.k === 'dig') lastDig = i; });
      const dot = T.findIndex((t, i) => t.k === 'dot' && i > first - 1 && i <= lastDig + 1);
      const exp = T.findIndex(t => t.k === 'exp');
      const intEnd = dot >= 0 ? dot : (exp >= 0 ? exp : lastDig + 1);
      S.intToks = T.slice(first, intEnd).filter(t => t.k !== 'comma');
      S.group = T.slice(first, intEnd).some((t, i, arr) => t.k === 'comma' && arr.slice(i + 1).some(x => x.k === 'dig'));
      // trailing commas scale by 1000
      let scale = 0;
      let k = dot >= 0 ? dot + 1 : intEnd; const decToks = [];
      if (dot >= 0) { while (k < T.length && (T[k].k === 'dig' || T[k].k === 'comma')) { if (T[k].k === 'dig') decToks.push(T[k]); else scale++; k++; } }
      else { while (k < T.length && T[k].k === 'comma') { scale++; k++; } }
      S.dec = decToks.length; S.minDec = decToks.filter(t => t.v !== '#').length;
      S.scale = scale; S.pct = T.filter(t => t.k === 'pct').length;
      S.minInt = S.intToks.filter(t => t.k === 'dig' && t.v === '0').length;
      S.prefix = T.slice(0, first).filter(t => t.k === 'lit').map(t => t.v).join('');
      if (exp >= 0) {
        S.exp = { sign: T[exp].v, digits: T.slice(exp + 1).filter(t => t.k === 'dig').length || 1 };
        const afterExp = exp + 1 + T.slice(exp + 1).findIndex(t => t.k !== 'dig');
        S.suffixToks = afterExp > exp ? T.slice(afterExp) : [];
      } else S.suffixToks = T.slice(Math.max(k, lastDig + 1));
      S.suffix = S.suffixToks.map(t => (t.k === 'lit' ? t.v : t.k === 'pct' ? '%' : t.k === 'text' ? '' : '')).join('');
      S.interleave = !S.group && S.intToks.some(t => t.k === 'lit');
    } else if (T.some(t => t.k === 'text')) S.type = 'text';
    else if (T.some(t => t.k === 'gen')) S.type = 'gen';
    return S;
  }
  const fmtCache = new Map();
  function getFmt(code) {
    let f = fmtCache.get(code);
    if (!f) {
      if (!code || /^general$/i.test(code)) f = { general: true };
      else if (code === '[INRSHORT]') f = { short: true };
      else f = { secs: splitSections(code).map(compileSection) };
      if (fmtCache.size > 400) fmtCache.clear();
      fmtCache.set(code, f);
    }
    return f;
  }
  const pad = (n, l = 2) => String(n).padStart(l, '0');
  function renderDate(v, S) {
    if (v < 0 || v > 2958465) return '#####';
    let days = Math.floor(v + 1e-9);
    let secs = Math.round((v - days) * 86400); if (secs >= 86400) { secs -= 86400; days++; }
    const d = fromSerial(days); const Y = d.getUTCFullYear(), M = d.getUTCMonth(), D = d.getUTCDate(), W = d.getUTCDay();
    let h = Math.floor(secs / 3600); const mi = Math.floor((secs % 3600) / 60), s = secs % 60;
    const ampm = h >= 12 ? 'PM' : 'AM';
    let h12 = h % 12; if (h12 === 0) h12 = 12;
    let out = '';
    for (const t of S.toks) {
      if (t.k === 'lit') { out += t.v; continue; }
      if (t.k !== 'dt') { if (t.k === 'pct') out += '%'; continue; }
      switch (t.v) {
        case 'yyyy': case 'yyy': out += Y; break;
        case 'yy': case 'y': out += pad(Y % 100); break;
        case 'mmmmm': out += MONTHS[M][0]; break;
        case 'mmmm': out += MONTHS[M]; break;
        case 'mmm': out += MONTHS[M].slice(0, 3); break;
        case 'mm': out += pad(M + 1); break;
        case 'm': out += M + 1; break;
        case 'dddd': out += DAYS[W]; break;
        case 'ddd': out += DAYS[W].slice(0, 3); break;
        case 'dd': out += pad(D); break;
        case 'd': out += D; break;
        case 'hh': out += pad(S.ampm ? h12 : h); break;
        case 'h': out += S.ampm ? h12 : h; break;
        case 'nn': out += pad(mi); break;
        case 'n': out += mi; break;
        case 'ss': out += pad(s); break;
        case 's': out += s; break;
        case 'ampm': out += ampm; break;
        case 'ap': out += ampm[0]; break;
        case 'elapsedh': out += Math.floor(v * 24); break;
        default: out += t.v.length > 4 && t.v[0] === 'm' ? MONTHS[M] : '';
      }
    }
    return out;
  }
  function roundHalfUp(n, d) { if (d > 15) d = 15; const r = Number(Math.round(Number(n + 'e' + d)) + 'e-' + d); return isNaN(r) ? n : r; }
  function renderNum(v, S, autoMinus) {
    let n = Math.abs(v) * Math.pow(100, S.pct) / Math.pow(1000, S.scale);
    let body;
    if (S.exp) {
      let e = n === 0 ? 0 : Math.floor(Math.log10(n));
      let mant = n / Math.pow(10, e);
      mant = roundHalfUp(mant, S.dec);
      if (mant >= 10) { mant /= 10; e++; }
      let ms = mant.toFixed(S.dec);
      if (S.dec > S.minDec) ms = ms.replace(new RegExp('0{1,' + (S.dec - S.minDec) + '}$'), '').replace(/\.$/, S.minDec ? '.' : '');
      body = ms + 'E' + (e < 0 ? '-' : (S.exp.sign === '+' ? '+' : '')) + pad(Math.abs(e), S.exp.digits);
    } else {
      n = roundHalfUp(n, S.dec);
      let [ip, fp = ''] = n.toFixed(S.dec).split('.');
      if (ip === '0' && S.minInt === 0) ip = '';
      if (ip.length < S.minInt) ip = ip.padStart(S.minInt, '0');
      if (S.dec > S.minDec) fp = fp.replace(new RegExp('0{1,' + (S.dec - S.minDec) + '}$'), '');
      let intOut;
      if (S.interleave) {
        let out = '', di = ip.length - 1;
        for (let k = S.intToks.length - 1; k >= 0; k--) {
          const t = S.intToks[k];
          if (t.k === 'dig') { if (di >= 0) out = ip[di--] + out; else if (t.v === '0') out = '0' + out; else if (t.v === '?') out = ' ' + out; }
          else out = t.v + out;
        }
        if (di >= 0) out = ip.slice(0, di + 1) + out;
        intOut = out;
      } else intOut = S.group ? groupDigits(ip) : ip;
      body = intOut + (S.dec ? (fp.length || S.minDec ? '.' + fp : (S.dec ? '' : '')) : '');
      if (S.dec && !fp.length && !S.minDec) body = intOut;
    }
    return (autoMinus && v < 0 && roundHalfUp(Math.abs(v), 10) !== 0 ? '-' : '') + S.prefix + body + S.suffix;
  }
  function pickSection(F, v) {
    const secs = F.secs;
    if (secs.some(s => s.cond)) {
      for (const s of secs) {
        if (!s.cond) continue;
        const c = s.cond, ok = c.op === '>' ? v > c.v : c.op === '<' ? v < c.v : c.op === '>=' ? v >= c.v : c.op === '<=' ? v <= c.v : c.op === '=' ? v === c.v : v !== c.v;
        if (ok) return { S: s, auto: false };
      }
      const rest = secs.filter(s => !s.cond && s.type !== 'text');
      return { S: rest[0] || secs[secs.length - 1], auto: v < 0 };
    }
    const numSecs = secs.filter((s, i) => i < 3);
    if (v > 0 || numSecs.length === 1) return { S: numSecs[0], auto: true };
    if (v < 0) return numSecs.length >= 2 ? { S: numSecs[1], auto: false } : { S: numSecs[0], auto: true };
    return { S: numSecs.length >= 3 ? numSecs[2] : numSecs[0], auto: false };
  }
  function shortINR(v) {
    const a = Math.abs(v), sign = v < 0 ? '-' : '';
    const f = (x, u) => sign + '₹' + parseFloat(x.toFixed(2)).toLocaleString('en-IN') + u;
    if (a >= 1e7) return f(a / 1e7, ' Cr');
    if (a >= 1e5) return f(a / 1e5, ' L');
    if (a >= 1e3) return f(a / 1e3, ' K');
    return f(a, '');
  }
  /** Format any value with an Excel-style code. Returns {text, color}. */
  function formatValue(v, code, maxLen) {
    if (v === null || v === undefined) return { text: '' };
    if (isErr(v)) return { text: v.code, color: null };
    if (isRich(v)) return { text: v.text };
    if (typeof v === 'boolean') return { text: v ? 'TRUE' : 'FALSE' };
    const F = getFmt(code);
    if (typeof v === 'string') {
      if (F.secs) {
        const ts = F.secs.length >= 4 ? F.secs[3] : (F.secs.length === 1 && F.secs[0].type === 'text' ? F.secs[0] : null);
        if (ts) return { text: ts.toks.map(t => (t.k === 'text' ? v : t.k === 'lit' ? t.v : '')).join(''), color: ts.color };
      }
      return { text: v };
    }
    if (typeof v !== 'number') return { text: String(v) };
    if (!isFinite(v)) return { text: '#NUM!' };
    if (F.general) return { text: generalNum(v, maxLen) };
    if (F.short) return { text: shortINR(v) };
    const { S, auto } = pickSection(F, v);
    if (!S) return { text: generalNum(v) };
    let text;
    if (S.type === 'date') text = renderDate(v, S);
    else if (S.type === 'num') text = renderNum(v, S, auto);
    else if (S.type === 'gen') text = (auto && v < 0 ? '' : '') + S.toks.map(t => (t.k === 'gen' ? generalNum(auto ? v : Math.abs(v)) : t.k === 'lit' ? t.v : '')).join('');
    else text = S.toks.map(t => (t.k === 'lit' ? t.v : '')).join('');
    return { text, color: S.color };
  }
  const fmtText = (v, code) => formatValue(v, code).text;
  function isDateFormat(code) { if (!code) return false; const F = getFmt(code); return !!(F.secs && F.secs[0] && F.secs[0].type === 'date'); }
  function isTimeOnlyFormat(code) { if (!isDateFormat(code)) return false; return !/[dy]/i.test(code.replace(/"[^"]*"/g, '')) && !/m{3,}/i.test(code); }
  /** Add or remove one decimal place in a format code. */
  function adjustDecimals(code, delta, sample) {
    if (!code || /^general$/i.test(code) || code === '[INRSHORT]') {
      let d = 0;
      if (typeof sample === 'number') { const s = generalNum(sample); d = s.includes('.') && !s.includes('E') ? s.split('.')[1].length : 0; }
      const nd = Math.max(0, d + delta);
      return nd ? '0.' + '0'.repeat(nd) : '0';
    }
    return splitSections(code).map(sec => {
      if (compileSection(sec).type !== 'num') return sec;
      const chars = [...sec]; let q = false, br = false, last = -1;
      chars.forEach((ch, i) => { if (ch === '"') q = !q; else if (!q && ch === '[') br = true; else if (!q && ch === ']') br = false; else if (!q && !br && '0#?'.includes(ch)) last = i; });
      if (last < 0) return sec;
      let j = last; while (j > 0 && '0#?'.includes(chars[j - 1])) j--;
      const hasDot = chars[j - 1] === '.';
      if (delta > 0) { chars.splice(last + 1, 0, ...(hasDot ? '0' : '.0')); }
      else if (hasDot) { if (last - j + 1 <= 1) chars.splice(j - 1, 2); else chars.splice(last, 1); }
      return chars.join('');
    }).join(';');
  }

  // ---------------------------------------------------------------- tokenizer & parser
  const SHEET = "(?:'(?:[^']|'')+'|[A-Za-z_\\u0900-\\u0DFF][A-Za-z0-9_.\\u0900-\\u0DFF]*)";
  const RE_COLRANGE = new RegExp('^(?:(' + SHEET + ')!)?\\$?([A-Za-z]{1,3}):\\$?([A-Za-z]{1,3})(?![0-9A-Za-z_(])');
  const RE_ROWRANGE = new RegExp('^(?:(' + SHEET + ')!)?\\$?([0-9]+):\\$?([0-9]+)(?![0-9A-Za-z.(])');
  const RE_REF = new RegExp('^(?:(' + SHEET + ')!)?(\\$?)([A-Za-z]{1,3})(\\$?)([0-9]+)(?![0-9A-Za-z_(])');
  const RE_NUM = /^(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/;
  const RE_IDENT = /^[A-Za-z_\\][A-Za-z0-9_.]*/;
  const RE_ERRLIT = /^#(?:DIV\/0!|N\/A|REF!|NAME\?|VALUE!|NUM!|NULL!|SPILL!|CALC!)/i;

  function tokenize(src) {
    const out = []; let i = 0;
    const operandPos = () => { const p = out[out.length - 1]; return !p || p.t === 'op' || p.t === 'comma' || (p.t === 'paren' && p.v === '(') || p.t === 'lbrace'; };
    while (i < src.length) {
      const ch = src[i];
      if (/\s/.test(ch)) { i++; continue; }
      const rest = src.slice(i); let m;
      if (ch === '"') {
        let j = i + 1, s = '';
        while (j < src.length) { if (src[j] === '"') { if (src[j + 1] === '"') { s += '"'; j += 2; continue; } break; } s += src[j++]; }
        if (j >= src.length) throw new Error('Unclosed text');
        out.push({ t: 'str', v: s }); i = j + 1; continue;
      }
      if (ch === '@') { i++; continue; }
      if ((m = rest.match(RE_ERRLIT))) { out.push({ t: 'err', v: ERR_BY_CODE[m[0].toUpperCase()] || E.ERROR }); i += m[0].length; continue; }
      if ((m = rest.match(RE_COLRANGE))) { out.push({ t: 'colrange', sheet: m[1] ? unquote(m[1]) : null, c1: colToNum(m[2]), c2: colToNum(m[3]) }); i += m[0].length; continue; }
      if (operandPos() && (m = rest.match(RE_ROWRANGE))) { out.push({ t: 'rowrange', sheet: m[1] ? unquote(m[1]) : null, r1: +m[2] - 1, r2: +m[3] - 1 }); i += m[0].length; continue; }
      if ((m = rest.match(RE_REF))) { out.push({ t: 'ref', sheet: m[1] ? unquote(m[1]) : null, c: colToNum(m[3]), r: +m[5] - 1 }); i += m[0].length; continue; }
      if ((m = rest.match(RE_NUM))) { out.push({ t: 'num', v: parseFloat(m[0]) }); i += m[0].length; continue; }
      if (ch === "'") {
        // quoted sheet name followed by ! and something we could not match above
        throw new Error('Bad reference');
      }
      if ((m = rest.match(RE_IDENT))) {
        let name = m[0].toUpperCase(); i += m[0].length;
        let j = i; while (j < src.length && /\s/.test(src[j])) j++;
        if (src[j] === '(') { name = name.replace(/^_XLFN\./, '').replace(/^_XLWS\./, ''); out.push({ t: 'fn', v: name }); }
        else if (name === 'TRUE' || name === 'FALSE') out.push({ t: 'bool', v: name === 'TRUE' });
        else out.push({ t: 'name', v: name });
        continue;
      }
      const two = src.substr(i, 2);
      if (two === '<=' || two === '>=' || two === '<>') { out.push({ t: 'op', v: two }); i += 2; continue; }
      if ('+-*/^&=<>%:'.includes(ch)) { out.push({ t: 'op', v: ch }); i++; continue; }
      if (ch === '(' || ch === ')') { out.push({ t: 'paren', v: ch }); i++; continue; }
      if (ch === '{') { out.push({ t: 'lbrace' }); i++; continue; }
      if (ch === '}') { out.push({ t: 'rbrace' }); i++; continue; }
      if (ch === ',' || ch === ';') { out.push({ t: 'comma', v: ch }); i++; continue; }
      throw new Error('Unexpected character ' + ch);
    }
    return out;
  }

  function parse(src) {
    const toks = tokenize(src); let p = 0;
    const peek = () => toks[p];
    const isOp = (...ops) => peek() && peek().t === 'op' && ops.includes(peek().v);
    const expr = () => compare();
    function compare() { let l = concat(); while (isOp('=', '<>', '<', '>', '<=', '>=')) { const op = toks[p++].v; l = { t: 'bin', op, l, r: concat() }; } return l; }
    function concat() { let l = add(); while (isOp('&')) { p++; l = { t: 'bin', op: '&', l, r: add() }; } return l; }
    function add() { let l = mul(); while (isOp('+', '-')) { const op = toks[p++].v; l = { t: 'bin', op, l, r: mul() }; } return l; }
    function mul() { let l = pow(); while (isOp('*', '/')) { const op = toks[p++].v; l = { t: 'bin', op, l, r: pow() }; } return l; }
    function pow() { let l = unary(); while (isOp('^')) { p++; l = { t: 'bin', op: '^', l, r: unary() }; } return l; }
    function unary() { if (isOp('-')) { p++; return { t: 'neg', e: unary() }; } if (isOp('+')) { p++; return unary(); } return postfix(); }
    function postfix() { let e = primary(); while (isOp('%')) { p++; e = { t: 'pct', e }; } return e; }
    function primary() {
      const tk = toks[p++];
      if (!tk) throw new Error('Formula is incomplete');
      switch (tk.t) {
        case 'num': return { t: 'num', v: tk.v };
        case 'str': return { t: 'str', v: tk.v };
        case 'bool': return { t: 'bool', v: tk.v };
        case 'err': return { t: 'errv', v: tk.v };
        case 'name': return { t: 'name', v: tk.v };
        case 'colrange': return { t: 'range', sheet: tk.sheet, r1: 0, c1: Math.min(tk.c1, tk.c2), r2: Infinity, c2: Math.max(tk.c1, tk.c2) };
        case 'rowrange': return { t: 'range', sheet: tk.sheet, r1: Math.min(tk.r1, tk.r2), c1: 0, r2: Math.max(tk.r1, tk.r2), c2: Infinity };
        case 'ref': {
          if (isOp(':') && toks[p + 1] && toks[p + 1].t === 'ref') {
            p++; const b = toks[p++];
            return { t: 'range', sheet: tk.sheet, r1: Math.min(tk.r, b.r), c1: Math.min(tk.c, b.c), r2: Math.max(tk.r, b.r), c2: Math.max(tk.c, b.c) };
          }
          return { t: 'ref', sheet: tk.sheet, r: tk.r, c: tk.c };
        }
        case 'lbrace': {
          const rows = [[]];
          if (!(peek() && peek().t === 'rbrace')) {
            for (;;) {
              rows[rows.length - 1].push(expr());
              const s = peek();
              if (s && s.t === 'comma') { p++; if (s.v === ';') rows.push([]); continue; }
              break;
            }
          }
          if (!(peek() && peek().t === 'rbrace')) throw new Error('Missing }');
          p++;
          const w = Math.max(...rows.map(r => r.length));
          rows.forEach(r => { while (r.length < w) r.push({ t: 'errv', v: E.NA }); });
          return { t: 'array', rows };
        }
        case 'fn': {
          p++; const args = [];
          if (!(peek() && peek().t === 'paren' && peek().v === ')')) {
            for (;;) {
              if (peek() && (peek().t === 'comma' || (peek().t === 'paren' && peek().v === ')'))) args.push({ t: 'blank' });
              else args.push(expr());
              if (peek() && peek().t === 'comma') { p++; continue; }
              break;
            }
          }
          if (!(peek() && peek().t === 'paren' && peek().v === ')')) throw new Error('Missing )');
          p++;
          return { t: 'fn', name: tk.v, args };
        }
        case 'paren':
          if (tk.v === '(') { const e = expr(); if (!(peek() && peek().t === 'paren' && peek().v === ')')) throw new Error('Missing )'); p++; return e; }
          break;
      }
      throw new Error('Unexpected ' + (tk.v || tk.t));
    }
    const ast = expr();
    if (p < toks.length) throw new Error('Unexpected text after formula');
    return ast;
  }

  // ---------------------------------------------------------------- coercion helpers
  function toNum(v) {
    v = norm(scalar(v));
    if (isErr(v)) return v;
    if (v === null || v === undefined || v === '') return 0;
    if (typeof v === 'number') return v;
    if (typeof v === 'boolean') return v ? 1 : 0;
    const p = parseInput(String(v));
    if (typeof p.value === 'number') return p.value;
    return E.VALUE;
  }
  function toBool(v) {
    v = norm(scalar(v));
    if (isErr(v)) return v;
    if (typeof v === 'boolean') return v;
    if (v === null || v === '' || v === undefined) return false;
    if (typeof v === 'number') return v !== 0;
    const u = String(v).toUpperCase(); if (u === 'TRUE') return true; if (u === 'FALSE') return false;
    return E.VALUE;
  }
  function toStr(v) {
    v = norm(scalar(v));
    if (isErr(v)) return v;
    if (v === null || v === undefined) return '';
    if (typeof v === 'boolean') return v ? 'TRUE' : 'FALSE';
    if (typeof v === 'number') return generalNum(v);
    return String(v);
  }
  const n1 = v => { const n = toNum(v); if (isErr(n)) throw n; return n; };
  const s1 = v => { const s = toStr(v); if (isErr(s)) throw s; return s; };
  const b1 = v => { const b = toBool(v); if (isErr(b)) throw b; return b; };
  const opt = (v, d) => (v === undefined || v === null ? d : v);

  function nums(args, o = {}) {
    const out = [];
    for (const a of args) {
      if (isRange(a)) {
        for (const row of a.rows) for (const v of row) {
          if (isErr(v)) throw v;
          if (typeof v === 'number') out.push(v);
          else if (o.countBool && typeof v === 'boolean') out.push(v ? 1 : 0);
        }
      } else if (a !== undefined) {
        if (a === null && !o.blankAsZero) continue;
        const n = toNum(a); if (isErr(n)) throw n; out.push(n);
      }
    }
    return out;
  }
  const allVals = args => { const out = []; for (const a of args) { if (isRange(a)) { for (const r of a.rows) for (const v of r) out.push(v); } else out.push(a); } return out; };
  const toRange = v => (isRange(v) ? v : new Range([[v]]));

  function compare(a, b) {
    a = norm(scalar(a)); b = norm(scalar(b));
    if (a === null || a === undefined) a = typeof b === 'string' ? '' : (typeof b === 'boolean' ? false : 0);
    if (b === null || b === undefined) b = typeof a === 'string' ? '' : (typeof a === 'boolean' ? false : 0);
    const rank = v => (typeof v === 'number' ? 0 : typeof v === 'string' ? 1 : 2);
    if (rank(a) !== rank(b)) return rank(a) < rank(b) ? -1 : 1;
    if (typeof a === 'string') { const x = a.toLowerCase(), y = b.toLowerCase(); return x < y ? -1 : x > y ? 1 : 0; }
    return a < b ? -1 : a > b ? 1 : 0;
  }
  function wildcard(pat) {
    let re = '';
    for (let i = 0; i < pat.length; i++) {
      const ch = pat[i];
      if (ch === '~' && i + 1 < pat.length) re += pat[++i].replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      else if (ch === '*') re += '[\\s\\S]*';
      else if (ch === '?') re += '[\\s\\S]';
      else re += ch.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    }
    return new RegExp('^' + re + '$', 'i');
  }
  function criteria(c) {
    c = norm(scalar(c));
    if (typeof c === 'number') return v => (v = norm(v), typeof v === 'number' ? v === c : (typeof v === 'string' && v.trim() !== '' && Number(v) === c));
    if (typeof c === 'boolean') return v => v === c;
    const s = c === null || c === undefined ? '' : String(c);
    const m = s.match(/^(<=|>=|<>|=|<|>)?([\s\S]*)$/);
    const op = m[1] || '=', rhs = m[2];
    const test = (x, y) => op === '=' ? x === y : op === '<>' ? x !== y : op === '<' ? x < y : op === '>' ? x > y : op === '<=' ? x <= y : x >= y;
    let rn = null;
    if (rhs.trim() !== '') { const p = parseInput(rhs); if (typeof p.value === 'number') rn = p.value; }
    if (rn !== null) return v => { v = norm(v); return typeof v === 'number' ? test(v, rn) : op === '<>'; };
    if (op === '=' || op === '<>') {
      const re = wildcard(rhs);
      return v => { v = norm(v); const t = v === null || v === undefined ? '' : String(toStr(v)); const r = rhs === '' ? t === '' : re.test(t); return op === '=' ? r : !r; };
    }
    return v => { v = norm(v); return typeof v === 'string' && test(v.toLowerCase(), rhs.toLowerCase()); };
  }
  const round = (n, d) => roundHalfUp(n, d);

  function lookupIndex(val, list, mode) {
    val = norm(scalar(val));
    if (mode === 0 || mode === 2) {
      const crit = typeof val === 'string' && mode === 2 ? wildcard(val) : (typeof val === 'string' && /[*?~]/.test(val) && mode === 0 ? wildcard(val) : null);
      for (let i = 0; i < list.length; i++) {
        const x = norm(list[i]);
        if (crit ? typeof x === 'string' && crit.test(x) : (x !== null && x !== undefined && compare(x, val) === 0)) return i;
      }
      return -1;
    }
    let best = -1;
    for (let i = 0; i < list.length; i++) {
      const x = list[i]; if (x === null || x === undefined) continue;
      const c = compare(x, val);
      if (mode === 1) { if (c <= 0) best = i; else break; } else { if (c >= 0) best = i; else break; }
    }
    return best;
  }

  // ---------------------------------------------------------------- evaluator
  const F = {};                    // function library (filled by functions.js)
  const VOLATILE = new Set(['TODAY', 'NOW', 'RAND', 'RANDBETWEEN', 'RANDARRAY', 'OFFSET', 'INDIRECT']);
  const ERR_OK = new Set(['IFERROR', 'IFNA', 'ISERROR', 'ISERR', 'ISNA', 'ERROR.TYPE', 'TYPE', 'ISBLANK', 'ISNUMBER', 'ISTEXT', 'ISLOGICAL', 'ISNONTEXT', 'COUNT', 'COUNTA', 'COUNTBLANK', 'XLOOKUP', 'CHOOSE', 'SWITCH', 'IFS', 'N', 'T', 'AGGREGATE']);
  const LIFT = new Set(('ABS ROUND ROUNDUP ROUNDDOWN INT TRUNC MOD POWER SQRT EXP LN LOG LOG10 SIGN CEILING FLOOR MROUND EVEN ODD QUOTIENT ' +
    'LEFT RIGHT MID LEN UPPER LOWER PROPER TRIM CLEAN VALUE TEXT SUBSTITUTE REPLACE REPT FIND SEARCH EXACT CHAR CODE UNICHAR UNICODE NUMBERVALUE FIXED ' +
    'YEAR MONTH DAY WEEKDAY WEEKNUM HOUR MINUTE SECOND DATE TIME EDATE EOMONTH DATEVALUE TIMEVALUE DAYS ' +
    'ISNUMBER ISTEXT ISBLANK ISERROR ISERR ISNA ISEVEN ISODD ISLOGICAL ISNONTEXT N T NOT ' +
    'RUPEEWORDS NUMWORDS HINDIWORDS GST CGST SGST IGST WITHGST REMOVEGST INR LAKH CRORE FY FYQUARTER ISGSTIN GSTINSTATE GSTINPAN ISPAN ISIFSC ISAADHAAR ISMOBILE ISPINCODE STATENAME STATECODE ' +
    'TEXTBEFORE TEXTAFTER REGEXMATCH REGEXEXTRACT REGEXREPLACE CONVERT METALWEIGHT AGEING SIN COS TAN RADIANS DEGREES ' +
    'PMT IPMT PPMT FV PV EMI').split(' '));

  function broadcast(args, fn) {
    let h = 1, w = 1;
    for (const a of args) if (isRange(a)) { h = Math.max(h, a.h); w = Math.max(w, a.w); }
    const rows = [];
    for (let i = 0; i < h; i++) {
      const row = [];
      for (let j = 0; j < w; j++) {
        const sc = args.map(a => {
          if (!isRange(a)) return a;
          const ii = a.h === 1 ? 0 : i, jj = a.w === 1 ? 0 : j;
          return ii < a.h && jj < a.w ? a.rows[ii][jj] : E.NA;
        });
        row.push(fn(sc));
      }
      rows.push(row);
    }
    return new Range(rows);
  }
  function binop(op, l, r) {
    l = norm(l); r = norm(r);
    if (isErr(l)) return l; if (isErr(r)) return r;
    if (op === '&') return toStr(l) + toStr(r);
    if (op === '=' || op === '<>' || op === '<' || op === '>' || op === '<=' || op === '>=') {
      const c = compare(l, r);
      switch (op) { case '=': return c === 0; case '<>': return c !== 0; case '<': return c < 0; case '>': return c > 0; case '<=': return c <= 0; default: return c >= 0; }
    }
    const a = toNum(l), b = toNum(r);
    if (isErr(a)) return a; if (isErr(b)) return b;
    switch (op) {
      case '+': return a + b; case '-': return a - b; case '*': return a * b;
      case '/': return b === 0 ? E.DIV0 : a / b;
      case '^': { const p = Math.pow(a, b); return isFinite(p) ? p : E.NUM; }
    }
    return E.ERROR;
  }
  const isRethrow = e => e && (e.__defer || e instanceof RangeError);

  function ev(node, ctx) {
    switch (node.t) {
      case 'num': case 'str': case 'bool': return node.v;
      case 'errv': return node.v;
      case 'blank': return null;
      case 'array': return new Range(node.rows.map(row => row.map(n => scalar(ev(n, ctx)))));
      case 'ref': return ctx.get(node.sheet || ctx.sheet, node.r, node.c);
      case 'range': return ctx.getRange(node.sheet || ctx.sheet, node.r1, node.c1, node.r2, node.c2);
      case 'name': {
        if (ctx.locals && ctx.locals.has(node.v)) return ctx.locals.get(node.v);
        const def = ctx.name ? ctx.name(node.v) : null;
        if (!def) return E.NAME;
        return ev(def, ctx);
      }
      case 'neg': { const v = ev(node.e, ctx); if (isRange(v)) return broadcast([v], ([x]) => { const n = toNum(x); return isErr(n) ? n : -n; }); const n = toNum(v); return isErr(n) ? n : -n; }
      case 'pct': { const v = ev(node.e, ctx); if (isRange(v)) return broadcast([v], ([x]) => { const n = toNum(x); return isErr(n) ? n : n / 100; }); const n = toNum(v); return isErr(n) ? n : n / 100; }
      case 'bin': {
        const l = ev(node.l, ctx), r = ev(node.r, ctx);
        if (isRange(l) || isRange(r)) return broadcast([l, r], ([a, b]) => binop(node.op, a, b));
        return binop(node.op, l, r);
      }
      case 'fn': return evFn(node, ctx);
    }
    return E.ERROR;
  }
  function evFn(node, ctx) {
    const name = node.name;
    if (name === 'IF') {
      const cond = ev(node.args[0] || { t: 'blank' }, ctx);
      const pick = (c, i) => { if (!node.args[i]) return i === 1 ? true : false; return ev(node.args[i], ctx); };
      if (isRange(cond)) {
        const a = node.args[1] ? ev(node.args[1], ctx) : true, b = node.args[2] ? ev(node.args[2], ctx) : false;
        return broadcast([cond, a, b], ([c, x, y]) => { const t = toBool(c); return isErr(t) ? t : (t ? x : y); });
      }
      const t = toBool(cond); if (isErr(t)) return t;
      const v = t ? pick(cond, 1) : pick(cond, 2);
      return v === null && node.args[t ? 1 : 2] && node.args[t ? 1 : 2].t === 'blank' ? 0 : v;
    }
    if (name === 'IFERROR' || name === 'IFNA') {
      const v = ev(node.args[0] || { t: 'blank' }, ctx);
      const bad = x => (name === 'IFNA' ? x === E.NA : isErr(x));
      if (isRange(v)) { const alt = node.args[1] ? ev(node.args[1], ctx) : ''; return broadcast([v, alt], ([x, y]) => (bad(x) ? y : x)); }
      return bad(v) ? (node.args[1] ? ev(node.args[1], ctx) : '') : v;
    }
    if (name === 'LET') {
      const child = Object.create(ctx); child.locals = new Map(ctx.locals || []);
      const a = node.args;
      for (let i = 0; i + 1 < a.length; i += 2) {
        if (a[i].t !== 'name') return E.VALUE;
        child.locals.set(a[i].v, ev(a[i + 1], child));
      }
      return a.length % 2 === 1 ? ev(a[a.length - 1], child) : E.VALUE;
    }
    const fn = F[name]; if (!fn) return E.NAME;
    if (VOLATILE.has(name) && ctx.volatile) ctx.volatile();
    const args = node.args.map(a => ev(a, ctx));
    if (!ERR_OK.has(name)) for (const a of args) if (isErr(a)) return a;
    if (LIFT.has(name) && args.some(isRange)) {
      return broadcast(args, sc => { for (const x of sc) if (isErr(x) && !ERR_OK.has(name)) return x; try { const v = fn(sc, ctx, node.args); return v === undefined ? null : scalar(v); } catch (e) { if (isRethrow(e)) throw e; return isErr(e) ? e : E.VALUE; } });
    }
    try { const v = fn(args, ctx, node.args); return v === undefined ? null : v; }
    catch (e) { if (isRethrow(e)) throw e; if (isErr(e)) return e; return E.VALUE; }
  }

  const astCache = new Map();
  function getAst(formula) {
    let ast = astCache.get(formula);
    if (!ast) {
      try { ast = parse(formula[0] === '=' ? formula.slice(1) : formula); } catch (e) { ast = { t: 'errv', v: E.ERROR, parseError: e.message }; }
      if (astCache.size > 20000) astCache.clear();
      astCache.set(formula, ast);
    }
    return ast;
  }
  /** Evaluate a formula string. Returns a scalar or a Range (for spilled results). */
  function run(formula, ctx) {
    const ast = getAst(formula);
    let v;
    try { v = ev(ast, ctx); } catch (e) { if (isRethrow(e)) throw e; v = isErr(e) ? e : E.ERROR; }
    if (isRange(v)) {
      if (v.h === 0 || v.w === 0) return E.CALC;
      if (v.h === 1 && v.w === 1) v = v.rows[0][0];
      else return v;
    }
    if (typeof v === 'number' && !isFinite(v)) v = E.NUM;
    if (v === undefined) v = null;
    return v;
  }
  function checkFormula(formula) { try { parse(formula[0] === '=' ? formula.slice(1) : formula); return true; } catch (e) { return e.message; } }
  function evalNode(node, ctx) { return ev(node, ctx); }

  // ---------------------------------------------------------------- reference tools
  const RE_REFS_G = new RegExp("(?<![A-Za-z0-9_.$'!\\u0900-\\u0DFF])(" + SHEET + "!)?(?:(\\$?)([A-Za-z]{1,3})(\\$?)([0-9]+)(?![A-Za-z0-9_(!])|(\\$?)([A-Za-z]{1,3}):(\\$?)([A-Za-z]{1,3})(?![A-Za-z0-9_(!])|(\\$?)([0-9]+):(\\$?)([0-9]+)(?![A-Za-z0-9_.(!]))", 'g');
  /**
   * Rewrite references in a formula. cb receives one of
   *  {kind:'cell', sheet, row, col, absR, absC, pos}  → return {row, col, sheet?} | null (#REF!) | undefined (keep)
   *  {kind:'cols', sheet, c1, c2, abs1, abs2}            → return {c1, c2, sheet?} | null | undefined
   *  {kind:'rows', sheet, r1, r2, abs1, abs2}            → return {r1, r2, sheet?} | null | undefined
   */
  function transformRefs(formula, cb) {
    let body = formula;
    return body.replace(/("(?:[^"]|"")*")|([^"]+)/g, (m, str, code) => {
      if (str) return str;
      let lastSheet = null, lastEnd = -2;
      return code.replace(RE_REFS_G, (all, sh, dc, col, dr, row, ca1, c1, ca2, c2, ra1, r1, ra2, r2, offset, whole) => {
        let sheet = sh ? unquote(sh.slice(0, -1)) : null;
        const prevChar = whole[offset - 1], nextChar = whole[offset + all.length];
        if (col !== undefined) {
          if (/[A-Za-z]/.test(prevChar || '') ) return all;
          if (!sheet && prevChar === ':' && lastEnd === offset - 1) sheet = lastSheet;
          const pos = prevChar === ':' ? 'end' : nextChar === ':' ? 'start' : null;
          const res = cb({ kind: 'cell', sheet, col: colToNum(col), row: +row - 1, absC: !!dc, absR: !!dr, pos });
          lastSheet = sheet; lastEnd = offset + all.length;
          if (res === null) return '#REF!';
          if (res === undefined) return all;
          const prefix = res.sheet !== undefined ? (res.sheet ? quoteSheet(res.sheet) + '!' : '') : (sh || '');
          return (pos === 'end' && !sh ? '' : prefix) + dc + numToCol(res.col) + dr + (res.row + 1);
        }
        if (c1 !== undefined) {
          const res = cb({ kind: 'cols', sheet, c1: colToNum(c1), c2: colToNum(c2), abs1: !!ca1, abs2: !!ca2 });
          if (res === null) return '#REF!';
          if (res === undefined) return all;
          const prefix = res.sheet !== undefined ? (res.sheet ? quoteSheet(res.sheet) + '!' : '') : (sh || '');
          return prefix + ca1 + numToCol(res.c1) + ':' + ca2 + numToCol(res.c2);
        }
        if (r1 !== undefined) {
          if (!/^[\s(,=+\-*/^&<>;]?$/.test(prevChar || '') && !sh) return all;
          const res = cb({ kind: 'rows', sheet, r1: +r1 - 1, r2: +r2 - 1, abs1: !!ra1, abs2: !!ra2 });
          if (res === null) return '#REF!';
          if (res === undefined) return all;
          const prefix = res.sheet !== undefined ? (res.sheet ? quoteSheet(res.sheet) + '!' : '') : (sh || '');
          return prefix + ra1 + (res.r1 + 1) + ':' + ra2 + (res.r2 + 1);
        }
        return all;
      });
    });
  }
  /** Copy-paste style shift of relative references. */
  function shiftFormula(formula, dr, dc) {
    return transformRefs(formula, ref => {
      if (ref.kind === 'cell') {
        const row = ref.absR ? ref.row : ref.row + dr, col = ref.absC ? ref.col : ref.col + dc;
        return row < 0 || col < 0 ? null : { row, col };
      }
      if (ref.kind === 'cols') { const c1 = ref.abs1 ? ref.c1 : ref.c1 + dc, c2 = ref.abs2 ? ref.c2 : ref.c2 + dc; return c1 < 0 || c2 < 0 ? null : { c1, c2 }; }
      const r1 = ref.abs1 ? ref.r1 : ref.r1 + dr, r2 = ref.abs2 ? ref.r2 : ref.r2 + dr; return r1 < 0 || r2 < 0 ? null : { r1, r2 };
    });
  }
  /** List references in a (possibly unfinished) formula, for colouring while typing. */
  function refsInFormula(text) {
    const out = []; let offsetBase = 0;
    const re = new RegExp("(?<![A-Za-z0-9_.$'!])(" + SHEET + "!)?\\$?([A-Za-z]{1,3})\\$?([0-9]+)(?::\\$?([A-Za-z]{1,3})\\$?([0-9]+))?(?![A-Za-z0-9_(!])", 'g');
    text.replace(/("(?:[^"]|"")*"?)|([^"]+)/g, (m, str, code) => {
      if (code) {
        let x; re.lastIndex = 0;
        while ((x = re.exec(code))) {
          const r1 = +x[3] - 1, c1 = colToNum(x[2]);
          const r2 = x[4] ? +x[5] - 1 : r1, c2 = x[4] ? colToNum(x[4]) : c1;
          out.push({ sheet: x[1] ? unquote(x[1].slice(0, -1)) : null, r1: Math.min(r1, r2), c1: Math.min(c1, c2), r2: Math.max(r1, r2), c2: Math.max(c1, c2), start: offsetBase + x.index, end: offsetBase + x.index + x[0].length });
        }
      }
      offsetBase += m.length;
      return m;
    });
    return out;
  }

  // ---------------------------------------------------------------- words (Indian system)
  const ONES = ['', 'One', 'Two', 'Three', 'Four', 'Five', 'Six', 'Seven', 'Eight', 'Nine', 'Ten', 'Eleven', 'Twelve', 'Thirteen', 'Fourteen', 'Fifteen', 'Sixteen', 'Seventeen', 'Eighteen', 'Nineteen'];
  const TENS = ['', '', 'Twenty', 'Thirty', 'Forty', 'Fifty', 'Sixty', 'Seventy', 'Eighty', 'Ninety'];
  const w2 = n => (n < 20 ? ONES[n] : TENS[Math.floor(n / 10)] + (n % 10 ? ' ' + ONES[n % 10] : ''));
  const w3 = n => { const h = Math.floor(n / 100), r = n % 100; return (h ? ONES[h] + ' Hundred' + (r ? ' ' : '') : '') + (r ? w2(r) : ''); };
  function inWords(n) {
    n = Math.floor(Math.abs(n));
    if (n === 0) return 'Zero';
    const parts = [];
    const crore = Math.floor(n / 1e7); n %= 1e7;
    const lakh = Math.floor(n / 1e5); n %= 1e5;
    const th = Math.floor(n / 1000); n %= 1000;
    if (crore) parts.push(inWords(crore) + ' Crore');
    if (lakh) parts.push(w2(lakh) + ' Lakh');
    if (th) parts.push(w2(th) + ' Thousand');
    if (n) parts.push(w3(n));
    return parts.join(' ');
  }
  const HI = ('शून्य एक दो तीन चार पाँच छह सात आठ नौ दस ग्यारह बारह तेरह चौदह पंद्रह सोलह सत्रह अठारह उन्नीस बीस ' +
    'इक्कीस बाईस तेईस चौबीस पच्चीस छब्बीस सत्ताईस अट्ठाईस उनतीस तीस इकतीस बत्तीस तैंतीस चौंतीस पैंतीस छत्तीस सैंतीस अड़तीस उनतालीस चालीस ' +
    'इकतालीस बयालीस तैंतालीस चवालीस पैंतालीस छियालीस सैंतालीस अड़तालीस उनचास पचास इक्यावन बावन तिरेपन चौवन पचपन छप्पन सत्तावन अट्ठावन उनसठ साठ ' +
    'इकसठ बासठ तिरेसठ चौंसठ पैंसठ छियासठ सड़सठ अड़सठ उनहत्तर सत्तर इकहत्तर बहत्तर तिहत्तर चौहत्तर पचहत्तर छिहत्तर सतहत्तर अठहत्तर उन्यासी अस्सी ' +
    'इक्यासी बयासी तिरासी चौरासी पचासी छियासी सत्तासी अट्ठासी नवासी नब्बे इक्यानबे बानबे तिरानबे चौरानबे पंचानबे छियानबे सत्तानबे अट्ठानबे निन्यानबे').split(' ');
  function hindiWords(n) {
    n = Math.floor(Math.abs(n));
    if (n === 0) return HI[0];
    const parts = [];
    const crore = Math.floor(n / 1e7); n %= 1e7;
    const lakh = Math.floor(n / 1e5); n %= 1e5;
    const th = Math.floor(n / 1000); n %= 1000;
    const hu = Math.floor(n / 100); n %= 100;
    if (crore) parts.push(hindiWords(crore) + ' करोड़');
    if (lakh) parts.push(HI[lakh] + ' लाख');
    if (th) parts.push(HI[th] + ' हज़ार');
    if (hu) parts.push(HI[hu] + ' सौ');
    if (n) parts.push(HI[n]);
    return parts.join(' ');
  }

  global.Formula = {
    // core
    run, parse, tokenize, getAst, checkFormula, evalNode, F, FN_INFO: {}, VOLATILE, LIFT, ERR_OK,
    // values
    E, FErr, Rich, Range, Defer, isErr, isRich, isRange, scalar, norm, ERR_BY_CODE,
    // helpers for the function library
    toNum, toStr, toBool, n1, s1, b1, opt, nums, allVals, toRange, compare, criteria, wildcard, lookupIndex, round, broadcast,
    // refs
    colToNum, numToCol, quoteSheet, unquote, a1, parseRef, transformRefs, shiftFormula, refsInFormula,
    // dates
    toSerial, fromSerial, todaySerial, nowSerial, parseDateTime, MONTHS, DAYS, daysIn,
    // input & formats
    settings, parseInput, formatValue, fmtText, generalNum, groupDigits, isDateFormat, isTimeOnlyFormat, adjustDecimals, getFmt,
    // words
    inWords, hindiWords,
    get FUNCTION_NAMES() { return Object.keys(F).sort(); }
  };
})(typeof window !== 'undefined' ? window : globalThis);
