/* India Sheets – UI toolkit: icons, menus, dialogs, toasts, colour palette, side panel */
(function (global) {
  'use strict';
  const IS = global.IS = global.IS || {};
  const $ = id => document.getElementById(id);
  const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[ch]));

  const P = {
    undo: '<path d="M9 14 4 9l5-5"/><path d="M4 9h10.5a5.5 5.5 0 0 1 0 11H11"/>',
    redo: '<path d="m15 14 5-5-5-5"/><path d="M20 9H9.5a5.5 5.5 0 0 0 0 11H13"/>',
    print: '<path d="M6 9V2h12v7"/><path d="M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2"/><rect width="12" height="8" x="6" y="14"/>',
    painter: '<path d="M18 4H6a2 2 0 0 0-2 2v3a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2Z"/><path d="M20 7h1a1 1 0 0 1 1 1v3a2 2 0 0 1-2 2h-8v2"/><rect x="10" y="15" width="4" height="7" rx="1"/>',
    bold: '<path d="M6 12h9a4 4 0 0 1 0 8H7a1 1 0 0 1-1-1V5a1 1 0 0 1 1-1h7a4 4 0 0 1 0 8"/>',
    italic: '<line x1="19" x2="10" y1="4" y2="4"/><line x1="14" x2="5" y1="20" y2="20"/><line x1="15" x2="9" y1="4" y2="20"/>',
    underline: '<path d="M6 4v6a6 6 0 0 0 12 0V4"/><line x1="4" x2="20" y1="20" y2="20"/>',
    strike: '<path d="M16 4H9a3 3 0 0 0-2.83 4"/><path d="M14 12a4 4 0 0 1 0 8H6"/><line x1="4" x2="20" y1="12" y2="12"/>',
    alignLeft: '<line x1="21" x2="3" y1="6" y2="6"/><line x1="15" x2="3" y1="12" y2="12"/><line x1="17" x2="3" y1="18" y2="18"/>',
    alignCenter: '<line x1="21" x2="3" y1="6" y2="6"/><line x1="17" x2="7" y1="12" y2="12"/><line x1="19" x2="5" y1="18" y2="18"/>',
    alignRight: '<line x1="21" x2="3" y1="6" y2="6"/><line x1="21" x2="9" y1="12" y2="12"/><line x1="21" x2="7" y1="18" y2="18"/>',
    vTop: '<path d="M4 3h16"/><path d="M12 21V7"/><path d="m8 11 4-4 4 4"/>',
    vMiddle: '<path d="M4 12h16"/><path d="M12 3v5"/><path d="m9 6 3 2 3-2"/><path d="M12 21v-5"/><path d="m9 18 3-2 3 2"/>',
    vBottom: '<path d="M4 21h16"/><path d="M12 3v14"/><path d="m8 13 4 4 4-4"/>',
    wrap: '<line x1="3" x2="21" y1="6" y2="6"/><path d="M3 12h15a3 3 0 1 1 0 6h-4"/><path d="m16 16-2 2 2 2"/><line x1="3" x2="10" y1="18" y2="18"/>',
    merge: '<rect x="3" y="5" width="18" height="14" rx="1"/><path d="M7 12h10"/><path d="m9 10-2 2 2 2"/><path d="m15 10 2 2-2 2"/>',
    borders: '<rect width="18" height="18" x="3" y="3" rx="1"/><path d="M3 12h18"/><path d="M12 3v18"/>',
    fill: '<path d="m19 11-8-8-8.6 8.6a2 2 0 0 0 0 2.8l5.2 5.2c.8.8 2 .8 2.8 0L19 11Z"/><path d="m5 2 5 5"/><path d="M2 13h15"/><path d="M22 20a2 2 0 1 1-4 0c0-1.6 1.7-2.4 2-4 .3 1.6 2 2.4 2 4Z"/>',
    link: '<path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/>',
    note: '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>',
    chart: '<path d="M3 3v18h18"/><path d="M18 17V9"/><path d="M13 17V5"/><path d="M8 17v-3"/>',
    filter: '<polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/>',
    sigma: '<path d="M18 7V4H6l6 8-6 8h12v-3"/>',
    mic: '<path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3Z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" x2="12" y1="19" y2="22"/>',
    sparkles: '<path d="m12 3-1.9 5.8a2 2 0 0 1-1.3 1.3L3 12l5.8 1.9a2 2 0 0 1 1.3 1.3L12 21l1.9-5.8a2 2 0 0 1 1.3-1.3L21 12l-5.8-1.9a2 2 0 0 1-1.3-1.3Z"/>',
    search: '<circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/>',
    image: '<rect width="18" height="18" x="3" y="3" rx="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.1-3.1a2 2 0 0 0-2.8 0L6 21"/>',
    download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m7 10 5 5 5-5"/><path d="M12 15V3"/>',
    upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><path d="m17 8-5-5-5 5"/><path d="M12 3v12"/>',
    folder: '<path d="m6 14 1.5-2.9A2 2 0 0 1 9.24 10H20a2 2 0 0 1 1.94 2.5l-1.54 6a2 2 0 0 1-1.95 1.5H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h3.9a2 2 0 0 1 1.69.9l.81 1.2a2 2 0 0 0 1.67.9H18a2 2 0 0 1 2 2v2"/>',
    filePlus: '<path d="M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7Z"/><path d="M14 2v4a2 2 0 0 0 2 2h4"/><path d="M9 15h6"/><path d="M12 18v-6"/>',
    check: '<rect x="3" y="3" width="18" height="18" rx="2"/><path d="m9 12 2 2 4-4"/>',
    lock: '<rect width="18" height="11" x="3" y="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/>',
    history: '<path d="M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8"/><path d="M3 3v5h5"/><path d="M12 7v5l4 2"/>',
    sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/>',
    moon: '<path d="M12 3a6 6 0 0 0 9 9 9 9 0 1 1-9-9Z"/>',
    speaker: '<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/>',
    table: '<rect width="18" height="18" x="3" y="3" rx="2"/><path d="M3 9h18"/><path d="M3 15h18"/><path d="M9 3v18"/>',
    qr: '<rect width="5" height="5" x="3" y="3" rx="1"/><rect width="5" height="5" x="16" y="3" rx="1"/><rect width="5" height="5" x="3" y="16" rx="1"/><path d="M21 16h-3a2 2 0 0 0-2 2v3"/><path d="M21 21v.01"/><path d="M12 7v3a2 2 0 0 1-2 2H7"/><path d="M3 12h.01"/><path d="M12 3h.01"/><path d="M12 16v.01"/><path d="M16 12h1"/><path d="M21 12v.01"/><path d="M12 21v-1"/>',
    calc: '<rect width="16" height="20" x="4" y="2" rx="2"/><line x1="8" x2="16" y1="6" y2="6"/><line x1="16" x2="16" y1="14" y2="18"/><path d="M16 10h.01"/><path d="M12 10h.01"/><path d="M8 10h.01"/><path d="M12 14h.01"/><path d="M8 14h.01"/><path d="M12 18h.01"/><path d="M8 18h.01"/>',
    more: '<circle cx="12" cy="12" r="1"/><circle cx="19" cy="12" r="1"/><circle cx="5" cy="12" r="1"/>',
    x: '<path d="M18 6 6 18"/><path d="m6 6 12 12"/>',
    chevronDown: '<path d="m6 9 6 6 6-6"/>',
    eraser: '<path d="m7 21-4.3-4.3c-1-1-1-2.5 0-3.4l9.6-9.6c1-1 2.5-1 3.4 0l5.6 5.6c1 1 1 2.5 0 3.4L13 21"/><path d="M22 21H7"/><path d="m5 11 9 9"/>',
    snow: '<path d="M2 12h20"/><path d="M12 2v20"/><path d="m20 16-4-4 4-4"/><path d="m4 8 4 4-4 4"/><path d="m16 4-4 4-4-4"/><path d="m8 20 4-4 4 4"/>',
    rupee: '<path d="M6 3h12"/><path d="M6 8h12"/><path d="m6 13 8.5 8"/><path d="M6 13h3"/><path d="M9 13c6.667 0 6.667-10 0-10"/>',
    percent: '<line x1="19" x2="5" y1="5" y2="19"/><circle cx="6.5" cy="6.5" r="2.5"/><circle cx="17.5" cy="17.5" r="2.5"/>',
    sort: '<path d="m3 16 4 4 4-4"/><path d="M7 20V4"/><path d="M11 4h10"/><path d="M11 8h7"/><path d="M11 12h4"/>',
    trash: '<path d="M3 6h18"/><path d="M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6"/><path d="M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2"/>',
    copy: '<rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/>',
    edit: '<path d="M12 20h9"/><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L7 19l-4 1 1-4Z"/>',
    india: '<path d="M12 2v20"/><circle cx="12" cy="12" r="3"/><path d="M4 7h16"/><path d="M4 17h16"/>'
  };
  const icon = (name, size = 18) => '<svg class="ic" width="' + size + '" height="' + size + '" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' + (P[name] || '') + '</svg>';

  // ---------------------------------------------------------------- toasts & busy
  function toast(msg, opts = {}) {
    const host = $('toasts'); if (!host) return;
    const t = document.createElement('div');
    t.className = 'toast ' + (opts.type || '');
    t.innerHTML = '<span>' + (opts.html ? msg : esc(msg)) + '</span>';
    if (opts.action) { const b = document.createElement('button'); b.textContent = opts.action.label; b.onclick = () => { opts.action.onClick(); t.remove(); }; t.appendChild(b); }
    host.appendChild(t);
    setTimeout(() => t.classList.add('out'), opts.ms || 4200);
    setTimeout(() => t.remove(), (opts.ms || 4200) + 400);
  }
  let busyCount = 0;
  function busy(text) { busyCount++; $('busyText').textContent = text || 'Working…'; $('busy').hidden = false; }
  function done() { busyCount = Math.max(0, busyCount - 1); if (!busyCount) $('busy').hidden = true; }
  const nextFrame = () => new Promise(r => requestAnimationFrame(() => setTimeout(r, 0)));

  // ---------------------------------------------------------------- dialog
  let dlgResolve = null;
  function modal(opts) {
    const dlg = $('dlg');
    if (dlg.open) { dlg.close('replaced'); }
    const body = $('dlgBody'), actions = $('dlgActions');
    dlg.className = 'dlg' + (opts.wide ? ' wide' : '') + (opts.className ? ' ' + opts.className : '');
    body.innerHTML = (opts.title ? '<h2 class="dlg-title">' + esc(opts.title) + '</h2>' : '');
    if (typeof opts.body === 'string') body.insertAdjacentHTML('beforeend', opts.body); else if (opts.body) body.appendChild(opts.body);
    actions.innerHTML = '';
    const list = opts.actions || [{ label: 'Close', value: null }];
    return new Promise(resolve => {
      dlgResolve = resolve;
      list.forEach(a => {
        const b = document.createElement('button'); b.type = 'button'; b.textContent = a.label;
        b.className = 'btn' + (a.primary ? ' primary' : '') + (a.danger ? ' danger' : '') + (a.left ? ' left' : '');
        b.onclick = async () => {
          if (a.onClick) { const r = await a.onClick(body); if (r === false) return; }
          const v = a.value !== undefined ? a.value : a.label; dlgResolve = null; dlg.close(); resolve(v);
        };
        actions.appendChild(b);
      });
      dlg.onclose = () => { if (dlgResolve) { const r = dlgResolve; dlgResolve = null; r(null); } if (opts.onClose) opts.onClose(); IS.focusGrid && IS.focusGrid(); };
      if (!dlg.open) dlg.showModal();
      if (opts.onOpen) opts.onOpen(body);
      const first = body.querySelector('[autofocus], input:not([type=hidden]):not([type=checkbox]):not([type=radio]), select, textarea');
      if (first && !opts.noFocus) setTimeout(() => { first.focus(); if (first.select && first.type !== 'color') first.select(); }, 30);
      body.querySelectorAll('input').forEach(inp => inp.addEventListener('keydown', e => {
        if (e.key === 'Enter' && !e.shiftKey && inp.type !== 'textarea') { const p = actions.querySelector('.btn.primary'); if (p) { e.preventDefault(); p.click(); } }
      }));
    });
  }
  function closeModal() { const d = $('dlg'); if (d.open) d.close(); }
  function confirm(message, opts = {}) {
    return modal({ title: opts.title || 'Please confirm', body: '<p>' + (opts.html ? message : esc(message)) + '</p>', actions: [{ label: opts.cancel || 'Cancel', value: false }, { label: opts.ok || 'OK', primary: !opts.danger, danger: !!opts.danger, value: true }] }).then(v => v === true);
  }
  function prompt(title, label, value, opts = {}) {
    let out = null;
    return modal({
      title, body: '<label class="field"><span>' + esc(label) + '</span><input id="promptInput" type="' + (opts.type || 'text') + '" value="' + esc(value || '') + '" ' + (opts.placeholder ? 'placeholder="' + esc(opts.placeholder) + '"' : '') + ' autocomplete="off"></label>' + (opts.hint ? '<p class="hint">' + esc(opts.hint) + '</p>' : ''),
      actions: [{ label: 'Cancel', value: null }, { label: opts.ok || 'OK', primary: true, onClick: () => { const v = $('promptInput').value; if (opts.validate) { const err = opts.validate(v); if (err) { IS.ui.toast(err, { type: 'error' }); return false; } } out = v; return true; }, value: '__ok' }]
    }).then(v => (v === '__ok' ? out : null));
  }

  // ---------------------------------------------------------------- popup menus
  let popStack = [];
  function closePopups() { popStack.forEach(p => p.remove()); popStack = []; document.querySelectorAll('.menubar .open').forEach(b => b.classList.remove('open')); }
  function placeEl(el, x, y, alignRight) {
    el.style.left = '0px'; el.style.top = '0px';
    document.body.appendChild(el);
    const r = el.getBoundingClientRect(), W = window.innerWidth, H = window.innerHeight;
    let left = alignRight ? x - r.width : x, top = y;
    if (left + r.width > W - 4) left = Math.max(4, W - r.width - 4);
    if (top + r.height > H - 4) top = Math.max(4, Math.min(y - r.height, H - r.height - 4));
    el.style.left = Math.max(4, left) + 'px'; el.style.top = Math.max(4, top) + 'px';
  }
  function menu(items, x, y, opts = {}) {
    if (!opts.sub) closePopups();
    const el = document.createElement('div');
    el.className = 'popup menu'; el.setAttribute('role', 'menu');
    items.filter(Boolean).forEach(it => {
      if (it.sep) { const s = document.createElement('div'); s.className = 'menu-sep'; el.appendChild(s); return; }
      if (it.header) { const h = document.createElement('div'); h.className = 'menu-head'; h.textContent = it.header; el.appendChild(h); return; }
      const b = document.createElement('button'); b.type = 'button'; b.className = 'menu-item'; b.setAttribute('role', 'menuitem');
      if (it.disabled) b.disabled = true;
      b.innerHTML = '<span class="mi-check">' + (it.checked ? '✓' : (it.icon ? icon(it.icon, 16) : '')) + '</span><span class="mi-label">' + (it.html || esc(it.label)) + '</span>' + (it.shortcut ? '<span class="mi-key">' + esc(it.shortcut) + '</span>' : '') + (it.sub ? '<span class="mi-arrow">›</span>' : '');
      if (it.sub) {
        const openSub = () => {
          while (popStack.length && popStack[popStack.length - 1] !== el && popStack.indexOf(el) >= 0 && popStack.indexOf(el) < popStack.length - 1) popStack.pop().remove();
          const r = b.getBoundingClientRect();
          const subItems = typeof it.sub === 'function' ? it.sub() : it.sub;
          const s = menu(subItems, r.right - 2, r.top - 4, { sub: true });
          s.dataset.parent = '1';
        };
        b.addEventListener('mouseenter', openSub);
        b.addEventListener('click', e => { e.stopPropagation(); openSub(); });
      } else {
        b.addEventListener('mouseenter', () => { const idx = popStack.indexOf(el); while (popStack.length > idx + 1) popStack.pop().remove(); });
        b.addEventListener('click', e => {
          e.stopPropagation(); closePopups();
          if (it.onClick) it.onClick(); else if (it.cmd) IS.run(it.cmd, it.arg);
        });
      }
      el.appendChild(b);
    });
    popStack.push(el);
    placeEl(el, x, y, opts.alignRight);
    el.addEventListener('keydown', e => {
      const btns = [...el.querySelectorAll('.menu-item:not(:disabled)')]; const i = btns.indexOf(document.activeElement);
      if (e.key === 'ArrowDown') { e.preventDefault(); (btns[i + 1] || btns[0]).focus(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); (btns[i - 1] || btns[btns.length - 1]).focus(); }
      else if (e.key === 'Escape') { e.preventDefault(); closePopups(); IS.focusGrid && IS.focusGrid(); }
      else if (e.key === 'ArrowRight' && document.activeElement) document.activeElement.click();
      else if (e.key === 'ArrowLeft' && opts.sub) { e.preventDefault(); popStack.pop().remove(); }
    });
    if (opts.focus) setTimeout(() => { const f = el.querySelector('.menu-item:not(:disabled)'); if (f) f.focus(); }, 10);
    return el;
  }
  /** Generic popover holding custom content */
  function popover(content, x, y, opts = {}) {
    if (!opts.keep) closePopups();
    const el = document.createElement('div'); el.className = 'popup pop ' + (opts.className || '');
    if (typeof content === 'string') el.innerHTML = content; else el.appendChild(content);
    popStack.push(el);
    placeEl(el, x, y, opts.alignRight);
    return el;
  }
  document.addEventListener('mousedown', e => { if (!popStack.length) return; if (popStack.some(p => p.contains(e.target))) return; if (e.target.closest && e.target.closest('.menubar button, [data-popup-owner]')) return; closePopups(); }, true);
  window.addEventListener('blur', () => { if (popStack.length && !document.hasFocus()) closePopups(); });
  window.addEventListener('resize', closePopups);

  // ---------------------------------------------------------------- colour palette
  const PALETTE = [
    '#000000', '#434343', '#666666', '#999999', '#b7b7b7', '#cccccc', '#d9d9d9', '#efefef', '#f3f3f3', '#ffffff',
    '#980000', '#ff0000', '#ff9900', '#ffff00', '#00ff00', '#00ffff', '#4a86e8', '#0000ff', '#9900ff', '#ff00ff',
    '#e6b8af', '#f4cccc', '#fce5cd', '#fff2cc', '#d9ead3', '#d0e0e3', '#c9daf8', '#cfe2f3', '#d9d2e9', '#ead1dc',
    '#dd7e6b', '#ea9999', '#f9cb9c', '#ffe599', '#b6d7a8', '#a2c4c9', '#a4c2f4', '#9fc5e8', '#b4a7d6', '#d5a6bd',
    '#cc4125', '#e06666', '#f6b26b', '#ffd966', '#93c47d', '#76a5af', '#6d9eeb', '#6fa8dc', '#8e7cc3', '#c27ba0',
    '#a61c00', '#cc0000', '#e69138', '#f1c232', '#6aa84f', '#45818e', '#3c78d8', '#3d85c6', '#674ea7', '#a64d79',
    '#0f7a3d', '#ff9933', '#1a3c8f', '#c62828', '#2e7d32', '#1565c0', '#6a1b9a', '#00838f', '#ef6c00', '#37474f'
  ];
  function palette(x, y, onPick, opts = {}) {
    const wrap = document.createElement('div');
    wrap.innerHTML = '<div class="pal-head"><button type="button" class="btn small" data-none="1">' + esc(opts.noneLabel || 'None / reset') + '</button></div>' +
      '<div class="pal-grid">' + PALETTE.map(c => '<button type="button" class="sw" title="' + c + '" data-c="' + c + '" style="background:' + c + '"></button>').join('') + '</div>' +
      '<label class="pal-custom">Custom <input type="color" value="' + (opts.value || '#0f7a3d') + '"></label>';
    const el = popover(wrap, x, y, { className: 'palette' });
    el.addEventListener('click', e => {
      const b = e.target.closest('button'); if (!b) return;
      closePopups(); onPick(b.dataset.none ? null : b.dataset.c);
    });
    el.querySelector('input[type=color]').addEventListener('change', e => { closePopups(); onPick(e.target.value); });
  }

  // ---------------------------------------------------------------- side panel
  let sideOnClose = null;
  function side(title, content, opts = {}) {
    const panel = $('sidePanel');
    if (sideOnClose) { const f = sideOnClose; sideOnClose = null; f(); }
    $('sideTitle').textContent = title;
    const body = $('sideBody'); body.innerHTML = '';
    if (typeof content === 'string') body.innerHTML = content; else if (content) body.appendChild(content);
    panel.hidden = false; panel.dataset.kind = opts.kind || '';
    sideOnClose = opts.onClose || null;
    IS.grid && IS.grid.resize && setTimeout(() => IS.grid.resize(), 0);
    return body;
  }
  function closeSide() {
    const panel = $('sidePanel'); if (panel.hidden) return;
    panel.hidden = true; panel.dataset.kind = '';
    if (sideOnClose) { const f = sideOnClose; sideOnClose = null; f(); }
    IS.grid && IS.grid.resize && setTimeout(() => IS.grid.resize(), 0);
    IS.focusGrid && IS.focusGrid();
  }
  document.addEventListener('click', e => { if (e.target.closest && e.target.closest('#sideClose')) closeSide(); });

  function download(name, data, type) {
    const blob = data instanceof Blob ? data : new Blob([data], { type: type || 'application/octet-stream' });
    const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = name;
    document.body.appendChild(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(a.href), 4000);
  }
  function loadScript(src) {
    return new Promise((res, rej) => {
      if (document.querySelector('script[data-src="' + src + '"]')) { res(); return; }
      const s = document.createElement('script'); s.src = src; s.dataset.src = src; s.onload = () => res(); s.onerror = () => { s.remove(); rej(new Error('Could not load ' + src)); };
      document.head.appendChild(s);
    });
  }
  const fmtDateTime = t => new Date(t).toLocaleString('en-IN', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
  const ago = t => { const s = (Date.now() - t) / 1000; if (s < 60) return 'just now'; if (s < 3600) return Math.floor(s / 60) + ' min ago'; if (s < 86400) return Math.floor(s / 3600) + ' h ago'; if (s < 86400 * 7) return Math.floor(s / 86400) + ' day' + (s >= 172800 ? 's' : '') + ' ago'; return new Date(t).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' }); };

  IS.ui = { icon, toast, busy, done, nextFrame, modal, closeModal, confirm, prompt, menu, popover, closePopups, palette, side, closeSide, download, loadScript, esc, fmtDateTime, ago, PALETTE, get popupOpen() { return popStack.length > 0; } };
  IS.esc = esc;
})(window);
