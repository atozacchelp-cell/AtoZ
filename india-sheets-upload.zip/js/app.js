/* India Sheets – application controller: editing, selection, keyboard, mouse, clipboard, undo, sheets, menus */
(function (global) {
  'use strict';
  const IS = global.IS, X = global.Formula, ui = IS.ui;
  const $ = id => document.getElementById(id);
  const esc = ui.esc, K = IS.K;
  const A1 = (r, c) => X.numToCol(c) + (r + 1);
  const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v));
  const isMac = /Mac|iPhone|iPad/.test(navigator.platform);
  const REF_COLORS = ['#1e6fd9', '#d32f2f', '#7b1fa2', '#2e7d32', '#ef6c00', '#00838f', '#c2185b', '#5d4037'];

  const state = IS.state = {
    wb: null, sel: { r: 0, c: 0, r2: 0, c2: 0 }, editing: null, refBoxes: null, clipRect: null, antsOffset: 0, fillPreview: null,
    findHits: null, trace: null, showFormulas: false, readOnly: false, dirty: false, formatPainter: null, zoom: 1
  };
  let grid, calc, editor, fx;
  const sheetSel = new Map();
  Object.defineProperty(IS, 'wb', { get: () => state.wb });
  Object.defineProperty(IS, 'sheet', { get: () => state.wb.sheets[state.wb.active] });
  const cur = () => state.wb.sheets[state.wb.active];
  const sheetById = id => state.wb.sheets.find(s => s.id === id) || null;
  const sheetByName = n => state.wb.sheets.find(s => s.name.toUpperCase() === String(n).toUpperCase()) || null;
  IS.sheetById = sheetById; IS.sheetByName = sheetByName;

  // ======================================================================= undo / transactions
  let tx = null;
  const undoStack = [], redoStack = [];
  const jclone = o => (o === undefined ? undefined : JSON.parse(JSON.stringify(o)));
  const metaOf = sh => { const o = {}; for (const k in sh) if (k !== 'cells') o[k] = sh[k]; return jclone(o); };
  function beginTx(label) { tx = { label, cells: new Map(), sheets: new Map(), metas: new Map(), book: null, layout: false, sel: { ...state.sel }, active: state.wb.active }; }
  function recCell(sh, key) {
    if (!tx || tx.sheets.has(sh.id)) return;
    const gk = sh.id + '!' + key;
    if (!tx.cells.has(gk)) tx.cells.set(gk, { sid: sh.id, key, before: IS.cloneCell(sh.cells[key]) });
  }
  function recMeta(sh) { if (tx && !tx.metas.has(sh.id) && !tx.sheets.has(sh.id)) tx.metas.set(sh.id, metaOf(sh)); if (tx) tx.layout = true; }
  function recSheet(sh) { if (tx && !tx.sheets.has(sh.id)) { tx.sheets.set(sh.id, jclone(sh)); tx.layout = true; } }
  function recBook() { if (tx && !tx.book) { tx.book = { sheets: state.wb.sheets.slice(), names: jclone(state.wb.names), active: state.wb.active, name: state.wb.name }; tx.layout = true; } }
  function applyEntry(e) {
    const wb = state.wb;
    const inv = { label: e.label, cells: new Map(), sheets: new Map(), metas: new Map(), book: null, layout: e.layout, sel: { ...state.sel }, active: wb.active };
    if (e.book) { inv.book = { sheets: wb.sheets.slice(), names: jclone(wb.names), active: wb.active, name: wb.name }; wb.sheets = e.book.sheets.slice(); wb.names = jclone(e.book.names); wb.name = e.book.name; }
    for (const [sid, snap] of e.sheets) {
      const i = wb.sheets.findIndex(s => s.id === sid); if (i < 0) continue;
      inv.sheets.set(sid, jclone(wb.sheets[i])); wb.sheets[i] = jclone(snap);
    }
    for (const [sid, meta] of e.metas) {
      const sh = sheetById(sid); if (!sh) continue;
      inv.metas.set(sid, metaOf(sh));
      for (const k of Object.keys(sh)) if (k !== 'cells' && !(k in meta)) delete sh[k];
      Object.assign(sh, jclone(meta)); IS.invalidateHidden(sh);
    }
    for (const [gk, rec] of e.cells) {
      const sh = sheetById(rec.sid); if (!sh) continue;
      inv.cells.set(gk, { sid: rec.sid, key: rec.key, before: IS.cloneCell(sh.cells[rec.key]) });
      if (rec.before) sh.cells[rec.key] = IS.cloneCell(rec.before); else delete sh.cells[rec.key];
    }
    wb.active = clamp(e.active, 0, wb.sheets.length - 1);
    state.sel = { ...e.sel };
    return inv;
  }
  function afterChange(t, full) {
    const structural = full || t.sheets.size || t.book || t.metas.size;
    if (full || t.book || t.sheets.size) calc.full();
    else if (t.cells.size) calc.changed([...t.cells.values()].map(x => { const i = x.key.indexOf(':'); return { sid: x.sid, r: +x.key.slice(0, i), c: +x.key.slice(i + 1) }; }));
    IS.cfInvalidate();
    if (grid.sheet !== cur()) grid.sheet = cur();
    if (structural || t.layout) { cur().merges = cur().merges || []; IS.invalidateHidden(cur()); grid.layout(); }
    grid.invalidate(); renderTabs(); afterSel(); markDirty();
    IS.emit('change', t);
  }
  /** Run fn as one undoable step. */
  IS.tx = function (label, fn, opts = {}) {
    if (tx) return fn();
    beginTx(label);
    let result;
    try { result = fn(); }
    catch (e) {
      const t = tx; tx = null; applyEntry(t); calc.full(); grid.layout();
      console.error(e); ui.toast('Something went wrong: ' + (e.message || e), { type: 'error' }); return undefined;
    }
    const t = tx; tx = null;
    if (opts.layout) t.layout = true;
    if (!t.cells.size && !t.sheets.size && !t.metas.size && !t.book) { if (t.layout) { grid.layout(); grid.invalidate(); } return result; }
    undoStack.push(t); if (undoStack.length > 200) undoStack.shift(); redoStack.length = 0;
    afterChange(t, opts.full);
    return result;
  };
  IS.rec = { cell: recCell, meta: recMeta, sheet: recSheet, book: recBook };
  function undo() { if (state.editing) { cancelEdit(); return; } const e = undoStack.pop(); if (!e) { ui.toast('Nothing to undo'); return; } const inv = applyEntry(e); redoStack.push(inv); afterChange(inv, true); ui.toast('Undone: ' + e.label, { ms: 1600 }); }
  function redo() { const e = redoStack.pop(); if (!e) { ui.toast('Nothing to redo'); return; } const inv = applyEntry(e); undoStack.push(inv); afterChange(inv, true); ui.toast('Redone: ' + e.label, { ms: 1600 }); }

  // ======================================================================= cell writing
  function putCell(sh, r, c, cell) {
    const key = K(r, c); recCell(sh, key);
    if (cell && (IS.hasValue(cell) || cell.s || cell.n || cell.t)) { if (!IS.hasValue(cell)) { delete cell.v; delete cell.t; } if (cell.s) { cell.s = IS.cleanStyle(cell.s); if (!cell.s) delete cell.s; } if (IS.hasValue(cell) || cell.s || cell.n) sh.cells[key] = cell; else delete sh.cells[key]; }
    else delete sh.cells[key];
    if (r >= sh.rows) sh.rows = Math.min(1048576, r + 100);
    if (c >= sh.cols) sh.cols = Math.min(16384, c + 5);
  }
  function editCell(sh, r, c, fn) {
    const key = K(r, c); recCell(sh, key);
    const cell = sh.cells[key] ? IS.cloneCell(sh.cells[key]) : {};
    fn(cell);
    putCell(sh, r, c, cell);
  }
  IS.putCell = putCell; IS.editCell = editCell;
  /** Store typed text into a cell (inside a transaction). */
  function writeText(sh, r, c, text) {
    editCell(sh, r, c, cell => {
      const e = IS.parseEntry(text, cell);
      if (e.v === null) { delete cell.v; delete cell.t; return; }
      cell.v = e.v; if (e.t) cell.t = e.t; else delete cell.t;
      if (e.nf && !(cell.s && cell.s.nf)) cell.s = Object.assign({}, cell.s, { nf: e.nf });
      if (IS.isFormulaCell(cell) && !(cell.s && cell.s.nf)) { const nf = inferFormat(sh, cell.v); if (nf) cell.s = Object.assign({}, cell.s, { nf }); }
    });
  }
  IS.writeText = writeText;
  function inferFormat(sh, f) {
    if (/^=\s*(TODAY|DATE|EDATE|EOMONTH|WORKDAY|DATEVALUE|FYSTART|FYEND)\s*\(/i.test(f)) return 'dd-mm-yyyy';
    if (/^=\s*NOW\s*\(/i.test(f)) return 'dd-mm-yyyy hh:mm';
    if (/^=\s*(EMI|PMT|WITHGST|REMOVEGST|GST|CGST|SGST|IGST)\s*\(/i.test(f)) return '"₹"#,##0.00';
    const refs = X.refsInFormula(f); if (!refs.length) return null;
    const rf = refs[0]; const s2 = rf.sheet ? sheetByName(rf.sheet) : sh; if (!s2) return null;
    const cell = s2.cells[K(rf.r1, rf.c1)]; const nf = cell && cell.s && cell.s.nf;
    if (!nf) return null;
    if (/^=\s*(SUM|AVERAGE|MIN|MAX|SUMIF|SUMIFS|AVERAGEIF|ROUND|SUBTOTAL)\(/i.test(f) || /^=[A-Z$]+\d+\s*[-+]/.test(f)) {
      if (/₹|\$|#,##0/.test(nf) || X.isDateFormat(nf)) return nf;
    }
    if (/^=\s*\$?[A-Z]+\$?\d+\s*[*\/+-]/.test(f) && /₹/.test(nf)) return nf;
    return null;
  }

  // ======================================================================= selection
  IS.selRect = () => {
    const s = state.sel, sh = cur();
    return IS.expandRect(sh, { t: Math.min(s.r, s.r2), l: Math.min(s.c, s.c2), b: Math.max(s.r, s.r2), r: Math.max(s.c, s.c2) });
  };
  IS.activeSpill = () => { const sh = cur(), s = state.sel; const a = calc.spillArea(sh, s.r, s.c); if (a) return a; const an = calc.spillAnchor(sh, s.r, s.c); return an ? calc.spillArea(sh, an.r, an.c) : null; };
  function setSel(r, c, r2, c2, opts = {}) {
    const sh = cur();
    r = clamp(r, 0, sh.rows - 1); c = clamp(c, 0, sh.cols - 1);
    if (r2 === undefined) { r2 = r; c2 = c; }
    r2 = clamp(r2, 0, sh.rows - 1); c2 = clamp(c2, 0, sh.cols - 1);
    const m = IS.mergeAt(sh, r, c);
    if (m) { r = m.r; c = m.c; if (r2 === m.r && c2 === m.c || (opts.single)) { r2 = m.r; c2 = m.c; } }
    state.sel = { r, c, r2, c2 };
    if (opts.scroll !== false) grid.scrollIntoView(opts.scrollR != null ? opts.scrollR : r2, opts.scrollC != null ? opts.scrollC : c2);
    afterSel();
  }
  IS.setSel = setSel;
  function afterSel() {
    grid && grid.invalidate();
    if (!state.editing) updateFx();
    updateNameBox(); updateStats(); syncToolbar();
    IS.emit('select');
  }
  IS.afterSel = afterSel;
  function step(sh, r, c, dr, dc) {
    const m = IS.mergeAt(sh, r, c);
    if (m) { if (dr > 0) r = m.r2; if (dr < 0) r = m.r; if (dc > 0) c = m.c2; if (dc < 0) c = m.c; }
    r += dr; c += dc;
    while (dr && r > 0 && r < sh.rows - 1 && !IS.rowVisible(sh, r)) r += dr;
    while (dc && c > 0 && c < sh.cols - 1 && !IS.colVisible(sh, c)) c += dc;
    r = clamp(r, 0, sh.rows - 1); c = clamp(c, 0, sh.cols - 1);
    return [r, c];
  }
  /** Enter after typing across a row with Tab returns to the column where the row started (like Excel) */
  function enterMove(dr) {
    const R = IS.selRect();
    if (state.tabStart != null && dr > 0 && R.t === R.b && R.l === R.r) { const c = state.tabStart; state.tabStart = null; setSel(state.sel.r + 1, c); return; }
    state.tabStart = null;
    moveWithin(dr, 0);
  }
  function move(dr, dc, extend) {
    state.tabStart = null;
    const sh = cur(), s = state.sel;
    if (extend) { const [r2, c2] = step(sh, s.r2, s.c2, dr, dc); setSel(s.r, s.c, r2, c2, { scrollR: r2, scrollC: c2 }); }
    else { const [r, c] = step(sh, s.r, s.c, dr, dc); setSel(r, c); }
  }
  /** Enter/Tab inside a multi-cell selection moves within it */
  function moveWithin(dr, dc) {
    const R = IS.selRect(), s = state.sel;
    if (R.t === R.b && R.l === R.r) { const ts = state.tabStart; move(dr, dc); state.tabStart = ts; return; }
    let r = s.r, c = s.c;
    if (dc) { c += dc; if (c > R.r) { c = R.l; r++; } if (c < R.l) { c = R.r; r--; } if (r > R.b) r = R.t; if (r < R.t) r = R.b; }
    else { r += dr; if (r > R.b) { r = R.t; c++; } if (r < R.t) { r = R.b; c--; } if (c > R.r) c = R.l; if (c < R.l) c = R.r; }
    state.sel = { r, c, r2: s.r2, c2: s.c2 }; grid.scrollIntoView(r, c); afterSel();
  }
  const hasContent = (sh, r, c) => { const cell = sh.cells[K(r, c)]; if (IS.hasValue(cell)) return true; const v = calc.value(sh, r, c); return v !== null && v !== undefined && v !== ''; };
  IS.hasContent = hasContent;
  function jump(dr, dc, extend) {
    const sh = cur(), s = state.sel;
    let r = extend ? s.r2 : s.r, c = extend ? s.c2 : s.c;
    const inb = (r, c) => r >= 0 && c >= 0 && r < sh.rows && c < sh.cols;
    const vis = (r, c) => IS.rowVisible(sh, r) && IS.colVisible(sh, c);
    const nxt = () => { let nr = r + dr, nc = c + dc; while (inb(nr, nc) && !vis(nr, nc)) { nr += dr; nc += dc; } return [nr, nc]; };
    let [nr, nc] = nxt();
    if (hasContent(sh, r, c) && inb(nr, nc) && hasContent(sh, nr, nc)) {
      while (inb(nr, nc) && hasContent(sh, nr, nc)) { r = nr; c = nc; [nr, nc] = nxt(); }
    } else {
      const used = IS.usedRange(sh); const limR = dr > 0 ? Math.max(used.b + 1, r + 1) : 0, limC = dc > 0 ? Math.max(used.r + 1, c + 1) : 0;
      r = nr; c = nc;
      while (inb(r, c) && !hasContent(sh, r, c)) {
        if ((dr > 0 && r >= limR) || (dc > 0 && c >= limC) || (dr < 0 && r <= 0) || (dc < 0 && c <= 0)) break;
        const [a, b] = nxt(); if (!inb(a, b)) break; r = a; c = b;
      }
      r = clamp(r, 0, sh.rows - 1); c = clamp(c, 0, sh.cols - 1);
    }
    if (extend) setSel(s.r, s.c, r, c, { scrollR: r, scrollC: c }); else setSel(r, c);
  }
  function selectAll() {
    const sh = cur(), used = IS.usedRange(sh), R = IS.selRect();
    // first Ctrl+A selects the data region, second selects everything
    const reg = currentRegion(sh, state.sel.r, state.sel.c);
    if (reg && !(R.t === reg.t && R.l === reg.l && R.b === reg.b && R.r === reg.r) && !(reg.t === reg.b && reg.l === reg.r)) setSel(reg.t, reg.l, reg.b, reg.r, { scroll: false });
    else setSel(0, 0, Math.max(sh.rows - 1, used.b), Math.max(sh.cols - 1, used.r), { scroll: false });
    state.sel.r = state.sel.r; afterSel();
  }
  /** Contiguous block of data around a cell (like Ctrl+A / current region in Excel) */
  function currentRegion(sh, r, c) {
    if (!hasContent(sh, r, c)) {
      let found = false;
      for (const [dr, dc] of [[0, 1], [0, -1], [1, 0], [-1, 0]]) if (r + dr >= 0 && c + dc >= 0 && hasContent(sh, r + dr, c + dc)) { r += dr; c += dc; found = true; break; }
      if (!found) return null;
    }
    let t = r, b = r, l = c, rr = c, grew = true;
    const rowHas = (row, c1, c2) => { for (let x = Math.max(0, c1); x <= c2; x++) if (hasContent(sh, row, x)) return true; return false; };
    const colHas = (col, r1, r2) => { for (let y = Math.max(0, r1); y <= r2; y++) if (hasContent(sh, y, col)) return true; return false; };
    let guard = 0;
    while (grew && guard++ < 5000) {
      grew = false;
      if (t > 0 && rowHas(t - 1, l - 1, rr + 1)) { t--; grew = true; }
      if (rowHas(b + 1, l - 1, rr + 1) && b + 1 < sh.rows) { b++; grew = true; }
      if (l > 0 && colHas(l - 1, t - 1, b + 1)) { l--; grew = true; }
      if (colHas(rr + 1, t - 1, b + 1) && rr + 1 < sh.cols) { rr++; grew = true; }
    }
    return { t, l, b, r: rr };
  }
  IS.currentRegion = currentRegion;

  // ======================================================================= editing
  const activeInput = () => (state.editing && state.editing.src === 'fx' ? fx : editor);
  function guardEdit(R, opts = {}) {
    if (state.readOnly) { ui.toast(state.readOnlyMsg || 'This view is read-only.'); return false; }
    if (!IS.Licence.canEdit()) { IS.run('plan'); return false; }
    const sh = opts.sheet || cur();
    if (sh.protect && sh.protect.on) {
      if (opts.structure || !R) { ui.toast('This sheet is protected. Use Data → Protect sheet to unlock it.', { type: 'warn' }); return false; }
      for (let r = R.t; r <= Math.min(R.b, R.t + 2000); r++) for (let c = R.l; c <= Math.min(R.r, R.l + 200); c++) {
        const cell = sh.cells[K(r, c)];
        if (!(cell && cell.s && cell.s.unlock)) { ui.toast('This cell is protected. Unprotect the sheet to edit it.', { type: 'warn' }); return false; }
      }
    }
    return true;
  }
  IS.guardEdit = guardEdit;
  function startEdit(initial, mode, src) {
    const s = state.sel, sh = cur();
    if (!guardEdit({ t: s.r, l: s.c, b: s.r, r: s.c })) return;
    const anchor = calc.spillAnchor(sh, s.r, s.c);
    if (anchor && initial == null && !IS.hasValue(sh.cells[K(s.r, s.c)])) { ui.toast('This cell shows a spilled result from ' + A1(anchor.r, anchor.c) + '. Edit that cell instead.'); return; }
    const text = initial != null ? initial : IS.editText(sh, s.r, s.c);
    state.editing = { r: s.r, c: s.c, sheetId: sh.id, mode: mode || 'edit', src: src || 'cell', point: null };
    editor.value = text; fx.value = text;
    styleEditor();
    editor.hidden = false;
    positionEditor();
    if ((src || 'cell') === 'cell') { editor.focus({ preventScroll: true }); editor.setSelectionRange(text.length, text.length); }
    updateRefBoxes(); updateHint(); grid.invalidate();
    document.body.classList.add('editing');
  }
  IS.startEdit = startEdit;
  function styleEditor() {
    const ed = state.editing; if (!ed) return;
    const sh = sheetById(ed.sheetId); const cell = sh.cells[K(ed.r, ed.c)]; const s = (cell && cell.s) || {};
    editor.style.font = IS.GridPaint.fontOf(s, grid.z);
    editor.style.textAlign = s.al === 'right' ? 'right' : s.al === 'center' ? 'center' : 'left';
    editor.style.color = s.color || '';
    editor.style.background = s.bg || '';
  }
  function positionEditor() {
    const ed = state.editing; if (!ed || editor.hidden) return;
    if (ed.sheetId !== cur().id) { editor.style.display = 'none'; return; }
    const rr = grid.cellRect(ed.r, ed.c);
    const visible = rr.x + rr.w > grid.hw && rr.y + rr.h > grid.hh && rr.x < grid.vw && rr.y < grid.vh;
    editor.style.display = visible ? 'block' : 'none';
    editor.style.left = rr.x + 'px'; editor.style.top = rr.y + 'px';
    editor.style.minWidth = rr.w + 'px'; editor.style.minHeight = rr.h + 'px';
    editor.style.width = rr.w + 'px'; editor.style.height = rr.h + 'px';
    // grow to fit the text
    const maxW = Math.max(rr.w, grid.vw - rr.x - 4);
    const meas = IS.GridPaint.measureCanvas; meas.font = editor.style.font;
    const lines = editor.value.split('\n');
    const w = Math.max(...lines.map(l => meas.measureText(l).width)) + 18;
    editor.style.width = Math.min(maxW, Math.max(rr.w, w)) + 'px';
    editor.style.height = 'auto';
    editor.style.height = Math.max(rr.h, editor.scrollHeight) + 'px';
  }
  function endEditUI() {
    state.editing = null; state.refBoxes = null;
    editor.hidden = true; editor.value = ''; hideHint();
    document.body.classList.remove('editing');
    if (document.activeElement === editor || document.activeElement === fx) focusGrid();
    updateFx(); grid.invalidate();
  }
  function cancelEdit() {
    const ed = state.editing; if (!ed) return;
    const back = ed.sheetId !== cur().id ? ed.sheetId : null;
    endEditUI();
    if (back) activateSheet(state.wb.sheets.findIndex(s => s.id === back));
    if (ed.prevSel) state.sel = ed.prevSel;
    afterSel();
  }
  IS.cancelEdit = cancelEdit;
  /** Save what was typed. Returns false if the value is rejected. */
  function commitEdit(opts = {}) {
    const ed = state.editing; if (!ed) return true;
    const text = activeInput().value;
    const sh = sheetById(ed.sheetId); if (!sh) { endEditUI(); return true; }
    const cell = sh.cells[K(ed.r, ed.c)];
    const entry = IS.parseEntry(text, cell);
    const rule = IS.dvFor(sh, ed.r, ed.c);
    if (rule && rule.strict !== false && entry.v !== null && !(typeof entry.v === 'string' && entry.v[0] === '=' && !entry.t)) {
      if (!IS.dvCheck(sh, rule, entry.v, ed.r, ed.c)) { ui.toast(IS.dvMessage(rule), { type: 'error' }); activeInput().focus(); return false; }
    }
    if (typeof entry.v === 'string' && entry.v[0] === '=' && !entry.t) {
      const chk = X.checkFormula(entry.v);
      if (chk !== true && !opts.force) { ui.toast('There is a problem with this formula: ' + chk + '. Press Esc to cancel or fix it.', { type: 'error', ms: 5000 }); activeInput().focus(); return false; }
    }
    const back = ed.sheetId !== cur().id;
    endEditUI();
    if (back) { activateSheet(state.wb.sheets.findIndex(s => s.id === ed.sheetId)); if (ed.prevSel) state.sel = ed.prevSel; }
    if (text === IS.editText(sh, ed.r, ed.c) && !opts.fill) { afterSel(); return true; }
    IS.tx('Edit ' + A1(ed.r, ed.c), () => {
      if (opts.fill) {
        const R = IS.selRect();
        for (let r = R.t; r <= R.b; r++) for (let c = R.l; c <= R.r; c++) {
          if (IS.isCovered(sh, r, c)) continue;
          const t = typeof entry.v === 'string' && entry.v[0] === '=' ? X.shiftFormula(entry.v, r - ed.r, c - ed.c) : text;
          writeText(sh, r, c, t);
        }
      } else writeText(sh, ed.r, ed.c, text);
    });
    return true;
  }
  IS.commitEdit = commitEdit;
  function canPoint() {
    const ed = state.editing; if (!ed) return false;
    const inp = activeInput(); const v = inp.value;
    if (!v.startsWith('=')) return false;
    if (ed.point && inp.selectionStart === ed.point.end) return true;
    const before = v.slice(0, inp.selectionStart).replace(/\s+$/, '');
    return '=(,;+-*/^&<>:'.includes(before[before.length - 1]);
  }
  function pointTo(r, c, r2, c2) {
    const ed = state.editing, inp = activeInput();
    if (r2 === undefined) { r2 = r; c2 = c; }
    let ref = A1(Math.min(r, r2), Math.min(c, c2));
    if (r !== r2 || c !== c2) ref += ':' + A1(Math.max(r, r2), Math.max(c, c2));
    if (cur().id !== ed.sheetId) ref = X.quoteSheet(cur().name) + '!' + ref;
    let text = inp.value, start;
    if (ed.point && inp.selectionStart === ed.point.end) { start = ed.point.start; text = text.slice(0, start) + ref + text.slice(ed.point.end); }
    else { start = inp.selectionStart; text = text.slice(0, start) + ref + text.slice(inp.selectionEnd); }
    ed.point = { start, end: start + ref.length, r, c, r2, c2 };
    inp.value = text; inp.setSelectionRange(ed.point.end, ed.point.end);
    mirror(inp); updateRefBoxes(); grid.invalidate();
  }
  function mirror(from) { if (from === editor) fx.value = editor.value; else editor.value = fx.value; positionEditor(); autoSizeFx(); }
  function updateRefBoxes() {
    const ed = state.editing;
    if (!ed) { state.refBoxes = null; return; }
    const text = activeInput().value;
    if (!text.startsWith('=')) { state.refBoxes = null; return; }
    const editSheet = sheetById(ed.sheetId);
    state.refBoxes = X.refsInFormula(text).map((rf, i) => {
      const s = rf.sheet ? sheetByName(rf.sheet) : editSheet;
      return { t: rf.r1, l: rf.c1, b: rf.r2, r: rf.c2, color: REF_COLORS[i % REF_COLORS.length], sheetId: s ? s.id : null, dashed: !!(ed.point && i === X.refsInFormula(text).findIndex(x => x.end === ed.point.end)) };
    });
  }
  function toggleAbsolute() {
    const inp = activeInput(); const text = inp.value, pos = inp.selectionStart;
    const refs = X.refsInFormula(text); const rf = refs.find(x => pos >= x.start && pos <= x.end); if (!rf) return;
    let part = text.slice(rf.start, rf.end);
    const cycle = p => p.replace(/(\$?)([A-Za-z]{1,3})(\$?)(\d+)/g, (m, a, col, b, row) => { const st = (a ? 2 : 0) + (b ? 1 : 0); const nx = { 0: 3, 3: 1, 1: 2, 2: 0 }[st]; return (nx & 2 ? '$' : '') + col + (nx & 1 ? '$' : '') + row; });
    const bang = part.lastIndexOf('!');
    part = bang >= 0 ? part.slice(0, bang + 1) + cycle(part.slice(bang + 1)) : cycle(part);
    inp.value = text.slice(0, rf.start) + part + text.slice(rf.end);
    inp.setSelectionRange(rf.start + part.length, rf.start + part.length);
    mirror(inp); updateRefBoxes(); grid.invalidate();
  }

  // ---- function autocomplete / argument hints
  let hint = null; let hintEl;
  function updateHint() {
    const ed = state.editing; const inp = activeInput();
    if (!ed || !inp.value.startsWith('=')) return hideHint();
    const before = inp.value.slice(0, inp.selectionStart);
    if ((before.match(/"/g) || []).length % 2) return hideHint();
    const m = before.match(/([A-Za-z_][A-Za-z0-9._]*)$/);
    const info = X.FN_INFO;
    if (m && !/^[A-Za-z]{1,3}\d+$/.test(m[1]) && !/^\d/.test(m[1])) {
      const q = m[1].toUpperCase();
      const names = Object.keys(state.wb.names || {}).filter(n => n.startsWith(q)).map(n => ({ name: n, sig: n, desc: 'Named range → ' + state.wb.names[n].ref, isName: true }));
      const fns = X.FUNCTION_NAMES.filter(n => n.startsWith(q) && !n.includes('.')).sort((a, b) => (info[b] ? 1 : 0) - (info[a] ? 1 : 0) || a.length - b.length || a.localeCompare(b)).slice(0, 10).map(n => ({ name: n, sig: info[n] ? info[n].sig : n + '()', desc: info[n] ? info[n].desc : '' }));
      const items = names.concat(fns).slice(0, 10);
      if (items.length) return showHint(items, 0, before.length - m[1].length);
    }
    const fnName = innermostFn(before);
    if (fnName && info[fnName]) return showHint([{ name: fnName, sig: info[fnName].sig, desc: info[fnName].desc, info: true, argIndex: argIndex(before) }], 0, null);
    hideHint();
  }
  function innermostFn(text) {
    let depth = 0, inStr = false;
    for (let i = text.length - 1; i >= 0; i--) {
      const ch = text[i]; if (ch === '"') inStr = !inStr; if (inStr) continue;
      if (ch === ')') depth++;
      else if (ch === '(') { if (depth === 0) { const m = text.slice(0, i).match(/([A-Za-z_][A-Za-z0-9._]*)\s*$/); return m ? m[1].toUpperCase() : null; } depth--; }
    }
    return null;
  }
  function argIndex(text) { let depth = 0, n = 0, inStr = false; for (let i = text.length - 1; i >= 0; i--) { const ch = text[i]; if (ch === '"') inStr = !inStr; if (inStr) continue; if (ch === ')') depth++; else if (ch === '(') { if (!depth) break; depth--; } else if ((ch === ',' || ch === ';') && !depth) n++; } return n; }
  function showHint(items, idx, start) {
    hint = { items, idx, start };
    const it0 = items[0];
    let html;
    if (it0.info) {
      const parts = it0.sig.replace(/^[^(]*\(|\)$/g, '').split(/,\s*/);
      const sig = it0.name + '(' + parts.map((p, i) => (i === Math.min(it0.argIndex, parts.length - 1) && p ? '<b class="arg-on">' + esc(p) + '</b>' : esc(p))).join(', ') + ')';
      html = '<div class="hint-sig">' + sig + '</div><div class="hint-desc">' + esc(it0.desc) + '</div>';
    } else {
      html = items.map((it, i) => '<div class="hint-item' + (i === idx ? ' on' : '') + '" data-i="' + i + '"><b>' + esc(it.name) + '</b><span>' + esc(it.desc || it.sig) + '</span></div>').join('') + '<div class="hint-foot">Tab to insert · ↑ ↓ to choose</div>';
    }
    hintEl.innerHTML = html; hintEl.hidden = false;
    const r = activeInput().getBoundingClientRect();
    hintEl.style.left = Math.min(r.left, window.innerWidth - 380) + 'px';
    hintEl.style.top = (r.bottom + 2) + 'px';
  }
  function hideHint() { hint = null; if (hintEl) hintEl.hidden = true; }
  function acceptHint(i) {
    if (!hint || hint.start === null) return false;
    const inp = activeInput(), it = hint.items[i], pos = inp.selectionStart;
    const add = it.isName ? it.name : it.name + '(';
    inp.value = inp.value.slice(0, hint.start) + add + inp.value.slice(pos);
    const np = hint.start + add.length; inp.setSelectionRange(np, np);
    mirror(inp); updateHint(); updateRefBoxes(); grid.invalidate();
    return true;
  }

  // ======================================================================= formula bar / name box / status
  function updateFx() {
    if (!fx) return;
    const sh = cur(), s = state.sel;
    const anchor = calc.spillAnchor(sh, s.r, s.c);
    if (anchor && !IS.hasValue(sh.cells[K(s.r, s.c)])) { fx.value = IS.editText(sh, anchor.r, anchor.c); fx.classList.add('ghost'); }
    else { fx.value = IS.editText(sh, s.r, s.c); fx.classList.remove('ghost'); }
    autoSizeFx();
  }
  function autoSizeFx() { fx.style.height = 'auto'; fx.style.height = Math.min(120, Math.max(26, fx.scrollHeight)) + 'px'; }
  function updateNameBox() {
    const nb = $('nameBox'); if (!nb || document.activeElement === nb) return;
    const R = IS.selRect(), s = state.sel, sh = cur();
    if (R.t === 0 && R.b >= sh.rows - 1 && R.l === R.r) nb.value = X.numToCol(R.l) + ':' + X.numToCol(R.r);
    else if (R.l === 0 && R.r >= sh.cols - 1 && R.t === R.b) nb.value = (R.t + 1) + ':' + (R.b + 1);
    else {
      const m = IS.mergeAt(sh, s.r, s.c);
      const single = (R.t === R.b && R.l === R.r) || (m && m.r === R.t && m.c === R.l && m.r2 === R.b && m.c2 === R.r);
      nb.value = single ? A1(s.r, s.c) : A1(R.t, R.l) + ':' + A1(R.b, R.r);
    }
    for (const n in state.wb.names) { const p = X.parseRef(state.wb.names[n].ref); if (p && (!p.sheet || p.sheet.toUpperCase() === sh.name.toUpperCase()) && p.r1 === R.t && p.c1 === R.l && p.r2 === R.b && p.c2 === R.r) { nb.value = n; break; } }
  }
  let statsTimer = null;
  function updateStats() {
    clearTimeout(statsTimer);
    statsTimer = setTimeout(() => {
      const el = $('stats'); if (!el) return;
      const R = IS.selRect(), sh = cur();
      if (R.t === R.b && R.l === R.r) { el.innerHTML = ''; return; }
      let sum = 0, n = 0, cnt = 0, mn = Infinity, mx = -Infinity;
      const area = (R.b - R.t + 1) * (R.r - R.l + 1);
      const visit = (r, c) => { if (!IS.rowVisible(sh, r)) return; const v = X.norm(calc.value(sh, r, c)); if (v === null || v === undefined || v === '') return; cnt++; if (typeof v === 'number') { sum += v; n++; if (v < mn) mn = v; if (v > mx) mx = v; } };
      if (area < 20000) { for (let r = R.t; r <= R.b; r++) for (let c = R.l; c <= R.r; c++) visit(r, c); }
      else { const vals = calc.vals.get(sh.id) || new Map(); for (const k of vals.keys()) { const i = k.indexOf(':'); const r = +k.slice(0, i), c = +k.slice(i + 1); if (r >= R.t && r <= R.b && c >= R.l && c <= R.r) visit(r, c); } }
      const f = x => (Math.abs(x) >= 1e15 ? x.toExponential(3) : x.toLocaleString('en-IN', { maximumFractionDigits: 2 }));
      el.innerHTML = n ? '<span>Sum <b>' + f(sum) + '</b></span><span>Avg <b>' + f(sum / n) + '</b></span><span class="hide-sm">Min <b>' + f(mn) + '</b></span><span class="hide-sm">Max <b>' + f(mx) + '</b></span><span>Count <b>' + cnt + '</b></span>' : (cnt ? '<span>Count <b>' + cnt + '</b></span>' : '');
    }, 60);
  }
  IS.updateStats = updateStats;

  // ======================================================================= toolbar state
  function syncToolbar() {
    const sh = cur(), s = state.sel; const cell = sh.cells[K(s.r, s.c)]; const st = (cell && cell.s) || {};
    const on = (cmd, v) => document.querySelectorAll('[data-cmd="' + cmd + '"]').forEach(b => b.classList.toggle('on', !!v));
    on('bold', st.b); on('italic', st.i); on('underline', st.u); on('strike', st.st); on('wrapToggle', st.wrap);
    on('alignLeft', st.al === 'left'); on('alignCenter', st.al === 'center'); on('alignRight', st.al === 'right');
    on('formatPainter', !!state.formatPainter); on('toggleFormulas', state.showFormulas); on('filterToggle', !!sh.filter);
    on('mergeToggle', !!IS.mergeAt(sh, s.r, s.c));
    const fs = $('tbFontSize'); if (fs) fs.value = String(st.fs || 10);
    const ff = $('tbFont'); if (ff) ff.value = st.ff || '';
    const nf = $('tbFormat'); if (nf) nf.textContent = nfLabel(st.nf);
    const tc = $('tbTextColorBar'); if (tc) tc.style.background = state.lastText || '#c62828';
    const fc = $('tbFillColorBar'); if (fc) fc.style.background = state.lastFill || '#fff2cc';
  }
  IS.syncToolbar = syncToolbar;
  function nfLabel(nf) {
    if (!nf) return '123';
    if (nf === '[INRSHORT]') return '₹ L/Cr';
    if (/₹/.test(nf)) return '₹';
    if (/%/.test(nf)) return '%';
    if (X.isDateFormat(nf)) return X.isTimeOnlyFormat(nf) ? 'Time' : 'Date';
    if (nf === '@') return 'Text';
    if (/E\+/.test(nf)) return 'Sci';
    return '0.00';
  }

  // ======================================================================= formatting core commands
  function forEachCell(R, fn, opts = {}) {
    const sh = cur();
    const used = IS.usedRange(sh);
    const b = opts.all ? R.b : Math.min(R.b, Math.max(used.b + 1, R.t + 1000)), rr = opts.all ? R.r : Math.min(R.r, Math.max(used.r + 1, R.l + 200));
    for (let r = R.t; r <= b; r++) for (let c = R.l; c <= rr; c++) { if (IS.isCovered(sh, r, c)) continue; fn(r, c); }
  }
  IS.forEachCell = forEachCell;
  /** Change the style of every selected cell */
  function applyStyle(label, fn, R) {
    R = R || IS.selRect();
    if (!guardEdit(R)) return;
    const sh = cur();
    IS.tx(label, () => {
      const full = R.b - R.t > 5000 || R.r - R.l > 500;
      if (full) {
        // whole columns/rows: only style existing cells + a reasonable block
        for (const k of Object.keys(sh.cells)) { const i = k.indexOf(':'); const r = +k.slice(0, i), c = +k.slice(i + 1); if (r >= R.t && r <= R.b && c >= R.l && c <= R.r) editCell(sh, r, c, cell => { cell.s = fn(Object.assign({}, cell.s), r, c) || cell.s; }); }
        const used = IS.usedRange(sh);
        for (let r = R.t; r <= Math.min(R.b, used.b + 200); r++) for (let c = R.l; c <= Math.min(R.r, used.r + 30); c++) if (!sh.cells[K(r, c)]) editCell(sh, r, c, cell => { cell.s = fn({}, r, c) || cell.s; });
      } else forEachCell(R, (r, c) => editCell(sh, r, c, cell => { cell.s = fn(Object.assign({}, cell.s), r, c) || cell.s; }), { all: true });
    });
  }
  IS.applyStyle = applyStyle;
  function toggleStyle(prop, label) {
    const sh = cur(), s = state.sel; const cell = sh.cells[K(s.r, s.c)];
    const on = !(cell && cell.s && cell.s[prop]);
    applyStyle(label, st => { if (on) st[prop] = true; else delete st[prop]; return st; });
  }
  const setStyle = (prop, value, label) => applyStyle(label, st => { if (value === null || value === undefined || value === '') delete st[prop]; else st[prop] = value; return st; });
  IS.setStyle = setStyle;
  function changeDecimals(d) {
    const sh = cur();
    applyStyle(d > 0 ? 'More decimals' : 'Fewer decimals', (st, r, c) => { const v = calc.value(sh, r, c); st.nf = X.adjustDecimals(st.nf, d, typeof v === 'number' ? v : undefined); if (st.nf === 'General') delete st.nf; return st; });
  }
  function setBorders(kind, color, style) {
    const R = IS.selRect(); const sh = cur(); style = style || 'thin';
    applyStyle('Borders', (st, r, c) => {
      const bd = Object.assign({}, st.bd || {});
      const m = IS.mergeAt(sh, r, c) || { r, c, r2: r, c2: c };
      const top = m.r === R.t, bottom = m.r2 === R.b, left = m.c === R.l, right = m.c2 === R.r;
      const set = (k, on) => { if (on) bd[k] = style; };
      switch (kind) {
        case 'none': return Object.assign(st, { bd: undefined });
        case 'all': ['bt', 'bb', 'bl', 'br'].forEach(k => set(k, true)); break;
        case 'outer': set('bt', top); set('bb', bottom); set('bl', left); set('br', right); break;
        case 'inner': set('bt', !top); set('bb', !bottom); set('bl', !left); set('br', !right); break;
        case 'top': set('bt', top); break; case 'bottom': set('bb', bottom); break; case 'left': set('bl', left); break; case 'right': set('br', right); break;
        case 'horizontal': set('bt', !top); set('bb', !bottom); break; case 'vertical': set('bl', !left); set('br', !right); break;
        case 'thickBox': style = 'medium'; bd.bt = top ? 'medium' : bd.bt; bd.bb = bottom ? 'medium' : bd.bb; bd.bl = left ? 'medium' : bd.bl; bd.br = right ? 'medium' : bd.br; break;
        case 'doubleBottom': if (bottom) bd.bb = 'double'; break;
      }
      if (color) bd.c = color;
      st.bd = bd; return st;
    });
  }
  IS.setBorders = setBorders;

  // ======================================================================= rows / columns structure
  function shiftRefsForStructure(sh, axis, at, n) {
    const m = -n;
    const mapIdx = p => (n > 0 ? (p >= at ? p + n : p) : (p >= at + m ? p - m : p >= at ? null : p));
    for (const other of state.wb.sheets) for (const k of Object.keys(other.cells)) {
      const cell = other.cells[k]; if (!IS.isFormulaCell(cell)) continue;
      const f = X.transformRefs(cell.v, ref => {
        const target = ref.sheet ? sheetByName(ref.sheet) : other;
        if (target !== sh) return undefined;
        if (ref.kind === 'cell') {
          const p = axis === 'row' ? ref.row : ref.col;
          let q = mapIdx(p);
          if (q === null) { if (!ref.pos) return null; q = ref.pos === 'start' ? at : Math.max(0, at - 1); }
          return axis === 'row' ? { row: q, col: ref.col } : { row: ref.row, col: q };
        }
        if (ref.kind === 'cols' && axis === 'col') { const a = mapIdx(ref.c1), b = mapIdx(ref.c2); if (a === null && b === null) return null; return { c1: a === null ? at : a, c2: b === null ? Math.max(0, at - 1) : b }; }
        if (ref.kind === 'rows' && axis === 'row') { const a = mapIdx(ref.r1), b = mapIdx(ref.r2); if (a === null && b === null) return null; return { r1: a === null ? at : a, r2: b === null ? Math.max(0, at - 1) : b }; }
        return undefined;
      });
      if (f !== cell.v) { recCell(other, k); cell.v = f; }
    }
    // named ranges
    for (const nm in state.wb.names) {
      const def = state.wb.names[nm]; const f = X.transformRefs('=' + def.ref, ref => {
        if (ref.kind !== 'cell') return undefined; const target = ref.sheet ? sheetByName(ref.sheet) : null; if (target !== sh) return undefined;
        const p = axis === 'row' ? ref.row : ref.col; let q = mapIdx(p); if (q === null) q = ref.pos === 'end' ? Math.max(0, at - 1) : at;
        return axis === 'row' ? { row: q, col: ref.col } : { row: ref.row, col: q };
      });
      def.ref = f.slice(1);
    }
    return mapIdx;
  }
  function restructure(axis, at, n) {
    const sh = cur();
    if (!guardEdit(null, { structure: true })) return;
    if (n < 0) { // deleting: refuse to cut through merges partially
      const m = -n;
      for (const mg of sh.merges) { const a = axis === 'row' ? mg.r : mg.c, b = axis === 'row' ? mg.r2 : mg.c2; if (a < at && b >= at && b < at + m) { /* merge will shrink */ } }
    }
    IS.tx(n > 0 ? (axis === 'row' ? 'Insert rows' : 'Insert columns') : (axis === 'row' ? 'Delete rows' : 'Delete columns'), () => {
      recBook(); recSheet(sh);
      const mapIdx = shiftRefsForStructure(sh, axis, at, n);
      const cells = {};
      for (const k in sh.cells) {
        const i = k.indexOf(':'); const r = +k.slice(0, i), c = +k.slice(i + 1);
        const p = mapIdx(axis === 'row' ? r : c); if (p === null) continue;
        cells[axis === 'row' ? K(p, c) : K(r, p)] = sh.cells[k];
      }
      // inserted rows/cols take the format of the row/col above/left (like Excel)
      if (n > 0 && at > 0) {
        for (const k in sh.cells) {
          const i = k.indexOf(':'); const r = +k.slice(0, i), c = +k.slice(i + 1);
          if ((axis === 'row' ? r : c) !== at - 1) continue;
          const cell = sh.cells[k]; if (!cell.s) continue;
          for (let j = 0; j < n; j++) { const key = axis === 'row' ? K(at + j, c) : K(r, at + j); if (!cells[key]) cells[key] = { s: jclone(cell.s) }; }
        }
      }
      sh.cells = cells;
      const remapObj = (obj) => { const o = {}; for (const k in obj) { const p = mapIdx(+k); if (p !== null) o[p] = obj[k]; } return o; };
      if (axis === 'col') { sh.colW = remapObj(sh.colW); sh.hiddenCols = (sh.hiddenCols || []).map(mapIdx).filter(x => x !== null); }
      else { sh.rowH = remapObj(sh.rowH); sh.rowHa = remapObj(sh.rowHa || {}); sh.hiddenRows = (sh.hiddenRows || []).map(mapIdx).filter(x => x !== null); }
      const remapRect = g => {
        const a = axis === 'row' ? g.t : g.l, b = axis === 'row' ? g.b : g.r;
        let na = mapIdx(a), nb = mapIdx(b);
        if (na === null && nb === null) { if (n < 0 && a >= at && b < at - n) return null; }
        if (na === null) na = at; if (nb === null) nb = Math.max(0, at - 1);
        if (n > 0 && a < at && b >= at) nb = b + n;
        if (nb < na) return null;
        return axis === 'row' ? Object.assign({}, g, { t: na, b: nb }) : Object.assign({}, g, { l: na, r: nb });
      };
      sh.merges = sh.merges.map(mg => { const g = remapRect({ t: mg.r, l: mg.c, b: mg.r2, r: mg.c2 }); return g ? { r: g.t, c: g.l, r2: g.b, c2: g.r } : null; }).filter(mg => mg && (mg.r2 > mg.r || mg.c2 > mg.c));
      sh.cf.forEach(rule => { rule.ranges = rule.ranges.map(remapRect).filter(Boolean); });
      sh.cf = sh.cf.filter(rule => rule.ranges.length);
      sh.dv.forEach(rule => { rule.ranges = rule.ranges.map(remapRect).filter(Boolean); });
      sh.dv = sh.dv.filter(rule => rule.ranges.length);
      if (sh.filter) { const g = remapRect(sh.filter); if (g) { sh.filter = Object.assign(sh.filter, g); sh.filter.hidden = (sh.filter.hidden || []).map(x => (axis === 'row' ? mapIdx(x) : x)).filter(x => x !== null); } else sh.filter = null; }
      (sh.objects || []).forEach(o => { const p = mapIdx(axis === 'row' ? o.r : o.c); if (p !== null) { if (axis === 'row') o.r = p; else o.c = p; } });
      if (axis === 'row') sh.rows = Math.max(100, sh.rows + n); else sh.cols = Math.max(10, sh.cols + n);
      if (axis === 'row' && sh.freezeR > at) sh.freezeR = Math.max(0, sh.freezeR + (n > 0 ? n : Math.max(n, at - sh.freezeR)));
      if (axis === 'col' && sh.freezeC > at) sh.freezeC = Math.max(0, sh.freezeC + (n > 0 ? n : Math.max(n, at - sh.freezeC)));
      IS.invalidateHidden(sh);
    }, { full: true });
  }
  IS.restructure = restructure;
  function setHidden(axis, list, hide) {
    const sh = cur(); if (!guardEdit(null, { structure: true })) return;
    IS.tx(hide ? 'Hide' : 'Unhide', () => {
      recMeta(sh);
      const key = axis === 'row' ? 'hiddenRows' : 'hiddenCols';
      const set = new Set(sh[key] || []);
      list.forEach(i => (hide ? set.add(i) : set.delete(i)));
      sh[key] = [...set].sort((a, b) => a - b);
      IS.invalidateHidden(sh);
    }, { layout: true });
  }
  IS.setHidden = setHidden;
  function selRows() { const R = IS.selRect(); const out = []; for (let r = R.t; r <= R.b; r++) out.push(r); return out; }
  function selCols() { const R = IS.selRect(); const out = []; for (let c = R.l; c <= R.r; c++) out.push(c); return out; }
  function unhideAround(axis) {
    const sh = cur(), R = IS.selRect();
    const list = axis === 'row' ? (sh.hiddenRows || []).filter(r => r >= R.t - 1 && r <= R.b + 1 || (R.t === 0 && R.b >= sh.rows - 1)) : (sh.hiddenCols || []).filter(c => c >= R.l - 1 && c <= R.r + 1 || (R.l === 0 && R.r >= sh.cols - 1));
    // also unhide hidden blocks that touch the selection edges
    const all = axis === 'row' ? sh.hiddenRows || [] : sh.hiddenCols || [];
    const a = axis === 'row' ? R.t : R.l, b = axis === 'row' ? R.b : R.r;
    const extra = all.filter(i => i >= a && i <= b);
    setHidden(axis, [...new Set(list.concat(extra))], false);
  }
  function resizeCols(cols, w) { const sh = cur(); IS.tx('Column width', () => { recMeta(sh); cols.forEach(c => { if (w == null) delete sh.colW[c]; else sh.colW[c] = Math.max(2, Math.round(w)); }); }, { layout: true }); }
  function resizeRows(rows, h) { const sh = cur(); IS.tx('Row height', () => { recMeta(sh); rows.forEach(r => { if (h == null) { delete sh.rowH[r]; } else sh.rowH[r] = Math.max(4, Math.round(h)); }); }, { layout: true }); }
  IS.resizeCols = resizeCols; IS.resizeRows = resizeRows;
  function autoFitCols(cols) {
    const sh = cur(); const meas = IS.GridPaint.measureCanvas;
    const widths = {};
    const byCol = new Map(); cols.forEach(c => byCol.set(c, 30));
    const src = IS.cellSource(sh);
    const consider = (r, c) => {
      if (!byCol.has(c) || IS.mergeAt(sh, r, c)) return;
      const info = src.info(r, c); if (!info || !info.text) return;
      meas.font = IS.GridPaint.fontOf(info.s, 1);
      const w = Math.max(...String(info.text).split('\n').map(t => meas.measureText(t).width)) + 14 + (info.filterBtn ? 18 : 0) + (info.arrow ? 14 : 0);
      if (w > byCol.get(c)) byCol.set(c, w);
    };
    const vals = calc.vals.get(sh.id) || new Map();
    for (const k of vals.keys()) { const i = k.indexOf(':'); consider(+k.slice(0, i), +k.slice(i + 1)); }
    for (const k in sh.cells) { const i = k.indexOf(':'); consider(+k.slice(0, i), +k.slice(i + 1)); }
    byCol.forEach((w, c) => { widths[c] = Math.min(600, Math.ceil(w)); });
    IS.tx('Fit column width', () => { recMeta(sh); Object.entries(widths).forEach(([c, w]) => { sh.colW[c] = w; }); }, { layout: true });
  }
  IS.autoFitCols = autoFitCols;
  function autoFitRows(rows) { const sh = cur(); IS.tx('Fit row height', () => { recMeta(sh); rows.forEach(r => { delete sh.rowH[r]; }); computeAutoHeights(sh, rows); }, { layout: true }); }
  /** Rows with wrapped text or big fonts grow automatically */
  function computeAutoHeights(sh, rows) {
    if (!sh.rowHa) sh.rowHa = {};
    const meas = IS.GridPaint.measureCanvas; const set = new Set(rows);
    const need = new Map();
    for (const k in sh.cells) {
      const i = k.indexOf(':'); const r = +k.slice(0, i); if (!set.has(r)) continue;
      const c = +k.slice(i + 1); const cell = sh.cells[k]; const s = cell.s || {};
      if (!s.wrap && !(s.fs > 11) && !(typeof cell.v === 'string' && cell.v.includes('\n'))) continue;
      if (IS.mergeAt(sh, r, c)) continue;
      const fontPx = (s.fs || 10) * IS.GridPaint.PT;
      let lines = 1;
      const v = calc.value(sh, r, c);
      const text = X.formatValue(v, s.nf).text;
      if (s.wrap) { const w = (sh.colW[c] != null ? sh.colW[c] : 100) - 8; lines = IS.GridPaint.wrapLines(meas, IS.GridPaint.fontOf(s, 1), text, Math.max(4, w)).length; }
      else lines = String(text).split('\n').length;
      const h = Math.ceil(lines * fontPx * 1.28 + 8);
      need.set(r, Math.max(need.get(r) || 0, h));
    }
    rows.forEach(r => { const h = need.get(r); if (h && h > 24) sh.rowHa[r] = h; else delete sh.rowHa[r]; });
  }
  IS.on('change', t => {
    // keep auto row heights in step with edits
    if (!t || !t.cells || !t.cells.size) return;
    const sh = cur(); const rows = new Set();
    for (const rec of t.cells.values()) if (rec.sid === sh.id) rows.add(+rec.key.split(':')[0]);
    if (rows.size && rows.size < 2000) { const before = JSON.stringify(sh.rowHa || {}); computeAutoHeights(sh, [...rows]); if (JSON.stringify(sh.rowHa) !== before) grid.layout(); }
  });

  // ======================================================================= merges
  function mergeCells(mode) {
    const sh = cur(), R = IS.selRect();
    if (R.t === R.b && R.l === R.r && mode !== 'unmerge') { ui.toast('Select more than one cell to merge.'); return; }
    if (!guardEdit(R)) return;
    if (mode === 'unmerge') {
      IS.tx('Unmerge', () => { recMeta(sh); sh.merges = sh.merges.filter(m => m.r2 < R.t || m.r > R.b || m.c2 < R.l || m.c > R.r); }, { layout: true });
      return;
    }
    const groups = [];
    if (mode === 'rows') for (let r = R.t; r <= R.b; r++) groups.push({ r, c: R.l, r2: r, c2: R.r });
    else if (mode === 'cols') for (let c = R.l; c <= R.r; c++) groups.push({ r: R.t, c, r2: R.b, c2: c });
    else groups.push({ r: R.t, c: R.l, r2: R.b, c2: R.r });
    let lost = 0;
    groups.forEach(g => { for (let r = g.r; r <= g.r2; r++) for (let c = g.c; c <= g.c2; c++) if ((r !== g.r || c !== g.c) && IS.hasValue(sh.cells[K(r, c)])) lost++; });
    const go = () => IS.tx('Merge cells', () => {
      recMeta(sh);
      sh.merges = sh.merges.filter(m => m.r2 < R.t || m.r > R.b || m.c2 < R.l || m.c > R.r);
      groups.forEach(g => {
        if (g.r === g.r2 && g.c === g.c2) return;
        for (let r = g.r; r <= g.r2; r++) for (let c = g.c; c <= g.c2; c++) if ((r !== g.r || c !== g.c) && sh.cells[K(r, c)]) editCell(sh, r, c, cell => { delete cell.v; delete cell.t; });
        sh.merges.push(g);
        editCell(sh, g.r, g.c, cell => { cell.s = Object.assign({}, cell.s); if (!cell.s.al && mode !== 'cols') cell.s.al = 'center'; if (!cell.s.va) cell.s.va = 'middle'; });
      });
    }, { layout: true });
    if (lost) ui.confirm('Merging keeps only the top-left value. ' + lost + ' other value(s) will be removed. Continue?', { ok: 'Merge' }).then(ok => { if (ok) go(); });
    else go();
  }
  IS.mergeCells = mergeCells;

  // ======================================================================= fill
  const SERIES_LISTS = [
    ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'], ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'],
    ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'], X.MONTHS.slice(),
    ['Q1', 'Q2', 'Q3', 'Q4']
  ];
  function seriesNext(srcVals, k) {
    // srcVals: raw values of the source line; k = index (0-based) of the new item after the source
    const n = srcVals.length;
    if (n && srcVals.every(v => typeof v === 'number')) {
      if (n === 1) return srcVals[0];
      const step = (srcVals[n - 1] - srcVals[0]) / (n - 1);
      return +(srcVals[n - 1] + step * (k + 1)).toFixed(10);
    }
    if (n && srcVals.every(v => typeof v === 'string')) {
      for (const list of SERIES_LISTS) {
        const idx = srcVals.map(v => list.findIndex(x => x.toLowerCase() === v.toLowerCase()));
        if (idx.every(i => i >= 0)) {
          const step = n > 1 ? (idx[n - 1] - idx[0]) / (n - 1) : 1;
          const i = ((idx[n - 1] + step * (k + 1)) % list.length + list.length) % list.length;
          const w = list[Math.round(i)]; const s0 = srcVals[0];
          return s0 === s0.toUpperCase() ? w.toUpperCase() : s0 === s0.toLowerCase() ? w.toLowerCase() : w;
        }
      }
      const ms = srcVals.map(v => v.match(/^(.*?)(\d+)(\D*)$/));
      if (ms.every(m => m && m[1] === ms[0][1] && m[3] === ms[0][3])) {
        const nums = ms.map(m => +m[2]); const step = n > 1 ? (nums[n - 1] - nums[0]) / (n - 1) : 1;
        const next = nums[n - 1] + step * (k + 1); const width = ms[0][2].length;
        return ms[0][1] + String(Math.round(next)).padStart(ms[0][2][0] === '0' ? width : 0, '0') + ms[0][3];
      }
    }
    return undefined;
  }
  /** Fill from src rect to dest rect (dest contains src). dir: down/up/right/left */
  function doFill(src, dest, dir, opts = {}) {
    const sh = cur();
    if (!guardEdit(dest)) return;
    IS.tx('Fill', () => {
      const vertical = dir === 'down' || dir === 'up';
      const lines = vertical ? range(src.l, src.r) : range(src.t, src.b);
      for (const line of lines) {
        const srcIdx = vertical ? range(src.t, src.b) : range(src.l, src.r);
        const srcCells = srcIdx.map(i => (vertical ? sh.cells[K(i, line)] : sh.cells[K(line, i)]));
        const raw = srcCells.map(c => (c && !IS.isFormulaCell(c) ? c.v : undefined));
        const series = !opts.copy && srcCells.every(c => c && IS.hasValue(c) && !IS.isFormulaCell(c)) && (srcCells.length > 1 || typeof raw[0] === 'string' || (opts.series && typeof raw[0] === 'number'));
        const isDate = series && srcCells.every(c => c.s && X.isDateFormat(c.s.nf));
        let targets;
        if (dir === 'down') targets = range(src.b + 1, dest.b);
        else if (dir === 'up') targets = range(dest.t, src.t - 1).reverse();
        else if (dir === 'right') targets = range(src.r + 1, dest.r);
        else targets = range(dest.l, src.l - 1).reverse();
        const n = srcIdx.length;
        targets.forEach((t, k) => {
          const si = dir === 'down' || dir === 'right' ? k % n : n - 1 - (k % n);
          const from = srcIdx[si];
          const r = vertical ? t : line, c = vertical ? line : t;
          const fr = vertical ? from : line, fc = vertical ? line : from;
          const s = sh.cells[K(fr, fc)];
          if (!s) { if (sh.cells[K(r, c)]) putCell(sh, r, c, null); return; }
          const cell = IS.cloneCell(s);
          if (IS.isFormulaCell(s)) cell.v = X.shiftFormula(s.v, r - fr, c - fc);
          else if (series) {
            let v;
            const vals = dir === 'down' || dir === 'right' ? raw : raw.slice().reverse();
            if (isDate && n === 1) v = raw[0] + (dir === 'down' || dir === 'right' ? k + 1 : -(k + 1));
            else v = seriesNext(vals, k);
            if (v !== undefined) { if (dir === 'up' || dir === 'left') { if (typeof v === 'number' && n === 1 && !isDate && opts.series) v = raw[0] - (k + 1); } cell.v = v; }
          } else if (opts.series && typeof s.v === 'number') cell.v = s.v + (dir === 'down' || dir === 'right' ? k + 1 : -(k + 1));
          putCell(sh, r, c, cell);
        });
      }
    });
    setSel(dest.t, dest.l, dest.b, dest.r, { scroll: false });
  }
  IS.doFill = doFill;
  const range = (a, b) => { const out = []; for (let i = a; i <= b; i++) out.push(i); return out; };
  function fillDir(dir) {
    const R = IS.selRect();
    if (dir === 'down') { if (R.t === R.b) { if (R.t === 0) return; doFill({ t: R.t - 1, l: R.l, b: R.t - 1, r: R.r }, { t: R.t - 1, l: R.l, b: R.b, r: R.r }, 'down', { copy: true }); return; } doFill({ t: R.t, l: R.l, b: R.t, r: R.r }, R, 'down', { copy: true }); }
    else { if (R.l === R.r) { if (R.l === 0) return; doFill({ t: R.t, l: R.l - 1, b: R.b, r: R.l - 1 }, { t: R.t, l: R.l - 1, b: R.b, r: R.r }, 'right', { copy: true }); return; } doFill({ t: R.t, l: R.l, b: R.b, r: R.l }, R, 'right', { copy: true }); }
  }

  // ======================================================================= clearing
  function clearRange(what, R) {
    R = R || IS.selRect(); const sh = cur();
    if (!guardEdit(R)) return;
    const keys = [];
    for (const k in sh.cells) { const i = k.indexOf(':'); const r = +k.slice(0, i), c = +k.slice(i + 1); if (r >= R.t && r <= R.b && c >= R.l && c <= R.r) keys.push([r, c]); }
    if (!keys.length && what !== 'formats') return;
    IS.tx(what === 'formats' ? 'Clear formatting' : what === 'all' ? 'Clear all' : what === 'notes' ? 'Clear notes' : 'Clear', () => {
      keys.forEach(([r, c]) => editCell(sh, r, c, cell => {
        if (what === 'contents' || what === 'all') { delete cell.v; delete cell.t; }
        if (what === 'formats' || what === 'all') delete cell.s;
        if (what === 'notes' || what === 'all') delete cell.n;
      }));
      if (what === 'all' || what === 'formats') {
        if (sh.cf.length || sh.dv.length) recMeta(sh);
        const inside = g => g.t >= R.t && g.b <= R.b && g.l >= R.l && g.r <= R.r;
        sh.cf = sh.cf.filter(rule => !rule.ranges.every(inside));
        if (what === 'all') sh.dv = sh.dv.filter(rule => !rule.ranges.every(inside));
      }
    });
  }
  IS.clearRange = clearRange;

  // ======================================================================= clipboard
  function cellsForCopy(R) {
    const sh = cur(); const rows = [];
    const ub = IS.usedRange(sh);
    const b = Math.min(R.b, Math.max(ub.b, R.t)), rr = Math.min(R.r, Math.max(ub.r, R.l));
    for (let r = R.t; r <= b; r++) { if (sh.filter && IS.isRowHidden(sh, r, false)) continue; rows.push(r); }
    const cols = range(R.l, rr);
    return { rows, cols };
  }
  function tsvQuote(t) { return /[\t\n"\r]/.test(t) ? '"' + t.replace(/"/g, '""') + '"' : t; }
  function buildCopy(R, cut) {
    const sh = cur(); const { rows, cols } = cellsForCopy(R);
    const src = IS.cellSource(sh);
    const data = [], lines = [];
    let html = '<meta charset="utf-8"><table style="border-collapse:collapse">';
    for (const r of rows) {
      const row = [], txt = [];
      html += '<tr' + (sh.rowH[r] ? ' style="height:' + sh.rowH[r] + 'px"' : '') + '>';
      for (const c of cols) {
        const cell = sh.cells[K(r, c)]; row.push(IS.cloneCell(cell));
        if (IS.isCovered(sh, r, c)) { txt.push(''); continue; }
        const info = src.info(r, c); const t = info ? (info.formula ? info.text : info.text) : '';
        txt.push(tsvQuote(info && info.checkbox ? String(!!info.value).toUpperCase() : t));
        const s = (cell && cell.s) || {}; const m = IS.mergeAt(sh, r, c);
        let css = 'border:1px solid #d0d0d0;padding:2px 4px;';
        if (s.b) css += 'font-weight:bold;'; if (s.i) css += 'font-style:italic;'; if (s.u) css += 'text-decoration:underline;';
        if (s.color || (info && info.color)) css += 'color:' + (info && info.color || s.color) + ';'; if (info && info.bg) css += 'background:' + info.bg + ';';
        if (s.al) css += 'text-align:' + s.al + ';'; else if (info && info.kind === 'num') css += 'text-align:right;';
        if (s.fs) css += 'font-size:' + s.fs + 'pt;';
        const v = calc.value(sh, r, c);
        html += '<td style="' + css + '"' + (m ? ' rowspan="' + (m.r2 - m.r + 1) + '" colspan="' + (m.c2 - m.c + 1) + '"' : '') + (typeof v === 'number' ? ' x:num="' + v + '"' : '') + '>' + esc(t).replace(/\n/g, '<br>') + '</td>';
      }
      html += '</tr>'; data.push(row); lines.push(txt.join('\t'));
    }
    html += '</table>';
    const merges = sh.merges.filter(m => m.r >= R.t && m.r2 <= R.b && m.c >= R.l && m.c2 <= R.r).map(m => ({ r: m.r - R.t, c: m.c - R.l, r2: m.r2 - R.t, c2: m.c2 - R.l }));
    const colW = cols.map(c => sh.colW[c]);
    return { text: lines.join('\r\n'), html, clip: { sheet: sh.id, rect: { t: R.t, l: R.l, b: R.t + rows.length - 1, r: R.l + cols.length - 1 }, rowsIdx: rows, data, merges, colW, cut, text: lines.join('\r\n') } };
  }
  function onCopy(e, cut) {
    if (clipIgnored(e)) return;
    e.preventDefault();
    const R = IS.selRect();
    if (cut && !guardEdit(R)) return;
    const out = buildCopy(R, cut);
    e.clipboardData.setData('text/plain', out.text);
    e.clipboardData.setData('text/html', out.html);
    state.clip = out.clip;
    state.clipRect = Object.assign({ sheet: cur().id }, R);
    startAnts();
    ui.toast((cut ? 'Cut ' : 'Copied ') + out.clip.data.length + ' × ' + (out.clip.data[0] || []).length + ' cells', { ms: 1400 });
  }
  let antsTimer = null;
  function startAnts() { clearInterval(antsTimer); antsTimer = setInterval(() => { if (!state.clipRect) { clearInterval(antsTimer); return; } state.antsOffset = (state.antsOffset + 1) % 20; grid.invalidate(); }, 80); }
  function clearClip() { state.clipRect = null; grid.invalidate(); }
  const clipIgnored = e => {
    const ae = document.activeElement;
    if (state.editing) return true;
    if ($('dlg').open) return true;
    if (ae && ae !== document.body && /^(INPUT|TEXTAREA|SELECT)$/.test(ae.tagName) && ae.id !== 'gridKeys') return true;
    return false;
  };
  function onPaste(e) {
    if (clipIgnored(e)) return;
    e.preventDefault();
    const mode = state.pasteMode; state.pasteMode = null;
    const text = (e.clipboardData.getData('text/plain') || '');
    const html = e.clipboardData.getData('text/html') || '';
    const files = [...(e.clipboardData.files || [])];
    if (files.length && files[0].type.startsWith('image/') && IS.insertImageFile) { IS.insertImageFile(files[0]); return; }
    pasteData({ text, html }, mode);
  }
  function normText(t) { return String(t || '').replace(/\r\n/g, '\n').replace(/\n$/, ''); }
  /** Paste from internal clipboard or external text/html */
  function pasteData(src, mode) {
    const R = IS.selRect(); const sh = cur();
    if (!guardEdit(R)) return;
    const clip = state.clip;
    if (clip && normText(src.text) === normText(clip.text)) return pasteInternal(clip, mode);
    let grid2 = null;
    if (src.html && /<table/i.test(src.html)) grid2 = parseHtmlTable(src.html);
    if (!grid2) grid2 = parseTSV(normText(src.text)).map(row => row.map(v => ({ text: v })));
    if (!grid2.length) return;
    const h = grid2.length, w = Math.max(...grid2.map(r => r.length));
    IS.tx('Paste', () => {
      grid2.forEach((row, i) => row.forEach((item, j) => {
        const r = R.t + i, c = R.l + j;
        if (!item) return;
        if (mode === 'formats') { if (item.s) editCell(sh, r, c, cell => { cell.s = Object.assign({}, cell.s, item.s); }); return; }
        if (item.formula && mode !== 'values') writeText(sh, r, c, item.formula);
        else if (item.num !== undefined) editCell(sh, r, c, cell => { cell.v = item.num; delete cell.t; if (item.nf && !(cell.s && cell.s.nf)) cell.s = Object.assign({}, cell.s, { nf: item.nf }); });
        else writeText(sh, r, c, item.text);
        if (item.s && mode !== 'values') editCell(sh, r, c, cell => { cell.s = Object.assign({}, cell.s, item.s); });
      }));
      if (src.merges && mode !== 'values') { recMeta(sh); src.merges.forEach(m => sh.merges.push({ r: R.t + m.r, c: R.l + m.c, r2: R.t + m.r2, c2: R.l + m.c2 })); }
    }, { layout: !!src.merges });
    setSel(R.t, R.l, R.t + h - 1, R.l + w - 1, { scroll: false });
  }
  IS.pasteData = pasteData;
  function pasteInternal(clip, mode) {
    const R = IS.selRect(); const sh = cur(); const srcSheet = sheetById(clip.sheet);
    const data = clip.data; const h = data.length, w = data[0] ? data[0].length : 0; if (!h || !w) return;
    const transpose = mode === 'transpose';
    const H = transpose ? w : h, W = transpose ? h : w;
    const th = (R.b - R.t + 1) % H === 0 && R.b > R.t ? R.b - R.t + 1 : H, tw = (R.r - R.l + 1) % W === 0 && R.r > R.l ? R.r - R.l + 1 : W;
    IS.tx(clip.cut ? 'Move' : 'Paste', () => {
      if (clip.cut && srcSheet) {
        for (let i = 0; i < h; i++) for (let j = 0; j < w; j++) { const r = clip.rowsIdx ? clip.rowsIdx[i] : clip.rect.t + i; if (srcSheet.cells[K(r, clip.rect.l + j)]) putCell(srcSheet, r, clip.rect.l + j, null); }
        if (clip.merges.length) { recMeta(srcSheet); srcSheet.merges = srcSheet.merges.filter(m => !(m.r >= clip.rect.t && m.r2 <= clip.rect.b && m.c >= clip.rect.l && m.c2 <= clip.rect.r)); }
      }
      for (let i = 0; i < th; i++) for (let j = 0; j < tw; j++) {
        const si = transpose ? j % w : i % h, sj = transpose ? i % h : j % w;
        const d = data[si][sj]; const r = R.t + i, c = R.l + j;
        const srcR = clip.rowsIdx ? clip.rowsIdx[si] : clip.rect.t + si, srcC = clip.rect.l + sj;
        if (mode === 'formats') { editCell(sh, r, c, cell => { if (d && d.s) cell.s = jclone(d.s); else delete cell.s; }); continue; }
        if (mode === 'values') {
          const v = srcSheet ? calc.value(srcSheet, srcR, srcC) : (d && d.v);
          editCell(sh, r, c, cell => { const vv = X.norm(v); if (vv === null || vv === undefined || X.isErr(vv)) { delete cell.v; } else cell.v = vv; delete cell.t; if (d && d.s && d.s.nf) cell.s = Object.assign({}, cell.s, { nf: d.s.nf }); });
          continue;
        }
        if (!d) { putCell(sh, r, c, null); continue; }
        const nc = IS.cloneCell(d);
        if (IS.isFormulaCell(d) && !clip.cut) nc.v = X.shiftFormula(d.v, r - srcR, c - srcC);
        if (mode === 'formulas') { editCell(sh, r, c, cell => { cell.v = nc.v; if (nc.t) cell.t = nc.t; }); continue; }
        putCell(sh, r, c, nc);
      }
      if (!mode || mode === 'formats') {
        if (clip.merges.length && !transpose) { recMeta(sh); sh.merges = sh.merges.filter(m => m.r2 < R.t || m.r > R.t + th - 1 || m.c2 < R.l || m.c > R.l + tw - 1); clip.merges.forEach(m => sh.merges.push({ r: R.t + m.r, c: R.l + m.c, r2: R.t + m.r2, c2: R.l + m.c2 })); }
      }
      if (mode === 'widths') { recMeta(sh); clip.colW.forEach((wd, j) => { if (wd) sh.colW[R.l + j] = wd; else delete sh.colW[R.l + j]; }); }
    }, { layout: !!(clip.merges.length || mode === 'widths' || clip.cut) });
    if (clip.cut) { state.clip = null; clearClip(); }
    setSel(R.t, R.l, R.t + th - 1, R.l + tw - 1, { scroll: false });
  }
  function parseTSV(text) {
    if (!text) return [];
    const rows = []; let row = [], f = '', q = false;
    for (let i = 0; i < text.length; i++) {
      const ch = text[i];
      if (q) { if (ch === '"') { if (text[i + 1] === '"') { f += '"'; i++; } else q = false; } else f += ch; }
      else if (ch === '"' && f === '') q = true;
      else if (ch === '\t') { row.push(f); f = ''; }
      else if (ch === '\n') { row.push(f); rows.push(row); row = []; f = ''; }
      else if (ch !== '\r') f += ch;
    }
    row.push(f); rows.push(row);
    return rows;
  }
  IS.parseTSV = parseTSV;
  function r1c1ToA1(f, r, c) {
    return f.replace(/("(?:[^"]|"")*")|R(\[-?\d+\]|\d+)?C(\[-?\d+\]|\d+)?/g, (m, str, rr, cc) => {
      if (str) return str;
      const row = rr === undefined ? r : rr[0] === '[' ? r + +rr.slice(1, -1) : +rr - 1;
      const col = cc === undefined ? c : cc[0] === '[' ? c + +cc.slice(1, -1) : +cc - 1;
      if (row < 0 || col < 0) return '#REF!';
      return (rr && rr[0] !== '[' ? '$' : '') + X.numToCol(col) + (cc && cc[0] !== '[' ? '' : '') + (rr && rr[0] !== '[' ? '' : '') + (row + 1);
    });
  }
  function parseHtmlTable(html) {
    let doc; try { doc = new DOMParser().parseFromString(html, 'text/html'); } catch (e) { return null; }
    const table = doc.querySelector('table'); if (!table) return null;
    const classStyles = {};
    doc.querySelectorAll('style').forEach(st => { String(st.textContent).replace(/\.([\w-]+)\s*\{([^}]*)\}/g, (m, cls, body) => { classStyles[cls] = body; }); });
    const out = []; const occupied = {}; const R = IS.selRect();
    const merges = [];
    [...table.rows].forEach((tr, i) => {
      out[i] = out[i] || []; let j = 0;
      [...tr.cells].forEach(td => {
        while (occupied[i + ':' + j]) j++;
        const rs = td.rowSpan || 1, cs = td.colSpan || 1;
        for (let a = 0; a < rs; a++) for (let b = 0; b < cs; b++) if (a || b) occupied[(i + a) + ':' + (j + b)] = true;
        if (rs > 1 || cs > 1) merges.push({ r: i, c: j, r2: i + rs - 1, c2: j + cs - 1 });
        const item = { text: (td.innerText !== undefined ? td.innerText : td.textContent).replace(/ /g, ' ').replace(/\n$/, '') };
        const gsv = td.getAttribute('data-sheets-value'), gsf = td.getAttribute('data-sheets-formula');
        if (gsf) item.formula = r1c1ToA1(gsf, R.t + i, R.l + j);
        if (gsv) { try { const o = JSON.parse(gsv); if (o['1'] === 3 && typeof o['3'] === 'number') item.num = o['3']; } catch (e) { /* ignore */ } }
        const xn = td.getAttribute('x:num'); if (xn !== null && xn !== '' && !isNaN(+xn)) item.num = +xn;
        const xf = td.getAttribute('x:fmla'); if (xf) item.formula = xf;
        let css = (td.getAttribute('style') || '');
        (td.getAttribute('class') || '').split(/\s+/).forEach(cls => { if (classStyles[cls]) css = classStyles[cls] + ';' + css; });
        const s = {};
        const get = p => { const m = css.match(new RegExp('(?:^|;)\\s*' + p + '\\s*:\\s*([^;]+)', 'i')); return m ? m[1].trim() : null; };
        const fw = get('font-weight'); if (fw && (fw === 'bold' || +fw >= 600)) s.b = true;
        if (/italic/i.test(get('font-style') || '')) s.i = true;
        if (/underline/i.test(get('text-decoration') || '')) s.u = true;
        const toHex = v => { if (!v) return null; v = v.replace(/!important/, '').trim(); if (/^#[0-9a-f]{6}$/i.test(v)) return v.toLowerCase(); if (/^#[0-9a-f]{3}$/i.test(v)) return '#' + v.slice(1).split('').map(x => x + x).join('').toLowerCase(); const m = v.match(/rgb\w*\((\d+),\s*(\d+),\s*(\d+)/i); return m ? '#' + [m[1], m[2], m[3]].map(x => (+x).toString(16).padStart(2, '0')).join('') : null; };
        const bg = toHex(get('background-color') || get('background')); if (bg && bg !== '#ffffff') s.bg = bg;
        const fc = toHex(get('color')); if (fc && fc !== '#000000') s.color = fc;
        const al = get('text-align'); if (al && /left|center|right/.test(al)) s.al = al.match(/left|center|right/)[0];
        if (Object.keys(s).length) item.s = s;
        out[i][j] = item;
        j += cs;
      });
    });
    out.merges = merges;
    const res = out.map(r => r || []);
    res.merges = merges;
    return res.length ? res : null;
  }
  async function pasteFromMenu(mode) {
    if (mode && state.clip) { pasteInternal(state.clip, mode); return; }
    try {
      const text = await navigator.clipboard.readText();
      pasteData({ text }, mode);
    } catch (e) { ui.toast('Your browser blocked reading the clipboard here. Use Ctrl+V (or Ctrl+Shift+V for values only).', { ms: 5000 }); }
  }

  // ======================================================================= grid pointer handling
  let drag = null, lastTap = 0, hoverTimer = null;
  function local(e) { const r = grid.host.getBoundingClientRect(); return { x: e.clientX - r.left, y: e.clientY - r.top }; }
  function onPointerDown(e) {
    if (e.button === 2) return;
    const p = local(e);
    if (p.x > grid.vw || p.y > grid.vh) return; // on a scrollbar
    if (e.button !== 0) return;
    ui.closePopups();
    state.tabStart = null;
    const h = grid.hit(p.x, p.y);
    const sh = cur();
    const touch = e.pointerType === 'touch';
    if (h.area === 'colresize' || h.area === 'rowresize') {
      e.preventDefault();
      if (state.editing && !commitEdit()) return;
      drag = h.area === 'colresize'
        ? { type: 'colresize', c: h.c, start: p.x, w0: grid.cw(h.c) / grid.z }
        : { type: 'rowresize', r: h.r, start: p.y, h0: grid.rh(h.r) / grid.z };
      grid.scroller.setPointerCapture(e.pointerId);
      return;
    }
    if (state.editing && (h.area === 'cell' || h.area === 'colhead' || h.area === 'rowhead') && canPoint()) {
      e.preventDefault();
      if (h.area === 'cell') { pointTo(h.r, h.c); drag = { type: 'point', r: h.r, c: h.c }; }
      else if (h.area === 'colhead') { pointTo(0, h.c, sh.rows - 1, h.c); }
      else pointTo(h.r, 0, h.r, sh.cols - 1);
      grid.scroller.setPointerCapture(e.pointerId);
      return;
    }
    if (state.editing && !commitEdit()) { e.preventDefault(); return; }
    focusGrid();
    if (h.area === 'corner') { e.preventDefault(); setSel(0, 0, sh.rows - 1, sh.cols - 1, { scroll: false }); return; }
    if (h.area === 'colhead') {
      e.preventDefault();
      if (e.shiftKey) setSel(0, state.sel.c, sh.rows - 1, h.c, { scroll: false });
      else { setSel(0, h.c, sh.rows - 1, h.c, { scroll: false }); }
      drag = { type: 'cols', anchor: e.shiftKey ? state.sel.c : h.c };
      grid.scroller.setPointerCapture(e.pointerId); return;
    }
    if (h.area === 'rowhead') {
      e.preventDefault();
      if (e.shiftKey) setSel(state.sel.r, 0, h.r, sh.cols - 1, { scroll: false });
      else setSel(h.r, 0, h.r, sh.cols - 1, { scroll: false });
      drag = { type: 'rows', anchor: e.shiftKey ? state.sel.r : h.r };
      grid.scroller.setPointerCapture(e.pointerId); return;
    }
    if (h.area !== 'cell') return;
    // fill handle
    const R = IS.selRect(); const rr = grid.rectScreen(R.t, R.l, R.b, R.r);
    if (!touch && Math.abs(p.x - (rr.x + rr.w)) <= 6 && Math.abs(p.y - (rr.y + rr.h)) <= 6) {
      e.preventDefault(); drag = { type: 'fill', src: R, dest: R, dir: null };
      grid.scroller.setPointerCapture(e.pointerId); return;
    }
    // cell widgets
    const cr = grid.cellRect(h.r, h.c);
    const info = IS.cellSource(sh).info(h.r, h.c);
    if (info) {
      if (info.filterBtn && p.x > cr.x + cr.w - 20 * grid.z) { e.preventDefault(); setSel(h.r, h.c, h.r, h.c, { scroll: false }); IS.run('filterMenu', { c: h.c, x: e.clientX, y: e.clientY }); return; }
      if (info.arrow && p.x > cr.x + cr.w - 20 * grid.z) { e.preventDefault(); setSel(h.r, h.c, h.r, h.c, { scroll: false }); openDropdown(); return; }
      if (info.checkbox) {
        const bs = Math.min(14 * grid.z, cr.h - 4), bx = cr.x + (cr.w - bs) / 2, by = cr.y + (cr.h - bs) / 2;
        if (p.x >= bx - 3 && p.x <= bx + bs + 3 && p.y >= by - 3 && p.y <= by + bs + 3) { e.preventDefault(); setSel(h.r, h.c, h.r, h.c, { scroll: false }); toggleCheckbox(h.r, h.c); return; }
      }
      if (info.link && (e.ctrlKey || e.metaKey)) { e.preventDefault(); openLink(info.link); return; }
    }
    if (touch) { drag = { type: 'tap', r: h.r, c: h.c, x: e.clientX, y: e.clientY, t: Date.now() }; return; }
    e.preventDefault();
    if (state.formatPainter) { setSel(h.r, h.c, h.r, h.c, { scroll: false }); drag = { type: 'cells', painter: true }; grid.scroller.setPointerCapture(e.pointerId); return; }
    if (e.shiftKey) setSel(state.sel.r, state.sel.c, h.r, h.c, { scroll: false });
    else setSel(h.r, h.c, h.r, h.c, { scroll: false, single: true });
    drag = { type: 'cells' };
    grid.scroller.setPointerCapture(e.pointerId);
  }
  function onPointerMove(e) {
    const p = local(e);
    if (!drag) { hover(p, e); return; }
    if (drag.type === 'tap') return;
    autoScroll(p, e);
    const h = grid.hit(clamp(p.x, grid.hw + 1, grid.vw - 1), clamp(p.y, grid.hh + 1, grid.vh - 1));
    const sh = cur();
    switch (drag.type) {
      case 'colresize': { const w = Math.max(2, drag.w0 + (p.x - drag.start) / grid.z); sh.colW[drag.c] = Math.round(w); grid.layout(); showSizeTip(e, Math.round(w) + ' px'); break; }
      case 'rowresize': { const hh = Math.max(4, drag.h0 + (p.y - drag.start) / grid.z); sh.rowH[drag.r] = Math.round(hh); grid.layout(); showSizeTip(e, Math.round(hh) + ' px'); break; }
      case 'cells': if (h.area === 'cell') { state.sel.r2 = h.r; state.sel.c2 = h.c; afterSel(); } break;
      case 'cols': { const c = grid.colFromX(clamp(p.x, grid.hw + 1, grid.vw - 1)); setSel(0, drag.anchor, sh.rows - 1, c, { scroll: false }); state.sel.c = drag.anchor; break; }
      case 'rows': { const r = grid.rowFromY(clamp(p.y, grid.hh + 1, grid.vh - 1)); setSel(drag.anchor, 0, r, sh.cols - 1, { scroll: false }); state.sel.r = drag.anchor; break; }
      case 'point': if (h.area === 'cell') pointTo(drag.r, drag.c, h.r, h.c); break;
      case 'fill': {
        if (h.area !== 'cell') break;
        const s = drag.src; let dest = { ...s }, dir = null;
        const dDown = h.r - s.b, dUp = s.t - h.r, dRight = h.c - s.r, dLeft = s.l - h.c;
        const best = Math.max(dDown, dUp, dRight, dLeft);
        if (best > 0) {
          if (best === dDown) { dest.b = h.r; dir = 'down'; } else if (best === dUp) { dest.t = h.r; dir = 'up'; }
          else if (best === dRight) { dest.r = h.c; dir = 'right'; } else { dest.l = h.c; dir = 'left'; }
        }
        drag.dest = dest; drag.dir = dir; state.fillPreview = dir ? dest : null; grid.invalidate();
        break;
      }
    }
  }
  function onPointerUp(e) {
    const d = drag; drag = null; stopAutoScroll(); hideSizeTip();
    if (!d) return;
    try { grid.scroller.releasePointerCapture(e.pointerId); } catch (err) { /* ignore */ }
    const sh = cur();
    if (d.type === 'colresize') {
      const w = sh.colW[d.c]; sh.colW[d.c] = Math.round(d.w0);
      const cols = (() => { const R = IS.selRect(); return R.t === 0 && R.b >= sh.rows - 1 && d.c >= R.l && d.c <= R.r ? selCols() : [d.c]; })();
      resizeCols(cols, w);
    } else if (d.type === 'rowresize') {
      const h = sh.rowH[d.r]; sh.rowH[d.r] = Math.round(d.h0); if (Math.abs(d.h0 - 24) < 0.5 && !sh.rowHa[d.r]) delete sh.rowH[d.r];
      const rows = (() => { const R = IS.selRect(); return R.l === 0 && R.r >= sh.cols - 1 && d.r >= R.t && d.r <= R.b ? selRows() : [d.r]; })();
      resizeRows(rows, h);
    } else if (d.type === 'fill') {
      state.fillPreview = null; grid.invalidate();
      if (d.dir) doFill(d.src, d.dest, d.dir, { series: e.ctrlKey });
    } else if (d.type === 'tap') {
      const moved = Math.abs(e.clientX - d.x) > 10 || Math.abs(e.clientY - d.y) > 10;
      if (!moved) {
        const now = Date.now();
        if (now - lastTap < 350 && state.sel.r === d.r && state.sel.c === d.c) startEdit(null, 'edit');
        else setSel(d.r, d.c, d.r, d.c, { scroll: false, single: true });
        lastTap = now;
      }
    } else if (d.type === 'cells' && d.painter) applyFormatPainter();
  }
  let autoTimer = null;
  function autoScroll(p) {
    const edge = 24; let dx = 0, dy = 0;
    if (p.x > grid.vw - edge) dx = 20; else if (p.x < grid.hw + 4 && drag && drag.type !== 'rows') dx = -20;
    if (p.y > grid.vh - edge) dy = 20; else if (p.y < grid.hh + 4 && drag && drag.type !== 'cols') dy = -20;
    if ((dx || dy) && drag && ['cells', 'cols', 'rows', 'fill', 'point'].includes(drag.type)) {
      if (!autoTimer) autoTimer = setInterval(() => { grid.scroller.scrollLeft += dx; grid.scroller.scrollTop += dy; }, 40);
    } else stopAutoScroll();
  }
  function stopAutoScroll() { clearInterval(autoTimer); autoTimer = null; }
  let tipEl = null;
  function showSizeTip(e, text) { if (!tipEl) { tipEl = document.createElement('div'); tipEl.className = 'size-tip'; document.body.appendChild(tipEl); } tipEl.textContent = text; tipEl.style.left = (e.clientX + 12) + 'px'; tipEl.style.top = (e.clientY + 12) + 'px'; tipEl.hidden = false; }
  function hideSizeTip() { if (tipEl) tipEl.hidden = true; }
  let noteEl = null;
  function hover(p, e) {
    const h = grid.hit(p.x, p.y); const sc = grid.scroller;
    let cursor = 'cell';
    if (h.area === 'colresize') cursor = 'col-resize'; else if (h.area === 'rowresize') cursor = 'row-resize';
    else if (h.area === 'colhead') cursor = 's-resize'; else if (h.area === 'rowhead') cursor = 'e-resize'; else if (h.area === 'corner') cursor = 'pointer';
    else if (h.area === 'cell') {
      const R = IS.selRect(); const rr = grid.rectScreen(R.t, R.l, R.b, R.r);
      if (Math.abs(p.x - (rr.x + rr.w)) <= 6 && Math.abs(p.y - (rr.y + rr.h)) <= 6 && !state.editing) cursor = 'crosshair';
      else {
        const info = IS.cellSource(cur()).info(h.r, h.c);
        const cr = grid.cellRect(h.r, h.c);
        if (info && (info.checkbox || ((info.arrow || info.filterBtn) && p.x > cr.x + cr.w - 20 * grid.z) || (info.link && (e.ctrlKey || e.metaKey)))) cursor = 'pointer';
        clearTimeout(hoverTimer);
        const cell = cur().cells[K(h.r, h.c)];
        if (cell && cell.n) hoverTimer = setTimeout(() => showNote(h.r, h.c, cell.n), 350);
        else if (info && info.link) hoverTimer = setTimeout(() => showNote(h.r, h.c, '🔗 ' + info.link + '\n(Ctrl+click to open)'), 500);
        else hideNote();
      }
    }
    if (state.formatPainter && h.area === 'cell') cursor = 'copy';
    if (sc.style.cursor !== cursor) sc.style.cursor = cursor;
  }
  function showNote(r, c, text) {
    if (!noteEl) { noteEl = document.createElement('div'); noteEl.className = 'note-pop'; grid.layer.appendChild(noteEl); }
    const cr = grid.cellRect(r, c);
    noteEl.textContent = text; noteEl.hidden = false;
    noteEl.style.left = Math.min(cr.x + cr.w + 4, grid.vw - 260) + 'px'; noteEl.style.top = Math.max(grid.hh, cr.y) + 'px';
  }
  function hideNote() { clearTimeout(hoverTimer); if (noteEl) noteEl.hidden = true; }
  function onDblClick(e) {
    const p = local(e); const h = grid.hit(p.x, p.y);
    if (h.area === 'colresize') { const R = IS.selRect(), sh = cur(); autoFitCols(R.t === 0 && R.b >= sh.rows - 1 && h.c >= R.l && h.c <= R.r ? selCols() : [h.c]); return; }
    if (h.area === 'rowresize') { autoFitRows([h.r]); return; }
    if (h.area === 'cell') {
      const info = IS.cellSource(cur()).info(h.r, h.c);
      if (info && info.checkbox) return;
      setSel(h.r, h.c, h.r, h.c, { scroll: false, single: true });
      const obj = IS.objectAtCell && IS.objectAtCell(h.r, h.c); if (obj) return;
      startEdit(null, 'edit');
    }
  }
  function onContextMenu(e) {
    e.preventDefault();
    if (state.editing) return;
    const p = local(e); const h = grid.hit(p.x, p.y); const sh = cur(); const R = IS.selRect();
    if (h.area === 'cell' && !(h.r >= R.t && h.r <= R.b && h.c >= R.l && h.c <= R.r)) setSel(h.r, h.c, h.r, h.c, { scroll: false, single: true });
    if (h.area === 'colhead' && !(h.c >= R.l && h.c <= R.r && R.t === 0 && R.b >= sh.rows - 1)) setSel(0, h.c, sh.rows - 1, h.c, { scroll: false });
    if (h.area === 'rowhead' && !(h.r >= R.t && h.r <= R.b && R.l === 0 && R.r >= sh.cols - 1)) setSel(h.r, 0, h.r, sh.cols - 1, { scroll: false });
    focusGrid();
    const items = h.area === 'colhead' ? IS.menus.colContext() : h.area === 'rowhead' ? IS.menus.rowContext() : IS.menus.cellContext();
    ui.menu(items, e.clientX, e.clientY);
  }
  function toggleCheckbox(r, c) {
    const sh = cur(); if (!guardEdit({ t: r, l: c, b: r, r: c })) return;
    const v = calc.value(sh, r, c);
    const on = v === true || v === 1 || (typeof v === 'string' && v.toUpperCase() === 'TRUE');
    if (IS.isFormulaCell(sh.cells[K(r, c)])) { ui.toast('This checkbox is controlled by a formula.'); return; }
    IS.tx(on ? 'Untick' : 'Tick', () => editCell(sh, r, c, cell => { cell.v = !on; delete cell.t; }));
  }
  function openLink(url) {
    if (/^#/.test(url) || /^[A-Za-z0-9 _'!]+![A-Z]+\d+$/.test(url)) { IS.goTo(url.replace(/^#/, '')); return; }
    if (!/^(https?:|mailto:|tel:|upi:)/i.test(url)) url = 'https://' + url;
    window.open(url, '_blank', 'noopener');
  }
  IS.openLink = openLink;

  // ---- dropdown for list validation
  function openDropdown() {
    const sh = cur(), s = state.sel; const rule = IS.dvFor(sh, s.r, s.c);
    if (!rule || (rule.type !== 'list' && rule.type !== 'range')) return;
    if (!guardEdit({ t: s.r, l: s.c, b: s.r, r: s.c })) return;
    const items = IS.dvItems(sh, rule);
    const cr = grid.cellRect(s.r, s.c), hr = grid.host.getBoundingClientRect();
    const wrap = document.createElement('div');
    wrap.innerHTML = '<input class="dd-search" placeholder="Search…" aria-label="Search list"><div class="dd-list" role="listbox"></div>';
    const list = wrap.querySelector('.dd-list'), search = wrap.querySelector('input');
    const curV = String(X.toStr(calc.value(sh, s.r, s.c))).toLowerCase();
    let idx = 0;
    const render = () => {
      const q = search.value.toLowerCase();
      const vis = items.filter(it => String(X.toStr(it)).toLowerCase().includes(q));
      list.innerHTML = vis.map((it, i) => '<button type="button" class="dd-item' + (String(X.toStr(it)).toLowerCase() === curV ? ' cur' : '') + (i === idx ? ' on' : '') + '" data-i="' + i + '">' + esc(X.toStr(it)) + '</button>').join('') || '<div class="dd-empty">No matches</div>';
      list._vis = vis;
    };
    render();
    const el = ui.popover(wrap, hr.left + cr.x, hr.top + cr.y + cr.h, { className: 'dropdown' });
    el.style.minWidth = Math.max(160, cr.w) + 'px';
    const pick = v => { ui.closePopups(); IS.tx('Choose ' + X.toStr(v), () => editCell(sh, s.r, s.c, cell => { cell.v = v; delete cell.t; })); focusGrid(); };
    list.addEventListener('click', e => { const b = e.target.closest('.dd-item'); if (b) pick(list._vis[+b.dataset.i]); });
    search.addEventListener('input', () => { idx = 0; render(); });
    search.addEventListener('keydown', e => {
      const vis = list._vis || [];
      if (e.key === 'ArrowDown') { e.preventDefault(); idx = Math.min(vis.length - 1, idx + 1); render(); }
      else if (e.key === 'ArrowUp') { e.preventDefault(); idx = Math.max(0, idx - 1); render(); }
      else if (e.key === 'Enter') { e.preventDefault(); if (vis[idx] !== undefined) pick(vis[idx]); }
      else if (e.key === 'Escape') { e.preventDefault(); ui.closePopups(); focusGrid(); }
    });
    setTimeout(() => search.focus(), 10);
  }
  IS.openDropdown = openDropdown;

  // ======================================================================= keyboard
  function focusGrid() { const k = $('gridKeys'); if (k && document.activeElement !== k) k.focus({ preventScroll: true }); }
  IS.focusGrid = focusGrid;
  function onKeyDown(e) {
    if ($('dlg').open) return;
    const ae = document.activeElement;
    const inEditorOrFx = ae === editor || ae === fx;
    if (!inEditorOrFx && ae && ae.id !== 'gridKeys' && ae !== document.body && /^(INPUT|TEXTAREA|SELECT|BUTTON)$/.test(ae.tagName)) {
      if (e.key === 'Escape' && ae.closest('.popup')) { ui.closePopups(); focusGrid(); }
      return;
    }
    if (ui.popupOpen && !inEditorOrFx && e.key === 'Escape') { ui.closePopups(); return; }
    const ctrl = e.ctrlKey || e.metaKey, k = e.key;
    if (state.editing) return editingKeys(e, ctrl);
    // shortcuts that work anywhere
    if (ctrl && !e.altKey) {
      const lower = k.toLowerCase();
      if (lower === 'v' && e.shiftKey) { state.pasteMode = 'values'; return; }
      if (lower === 'c' || lower === 'x' || lower === 'v') { state.pasteMode = null; return; }
      if (k === 'ArrowUp' || k === 'ArrowDown' || k === 'ArrowLeft' || k === 'ArrowRight') { e.preventDefault(); jump(k === 'ArrowDown' ? 1 : k === 'ArrowUp' ? -1 : 0, k === 'ArrowRight' ? 1 : k === 'ArrowLeft' ? -1 : 0, e.shiftKey); return; }
      if (k === 'Home') { e.preventDefault(); setSel(0, 0); return; }
      if (k === 'End') { e.preventDefault(); const u = IS.usedRange(cur()); setSel(u.b, u.r); return; }
      if (k === 'PageDown') { e.preventDefault(); IS.run('nextSheet'); return; }
      if (k === 'PageUp') { e.preventDefault(); IS.run('prevSheet'); return; }
      if (k === 'Enter') { e.preventDefault(); return; }
      if (k === ' ' || e.code === 'Space') { e.preventDefault(); const R = IS.selRect(); setSel(0, R.l, cur().rows - 1, R.r, { scroll: false }); state.sel.c = R.l; return; }
      if (k === ';' && !e.shiftKey) { e.preventDefault(); insertNow('date'); return; }
      if ((k === ':' || (k === ';' && e.shiftKey))) { e.preventDefault(); insertNow('time'); return; }
      if (k === '`' || e.code === 'Backquote') { e.preventDefault(); IS.run('toggleFormulas'); return; }
      const map = {
        z: 'undo', y: 'redo', b: 'bold', i: 'italic', u: 'underline', '5': 'strike', d: 'fillDown', r: 'fillRight', s: e.shiftKey ? 'download:xlsx' : 'saveNow', o: 'openFile', f: 'find', h: 'findReplace', g: 'goTo', k: 'insertLink', p: 'print', a: 'selectAll', '1': 'formatCells', '/': 'shortcuts', e: e.shiftKey ? 'center' : null, l: e.shiftKey ? 'filterToggle' : null, '9': 'hideRows', '0': 'hideCols', '-': 'deleteDialog', '=': 'insertDialog', '+': 'insertDialog', '\\': 'clearFormats'
      };
      if (e.shiftKey && lower === 'z') { e.preventDefault(); IS.run('redo'); return; }
      if (e.shiftKey && ['!', '1'].includes(k)) { e.preventDefault(); IS.run('nf', '#,##0.00'); return; }
      if (e.shiftKey && ['$', '4'].includes(k)) { e.preventDefault(); IS.run('nf', '"₹"#,##0.00'); return; }
      if (e.shiftKey && ['%', '5'].includes(k)) { e.preventDefault(); IS.run('nf', '0%'); return; }
      if (e.shiftKey && ['#', '3'].includes(k)) { e.preventDefault(); IS.run('nf', 'dd-mm-yyyy'); return; }
      if (e.shiftKey && ['(', '9'].includes(k)) { e.preventDefault(); unhideAround('row'); return; }
      if (e.shiftKey && [')', '0'].includes(k)) { e.preventDefault(); unhideAround('col'); return; }
      const cmd = map[lower];
      if (cmd) { e.preventDefault(); IS.run(cmd.split(':')[0], cmd.split(':')[1]); return; }
      return;
    }
    if (e.altKey && !ctrl) {
      if (k === '=' || e.code === 'Equal') { e.preventDefault(); IS.run('autosum', 'SUM'); return; }
      if (k === 'ArrowDown') { e.preventDefault(); openDropdown(); return; }
      if (k === 'Enter') return;
      return;
    }
    if (e.shiftKey && k === 'F11') { e.preventDefault(); IS.run('addSheet'); return; }
    if (e.shiftKey && k === 'F2') { e.preventDefault(); IS.run('editNote'); return; }
    if (e.shiftKey && (k === ' ' || e.code === 'Space')) { e.preventDefault(); const R = IS.selRect(); setSel(R.t, 0, R.b, cur().cols - 1, { scroll: false }); state.sel.r = R.t; return; }
    switch (k) {
      case 'ArrowUp': e.preventDefault(); move(-1, 0, e.shiftKey); return;
      case 'ArrowDown': e.preventDefault(); move(1, 0, e.shiftKey); return;
      case 'ArrowLeft': e.preventDefault(); move(0, -1, e.shiftKey); return;
      case 'ArrowRight': e.preventDefault(); move(0, 1, e.shiftKey); return;
      case 'Enter': e.preventDefault(); enterMove(e.shiftKey ? -1 : 1); return;
      case 'Tab': e.preventDefault(); if (state.tabStart == null) state.tabStart = state.sel.c; moveWithin(0, e.shiftKey ? -1 : 1); return;
      case 'PageDown': e.preventDefault(); move(grid.visibleRowCount(), 0, e.shiftKey); return;
      case 'PageUp': e.preventDefault(); move(-grid.visibleRowCount(), 0, e.shiftKey); return;
      case 'Home': e.preventDefault(); setSel(state.sel.r, Math.max(0, cur().freezeC || 0) && state.sel.c > cur().freezeC ? cur().freezeC : 0); return;
      case 'End': e.preventDefault(); jump(0, 1, e.shiftKey); return;
      case 'Delete': e.preventDefault(); if (IS.deleteSelectedObject && IS.deleteSelectedObject()) return; clearRange('contents'); return;
      case 'Backspace': e.preventDefault(); if (IS.deleteSelectedObject && IS.deleteSelectedObject()) return; { const s = state.sel; clearRange('contents', IS.selRect()); startEdit('', 'enter'); } return;
      case 'F2': e.preventDefault(); startEdit(null, 'edit'); return;
      case 'F4': e.preventDefault(); return;
      case 'F9': e.preventDefault(); calc.full(); grid.invalidate(); ui.toast('Recalculated'); return;
      case 'Escape': if (state.formatPainter) { state.formatPainter = null; syncToolbar(); } if (state.clipRect) { state.clipRect = null; state.clip && (state.clip.cut = false); grid.invalidate(); } if (state.trace) { state.trace = null; grid.invalidate(); } if (state.findHits) { state.findHits = null; grid.invalidate(); } return;
      case 'ContextMenu': { e.preventDefault(); const cr = grid.cellRect(state.sel.r, state.sel.c), hr = grid.host.getBoundingClientRect(); ui.menu(IS.menus.cellContext(), hr.left + cr.x + cr.w / 2, hr.top + cr.y + cr.h, { focus: true }); return; }
    }
    if (k.length === 1 && !e.altKey) {
      e.preventDefault();
      if (k === ' ' && IS.cellSource(cur()).info(state.sel.r, state.sel.c)?.checkbox) { toggleCheckbox(state.sel.r, state.sel.c); return; }
      startEdit(k, 'enter');
    }
  }
  function editingKeys(e, ctrl) {
    const k = e.key, ed = state.editing;
    if (hint && hint.start !== null) {
      if (k === 'ArrowDown' || k === 'ArrowUp') { e.preventDefault(); hint.idx = (hint.idx + (k === 'ArrowDown' ? 1 : -1) + hint.items.length) % hint.items.length; showHint(hint.items, hint.idx, hint.start); return; }
      if (k === 'Tab') { e.preventDefault(); acceptHint(hint.idx); return; }
    }
    if (k === 'Enter') {
      if (e.altKey || (ed.src === 'fx' && e.shiftKey && false)) { e.preventDefault(); insertAtCaret('\n'); return; }
      e.preventDefault();
      if (commitEdit({ fill: ctrl })) { if (!ctrl) enterMove(e.shiftKey ? -1 : 1); }
      return;
    }
    if (k === 'Tab') { e.preventDefault(); if (state.tabStart == null) state.tabStart = ed.c; if (commitEdit()) moveWithin(0, e.shiftKey ? -1 : 1); return; }
    if (k === 'Escape') { e.preventDefault(); cancelEdit(); return; }
    if (k === 'F4') { e.preventDefault(); toggleAbsolute(); return; }
    if (k === 'F2') { e.preventDefault(); ed.mode = ed.mode === 'enter' ? 'edit' : 'enter'; ui.toast(ed.mode === 'edit' ? 'Edit mode – arrow keys move inside the text' : 'Enter mode – arrow keys move between cells', { ms: 1500 }); return; }
    if (k.startsWith('Arrow') && ed.mode === 'enter' && ed.src === 'cell') {
      const dr = k === 'ArrowDown' ? 1 : k === 'ArrowUp' ? -1 : 0, dc = k === 'ArrowRight' ? 1 : k === 'ArrowLeft' ? -1 : 0;
      if (canPoint()) {
        e.preventDefault();
        const sh = cur(); const pt = ed.point;
        if (pt && e.shiftKey) { const [r2, c2] = step(sh, pt.r2, pt.c2, dr, dc); pointTo(pt.r, pt.c, r2, c2); }
        else { const base = pt ? [pt.r2, pt.c2] : [ed.r, ed.c]; const [r, c] = step(sh, base[0], base[1], dr, dc); pointTo(r, c); }
        return;
      }
      e.preventDefault();
      if (commitEdit()) move(dr, dc);
      return;
    }
    if (ctrl && k.toLowerCase() === 'z') { e.preventDefault(); cancelEdit(); return; }
    if (k.startsWith('Arrow') || k === 'Home' || k === 'End') setTimeout(() => { updateHint(); }, 0);
  }
  function insertAtCaret(t) { const inp = activeInput(); const s = inp.selectionStart; inp.value = inp.value.slice(0, s) + t + inp.value.slice(inp.selectionEnd); inp.setSelectionRange(s + t.length, s + t.length); mirror(inp); }
  function insertNow(kind) {
    const sh = cur(), s = state.sel; if (!guardEdit({ t: s.r, l: s.c, b: s.r, r: s.c })) return;
    const now = X.nowSerial();
    IS.tx(kind === 'date' ? 'Insert date' : 'Insert time', () => editCell(sh, s.r, s.c, cell => {
      cell.v = kind === 'date' ? Math.floor(now) : +(now - Math.floor(now)).toFixed(8); delete cell.t;
      cell.s = Object.assign({}, cell.s, { nf: kind === 'date' ? 'dd-mm-yyyy' : 'h:mm AM/PM' });
    }));
  }

  // ======================================================================= format painter
  function startFormatPainter() {
    const sh = cur(), R = IS.selRect();
    const styles = []; for (let r = R.t; r <= R.b && r < R.t + 200; r++) { const row = []; for (let c = R.l; c <= R.r && c < R.l + 50; c++) { const cell = sh.cells[K(r, c)]; row.push(cell && cell.s ? jclone(cell.s) : null); } styles.push(row); }
    state.formatPainter = { styles, h: styles.length, w: styles[0].length };
    syncToolbar(); ui.toast('Format painter: click or drag over the cells to format. Esc to stop.', { ms: 2500 });
  }
  function applyFormatPainter() {
    const fp = state.formatPainter; if (!fp) return;
    const R = IS.selRect();
    applyStyle('Paste format', (st, r, c) => { const s = fp.styles[(r - R.t) % fp.h][(c - R.l) % fp.w]; return s ? jclone(s) : {}; });
    state.formatPainter = null; syncToolbar();
  }

  // ======================================================================= sheets
  function activateSheet(i, opts = {}) {
    const wb = state.wb; if (i < 0 || i >= wb.sheets.length) return;
    const editingPoint = state.editing && canPoint();
    if (state.editing && !editingPoint) { if (!commitEdit()) return; }
    if (state.editing && editingPoint) { state.editing.prevSel = state.editing.prevSel || { ...state.sel }; }
    sheetSel.set(cur().id, { sel: { ...state.sel }, sl: grid.scroller.scrollLeft, st: grid.scroller.scrollTop });
    wb.active = i;
    const sh = cur();
    IS.invalidateHidden(sh);
    grid.setSheet(sh);
    const saved = sheetSel.get(sh.id);
    if (saved && !state.editing) { state.sel = { ...saved.sel }; grid.scroller.scrollLeft = saved.sl; grid.scroller.scrollTop = saved.st; grid.readScroll(); }
    else if (!state.editing) state.sel = { r: 0, c: 0, r2: 0, c2: 0 };
    if (state.editing) { editor.style.display = state.editing.sheetId === sh.id ? 'block' : 'none'; fx.focus(); state.editing.src = 'fx'; }
    renderTabs(); afterSel(); positionEditor();
    IS.emit('sheet', sh);
    if (!opts.silent) markDirty(true);
  }
  IS.activateSheet = activateSheet;
  function uniqueSheetName(base) { let n = 1, name = base; while (sheetByName(name)) name = base + ' (' + (++n) + ')'; return name; }
  IS.uniqueSheetName = uniqueSheetName;
  function addSheet(sheet, at) {
    if (!guardEdit(null)) return;
    const wb = state.wb;
    IS.tx('Add sheet', () => {
      recBook();
      let n = wb.sheets.length + 1; while (sheetByName('Sheet' + n)) n++;
      const sh = sheet || IS.newSheet('Sheet' + n);
      if (sheetByName(sh.name)) sh.name = uniqueSheetName(sh.name);
      wb.sheets.splice(at == null ? wb.active + 1 : at, 0, sh);
    });
    activateSheet(wb.sheets.indexOf(sheet || wb.sheets[at == null ? wb.active + 1 : at]));
  }
  IS.addSheet = addSheet;
  function renameSheet(i, name) {
    const wb = state.wb, sh = wb.sheets[i]; const old = sh.name;
    name = String(name || '').trim().replace(/[\\/?*[\]:]/g, '').slice(0, 31);
    if (!name || name === old) return;
    if (wb.sheets.some((s, j) => j !== i && s.name.toUpperCase() === name.toUpperCase())) { ui.toast('A sheet called "' + name + '" already exists.', { type: 'error' }); return; }
    IS.tx('Rename sheet', () => {
      recMeta(sh); sh.name = name;
      for (const other of wb.sheets) for (const k of Object.keys(other.cells)) {
        const cell = other.cells[k]; if (!IS.isFormulaCell(cell)) continue;
        const f = X.transformRefs(cell.v, ref => (ref.sheet && ref.sheet.toUpperCase() === old.toUpperCase() ? (ref.kind === 'cell' ? { row: ref.row, col: ref.col, sheet: name } : ref.kind === 'cols' ? { c1: ref.c1, c2: ref.c2, sheet: name } : { r1: ref.r1, r2: ref.r2, sheet: name }) : undefined));
        if (f !== cell.v) { recCell(other, k); cell.v = f; }
      }
      recBook();
      for (const n in wb.names) { const ref = wb.names[n].ref; const f = X.transformRefs('=' + ref, rf => (rf.sheet && rf.sheet.toUpperCase() === old.toUpperCase() ? (rf.kind === 'cell' ? { row: rf.row, col: rf.col, sheet: name } : undefined) : undefined)); wb.names[n].ref = f.slice(1); }
      (wb.sheets.flatMap(s => s.objects || [])).forEach(o => { if (o.chart && o.chart.src && o.chart.src.startsWith(X.quoteSheet(old) + '!')) o.chart.src = X.quoteSheet(name) + o.chart.src.slice(X.quoteSheet(old).length); });
    }, { full: true });
  }
  IS.renameSheet = renameSheet;
  async function deleteSheet(i) {
    const wb = state.wb;
    if (wb.sheets.filter(s => !s.hidden).length <= 1) { ui.toast('A workbook needs at least one visible sheet.'); return; }
    if (!guardEdit(null)) return;
    const sh = wb.sheets[i];
    const hasData = Object.keys(sh.cells).length > 0;
    if (hasData && !(await ui.confirm('Delete sheet "' + sh.name + '"? You can undo this with Ctrl+Z.', { ok: 'Delete', danger: true }))) return;
    IS.tx('Delete sheet', () => { recBook(); wb.sheets.splice(i, 1); wb.active = clamp(wb.active >= i ? wb.active - 1 : wb.active, 0, wb.sheets.length - 1); if (wb.sheets[wb.active].hidden) wb.active = wb.sheets.findIndex(s => !s.hidden); }, { full: true });
    activateSheet(wb.active);
  }
  function duplicateSheet(i) {
    const wb = state.wb; const copy = jclone(wb.sheets[i]); copy.id = IS.rid('s'); copy.name = uniqueSheetName(wb.sheets[i].name + ' copy'); copy.hidden = false;
    (copy.objects || []).forEach(o => { o.id = IS.rid('o'); });
    addSheet(copy, i + 1);
  }
  function moveSheet(i, j) {
    const wb = state.wb; if (j < 0 || j >= wb.sheets.length || i === j) return;
    IS.tx('Move sheet', () => { recBook(); const activeId = cur().id; const [s] = wb.sheets.splice(i, 1); wb.sheets.splice(j, 0, s); wb.active = wb.sheets.findIndex(x => x.id === activeId); });
  }
  function renderTabs() {
    const el = $('tabs'); if (!el) return;
    const wb = state.wb; el.innerHTML = '';
    wb.sheets.forEach((s, i) => {
      if (s.hidden) return;
      const b = document.createElement('button'); b.type = 'button';
      b.className = 'tab' + (i === wb.active ? ' on' : '');
      b.innerHTML = (s.protect && s.protect.on ? ui.icon('lock', 12) + ' ' : '') + esc(s.name) + (s.color ? '<i class="tab-color" style="background:' + s.color + '"></i>' : '');
      b.title = s.name + ' — double-click to rename, right-click for more';
      b.draggable = true;
      b.addEventListener('click', () => activateSheet(i));
      b.addEventListener('dblclick', () => inlineRename(b, i));
      b.addEventListener('contextmenu', e => { e.preventDefault(); ui.menu(IS.menus.sheetContext(i), e.clientX, e.clientY - 4); });
      b.addEventListener('dragstart', e => { e.dataTransfer.setData('text/x-sheet', String(i)); e.dataTransfer.effectAllowed = 'move'; });
      b.addEventListener('dragover', e => { if ([...e.dataTransfer.types].includes('text/x-sheet')) { e.preventDefault(); b.classList.add('drop'); } });
      b.addEventListener('dragleave', () => b.classList.remove('drop'));
      b.addEventListener('drop', e => { e.preventDefault(); b.classList.remove('drop'); const from = +e.dataTransfer.getData('text/x-sheet'); moveSheet(from, i); });
      el.appendChild(b);
      if (i === wb.active) setTimeout(() => b.scrollIntoView({ block: 'nearest', inline: 'nearest' }), 0);
    });
  }
  IS.renderTabs = renderTabs;
  function inlineRename(btn, i) {
    if (!guardEdit(null)) return;
    const inp = document.createElement('input'); inp.className = 'tab-input'; inp.value = state.wb.sheets[i].name;
    btn.replaceWith(inp); inp.focus(); inp.select();
    let done = false;
    const finish = save => { if (done) return; done = true; if (save) renameSheet(i, inp.value); renderTabs(); focusGrid(); };
    inp.addEventListener('keydown', e => { if (e.key === 'Enter') finish(true); else if (e.key === 'Escape') finish(false); e.stopPropagation(); });
    inp.addEventListener('blur', () => finish(true));
  }

  // ======================================================================= go to / name box
  IS.goTo = function (text) {
    text = String(text || '').trim(); if (!text) return false;
    const wb = state.wb;
    const nm = wb.names[text.toUpperCase()];
    const target = nm ? nm.ref : text;
    const p = X.parseRef(target);
    if (!p) return false;
    if (p.sheet) { const i = wb.sheets.findIndex(s => s.name.toUpperCase() === p.sheet.toUpperCase()); if (i < 0) return false; if (i !== wb.active) activateSheet(i); }
    const sh = cur();
    const r2 = p.r2 === Infinity ? sh.rows - 1 : p.r2, c2 = p.c2 === Infinity ? sh.cols - 1 : p.c2;
    if (r2 >= sh.rows) sh.rows = Math.min(1048576, r2 + 50);
    if (c2 >= sh.cols) sh.cols = Math.min(16384, c2 + 5);
    grid.layout();
    setSel(p.r1, p.c1, r2, c2, { scrollR: p.r1, scrollC: p.c1 });
    return true;
  };
  function onNameBoxKey(e) {
    if (e.key === 'Enter') {
      e.preventDefault(); const v = e.target.value.trim();
      if (IS.goTo(v)) { focusGrid(); return; }
      if (/^[A-Za-z_\\][A-Za-z0-9_.]*$/.test(v) && !/^[A-Za-z]{1,3}\d+$/.test(v) && !/^(TRUE|FALSE)$/i.test(v)) {
        const R = IS.selRect(); const ref = X.quoteSheet(cur().name) + '!' + X.a1(R.t, R.l, true, true) + (R.t !== R.b || R.l !== R.r ? ':' + X.a1(R.b, R.r, true, true) : '');
        IS.tx('Define name', () => { recBook(); state.wb.names[v.toUpperCase()] = { name: v, ref }; }, { full: true });
        ui.toast('Named range "' + v + '" created → ' + ref); focusGrid(); return;
      }
      ui.toast('"' + v + '" is not a cell, range or name.', { type: 'error' });
    } else if (e.key === 'Escape') { updateNameBox(); focusGrid(); }
  }

  // ======================================================================= saving
  let saveTimer = null, lastSnap = 0, snapTimer = null;
  function markDirty(quiet) {
    state.dirty = true;
    if (!quiet) { const ss = $('saveState'); if (ss) { ss.textContent = 'Saving…'; ss.className = 'save-state busy'; } }
    clearTimeout(saveTimer); saveTimer = setTimeout(saveNow, 900);
  }
  IS.markDirty = markDirty;
  async function saveNow() {
    clearTimeout(saveTimer);
    if (!state.wb || state.readOnly) return;
    const wb = state.wb; wb.updated = Date.now();
    const ss = $('saveState');
    try {
      await IS.store.put(wb);
      state.dirty = false;
      if (ss) { ss.textContent = IS.store.persistent ? 'Saved ✓' : 'Not saved (private window)'; ss.title = IS.store.persistent ? 'Saved on this device at ' + new Date().toLocaleTimeString('en-IN') : 'This browser window does not allow saving – download your work'; ss.className = 'save-state' + (IS.store.persistent ? '' : ' warn'); }
      if (Date.now() - lastSnap > 10 * 60 * 1000) { lastSnap = Date.now(); IS.store.addVersion(wb.id, 'Auto-save', jclone(wb)).catch(() => {}); }
    } catch (e) {
      console.error(e);
      if (ss) { ss.textContent = 'Could not save!'; ss.className = 'save-state warn'; }
      ui.toast('Saving failed: ' + (e.message || e) + '. Download a copy with File → Download.', { type: 'error', ms: 8000 });
    }
  }
  IS.saveNow = saveNow;
  async function openBook(book, opts = {}) {
    if (state.editing) cancelEdit();
    if (state.dirty) await saveNow();
    const wb = IS.normalizeBook(book);
    state.wb = wb; state.readOnly = !!opts.readOnly; state.readOnlyMsg = opts.readOnlyMsg || null;
    undoStack.length = 0; redoStack.length = 0; sheetSel.clear(); state.clip = null; state.clipRect = null; state.findHits = null; state.trace = null;
    calc.attach(wb);
    wb.sheets.forEach(IS.invalidateHidden);
    grid.setSheet(cur());
    state.sel = { r: 0, c: 0, r2: 0, c2: 0 };
    $('bookName').value = wb.name; document.title = wb.name + ' – India Sheets';
    document.body.classList.toggle('readonly', state.readOnly);
    if (!opts.readOnly) IS.prefs.set('lastBook', wb.id);
    lastSnap = Date.now();
    renderTabs(); afterSel();
    IS.emit('book', wb);
    if (opts.save) await saveNow();
  }
  IS.openBook = openBook;
  async function newBook(name, sheets) {
    const b = IS.newBook(name); if (sheets) b.sheets = sheets;
    await openBook(b, { save: true });
    return b;
  }
  IS.newBookAndOpen = newBook;

  // ======================================================================= commands
  const cmd = IS.cmd = IS.cmd || {};
  IS.run = function (name, arg) {
    const fn = cmd[name];
    if (!fn) { ui.toast('Not available: ' + name); return; }
    if (state.editing && !['undo', 'insertFunction', 'functions', 'assistant', 'explainFormula'].includes(name)) { if (!commitEdit()) return; }
    try { return fn(arg); } catch (e) { console.error(e); ui.toast('Error: ' + (e.message || e), { type: 'error' }); }
  };
  Object.assign(cmd, {
    undo, redo,
    cut: () => { focusGrid(); if (!document.execCommand('cut')) ui.toast('Use Ctrl+X to cut.'); },
    copy: () => { focusGrid(); if (!document.execCommand('copy')) ui.toast('Use Ctrl+C to copy.'); },
    paste: () => pasteFromMenu(null),
    pasteValues: () => pasteFromMenu('values'), pasteFormats: () => pasteFromMenu('formats'), pasteFormulas: () => pasteFromMenu('formulas'), pasteTranspose: () => pasteFromMenu('transpose'), pasteWidths: () => pasteFromMenu('widths'),
    selectAll, fillDown: () => fillDir('down'), fillRight: () => fillDir('right'),
    clearAll: () => clearRange('all'), clearContents: () => clearRange('contents'), clearFormats: () => clearRange('formats'), clearNotes: () => clearRange('notes'),
    bold: () => toggleStyle('b', 'Bold'), italic: () => toggleStyle('i', 'Italic'), underline: () => toggleStyle('u', 'Underline'), strike: () => toggleStyle('st', 'Strikethrough'),
    alignLeft: () => setStyle('al', 'left', 'Align left'), alignCenter: () => setStyle('al', 'center', 'Align centre'), center: () => setStyle('al', 'center', 'Align centre'), alignRight: () => setStyle('al', 'right', 'Align right'), alignAuto: () => setStyle('al', null, 'Align'),
    vTop: () => setStyle('va', 'top', 'Align top'), vMiddle: () => setStyle('va', 'middle', 'Align middle'), vBottom: () => setStyle('va', null, 'Align bottom'),
    wrapToggle: () => toggleStyle('wrap', 'Wrap text'), wrapOn: () => setStyle('wrap', true, 'Wrap text'), wrapOff: () => setStyle('wrap', null, 'Overflow text'),
    fontSize: n => setStyle('fs', n && +n !== 10 ? +n : null, 'Font size'), fontFamily: f => setStyle('ff', f || null, 'Font'),
    fontBigger: () => { const s = state.sel, cell = cur().cells[K(s.r, s.c)]; const fs = (cell && cell.s && cell.s.fs) || 10; setStyle('fs', fs + 2, 'Font size'); },
    fontSmaller: () => { const s = state.sel, cell = cur().cells[K(s.r, s.c)]; const fs = (cell && cell.s && cell.s.fs) || 10; setStyle('fs', Math.max(6, fs - 2), 'Font size'); },
    textColor: c => { if (c !== undefined) { state.lastText = c; setStyle('color', c, 'Text colour'); } else { const b = $('tbTextColor').getBoundingClientRect(); ui.palette(b.left, b.bottom + 4, col => { state.lastText = col || state.lastText; setStyle('color', col, 'Text colour'); }, { noneLabel: 'Automatic' }); } },
    fillColor: c => { if (c !== undefined) { state.lastFill = c; setStyle('bg', c, 'Fill colour'); } else { const b = $('tbFillColor').getBoundingClientRect(); ui.palette(b.left, b.bottom + 4, col => { state.lastFill = col || state.lastFill; setStyle('bg', col, 'Fill colour'); }, { noneLabel: 'No fill' }); } },
    textColorLast: () => setStyle('color', state.lastText || '#c62828', 'Text colour'),
    fillColorLast: () => setStyle('bg', state.lastFill || '#fff2cc', 'Fill colour'),
    nf: code => applyStyle('Number format', st => { if (!code || code === 'General') delete st.nf; else st.nf = code; return st; }),
    decUp: () => changeDecimals(1), decDown: () => changeDecimals(-1),
    indentMore: () => applyStyle('Indent', st => { st.ind = Math.min(10, (st.ind || 0) + 1); return st; }), indentLess: () => applyStyle('Indent', st => { st.ind = Math.max(0, (st.ind || 0) - 1) || undefined; return st; }),
    borders: kind => setBorders(kind, state.borderColor, state.borderStyle),
    mergeAll: () => mergeCells('all'), mergeRows: () => mergeCells('rows'), mergeCols: () => mergeCells('cols'), unmerge: () => mergeCells('unmerge'),
    mergeToggle: () => { const s = state.sel; if (IS.mergeAt(cur(), s.r, s.c)) mergeCells('unmerge'); else mergeCells('all'); },
    insertRowsAbove: () => { const R = IS.selRect(); restructure('row', R.t, R.b - R.t + 1); }, insertRowsBelow: () => { const R = IS.selRect(); restructure('row', R.b + 1, R.b - R.t + 1); },
    insertColsLeft: () => { const R = IS.selRect(); restructure('col', R.l, R.r - R.l + 1); }, insertColsRight: () => { const R = IS.selRect(); restructure('col', R.r + 1, R.r - R.l + 1); },
    deleteRows: () => { const R = IS.selRect(); restructure('row', R.t, -(R.b - R.t + 1)); }, deleteCols: () => { const R = IS.selRect(); restructure('col', R.l, -(R.r - R.l + 1)); },
    insertDialog: () => { const R = IS.selRect(), sh = cur(); if (R.l === 0 && R.r >= sh.cols - 1) return cmd.insertRowsAbove(); if (R.t === 0 && R.b >= sh.rows - 1) return cmd.insertColsLeft(); ui.menu([{ label: 'Insert rows above', cmd: 'insertRowsAbove' }, { label: 'Insert columns left', cmd: 'insertColsLeft' }], window.innerWidth / 2 - 80, window.innerHeight / 3, { focus: true }); },
    deleteDialog: () => { const R = IS.selRect(), sh = cur(); if (R.l === 0 && R.r >= sh.cols - 1) return cmd.deleteRows(); if (R.t === 0 && R.b >= sh.rows - 1) return cmd.deleteCols(); ui.menu([{ label: 'Delete rows', cmd: 'deleteRows' }, { label: 'Delete columns', cmd: 'deleteCols' }, { label: 'Clear contents', cmd: 'clearContents' }], window.innerWidth / 2 - 80, window.innerHeight / 3, { focus: true }); },
    hideRows: () => setHidden('row', selRows(), true), hideCols: () => setHidden('col', selCols(), true),
    unhideRows: () => unhideAround('row'), unhideCols: () => unhideAround('col'),
    unhideAllRows: () => setHidden('row', cur().hiddenRows.slice(), false), unhideAllCols: () => setHidden('col', cur().hiddenCols.slice(), false),
    rowHeight: async () => { const v = await ui.prompt('Row height', 'Height in pixels (default 24)', String(Math.round(grid.rh(state.sel.r) / grid.z))); if (v !== null && +v > 0) resizeRows(selRows(), +v); },
    colWidth: async () => { const v = await ui.prompt('Column width', 'Width in pixels (default 100)', String(Math.round(grid.cw(state.sel.c) / grid.z))); if (v !== null && +v > 0) resizeCols(selCols(), +v); },
    autofitCols: () => autoFitCols(selCols()), autofitRows: () => autoFitRows(selRows()),
    freeze: arg => {
      const sh = cur(); const s = state.sel;
      IS.tx('Freeze', () => {
        recMeta(sh);
        if (arg === 'none') { sh.freezeR = 0; sh.freezeC = 0; }
        else if (arg === 'row1') sh.freezeR = 1; else if (arg === 'row2') sh.freezeR = 2; else if (arg === 'rowsHere') sh.freezeR = s.r; else if (arg === 'rows0') sh.freezeR = 0;
        else if (arg === 'col1') sh.freezeC = 1; else if (arg === 'col2') sh.freezeC = 2; else if (arg === 'colsHere') sh.freezeC = s.c; else if (arg === 'cols0') sh.freezeC = 0;
        else if (arg === 'here') { sh.freezeR = s.r; sh.freezeC = s.c; }
        else if (arg === 'toggle') { if (sh.freezeR || sh.freezeC) { sh.freezeR = 0; sh.freezeC = 0; } else sh.freezeR = 1; }
      }, { layout: true });
    },
    toggleGrid: () => { const sh = cur(); IS.tx('Gridlines', () => { recMeta(sh); sh.showGrid = sh.showGrid === false; }, { layout: true }); },
    toggleFormulas: () => { state.showFormulas = !state.showFormulas; grid.invalidate(); syncToolbar(); ui.toast(state.showFormulas ? 'Showing formulas (Ctrl+` to switch back)' : 'Showing results', { ms: 1500 }); },
    zoomIn: () => setZoom(state.zoom + 0.1), zoomOut: () => setZoom(state.zoom - 0.1), zoomReset: () => setZoom(1), zoomTo: z => setZoom(+z),
    fullscreen: () => { if (document.fullscreenElement) document.exitFullscreen(); else document.documentElement.requestFullscreen().catch(() => {}); },
    theme: t => applyTheme(t, true),
    toggleTheme: () => { const dark = document.documentElement.dataset.themeResolved !== 'dark'; applyTheme(dark ? 'dark' : 'light', true); ui.toast(dark ? 'Dark mode on – click ☀ to go back to white' : 'Light (white) mode on', { ms: 1800 }); },
    addSheet: () => addSheet(), renameSheet: i => inlineRename(document.querySelector('.tab.on') || document.createElement('button'), i == null ? state.wb.active : i),
    duplicateSheet: i => duplicateSheet(i == null ? state.wb.active : i), deleteSheet: i => deleteSheet(i == null ? state.wb.active : i),
    moveSheetLeft: i => { i = i == null ? state.wb.active : i; moveSheet(i, i - 1); }, moveSheetRight: i => { i = i == null ? state.wb.active : i; moveSheet(i, i + 1); },
    nextSheet: () => { const wb = state.wb; for (let i = wb.active + 1; i < wb.sheets.length; i++) if (!wb.sheets[i].hidden) return activateSheet(i); },
    prevSheet: () => { const wb = state.wb; for (let i = wb.active - 1; i >= 0; i--) if (!wb.sheets[i].hidden) return activateSheet(i); },
    sheetColor: i => { i = i == null ? state.wb.active : i; const b = document.querySelector('.tab.on'); const r = b ? b.getBoundingClientRect() : { left: 200, top: window.innerHeight - 300 }; ui.palette(r.left, r.top - 260, col => { const sh = state.wb.sheets[i]; IS.tx('Tab colour', () => { recMeta(sh); sh.color = col; }); renderTabs(); }, { noneLabel: 'No colour' }); },
    hideSheet: i => { i = i == null ? state.wb.active : i; const wb = state.wb; if (wb.sheets.filter(s => !s.hidden).length <= 1) { ui.toast('At least one sheet must stay visible.'); return; } const sh = wb.sheets[i]; IS.tx('Hide sheet', () => { recMeta(sh); sh.hidden = true; }); cmd.nextSheet(); if (cur().hidden) cmd.prevSheet(); renderTabs(); },
    unhideSheet: id => { const sh = sheetById(id); if (!sh) return; IS.tx('Unhide sheet', () => { recMeta(sh); sh.hidden = false; }); renderTabs(); activateSheet(state.wb.sheets.indexOf(sh)); },
    sheetList: () => { const b = document.querySelector('[data-cmd="sheetList"]').getBoundingClientRect(); ui.menu(state.wb.sheets.map((s, i) => ({ label: s.name + (s.hidden ? ' (hidden)' : ''), checked: i === state.wb.active, onClick: () => { if (s.hidden) cmd.unhideSheet(s.id); else activateSheet(i); } })), b.left, b.top - 8 - Math.min(400, state.wb.sheets.length * 30)); },
    insertCheckbox: () => { const sh = cur(), R = IS.selRect(); if (!guardEdit(R)) return; IS.tx('Insert checkbox', () => forEachCell(R, (r, c) => editCell(sh, r, c, cell => { cell.s = Object.assign({}, cell.s, { cb: true, al: 'center' }); if (!IS.hasValue(cell) || typeof cell.v !== 'boolean') { cell.v = false; delete cell.t; } }), { all: true })); },
    insertDate: () => insertNow('date'), insertTime: () => insertNow('time'),
    insertLink: async () => {
      const sh = cur(), s = state.sel; if (!guardEdit({ t: s.r, l: s.c, b: s.r, r: s.c })) return;
      const cell = sh.cells[K(s.r, s.c)];
      const url = await ui.prompt('Insert link', 'Web address, email or cell (e.g. https://…, mailto:…, Sheet2!A1)', (cell && cell.s && cell.s.link) || '');
      if (url === null) return;
      IS.tx('Link', () => editCell(sh, s.r, s.c, c => { c.s = Object.assign({}, c.s); if (url) c.s.link = url.trim(); else delete c.s.link; if (!IS.hasValue(c) && url) c.v = url.trim(); }));
    },
    removeLink: () => setStyle('link', null, 'Remove link'),
    editNote: async () => {
      const sh = cur(), s = state.sel; if (!guardEdit({ t: s.r, l: s.c, b: s.r, r: s.c })) return;
      const cell = sh.cells[K(s.r, s.c)];
      const v = await ui.modal({ title: 'Note for ' + A1(s.r, s.c), body: '<textarea id="noteText" class="note-text" rows="5" placeholder="Write a note…">' + esc((cell && cell.n) || '') + '</textarea>', actions: [{ label: 'Delete note', value: 'del', left: true }, { label: 'Cancel', value: null }, { label: 'Save', primary: true, value: 'save', onClick: b => { state._note = b.querySelector('#noteText').value; } }] });
      if (v === 'save') IS.tx('Note', () => editCell(sh, s.r, s.c, c => { if (state._note.trim()) c.n = state._note; else delete c.n; }));
      if (v === 'del') IS.tx('Delete note', () => editCell(sh, s.r, s.c, c => { delete c.n; }));
    },
    autosum: fn => {
      fn = fn || 'SUM'; const sh = cur(), R = IS.selRect();
      if (!guardEdit(R)) return;
      if (R.t === R.b && R.l === R.r) {
        let r0 = R.t - 1; while (r0 >= 0 && typeof X.norm(calc.value(sh, r0, R.l)) === 'number') r0--;
        if (r0 < R.t - 1) return startEdit('=' + fn + '(' + A1(r0 + 1, R.l) + ':' + A1(R.t - 1, R.l) + ')', 'edit');
        let c0 = R.l - 1; while (c0 >= 0 && typeof X.norm(calc.value(sh, R.t, c0)) === 'number') c0--;
        if (c0 < R.l - 1) return startEdit('=' + fn + '(' + A1(R.t, c0 + 1) + ':' + A1(R.t, R.l - 1) + ')', 'edit');
        return startEdit('=' + fn + '(', 'enter');
      }
      IS.tx('AutoSum', () => {
        if (R.t === R.b) writeText(sh, R.t, R.r + 1, '=' + fn + '(' + A1(R.t, R.l) + ':' + A1(R.t, R.r) + ')');
        else for (let c = R.l; c <= R.r; c++) writeText(sh, R.b + 1, c, '=' + fn + '(' + A1(R.t, c) + ':' + A1(R.b, c) + ')');
      });
    },
    insertFunction: name => {
      if (state.editing) { insertAtCaret(name + '('); updateHint(); updateRefBoxes(); return; }
      startEdit('=' + name + '(', 'enter');
    },
    find: () => openFind(false), findReplace: () => (cmd.findReplaceDialog ? cmd.findReplaceDialog() : openFind(true)),
    goTo: () => { const nb = $('nameBox'); nb.focus(); nb.select(); },
    saveNow: async () => { await saveNow(); ui.toast(IS.store.persistent ? 'Saved on this device ✓ (use File → Download to keep a file copy)' : 'Saved in memory only – this browser blocks storage. Download a copy!', { ms: 3000 }); },
    formatPainter: () => { if (state.formatPainter) { state.formatPainter = null; syncToolbar(); } else startFormatPainter(); },
    recalc: () => { calc.full(); grid.invalidate(); ui.toast('Recalculated everything'); },
    rename: () => { $('bookName').focus(); $('bookName').select(); }
  });

  function setZoom(z) {
    z = Math.round(clamp(z, 0.5, 2) * 100) / 100;
    state.zoom = z; grid.setZoom(z); $('zoomLabel').textContent = Math.round(z * 100) + '%';
    IS.prefs.set('zoom', z); positionEditor();
  }

  // ======================================================================= find bar (quick find)
  function openFind(replace) {
    const bar = $('findBar'); bar.hidden = false; $('replaceRow').hidden = !replace;
    const t = $('findText'); t.focus(); t.select();
    grid.resize();
  }
  function closeFind() { $('findBar').hidden = true; state.findHits = null; grid.invalidate(); grid.resize(); focusGrid(); }
  function collectHits() {
    const q = $('findText').value; const sh = cur();
    if (!q) { state.findHits = null; grid.invalidate(); $('findInfo').textContent = ''; return []; }
    const mc = $('findCase').checked, whole = $('findWhole').checked, inF = $('findFormulas').checked;
    const norm = s => (mc ? s : s.toLowerCase()), qq = norm(q);
    const list = [];
    const keys = new Set(Object.keys(sh.cells)); (calc.vals.get(sh.id) || new Map()).forEach((v, k) => keys.add(k));
    for (const k of keys) {
      const i = k.indexOf(':'); const r = +k.slice(0, i), c = +k.slice(i + 1);
      const cell = sh.cells[k];
      const disp = X.formatValue(calc.value(sh, r, c), cell && cell.s && cell.s.nf).text;
      const hay = [disp]; if (inF && cell && typeof cell.v === 'string') hay.push(cell.v);
      if (hay.some(h => (whole ? norm(String(h)) === qq : norm(String(h)).includes(qq)))) list.push({ r, c });
    }
    list.sort((a, b) => a.r - b.r || a.c - b.c);
    state.findHits = { sheet: sh.id, list };
    $('findInfo').textContent = list.length ? list.length + ' found' : 'Not found';
    grid.invalidate();
    return list;
  }
  function findNext(back) {
    const list = collectHits(); if (!list.length) return;
    const s = state.sel;
    let hit = back ? [...list].reverse().find(h => h.r < s.r || (h.r === s.r && h.c < s.c)) : list.find(h => h.r > s.r || (h.r === s.r && h.c > s.c));
    if (!hit) hit = back ? list[list.length - 1] : list[0];
    setSel(hit.r, hit.c);
    $('findInfo').textContent = (list.indexOf(hit) + 1) + ' of ' + list.length;
  }
  function replaceOne() {
    const s = state.sel, sh = cur(); const q = $('findText').value, rep = $('replaceText').value;
    const cell = sh.cells[K(s.r, s.c)];
    if (cell && typeof cell.v === 'string' && q && guardEdit({ t: s.r, l: s.c, b: s.r, r: s.c })) {
      const re = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), $('findCase').checked ? '' : 'i');
      if (re.test(cell.v)) IS.tx('Replace', () => editCell(sh, s.r, s.c, c => { c.v = c.v.replace(re, rep); }));
    }
    findNext();
  }
  function replaceAll() {
    const q = $('findText').value, rep = $('replaceText').value; if (!q) return;
    const sh = cur(); if (!guardEdit(null, { structure: !!(sh.protect && sh.protect.on) })) return;
    const re = new RegExp(q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), $('findCase').checked ? 'g' : 'gi');
    let n = 0;
    IS.tx('Replace all', () => {
      for (const k of Object.keys(sh.cells)) {
        const cell = sh.cells[k];
        if (typeof cell.v !== 'string' || (IS.isFormulaCell(cell) && !$('findFormulas').checked)) continue;
        if ($('findWhole').checked ? cell.v.toLowerCase() !== q.toLowerCase() : !re.test(cell.v)) { re.lastIndex = 0; continue; }
        re.lastIndex = 0;
        const i = k.indexOf(':'); const r = +k.slice(0, i), c = +k.slice(i + 1);
        editCell(sh, r, c, cl => { cl.v = $('findWhole').checked ? rep : cl.v.replace(re, rep); if (!IS.isFormulaCell(cl)) { const p = IS.parseEntry(cl.v, cl); cl.v = p.v === null ? '' : p.v; } });
        n++;
      }
    });
    $('findInfo').textContent = n + ' replaced';
    collectHits();
  }

  // ======================================================================= theme
  /** White (light) is the default for everyone; dark only when the user chooses it (or picks "Same as Windows"). */
  function applyTheme(t, save) {
    if (t) { if (save) IS.prefs.set('theme', t); } else t = IS.prefs.get('theme', 'light');
    const dark = t === 'dark' || (t === 'system' && window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches);
    const root = document.documentElement;
    root.dataset.theme = dark ? 'dark' : 'light';
    root.dataset.themeResolved = dark ? 'dark' : 'light';
    const cs = document.querySelector('meta[name=color-scheme]'); if (cs) cs.content = dark ? 'dark' : 'light';
    const meta = document.querySelector('meta[name=theme-color]'); if (meta) meta.content = dark ? '#151a18' : '#0f7a3d';
    const tb = document.getElementById('themeBtn');
    if (tb) { tb.innerHTML = ui.icon(dark ? 'sun' : 'moon', 17); tb.title = dark ? 'Switch to light (white) mode' : 'Switch to dark mode'; tb.setAttribute('aria-label', tb.title); }
    if (grid) grid.refreshTheme();
    IS.emit('theme', dark ? 'dark' : 'light');
  }
  IS.applyTheme = applyTheme;
  if (window.matchMedia) matchMedia('(prefers-color-scheme: dark)').addEventListener('change', () => { if (IS.prefs.get('theme', 'light') === 'system') applyTheme(); });

  // ======================================================================= init
  function buildEditor() {
    editor = document.createElement('textarea');
    editor.id = 'cellEditor'; editor.className = 'cell-editor'; editor.spellcheck = false; editor.hidden = true; editor.rows = 1;
    editor.setAttribute('aria-label', 'Cell editor');
    grid.layer.appendChild(editor);
    editor.addEventListener('input', () => { if (state.editing) { state.editing.point = null; } mirror(editor); updateHint(); updateRefBoxes(); grid.invalidate(); });
    editor.addEventListener('click', () => { if (state.editing) { state.editing.mode = 'edit'; updateHint(); } });
    editor.addEventListener('blur', e => {
      if (!state.editing) return;
      if (e.relatedTarget === fx) { state.editing.src = 'fx'; return; }
      if ($('dlg').open || (e.relatedTarget && e.relatedTarget.closest && e.relatedTarget.closest('.popup, .hint-pop'))) return;
      setTimeout(() => { if (state.editing && document.activeElement !== editor && document.activeElement !== fx) commitEdit({ force: true }); }, 0);
    });
    hintEl = document.createElement('div'); hintEl.className = 'hint-pop'; hintEl.hidden = true; document.body.appendChild(hintEl);
    hintEl.addEventListener('mousedown', e => { e.preventDefault(); const d = e.target.closest('[data-i]'); if (d) acceptHint(+d.dataset.i); });
    fx = $('fx');
    fx.addEventListener('focus', () => {
      if (state.editing) { state.editing.src = 'fx'; return; }
      const s = state.sel;
      if (!guardEdit({ t: s.r, l: s.c, b: s.r, r: s.c })) { fx.blur(); return; }
      if (calc.spillAnchor(cur(), s.r, s.c) && !IS.hasValue(cur().cells[K(s.r, s.c)])) { fx.blur(); ui.toast('This cell shows a spilled result. Edit the first cell of the spill.'); return; }
      state.editing = { r: s.r, c: s.c, sheetId: cur().id, mode: 'edit', src: 'fx', point: null };
      editor.value = fx.value; styleEditor(); editor.hidden = false; positionEditor(); document.body.classList.add('editing'); updateRefBoxes(); grid.invalidate();
    });
    fx.addEventListener('input', () => { if (state.editing) state.editing.point = null; mirror(fx); updateHint(); updateRefBoxes(); grid.invalidate(); });
    fx.addEventListener('keydown', e => { if (!state.editing) return; e.stopPropagation(); editingKeys(e, e.ctrlKey || e.metaKey); });
    fx.addEventListener('blur', e => {
      if (!state.editing || state.editing.src !== 'fx') return;
      if (e.relatedTarget === editor || $('dlg').open || (e.relatedTarget && e.relatedTarget.closest && e.relatedTarget.closest('.popup, .hint-pop, .tabs'))) return;
      setTimeout(() => { if (state.editing && document.activeElement !== editor && document.activeElement !== fx && !drag) commitEdit({ force: true }); }, 120);
    });
  }
  function bindEvents() {
    const sc = grid.scroller;
    sc.addEventListener('pointerdown', onPointerDown);
    window.addEventListener('pointermove', onPointerMove);
    window.addEventListener('pointerup', onPointerUp);
    window.addEventListener('pointercancel', e => { if (drag && drag.type === 'tap') drag = null; onPointerUp(e); });
    sc.addEventListener('dblclick', onDblClick);
    sc.addEventListener('contextmenu', onContextMenu);
    sc.addEventListener('mouseleave', () => { hideNote(); });
    sc.addEventListener('wheel', e => { if (e.ctrlKey) { e.preventDefault(); setZoom(state.zoom + (e.deltaY < 0 ? 0.1 : -0.1)); } }, { passive: false });
    sc.addEventListener('scroll', () => { positionEditor(); hideNote(); });
    document.addEventListener('keydown', onKeyDown);
    document.addEventListener('copy', e => onCopy(e, false));
    document.addEventListener('cut', e => onCopy(e, true));
    document.addEventListener('paste', onPaste);
    $('nameBox').addEventListener('keydown', onNameBoxKey);
    $('nameBox').addEventListener('focus', e => e.target.select());
    $('nameBox').addEventListener('blur', () => updateNameBox());
    $('bookName').addEventListener('change', e => { const v = e.target.value.trim() || 'Untitled workbook'; IS.tx('Rename workbook', () => { recBook(); state.wb.name = v; }); document.title = v + ' – India Sheets'; markDirty(); });
    $('bookName').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); focusGrid(); } });
    $('findText').addEventListener('input', () => collectHits());
    $('findText').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); findNext(e.shiftKey); } if (e.key === 'Escape') closeFind(); });
    $('replaceText').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); replaceOne(); } if (e.key === 'Escape') closeFind(); });
    $('findNextBtn').onclick = () => findNext(); $('findPrevBtn').onclick = () => findNext(true);
    $('replaceBtn').onclick = replaceOne; $('replaceAllBtn').onclick = replaceAll; $('findCloseBtn').onclick = closeFind;
    ['findCase', 'findWhole', 'findFormulas'].forEach(id => $(id).addEventListener('change', collectHits));
    document.addEventListener('click', e => {
      const b = e.target.closest('[data-cmd]'); if (!b || b.closest('.popup')) return;
      if (b.closest('#menubar')) return;
      e.preventDefault();
      IS.run(b.dataset.cmd, b.dataset.arg);
      if (!b.dataset.keepFocus && !['find', 'findReplace', 'goTo'].includes(b.dataset.cmd)) setTimeout(() => { if (!$('dlg').open && !ui.popupOpen && !state.editing && !document.querySelector('#sidePanel:not([hidden]) :focus')) focusGrid(); }, 0);
    });
    IS.on('scroll', () => positionEditor());
    window.addEventListener('beforeunload', e => { if (state.dirty) { saveNow(); } });
    document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'hidden' && state.dirty) saveNow(); if (document.visibilityState === 'visible' && calc.hasVolatile()) { calc.recalcVolatile(); grid.invalidate(); } });
    window.addEventListener('online', updateNet); window.addEventListener('offline', updateNet);
  }
  function updateNet() { const on = navigator.onLine, p = $('netStatus'); if (!p) return; p.textContent = on ? 'Online' : 'Offline'; p.title = on ? 'Connected. India Sheets also works without internet.' : 'No internet – everything still works and is saved on this device.'; p.classList.toggle('offline', !on); }
  IS.updateNet = updateNet;

  IS.start = async function () {
    applyTheme();
    grid = IS.grid = new IS.Grid($('gridHost'));
    calc = IS.calc = new IS.Calc();
    buildEditor();
    IS.buildChrome && IS.buildChrome();
    bindEvents();
    await IS.store.ready();
    // upgrade the version-1 single workbook stored in localStorage
    try {
      const old = localStorage.getItem('isheets_workbook_v1');
      if (old && !IS.prefs.get('migratedV1')) {
        const b = IS.normalizeBook(JSON.parse(old)); await IS.store.put(b); IS.prefs.set('lastBook', b.id); IS.prefs.set('migratedV1', true);
      }
    } catch (e) { console.warn('migration', e); }
    const params = new URLSearchParams(location.search);
    let book = null;
    const lastId = IS.prefs.get('lastBook');
    if (lastId) book = await IS.store.get(lastId);
    if (!book) { const list = await IS.store.list(); if (list.length) book = await IS.store.get(list[0].id); }
    const first = !book;
    if (!book) book = IS.newBook();
    await openBook(book, { save: first });
    const z = IS.prefs.get('zoom', 1); if (z !== 1) setZoom(z);
    updateNet();
    focusGrid();
    IS.emit('ready', { first, params });
    if (params.get('action') === 'new') IS.run('newBook');
    else if (params.get('action') === 'open') IS.run('openFile');
    else if (params.get('template')) IS.run('newFromTemplate', params.get('template'));
    if (params.toString()) history.replaceState(null, '', location.pathname);
    IS.store.requestPersist();
  };

  IS._internal = { commitEdit, cancelEdit, startEdit, setSel, move, jump, currentRegion, pointTo, canPoint, updateRefBoxes, setZoom, openFind, closeFind, unhideAround, selRows, selCols };
})(window);
