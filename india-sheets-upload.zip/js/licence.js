/* India Sheets – free trial and subscription.
 *
 * ┌──────────────────────────── SETTINGS (change these) ────────────────────────────┐
 *   TRIAL_DAYS    free days for a new user
 *   PRICE_INR     price after the trial
 *   PERIOD_DAYS   days unlocked by one payment
 *   STORE_SKU     Product ID of your Microsoft Store add-on (Partner Center → Add-ons).
 *                 Used automatically when the app runs as the Microsoft Store version.
 *   RAZORPAY_KEY  your Razorpay "Key Id" (rzp_live_… or rzp_test_…) for the web version
 *   UPI_ID        optional UPI id (e.g. yourname@okhdfcbank) – shows a "pay by UPI" option
 *   SUPPORT_EMAIL shown to users for help
 * └──────────────────────────────────────────────────────────────────────────────────┘
 *
 * IMPORTANT: the trial is counted on the user's device. Someone who clears the app's data
 * gets a new trial. Microsoft Store purchases are checked with the Store every time the app
 * starts, so they cannot be faked; for the web version add a login + server check (see README).
 */
(function (global) {
  'use strict';
  const IS = global.IS = global.IS || {};
  const CONFIG = {
    APP_NAME: 'India Sheets',
    TRIAL_DAYS: 30,
    PRICE_INR: 11,
    PERIOD_DAYS: 30,
    STORE_SKU: 'india_sheets_pro_monthly',
    RAZORPAY_KEY: '',
    UPI_ID: '',
    SUPPORT_EMAIL: 'support@example.com'
  };
  const DAY = 86400000;
  const K_START = 'isheets_trial_start', K_PAID = 'isheets_paid_until', K_SRC = 'isheets_paid_source';
  const get = k => { try { return localStorage.getItem(k); } catch (e) { return null; } };
  const set = (k, v) => { try { localStorage.setItem(k, v); } catch (e) { /* ignore */ } };

  function trialStart() {
    let s = Number(get(K_START));
    if (!s) {
      // keep the earliest known start (also mirrored in IndexedDB-backed prefs)
      s = Date.now(); set(K_START, String(s));
    }
    return s;
  }
  function status() {
    const now = Date.now(), paidUntil = Number(get(K_PAID)) || 0;
    if (paidUntil > now) return { state: 'paid', daysLeft: Math.ceil((paidUntil - now) / DAY), until: new Date(paidUntil), source: get(K_SRC) || '' };
    const end = trialStart() + CONFIG.TRIAL_DAYS * DAY;
    if (end > now) return { state: 'trial', daysLeft: Math.ceil((end - now) / DAY), until: new Date(end) };
    return { state: 'expired', daysLeft: 0 };
  }
  const canEdit = () => status().state !== 'expired';
  function markPaid(source, days) {
    const now = Date.now();
    const base = source === 'store' ? now : Math.max(Number(get(K_PAID)) || 0, now);
    set(K_PAID, String(base + (days || CONFIG.PERIOD_DAYS) * DAY)); set(K_SRC, source || 'web');
    IS.emit && IS.emit('licence');
  }

  // ---------------- Microsoft Store (Digital Goods API, available in the Store version of Edge PWAs)
  async function storeService() {
    if (!('getDigitalGoodsService' in global)) return null;
    try { return await global.getDigitalGoodsService('https://store.microsoft.com/billing'); } catch (e) { return null; }
  }
  async function checkStore() {
    const s = await storeService(); if (!s) return false;
    try {
      const list = await s.listPurchases();
      if (list && list.some(p => p.itemId === CONFIG.STORE_SKU)) { markPaid('store', 3); return true; }
    } catch (e) { /* ignore */ }
    return false;
  }
  async function payStore() {
    const s = await storeService(); if (!s) return false;
    try {
      const req = new PaymentRequest([{ supportedMethods: 'https://store.microsoft.com/billing', data: { sku: CONFIG.STORE_SKU } }]);
      const resp = await req.show(); await resp.complete('success');
      markPaid('store', CONFIG.PERIOD_DAYS); return true;
    } catch (e) { console.warn('Store purchase', e); return 'cancel'; }
  }

  // ---------------- Razorpay (web version)
  async function payRazorpay() {
    if (!navigator.onLine) { IS.ui.toast('Please connect to the internet to pay.', { type: 'error' }); return false; }
    try { if (!global.Razorpay) await IS.ui.loadScript('https://checkout.razorpay.com/v1/checkout.js'); }
    catch (e) { IS.ui.toast('Could not open the payment page. Check your internet and try again.', { type: 'error' }); return false; }
    return new Promise(resolve => {
      const rz = new global.Razorpay({
        key: CONFIG.RAZORPAY_KEY, amount: CONFIG.PRICE_INR * 100, currency: 'INR', name: CONFIG.APP_NAME,
        description: CONFIG.PERIOD_DAYS + ' days of ' + CONFIG.APP_NAME, theme: { color: '#0f7a3d' },
        handler: resp => { set('isheets_last_payment', JSON.stringify({ at: Date.now(), id: resp.razorpay_payment_id })); markPaid('razorpay'); resolve(true); },
        modal: { ondismiss: () => resolve(false) }
      });
      rz.open();
    });
  }
  async function pay() {
    const st = await payStore();
    if (st === true) return true; if (st === 'cancel') return false;
    if (CONFIG.RAZORPAY_KEY) return payRazorpay();
    if (CONFIG.UPI_ID) {
      const uri = 'upi://pay?pa=' + encodeURIComponent(CONFIG.UPI_ID) + '&pn=' + encodeURIComponent(CONFIG.APP_NAME) + '&am=' + CONFIG.PRICE_INR + '&cu=INR&tn=' + encodeURIComponent(CONFIG.APP_NAME + ' plan');
      IS.ui.modal({ title: 'Pay ₹' + CONFIG.PRICE_INR + ' by UPI', body: '<p>Scan with any UPI app (GPay, PhonePe, Paytm, BHIM) or tap the link on your phone.</p><div id="upiQr" class="upi-qr"></div><p><a href="' + IS.esc(uri) + '">Open UPI app</a></p><p class="hint">After paying, email your UPI reference number to ' + IS.esc(CONFIG.SUPPORT_EMAIL) + ' to receive your activation.</p>', onOpen: b => { const c = document.createElement('canvas'); c.width = c.height = 220; IS.GridPaint.drawQR(c.getContext('2d'), uri, 0, 0, 220, 220); b.querySelector('#upiQr').appendChild(c); } });
      return false;
    }
    IS.ui.modal({ title: 'Payments are not set up yet', body: '<p>The app owner still needs to connect a payment method.</p><p class="hint">Owner: add your Microsoft Store add-on ID, Razorpay Key Id or UPI id in <code>js/licence.js</code>.</p>' });
    return false;
  }

  function showPlan() {
    const st = status(), C = CONFIG;
    const d = st.until ? st.until.toLocaleDateString('en-IN', { day: 'numeric', month: 'long', year: 'numeric' }) : '';
    const price = '<div class="price">₹' + C.PRICE_INR + '<small> / ' + C.PERIOD_DAYS + ' days</small></div>';
    const perks = '<ul class="perks"><li>All 280+ formulas incl. GST, ₹ words, GSTIN check</li><li>Unlimited workbooks, works offline</li><li>Excel, PDF, CSV, ODS downloads & printing</li><li>Charts, pivots, templates, voice typing</li></ul>';
    let html;
    if (st.state === 'paid') html = '<p class="plan-badge paid">Pro – active</p><p>Your plan is active until <b>' + d + '</b>' + (st.source === 'store' ? ' (managed by Microsoft Store)' : '') + '.</p>' + perks;
    else if (st.state === 'trial') html = '<p class="plan-badge">Free trial</p><p>You have <b>' + st.daysLeft + ' day' + (st.daysLeft === 1 ? '' : 's') + '</b> of free use left (until ' + d + '). After that India Sheets costs only</p>' + price + perks;
    else html = '<p class="plan-badge expired">Trial ended</p><p>Thank you for trying India Sheets for ' + C.TRIAL_DAYS + ' days. You can still open, view, print and download all your files.</p><p>To keep editing, continue for just</p>' + price + perks;
    IS.ui.modal({
      title: 'India Sheets plan', body: html,
      actions: [
        { label: st.state === 'expired' ? 'View only' : 'Close', value: null },
        { label: st.state === 'paid' ? 'Add ' + C.PERIOD_DAYS + ' more days (₹' + C.PRICE_INR + ')' : 'Pay ₹' + C.PRICE_INR, primary: true, onClick: () => { setTimeout(async () => { const ok = await pay(); if (ok) { IS.ui.toast('Payment received – thank you! Your plan is active. 🙏', { ms: 5000 }); updateBadge(); } }, 50); } }
      ]
    });
  }
  function updateBadge() {
    const b = document.getElementById('trialBadge'); if (!b) return;
    const st = status();
    b.className = 'pill trial ' + st.state;
    b.textContent = st.state === 'paid' ? 'Pro' : st.state === 'trial' ? 'Free trial · ' + st.daysLeft + ' day' + (st.daysLeft === 1 ? '' : 's') + ' left' : 'Trial ended · ₹' + CONFIG.PRICE_INR;
    b.title = st.state === 'paid' ? 'Pro plan active until ' + st.until.toLocaleDateString('en-IN') : 'Plan & billing';
    document.body.classList.toggle('trial-ended', st.state === 'expired');
  }

  IS.Licence = { CONFIG, status, canEdit, markPaid, pay, checkStore, showPlan, updateBadge };
  IS.on && IS.on('ready', async () => {
    updateBadge();
    if (await checkStore()) updateBadge();
    if (status().state === 'expired') setTimeout(showPlan, 600);
    setInterval(updateBadge, 60 * 60 * 1000);
  });
  IS.on && IS.on('licence', updateBadge);
  IS.cmd = IS.cmd || {};
  IS.cmd.plan = showPlan;
})(window);
