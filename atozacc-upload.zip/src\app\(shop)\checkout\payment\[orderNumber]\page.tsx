import Link from "next/link";
import { notFound, redirect } from "next/navigation";

import { Container } from "@/components/ui";
import { UpiPayment } from "@/components/upi-payment";
import { formatINR } from "@/lib/money";
import { getOrder } from "@/lib/orders";
import { getSettings } from "@/lib/settings";
import { buildUpiLink, buildUpiQr, isValidUpiId } from "@/lib/upi";

export const metadata = { title: "Pay", robots: { index: false } };

export default async function PaymentPage({
  params,
}: {
  params: Promise<{ orderNumber: string }>;
}) {
  const { orderNumber } = await params;
  const order = await getOrder(orderNumber);
  if (!order) notFound();

  // Nothing to collect online — a settled order or a COD one.
  if (order.balanceAmount <= 0 || order.paymentMethod === "COD") {
    redirect(`/order/success/${order.orderNumber}`);
  }

  const settings = await getSettings();
  const amount = order.onlineAmountDue;

  // Online payment is not set up. Say so, keep the order, offer a way through
  // — rather than showing a QR that pays nobody.
  if (settings.onlinePaymentMode !== "upi" || !isValidUpiId(settings.upiId)) {
    return (
      <Container className="max-w-md py-16 text-center">
        <h1 className="font-display text-2xl">Online payment isn&apos;t set up yet</h1>
        <p className="mt-3 text-[13.5px] text-ink-mid">
          Your order is saved and nothing has been charged.
        </p>
        <div className="mt-5 rounded-[var(--radius-card)] border border-line bg-surface p-4 text-left text-[13px]">
          <p className="tnum">
            <strong>Order {order.orderNumber}</strong> — {formatINR(order.total)}
          </p>
          <p className="mt-1 text-ink-mute">
            Message us and we will complete it with you.
          </p>
        </div>
        <div className="mt-6 space-y-2">
          <Link
            href="/contact"
            className="block rounded-[var(--radius-card)] bg-brand px-6 py-3 text-[14px] font-semibold text-white hover:bg-brand-deep"
          >
            Contact us
          </Link>
          <Link
            href={`/order/success/${order.orderNumber}`}
            className="block text-[12.5px] font-semibold text-ink-mute hover:text-brand"
          >
            View order details
          </Link>
        </div>
      </Container>
    );
  }

  const upiParams = {
    upiId: settings.upiId,
    payeeName: settings.upiPayeeName || settings.storeName,
    amountPaise: amount,
    orderNumber: order.orderNumber,
  };

  const [qrDataUri, upiLink] = await Promise.all([
    buildUpiQr(upiParams),
    Promise.resolve(buildUpiLink(upiParams)),
  ]);

  return (
    <Container className="max-w-4xl py-8">
      <UpiPayment
        orderNumber={order.orderNumber}
        amount={amount}
        upiId={settings.upiId}
        upiLink={upiLink}
        qrDataUri={qrDataUri}
        fallbackQrImage={settings.upiQrImageUrl || undefined}
        supportPhone={settings.whatsappNumber || settings.supportPhone}
        alreadyClaimed={order.paymentClaimedAt}
      />
    </Container>
  );
}
