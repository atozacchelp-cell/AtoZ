import { Card, EmptyRow, PageHeader, Pill, Stat, Table } from "@/components/admin-ui";
import { SupplierForm } from "@/components/supplier-form";
import { ForwardOrders } from "@/components/forward-orders";
import { formatINR } from "@/lib/money";
import { listOrders } from "@/lib/orders";
import { getAllProducts } from "@/lib/product-store";
import { getSuppliers } from "@/lib/suppliers";

export const metadata = { title: "Suppliers", robots: { index: false } };

export default async function SuppliersPage() {
  const [suppliers, products, orders] = await Promise.all([
    getSuppliers(),
    getAllProducts(),
    (listOrders()),
  ]);

  const dropship = products.filter((p) => p.fulfilment === "dropship");
  const ownStock = products.length - dropship.length;

  // Which supplier ships each SKU, so order lines can be grouped.
  const supplierBySku = new Map(
    products.filter((p) => p.supplier).map((p) => [p.sku, p.supplier!]),
  );

  // Named suppliers that have no entry here — their terms are unknown, which
  // means the delivery estimate and COD rule fall back to guesses.
  const known = new Set(suppliers.map((s) => s.name.trim().toLowerCase()));
  const unconfigured = [
    ...new Set(
      dropship
        .map((p) => p.supplier?.trim())
        .filter((s): s is string => !!s && !known.has(s.toLowerCase())),
    ),
  ];

  // Orders still to be forwarded: anything confirmed but not yet shipped.
  const pending = orders.filter((o) =>
    ["PENDING", "CONFIRMED", "PACKED"].includes(o.status),
  );

  return (
    <>
      <PageHeader
        title="Suppliers"
        subtitle="For products a supplier ships direct, rather than from your own stock"
      />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Your own stock" value={String(ownStock)} sub="products" />
        <Stat
          label="Dropshipped"
          value={String(dropship.length)}
          sub="products"
          tone={dropship.length > 0 ? "warn" : "neutral"}
        />
        <Stat label="Suppliers set up" value={String(suppliers.length)} />
        <Stat
          label="Missing details"
          value={String(unconfigured.length)}
          tone={unconfigured.length > 0 ? "bad" : "good"}
          sub="Named in the sheet, not set up here"
        />
      </div>

      {unconfigured.length > 0 && (
        <div className="mt-4 rounded-[var(--radius-card)] border border-brand bg-blush px-4 py-3 text-[12.5px] text-brand-deep">
          <strong>Set these up below:</strong> {unconfigured.join(", ")}. Until
          you do, the site assumes 2 days to dispatch and that they accept cash
          on delivery — both guesses, and the second one is usually wrong.
        </div>
      )}

      {/* Forwarding orders is the actual daily work of dropshipping. */}
      <div className="mt-8">
        <ForwardOrders
          orders={pending.map((o) => ({
            orderNumber: o.orderNumber,
            placedAt: o.placedAt,
            status: o.status,
            paymentMethod: o.paymentMethod,
            address: o.shippingAddress,
            items: o.items.map((i) => ({
              name: i.name,
              sku: i.sku,
              qty: i.qty,
              supplier: supplierBySku.get(i.sku) ?? null,
            })),
          }))}
          suppliers={suppliers}
        />
      </div>

      <h2 className="mt-10 font-display text-xl">Your suppliers</h2>
      <p className="mb-3 text-[12.5px] text-ink-mute">
        The name here must match the <code>supplier</code> column in your sheet.
      </p>

      <div className="mb-5">
        <Table head={["Supplier", "Contact", "Ships from", "Dispatch", "COD", "Products"]}>
          {suppliers.length === 0 ? (
            <EmptyRow colSpan={6}>
              No suppliers yet. Add one below if you plan to dropship.
            </EmptyRow>
          ) : (
            suppliers.map((s) => {
              const count = dropship.filter(
                (p) => p.supplier?.trim().toLowerCase() === s.name.trim().toLowerCase(),
              ).length;
              return (
                <tr key={s.name} className="border-b border-line last:border-0">
                  <td className="px-3 py-2 font-semibold">{s.name}</td>
                  <td className="px-3 py-2 text-ink-mute">
                    {s.contactName && <span className="block">{s.contactName}</span>}
                    <span className="tnum block text-[11.5px]">
                      {[s.phone, s.email].filter(Boolean).join(" · ") || "—"}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-ink-mute">{s.city ?? "—"}</td>
                  <td className="tnum px-3 py-2">
                    {s.dispatchDays} {s.dispatchDays === 1 ? "day" : "days"}
                  </td>
                  <td className="px-3 py-2">
                    {s.acceptsCod ? (
                      <Pill tone="good">Accepts COD</Pill>
                    ) : (
                      <Pill tone="bad">Prepaid only</Pill>
                    )}
                  </td>
                  <td className="tnum px-3 py-2">{count}</td>
                </tr>
              );
            })
          )}
        </Table>
      </div>

      <SupplierForm suppliers={suppliers} />

      <Card className="mt-6">
        <h2 className="font-display text-lg">How to mark a product as dropshipped</h2>
        <p className="mt-1.5 text-[13px] text-ink-mid">
          Add two columns to your Products tab and fill them in for the products
          a supplier ships:
        </p>
        <div className="mt-3 overflow-x-auto rounded-[var(--radius-card)] border border-line bg-surface p-3">
          <code className="block whitespace-nowrap text-[12px] text-ink-mid">
            supplier &nbsp;·&nbsp; fulfilment &nbsp;·&nbsp; dispatchdays
          </code>
        </div>
        <ul className="mt-3 space-y-1.5 text-[12.5px] text-ink-mid">
          <li>
            <code>supplier</code> — the name, matching a row above.
          </li>
          <li>
            <code>fulfilment</code> — <code>dropship</code> or <code>self</code>.
            Naming a supplier is enough; it defaults to dropship.
          </li>
          <li>
            <code>dispatchdays</code> — optional override of the supplier default,
            for one slow item.
          </li>
        </ul>
        <p className="mt-3 text-[12.5px] text-ink-mute">
          Set <code>stock</code> to a high number on dropshipped rows — the
          supplier holds the stock, so your count is not real. Ask them for
          their stock list weekly rather than guessing.
        </p>
      </Card>
    </>
  );
}
