"use server";

import { redirect } from "next/navigation";
import { z } from "zod";

import { passwordProblem } from "@/lib/auth";
import { clientKey, hit, reset } from "@/lib/rate-limit";
import { endSession, startSession } from "@/lib/session";
import {
  authenticate,
  createUser,
  findByEmail,
  hasAdmin,
  touchLogin,
} from "@/lib/users";

/**
 * Sign-in, sign-up and the one-time admin claim.
 *
 * Every failure here returns the SAME message regardless of whether the email
 * exists, the password was wrong, or the account is Google-only. Telling
 * someone "no account with that email" hands an attacker a free way to
 * enumerate which of a leaked address list are customers here.
 */

export type AuthState = { error?: string; ok?: boolean };

const GENERIC = "That email and password do not match.";

const Credentials = z.object({
  email: z.string().trim().toLowerCase().email().max(200),
  password: z.string().min(1).max(200),
});

/** Where to send someone after signing in. Never trusts an absolute URL. */
function safeNext(raw: FormDataEntryValue | null, fallback: string): string {
  const value = String(raw ?? "");
  // Must be a path on this site. "//evil.com" and "https://evil.com" are both
  // rejected — an open redirect turns our login into a phishing launchpad.
  if (!value.startsWith("/") || value.startsWith("//")) return fallback;
  return value;
}

/* -------------------------------------------------------------------------
   Customers
   ------------------------------------------------------------------------- */

export async function signIn(
  _prev: AuthState,
  formData: FormData,
): Promise<AuthState> {
  const ip = await clientKey();
  // Ten tries per fifteen minutes. bcrypt makes each guess slow; this makes
  // the total number of guesses finite.
  const gate = hit("signin", ip, 10, 15 * 60_000);
  if (!gate.allowed) {
    return {
      error: `Too many attempts. Try again in ${Math.ceil(gate.retryAfterSeconds / 60)} minutes.`,
    };
  }

  const parsed = Credentials.safeParse({
    email: formData.get("email"),
    password: formData.get("password"),
  });
  if (!parsed.success) return { error: GENERIC };

  const user = await authenticate(parsed.data.email, parsed.data.password);
  if (!user) return { error: GENERIC };

  reset("signin", ip);
  await startSession(user.id);
  await touchLogin(user.id);

  redirect(safeNext(formData.get("next"), user.isAdmin ? "/admin" : "/account"));
}

export async function signUp(
  _prev: AuthState,
  formData: FormData,
): Promise<AuthState> {
  const ip = await clientKey();
  const gate = hit("signup", ip, 5, 60 * 60_000);
  if (!gate.allowed) {
    return { error: "Too many accounts created from here. Try again later." };
  }

  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");
  const name = String(formData.get("name") ?? "").trim();

  if (!email.includes("@") || email.length > 200) {
    return { error: "Enter a valid email address." };
  }

  const problem = passwordProblem(password);
  if (problem) return { error: problem };

  const existing = await findByEmail(email);
  if (existing) {
    // Deliberately not "that email is taken" — that is the same enumeration
    // leak as a login error. They are told to sign in instead, which is the
    // right advice either way.
    return { error: "Could not create that account. Try signing in instead." };
  }

  const created = await createUser({ email, name, password });
  if (!created.ok) return { error: created.error };

  await startSession(created.user.id);
  redirect(safeNext(formData.get("next"), "/account"));
}

export async function signOut(): Promise<void> {
  await endSession();
  redirect("/");
}

/* -------------------------------------------------------------------------
   The first admin
   ------------------------------------------------------------------------- */

/**
 * Claims the admin panel, once.
 *
 * This is open only while NO admin exists. The moment one does, it refuses —
 * so the window in which anyone could take the panel closes the first time
 * the owner uses it, and cannot be reopened from the browser.
 */
export async function claimAdmin(
  _prev: AuthState,
  formData: FormData,
): Promise<AuthState> {
  if (await hasAdmin()) {
    return { error: "An admin account already exists. Sign in instead." };
  }

  const ip = await clientKey();
  const gate = hit("claim", ip, 5, 60 * 60_000);
  if (!gate.allowed) return { error: "Too many attempts. Try again later." };

  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");
  const name = String(formData.get("name") ?? "").trim();

  if (!email.includes("@")) return { error: "Enter a valid email address." };

  // The admin password guards every order, address and payment setting in the
  // shop, so it is held to a higher bar than a customer's.
  if (password.length < 12) {
    return { error: "The admin password must be at least 12 characters." };
  }
  const problem = passwordProblem(password);
  if (problem) return { error: problem };

  const created = await createUser({ email, name, password, isAdmin: true });
  if (!created.ok) return { error: created.error };

  await startSession(created.user.id);
  redirect("/admin");
}
