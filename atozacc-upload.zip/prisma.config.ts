import { defineConfig, env } from "prisma/config";

// Prisma 7 no longer reads .env on its own. Node 22 can, so no dotenv needed.
// In production (Vercel) the vars are already in the environment and there is
// no file to read — hence the catch.
for (const file of [".env.local", ".env"]) {
  try {
    process.loadEnvFile(file);
  } catch {
    // file absent — fine
  }
}

/**
 * Prisma 7 moved connection URLs out of schema.prisma and into this file.
 * The CLI reads it for migrate/introspect; the runtime client gets its
 * connection through a driver adapter instead (see src/lib/db.ts).
 */
export default defineConfig({
  schema: "prisma/schema.prisma",
  datasource: {
    url: env("DATABASE_URL"),
  },
  migrations: {
    path: "prisma/migrations",
    seed: "npx tsx prisma/seed.ts",
  },
});
