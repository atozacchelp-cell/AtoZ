import { ProductListing, type SearchParamsShape } from "@/components/product-listing";

export const metadata = {
  title: "Trending",
  description: "The AtoZacc pieces people are buying right now.",
};

export default async function Page({
  searchParams,
}: {
  searchParams: Promise<SearchParamsShape>;
}) {
  const sp = await searchParams;
  return (
    <ProductListing
      title={"Trending"}
      description={"What is moving fastest this week."}
      breadcrumbs={[{ label: "Trending" }]}
      searchParams={sp}
      baseFilters={{ collection: "trending" }}
    />
  );
}
