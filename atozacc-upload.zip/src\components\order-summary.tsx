import { formatINR } from "@/lib/money";
import type { PriceBreakdown } from "@/lib/pricing";

/**
 * The money breakdown, shown identically in cart and checkout.
 *
 * Every line the customer is charged appears here explicitly. Nothing is
 * folded into a single "total" — a surprise at the payment screen is the
 * commonest reason a cart is abandoned in Indian D2C.
 */
export function OrderSummary({
  breakdown,
  payLater,
  payNow,
  showTax = false,
}: {
  breakdown: PriceBreakdown;
  payNow?: number;
  payLater?: number;
  showTax?: boolean;
}) {
  const b = breakdown;

  return (
    <div className="rounded-[var(--radius-card)] border border-line bg-surface p-5">
      <h2 className="font-display text-lg">Order summary</h2>

      <dl className="tnum mt-4 space-y-2 text-[13.5px]">
        <Row label={`Subtotal (${b.itemCount} ${b.itemCount === 1 ? "item" : "items"})`}>
          {formatINR(b.subtotal + b.productDiscount)}
        </Row>

        {b.productDiscount > 0 && (
          <Row label="Product discount" tone="success">
            −{formatINR(b.productDiscount)}
          </Row>
        )}

        {b.couponDiscount > 0 && (
          <Row label={`Coupon${b.couponCode ? ` (${b.couponCode})` : ""}`} tone="success">
            −{formatINR(b.couponDiscount)}
          </Row>
        )}

        {b.prepaidDiscount > 0 && (
          <Row label="Online payment discount" tone="success">
            −{formatINR(b.prepaidDiscount)}
          </Row>
        )}

        <Row label="Shipping">
          {b.shippingCharge === 0 ? (
            <span className="font-semibold text-success">FREE</span>
          ) : (
            formatINR(b.shippingCharge)
          )}
        </Row>

        {b.codFee > 0 && <Row label="Cash on delivery fee">{formatINR(b.codFee)}</Row>}

        {showTax && b.taxAmount > 0 && (
          <Row label="Tax included">{formatINR(b.taxAmount)}</Row>
        )}
      </dl>

      <div className="tnum mt-4 flex items-baseline justify-between border-t border-line-firm pt-4">
        <span className="text-[15px] font-bold">Total</span>
        <span className="font-display text-2xl">{formatINR(b.total)}</span>
      </div>

      {/* Partial payment: what is due now versus on delivery. Stating both
          removes the ambiguity that makes advance payment feel like a trick. */}
      {payNow !== undefined && payLater !== undefined && payLater > 0 && (
        <div className="tnum mt-4 space-y-1.5 rounded-[var(--radius-card)] border border-brand/35 bg-blush p-3 text-[13px]">
          <div className="flex justify-between">
            <span className="font-semibold text-ink">Pay now</span>
            <span className="font-bold text-brand-deep">{formatINR(payNow)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-ink-mid">Pay on delivery</span>
            <span className="font-semibold text-ink-mid">{formatINR(payLater)}</span>
          </div>
        </div>
      )}

      {b.productDiscount + b.couponDiscount + b.prepaidDiscount > 0 && (
        <p className="tnum mt-3 rounded-[var(--radius-card)] bg-canvas px-3 py-2 text-center text-[12.5px] font-semibold text-success">
          You save{" "}
          {formatINR(b.productDiscount + b.couponDiscount + b.prepaidDiscount)} on this
          order
        </p>
      )}

      {!b.shippingIsFree && b.amountToFreeShipping > 0 && (
        <FreeShippingNudge
          remaining={b.amountToFreeShipping}
          progress={b.subtotal}
          target={b.subtotal + b.amountToFreeShipping}
        />
      )}
    </div>
  );
}

/**
 * The single highest-leverage element on the page for this business: the
 * threshold sits just above the average order, so this bar is what turns a
 * one-item cart into a two-item cart.
 */
function FreeShippingNudge({
  remaining,
  progress,
  target,
}: {
  remaining: number;
  progress: number;
  target: number;
}) {
  const pct = Math.min(100, Math.round((progress / target) * 100));
  return (
    <div className="mt-4">
      <p className="text-[12.5px] text-ink-mid">
        Add <strong className="tnum text-brand">{formatINR(remaining)}</strong> more for
        free shipping
      </p>
      <div
        className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-line"
        role="progressbar"
        aria-valuenow={pct}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label="Progress toward free shipping"
      >
        <div className="h-full rounded-full bg-brand transition-all" style={{ width: `${pct}%` }} />
      </div>
    </div>
  );
}

function Row({
  label,
  children,
  tone,
}: {
  label: string;
  children: React.ReactNode;
  tone?: "success";
}) {
  return (
    <div className="flex justify-between gap-3">
      <dt className="text-ink-mid">{label}</dt>
      <dd className={tone === "success" ? "font-semibold text-success" : "text-ink"}>
        {children}
      </dd>
    </div>
  );
}
