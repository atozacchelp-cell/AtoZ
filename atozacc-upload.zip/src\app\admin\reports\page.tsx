import { Card, EmptyRow, PageHeader, Stat, Table } from "@/components/admin-ui";
import { allCategories } from "@/lib/taxonomy";
import { getAllProducts } from "@/lib/product-store";
import { formatINR } from "@/lib/money";
import { listOrders } from "@/lib/orders";

export const metadata = { title: "Reports", robots: { index: false } };

const categoryName = new Map(allCategories().map((c) => [c.slug, c.name]));

export default async function AdminReports() {
  const orders = await listOrders();
  const products = await getAllProducts();
  const live = orders.filter((o) => o.status !== "CANCELLED");

  const revenue = live.reduce((s, o) => s + o.total, 0);
  const collected = orders.reduce((s, o) => s + o.paidAmount, 0);
  const aov = live.length ? Math.round(revenue / live.length) : 0;

  const codOrders = live.filter((o) => o.paymentMethod === "COD");
  const rto = orders.filter((o) => o.status === "RTO" || o.status === "FAILED_DELIVERY");
  const rtoRate = codOrders.length
    ? Math.round((rto.length / codOrders.length) * 100)
    : 0;

  // Units sold per product, from order lines.
  const sold = new Map<string, { name: string; qty: number; revenue: number }>();
  for (const o of live) {
    for (const item of o.items) {
      const prev = sold.get(item.sku) ?? { name: item.name, qty: 0, revenue: 0 };
      sold.set(item.sku, {
        name: item.name,
        qty: prev.qty + item.qty,
        revenue: prev.revenue + item.lineTotal,
      });
    }
  }
  const topProducts = [...sold.entries()]
    .map(([sku, v]) => ({ sku, ...v }))
    .sort((a, b) => b.revenue - a.revenue)
    .slice(0, 10);

  const byCategory = new Map<string, number>();
  for (const p of products) {
    const name = categoryName.get(p.category) ?? p.category;
    byCategory.set(name, (byCategory.get(name) ?? 0) + 1);
  }

  return (
    <>
      <PageHeader title="Reports" subtitle="All orders to date" />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Order value" value={formatINR(revenue)} sub={`${live.length} live orders`} />
        <Stat label="Cash collected" value={formatINR(collected)} tone="good" />
        <Stat label="Average order" value={formatINR(aov)} />
        <Stat
          label="COD share"
          value={live.length ? `${Math.round((codOrders.length / live.length) * 100)}%` : "—"}
          sub={`${codOrders.length} of ${live.length}`}
          tone={codOrders.length / Math.max(1, live.length) > 0.7 ? "warn" : "neutral"}
        />
      </div>

      {/* The number that decides where COD stays switched on. */}
      <div className="mt-4">
        <Card>
          <h2 className="font-display text-lg">COD performance</h2>
          <p className="mt-1 text-[12px] text-ink-mute">
            Return-to-origin rate is the single number worth watching here. Each
            refused COD parcel costs shipping both ways and returns stock in
            unsellable condition — at a ₹500 average order that is roughly a
            whole order&apos;s margin gone.
          </p>
          <div className="mt-3 grid grid-cols-2 gap-3 lg:grid-cols-4">
            <Stat label="COD orders" value={String(codOrders.length)} />
            <Stat label="Refused / RTO" value={String(rto.length)} tone={rto.length ? "bad" : "good"} />
            <Stat
              label="RTO rate"
              value={`${rtoRate}%`}
              tone={rtoRate > 20 ? "bad" : rtoRate > 10 ? "warn" : "good"}
            />
            <Stat
              label="COD fees earned"
              value={formatINR(codOrders.reduce((s, o) => s + o.codFee, 0))}
            />
          </div>
        </Card>
      </div>

      <div className="mt-6 grid gap-5 lg:grid-cols-2">
        <section>
          <h2 className="mb-2 font-display text-lg">Top products</h2>
          <Table head={["Product", "Units", "Revenue"]}>
            {topProducts.length === 0 ? (
              <EmptyRow colSpan={3}>No sales yet.</EmptyRow>
            ) : (
              topProducts.map((p) => (
                <tr key={p.sku} className="border-b border-line last:border-0">
                  <td className="px-3 py-2">
                    <span className="block max-w-[220px] truncate">{p.name}</span>
                  </td>
                  <td className="tnum px-3 py-2">{p.qty}</td>
                  <td className="tnum px-3 py-2 font-semibold">{formatINR(p.revenue)}</td>
                </tr>
              ))
            )}
          </Table>
        </section>

        <section>
          <h2 className="mb-2 font-display text-lg">Catalogue by category</h2>
          <Table head={["Category", "Products"]}>
            {[...byCategory.entries()]
              .sort((a, b) => b[1] - a[1])
              .slice(0, 12)
              .map(([name, count]) => (
                <tr key={name} className="border-b border-line last:border-0">
                  <td className="px-3 py-2">{name}</td>
                  <td className="tnum px-3 py-2 font-semibold">{count}</td>
                </tr>
              ))}
          </Table>
        </section>
      </div>

      <p className="mt-5 rounded-[var(--radius-card)] border border-line bg-canvas px-4 py-3 text-[12.5px] text-ink-mute">
        Date-range filters, CSV export and the profit report land with the
        database — profit needs cost price on every product, which the schema
        already carries.
      </p>
    </>
  );
}
