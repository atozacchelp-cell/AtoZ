import { requireAdmin } from "@/lib/session";
import { toRupees } from "@/lib/money";
import { listOrders, ORDER_STATUS_LABELS } from "@/lib/orders";

/**
 * Orders as CSV, for pasting into a Google Sheet.
 *
 * The column that matters is `paid` — a plain yes/no. It says yes ONLY when
 * a payment has been verified by hand, so the sheet can never claim money
 * arrived that you have not actually seen.
 */

function cell(value: string | number | undefined | null): string {
  const s = value === undefined || value === null ? "" : String(value);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

const HEADERS = [
  "order_number", "date", "status",
  "customer", "mobile", "email",
  "address", "city", "state", "pincode",
  "items", "quantity",
  "order_value", "paid_amount", "balance_due",
  "payment_method", "paid", "upi_reference", "verified_at",
] as const;

export async function GET() {
  // Customer data and cost prices. Admin only.
  const denied = await requireAdmin();
  if (denied) return denied;

  const orders = await listOrders();

  const rows = [
    HEADERS.join(","),
    ...orders.map((o) => {
      const a = o.shippingAddress;
      return [
        o.orderNumber,
        new Date(o.placedAt).toLocaleString("en-IN"),
        ORDER_STATUS_LABELS[o.status],
        a.name,
        a.mobile,
        a.email ?? "",
        [a.line1, a.line2, a.area].filter(Boolean).join(", "),
        a.city,
        a.state,
        a.pincode,
        o.items.map((i) => `${i.qty}x ${i.name}`).join(" | "),
        o.items.reduce((n, i) => n + i.qty, 0),
        toRupees(o.total),
        toRupees(o.paidAmount),
        toRupees(o.balanceAmount),
        o.paymentMethod === "COD" ? "Cash on delivery" : "UPI",
        // The whole point of the export. Verified means verified by a person.
        o.paymentVerifiedAt
          ? "yes"
          : o.paymentMethod === "COD" && o.paidAmount >= o.total
            ? "yes"
            : "no",
        o.upiReference ?? "",
        o.paymentVerifiedAt ? new Date(o.paymentVerifiedAt).toLocaleString("en-IN") : "",
      ]
        .map(cell)
        .join(",");
    }),
  ].join("\n");

  const date = new Date().toISOString().slice(0, 10);

  return new Response(rows, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="atozacc-orders-${date}.csv"`,
    },
  });
}
