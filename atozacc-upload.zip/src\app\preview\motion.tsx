"use client";

import { useEffect, useRef, useState } from "react";

/**
 * The motion pieces of the preview design.
 *
 * Two rules hold everything here together:
 *
 *  1. Nothing moves for someone who asked it not to. `prefers-reduced-motion`
 *     is a real accessibility setting, not a nicety — vestibular disorders
 *     make parallax genuinely unpleasant — so every effect below checks it and
 *     renders the plain version instead.
 *
 *  2. Nothing is hidden until JavaScript proves it can bring it back. Content
 *     that starts at `opacity: 0` and waits for a script is content that never
 *     appears if the script fails, and this is a shop: an invisible product is
 *     an unsold product.
 */

function usePrefersReducedMotion(): boolean {
  const [reduced, setReduced] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduced(mq.matches);
    const onChange = () => setReduced(mq.matches);
    mq.addEventListener("change", onChange);
    return () => mq.removeEventListener("change", onChange);
  }, []);

  return reduced;
}

/**
 * Tilts towards the cursor in 3D.
 *
 * Deliberately restrained — 8 degrees, not 25. A card that flips halfway over
 * is a demo of a technique; a card that leans slightly makes a flat grid feel
 * like objects on a table, which is the actual goal for a jewellery shop.
 *
 * Pointer-driven only: on a phone there is no cursor, and translating this to
 * touch would fight the scroll.
 */
export function Tilt({
  children,
  className = "",
  max = 8,
}: {
  children: React.ReactNode;
  className?: string;
  max?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const reduced = usePrefersReducedMotion();
  const [style, setStyle] = useState<React.CSSProperties>({});

  function onMove(e: React.PointerEvent) {
    if (reduced || e.pointerType !== "mouse" || !ref.current) return;
    const r = ref.current.getBoundingClientRect();
    const px = (e.clientX - r.left) / r.width - 0.5;
    const py = (e.clientY - r.top) / r.height - 0.5;
    setStyle({
      transform: `perspective(900px) rotateX(${(-py * max).toFixed(2)}deg) rotateY(${(px * max).toFixed(2)}deg) translateZ(0)`,
      transition: "transform 80ms linear",
    });
  }

  function reset() {
    setStyle({
      transform: "perspective(900px) rotateX(0deg) rotateY(0deg)",
      transition: "transform 420ms cubic-bezier(0.22,1,0.36,1)",
    });
  }

  return (
    <div
      ref={ref}
      onPointerMove={onMove}
      onPointerLeave={reset}
      style={style}
      className={className}
    >
      {children}
    </div>
  );
}

/**
 * Fades and lifts a section into view as it is scrolled to.
 *
 * Starts VISIBLE and is hidden by the effect only once the observer is
 * actually attached, so the no-JS and failed-JS cases both show the content.
 */
export function Reveal({
  children,
  delay = 0,
  className = "",
}: {
  children: React.ReactNode;
  delay?: number;
  className?: string;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [shown, setShown] = useState(true);
  const reduced = usePrefersReducedMotion();

  useEffect(() => {
    if (reduced || !ref.current) return;
    const el = ref.current;

    // Anything already on screen at load stays put — animating it would mean
    // flashing content the reader is looking at.
    if (el.getBoundingClientRect().top < window.innerHeight * 0.9) return;

    setShown(false);
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setShown(true);
          io.disconnect();
        }
      },
      { rootMargin: "0px 0px -10% 0px" },
    );
    io.observe(el);
    return () => io.disconnect();
  }, [reduced]);

  return (
    <div
      ref={ref}
      style={{
        opacity: shown ? 1 : 0,
        transform: shown ? "none" : "translateY(22px)",
        transition: `opacity 620ms ease ${delay}ms, transform 620ms cubic-bezier(0.22,1,0.36,1) ${delay}ms`,
      }}
      className={className}
    >
      {children}
    </div>
  );
}

/** Slow horizontal scroller for the announcement band. Pauses on hover. */
export function Marquee({ items }: { items: string[] }) {
  const reduced = usePrefersReducedMotion();

  if (reduced) {
    return (
      <div className="flex flex-wrap justify-center gap-x-6 gap-y-1 py-2.5 text-[12px]">
        {items.map((t) => (
          <span key={t}>{t}</span>
        ))}
      </div>
    );
  }

  // Rendered twice so the loop has no visible seam.
  const run = [...items, ...items];

  return (
    <div className="group relative overflow-hidden py-2.5">
      <div className="flex w-max animate-[atz-marquee_28s_linear_infinite] gap-10 group-hover:[animation-play-state:paused]">
        {run.map((t, i) => (
          <span key={i} className="whitespace-nowrap text-[12px]">
            {t}
          </span>
        ))}
      </div>
    </div>
  );
}
