"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";

import {
  claimUpiPayment,
  getOrder,
  rejectUpiPayment,
  verifyUpiPayment,
} from "@/lib/orders";
import { looksLikeUtr } from "@/lib/upi";

/* -------------------------------------------------------------------------
   Customer side
   ------------------------------------------------------------------------- */

export type ClaimState = { ok?: boolean; error?: string };

const ClaimSchema = z.object({
  orderNumber: z.string().trim().min(1).max(40),
  // Optional on purpose. Asking for a 12-digit UTR loses customers who cannot
  // find it, and the payment can still be matched: the UPI note carries the
  // order number, and the amount is unique per order. A reference makes YOUR
  // matching faster, so it is offered — never required.
  reference: z.string().trim().max(40).optional(),
});

export async function submitUpiReference(
  _prev: ClaimState,
  formData: FormData,
): Promise<ClaimState> {
  const parsed = ClaimSchema.safeParse({
    orderNumber: formData.get("orderNumber"),
    reference: formData.get("reference") ?? "",
  });

  if (!parsed.success) {
    return { error: "Something went wrong. Please try again." };
  }

  const order = await getOrder(parsed.data.orderNumber);
  if (!order) return { error: "We could not find that order." };

  if (order.paymentVerifiedAt) {
    return { ok: true }; // already confirmed; nothing to do
  }

  const reference = parsed.data.reference?.trim() ?? "";

  // A supplied reference is passed through as-is. It is a hint for matching,
  // never a proof of payment — only the bank statement is that.
  await claimUpiPayment(
    parsed.data.orderNumber,
    reference || (looksLikeUtr(reference) ? reference : "not provided"),
  );

  revalidatePath(`/order/success/${parsed.data.orderNumber}`);
  revalidatePath("/admin/orders");
  revalidatePath("/admin");

  return { ok: true };
}

/* -------------------------------------------------------------------------
   Admin side — the only place an order becomes paid
   ------------------------------------------------------------------------- */

export async function confirmPaymentReceived(formData: FormData): Promise<void> {
  const orderNumber = String(formData.get("orderNumber") ?? "");
  if (!orderNumber) return;

  await verifyUpiPayment(orderNumber);

  revalidatePath(`/admin/orders/${orderNumber}`);
  revalidatePath("/admin/orders");
  revalidatePath("/admin");
}

export async function rejectPaymentClaim(formData: FormData): Promise<void> {
  const orderNumber = String(formData.get("orderNumber") ?? "");
  const reason = String(formData.get("reason") ?? "Payment not found in account");
  if (!orderNumber) return;

  await rejectUpiPayment(orderNumber, reason);

  revalidatePath(`/admin/orders/${orderNumber}`);
  revalidatePath("/admin/orders");
  revalidatePath("/admin");
}
