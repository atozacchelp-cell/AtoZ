# AtoZacc — Final System Requirements Document

**Project:** AtoZacc — Indian fashion accessories & lifestyle e-commerce
**Prepared:** 2026-08-26
**Status:** Awaiting your approval. No code written yet.
**Version:** 1.0

---

## 0. How to read this document

You answered Modules 1–3 and asked me to decide the rest. I have.

Every decision I made is recorded in **Section 3 — Decision Register**, with the reasoning. Decisions marked **★** are ones where I want you to actively confirm, because I made a judgement call that materially affects your money or your business, and I could be wrong about your situation.

Everything else is a safe default that can be changed later from the admin panel without touching code — that was a deliberate design goal, given that you didn't have answers yet.

**If you disagree with any decision, say the module number and what you want instead.** I'll revise before building.

---

## 1. Executive summary

AtoZacc is a single-seller D2C e-commerce store selling fashion accessories across women, men and kids, launching in Delhi with all-India shipping.

**Operating profile driving every technical decision:**

| Factor | Your answer | What it means for the build |
|---|---|---|
| Volume | Under 20 orders/day | No need for queues, caching layers, or horizontal scaling on day one. Free-tier infrastructure is genuinely sufficient. |
| AOV | ~₹500 | **Margin is the constraint, not scale.** Shipping and COD returns will eat profit. The system must actively push prepaid orders and larger baskets. |
| Team | You, alone | Admin must be usable on a phone, in under a minute per order. Complexity is the enemy. |
| Technical skill | Low | No servers to patch. Everything managed. |
| Launch | September 2026 | ~4–5 weeks. Scope must be phased ruthlessly. |
| GST | Not registered yet | Invoices are Bills of Supply now, switchable to GST tax invoices later without a rebuild. |

**The recommended build:** a custom Next.js + PostgreSQL store on fully managed infrastructure, running at roughly **₹0–500/month** at your launch volume, with everything you described in your brief either built or built-and-disabled.

---

## 2. Blockers — things code cannot solve

These are ordered by how badly they threaten a September launch.

### 2.1 Product photography — the real blocker ★

You have no product photos. A fashion accessories store is 90% photography. With 50–200 products at 4–6 images each, that's **200–1,200 images** to shoot, crop to 1:1, and colour-correct.

**This will take longer than building the website.** Start now, in parallel.

Minimum viable approach: white sweep background, phone camera, window light, consistent framing. I'll build a bulk image uploader and auto-crop so the processing side isn't manual.

### 2.2 Payment gateway activation ★

Razorpay (and every Indian gateway) requires, at minimum, for a sole proprietorship:

- PAN card
- A bank account the settlements land in
- Business address proof
- Usually: GST certificate, or a declaration if turnover is below the threshold

You have **none of these in place** and no current account.

**Consequence:** you cannot accept online payments until this is done. Gateway KYC typically takes days to weeks.

**Realistic paths:**

- **A** — Start the Razorpay signup this week using PAN + a savings account under proprietorship. Many sole proprietors onboard this way. *Confirm with Razorpay support what they'll accept in your case.*
- **B** — **Launch COD-only**, add online payment when the gateway activates. The system supports this: I'll build both, and online payment methods simply stay switched off in Settings until the keys are live.

I recommend planning for **B** and treating online payment as a switch you flip, so gateway KYC never blocks your launch date.

### 2.3 SMS OTP requires DLT registration ★

Sending transactional SMS in India (order updates, login OTP, COD verification) requires registering your entity and message templates on a DLT platform under TRAI rules. This is not instant.

**Consequence:** mobile-OTP login and COD OTP verification may not be ready on day one.

**Mitigation built into the design:** login falls back to **Google sign-in + guest checkout** if SMS isn't live, and COD verification falls back to a **WhatsApp/phone confirmation you do manually** from the admin panel. Neither blocks launch.

*Start the DLT process as early as you can — verify the current requirements, as telecom rules change.*

### 2.4 Domain not purchased ★

Preferred: `atozacc.com`, fallback `atozacc.in`.

I have not checked availability — please check and buy it. Everything downstream (email on your domain, gateway registration, SEO, SMS sender ID) depends on owning the domain.

### 2.5 Address inconsistency

You gave **Ansal Tower-38, 1324, Nehru Place, Delhi — 110080**, and warehouse **K-2 Sangam Vihar — 110080**.

Nehru Place is normally **110019**; 110080 appears to be the Sangam Vihar PIN. Since one of these prints on every invoice and sets your shipping origin, please confirm both.

Also note: "New Delhi" is the **city**; the **state** is "Delhi" (or "NCT of Delhi"). Your form has these swapped. Minor, but invoices should be right.

### 2.6 Unit economics — please read this ★

At ₹500 AOV this is the single most important business fact in the document.

| Line | Typical amount | Note |
|---|---|---|
| Order value | ₹500 | |
| Shipping (500g, ex-Delhi, aggregator) | −₹55 to −₹75 | Approximate; verify current rates |
| Payment gateway (~2% + GST) | −₹12 | Prepaid only |
| Packaging | −₹15 | |
| **Cost of fulfilling** | **≈ −₹90 to −₹100** | Before product cost |

That is **~18–20% of order value gone before you've paid for the product.**

Now COD. A COD order that's refused costs you shipping **both ways** and returns unsellable-condition stock:

| Line | Amount |
|---|---|
| Forward shipping | −₹65 |
| Return (RTO) shipping | −₹65 |
| **Loss on one refused COD order** | **≈ −₹130** |

Indian D2C RTO rates on COD commonly run 15–30%. At 20% RTO, every 5 COD orders lose you one order's entire margin.

**This is why the system is designed to push prepaid hard:**

- ₹25 instant discount on prepaid orders
- ₹40 COD fee
- Free shipping only above ₹699 (pushes basket from 1 item to 2)
- Mandatory OTP verification on COD orders
- Automatic COD block on customers who have refused deliveries before

Combined, that's a ~13% price swing favouring prepaid. **These are all configurable — set them to zero if you disagree.** But please make that choice deliberately.

---

## 3. Decision register

Every question you left blank, with my answer and reasoning. **★ = please confirm.**

### Module 1 — Business information (you answered)

| # | Decision | Notes |
|---|---|---|
| 1.1–1.3 | Sole proprietorship, trading as AtoZacc | Legal name = AtoZacc |
| 1.4 | **Not GST registered.** Invoices = Bill of Supply, tax = 0% | Tax engine built and dormant; flip one setting when you register |
| 1.5–1.6 | Billing: Nehru Place, Delhi. Ship-from: K-2 Sangam Vihar | ★ Confirm PINs (§2.5) |
| 1.7 | ujjwalakki9633@gmail.com / 8447920965 | ★ Move to `support@atozacc.com` once the domain is bought — a Gmail address on a store hurts trust and conversion |
| 1.9 | <20 orders/day → free-tier infrastructure | |
| 1.10 | Target September 2026 | See §16 for what fits |

### Module 2 — Brand

| # | Decision | Reasoning |
|---|---|---|
| 2.1 | Logo to be designed | Wordmark-led (the name reads as "A to Z"), works at 32px on mobile |
| 2.2 | Palette defined in §14 — warm white canvas, signature red, muted gold accent | You asked for light, attractive, white/red, not black. Gold accent supplies the "premium" you also asked for without going dark |
| 2.3 | Premium + affordable + youthful | See §14 for how three conflicting adjectives are reconciled |
| 2.4 | Tagline options in §14.6 | |
| 2.7 | English only, i18n structure left in place | |

### Module 3 — Customers (you answered)

All-India, ~₹500 AOV, all traffic sources, broad audience skewing young.
**3.4 decided: assume 85% mobile.** Every layout is designed phone-first and only then widened.

### Module 4 — Categories

| # | Decision | Reasoning |
|---|---|---|
| 4.1 | **A — Gender at top level.** Gift / Trending / Seasonal / Combo become **Collections** | Matches how Indian accessory shoppers navigate, matches your brief, and keeps URLs clean. Collections are unlimited per product; category is exactly one |
| 4.2 | Full tree in §4 below | |
| 4.3 | **A — Kids is the parent; Girls and Boys sit under it** | Gives four clean top-level items (Women, Men, Kids, Unisex) instead of six thin ones |
| 4.4 | **B — 3 levels max** | Women > Jewellery > Earrings |
| 4.5 | **A — one primary category + unlimited collections/tags** | Prevents duplicate-content SEO penalties and keeps stock reporting unambiguous |

**★ Honest warning:** with 50–200 products, Men and Kids will look sparse next to Women. **Launch only the gender sections you actually have 12+ products for.** An empty category is worse than no category. The admin lets you hide and show them.

### Module 5 — Product types

| # | Decision |
|---|---|
| 5.1 | Launch core: fashion/imitation jewellery, oxidised jewellery, hair accessories, handbags & slings, wallets, belts, watches, sunglasses, scarves, caps. Expansion: phone accessories, ethnic/festive, gift hampers |
| 5.2 | **50–200 products** at launch |
| 5.3 | **Yes, size matters** — rings, bangles (2.4/2.6/2.8), belts (28–42). Size chart per category |
| 5.4 | **A — no personalisation at launch.** Data model supports it; UI comes in Phase 2 |
| 5.5 | **A — a combo is its own SKU with its own stock** |
| 5.6 | Not yet — see §2.1. 4–6 images/product, 1:1 |
| 5.7 | Video supported, optional |

**Why no personalisation at launch:** custom items are non-returnable, non-restockable, slow to fulfil and easy to get wrong. At 20 orders/day solo, they'd consume disproportionate time. Add them once the base is running.

### Module 6 — Product attributes

**6.1 — Field requirements.** Only 9 fields are mandatory. Everything else is optional so you can list a product in under a minute.

| Field | Status | Note |
|---|---|---|
| SKU | **Required** | Auto-generated (`ATZ-WJE-0001`) if left blank |
| Product name | **Required** | |
| Category | **Required** | |
| Main image | **Required** | |
| MRP | **Required** | |
| Selling price | **Required** | |
| Stock quantity | **Required** | |
| Slug | **Required** | Auto-generated from name |
| Weight | **Required** | Defaults to 100g — needed for shipping rates |
| Short description | Optional | Auto-drafted from name + category if blank |
| Full description, gallery, video, colour, size, material, dimensions, specs, features, care, origin, tags, collection, brand | Optional | |
| Cost price | Optional | Fills the profit report when present |
| HSN, GST rate | Optional | Hidden entirely until you register for GST |
| SEO title/description | Optional | Auto-generated from product data if blank |

**6.2 — C: mostly unbranded, occasionally branded.** Brand field is optional; the brand filter only appears on the shop page once more than one brand exists.

**6.3 — Filters:** Price, Category, Gender, Colour, Size, Material, Discount %, Rating, In stock, New arrivals.
*Dropped:* Age group (redundant with the gender tree), Occasion (that's a collection).

**6.4 — A: fixed master colour list**, so filters and swatches stay consistent.

**6.5 — Colours:** Black, White, Gold, Silver, Rose Gold, Oxidised Silver, Red, Maroon, Pink, Peach, Blue, Navy, Green, Yellow, Beige, Brown, Grey, Multicolour. Editable in admin.

### Module 7 — Pricing

| # | Decision | Reasoning |
|---|---|---|
| 7.1 | **A — prices are tax-inclusive** | Standard Indian B2C. Critically: when you register for GST later, **customer-facing prices don't change** — tax is extracted from the existing price rather than added on top. Choosing "exclusive" would force a price rise on every product on registration day |
| 7.2 | **0% now** (unregistered). Engine supports 0/3/5/12/18/28 | |
| 7.3 | **B — rate varies by category**, overridable per product | Indian GST rates differ across imitation jewellery, leather goods, watches and eyewear. ★ Confirm actual rates with your CA when you register — do not rely on this document for tax rates |
| 7.4 | HSN deferred until registration | |
| 7.5 | **A — enter MRP + selling price**, discount % auto-calculated | Fewer mistakes than entering percentages |
| 7.6 | **A — round to nearest rupee** | |
| 7.7 | **A — one price for everyone.** Wholesale tier = Phase 3 | |
| 7.8 | INR only | |

### Module 8 — Inventory

| # | Decision | Reasoning |
|---|---|---|
| 8.1 | **A — one location** (Sangam Vihar) | |
| 8.2 | **A + D** — show "Out of Stock", with a "Notify me when back" button | Captures demand instead of losing the visitor. Cheap to build, feeds a restock email list |
| 8.3 | **C — stock reserved when checkout starts, released after 15 minutes** if payment doesn't complete | Prevents the classic double-sell on a last-remaining item |
| 8.4 | **Yes — COD deducts stock on order placement**, after OTP verification | |
| 8.5 | **A — cost price + full stock movement ledger** | At ₹500 AOV you cannot afford to guess at margin. Ledger only — no supplier/purchase-order module, which is disproportionate at this scale |
| 8.6 | **C — global default of 5 units, overridable per product** | |
| 8.7 | Admin badge + daily email digest | Not a per-event email — that becomes noise you'll start ignoring |

### Module 9 — Payment

| # | Decision |
|---|---|
| 9.1 | UPI, cards, net banking, wallets, COD, store credit. **Partial payment built but off.** No manual bank-transfer/screenshot flow |
| 9.2 | **A — customer chooses** at checkout, subject to eligibility rules |
| 9.3 | **★ Yes — ₹25 off prepaid orders**, configurable, on by default |
| 9.4 | **A — prepaid auto-confirms** on payment success. COD confirms on OTP |

**Why no bank-transfer-with-screenshot:** it's manual, easily faked, and needs you to verify every order by hand. At 20 orders/day it would consume your morning.

### Module 10 — Partial / advance payment

**★ This is the decision I'd most like you to review.**

| # | Decision |
|---|---|
| 10.1 | **B — built, configurable, disabled at launch** |
| 10.2 | **C — 25% of order value, minimum ₹200** |
| 10.3 | Offered only when order value **> ₹1,500** *and* COD is available for that PIN code |
| 10.4 | **A + B + E** — balance via COD, or a payment link before dispatch, or from "My Orders" |
| 10.5 | **A — order held, 2 reminders, auto-cancel after 3 days** |
| 10.6 | **C — advance refundable if cancelled before dispatch**, forfeited after |
| 10.7 | Coupons allowed; discount applies **first**, advance is calculated on the discounted total |
| 10.8 | **A — one invoice showing total / paid / balance due** |
| 10.9 | All nine statuses kept as you listed them |

**Why disabled at launch:** your AOV is ₹500. Partial payment on a ₹500 order means paying ₹200 online and ₹300 on delivery — that's *more* friction than either full prepaid or plain COD, with no benefit to either side. It also multiplies your reconciliation work.

It genuinely earns its place when you sell **gift hampers, combo sets, or jewellery sets above ₹1,500**. So: fully built, threshold pre-set at ₹1,500, one switch in Settings turns it on the day you need it.

If you have a specific reason to need it live on day one, tell me and I'll enable it — the code is identical either way.

### Module 11 — Cash on Delivery

| # | Decision | Reasoning |
|---|---|---|
| 11.1 | **Yes, with restrictions** | COD is 50–70% of Indian D2C orders. Not offering it costs more than it saves |
| 11.2 | Min ₹199, max ₹3,000 | Below ₹199 the COD fee makes it pointless; above ₹3,000 the RTO loss is too painful |
| 11.3 | **★ Flat ₹40 COD fee** | See §2.6. Set to 0 in Settings if you'd rather absorb it |
| 11.4 | Blocked for: personalised items, non-serviceable PINs, and any customer with **2+ previous refused deliveries** | The repeat-refuser block is the highest-value fraud control you have |
| 11.5 | **B — OTP verification required** | With manual WhatsApp/call fallback if DLT isn't ready (§2.3) |
| 11.6 | Auto-cancel unverified COD orders after **24 hours**, stock released | |

### Module 12 — Shipping

| # | Decision | Reasoning |
|---|---|---|
| 12.1 | **Launch: C (manual booking).** Then **A (Shiprocket)** once volume justifies it | You have no courier account. Manual works fine at 20/day and removes an integration from the critical path |
| 12.3 | **B — free above ₹699, otherwise ₹59** | ★ The ₹699 threshold is set just above your ₹500 AOV specifically to push a second item into the basket. This is the highest-leverage number in the whole system |
| 12.5 | Free above ₹699 | |
| 12.6 | Free shipping applies to COD too, but the ₹40 COD fee still applies | |
| 12.7 | **B — by zone.** Delhi NCR 1–2 days, metros 3–4, rest of India 4–7 | ★ Confirm these are promises you can keep — under-promising is safer |
| 12.8 | **Launch: C (accept all India).** Then A via courier API | |
| 12.9 | Cut-off 2:00 PM. Non-working: Sundays + national holidays | ★ Confirm |
| 12.10 | Simplified to 9 statuses (below) | "Processing" and "Ready to ship" were redundant with "Confirmed" and "Packed" — every extra status is another decision you make per order |

**Shipping statuses:** Placed → Confirmed → Packed → Shipped → In Transit → Out for Delivery → Delivered. Plus terminal states: Failed Delivery / RTO, Cancelled.

### Module 13 — Returns

| # | Decision | Reasoning |
|---|---|---|
| 13.1 | **Yes**, 7 days from delivery | |
| 13.3 | Non-returnable: **earrings and pierced jewellery** (hygiene), personalised items, combo hampers, clearance items | The earrings exclusion is standard and defensible. State it plainly on the product page, not buried in policy |
| 13.4 | **D — depends on reason.** Our fault (damaged/wrong) → free reverse pickup. Customer's choice (didn't like it) → customer self-ships | ★ At ₹500 AOV, paying ₹80 for reverse pickup on a change-of-mind return wipes out the entire margin twice over |
| 13.5 | **Both** — exchange or refund, customer chooses. Exchange presented first | Exchange keeps the revenue |
| 13.6 | **A — manual approval** on every request | |
| 13.7 | Unboxing video **preferred, not mandatory**, for damage claims | |
| 13.8 | All six reasons kept | |

### Module 14 — Refunds

| # | Decision |
|---|---|
| 14.1 | Original payment method, store credit, UPI transfer, replacement |
| 14.2 | **D — customer chooses** between UPI transfer and store credit for COD refunds |
| 14.3 | **5–7 business days** after the return is received and approved |
| 14.4 | **C — shipping refunded only when the return is our fault** |
| 14.5 | COD fee not refunded |
| 14.6 | **Partial refunds supported** — refund one item from a multi-item order |
| 14.7 | **B — Super Admin only** at launch (you're solo) |

### Module 15 — Customer accounts

| # | Decision | Reasoning |
|---|---|---|
| 15.1 | **Mobile + OTP** (primary) and **Google sign-in**. Email+password Phase 2 | Google is the DLT-independent fallback (§2.3) |
| 15.2 | **C — guest checkout, account auto-created from the mobile number** | Best conversion, and you still get a customer record and order history |
| 15.3 | **MSG91** for SMS/OTP | Indian provider, handles DLT, low per-SMS cost. ★ Verify current pricing and DLT process |
| 15.4 | **Wallet / store credit — yes, at launch** | Not optional: it's the refund mechanism for COD orders where there's no payment to reverse |
| 15.5 | Profile, addresses, orders, tracking, wishlist, reviews, returns, wallet, coupons, notifications. Referrals Phase 2 |
| 15.6 | Up to 10 saved addresses |

### Module 16 — Coupons

| # | Decision | Reasoning |
|---|---|---|
| 16.1 | Launch: % off, ₹ off, free shipping, first-order, min-order, category, product, flash sale. Phase 2: BOGO, tiered, automatic offers |
| 16.2 | **A — one coupon per order** | |
| 16.3 | **Yes — coupons stack on top of product discounts by default**, with an optional per-coupon exclusion | Almost every product will show an MRP-vs-price discount. Blocking coupons on discounted products would mean no coupon ever works |
| 16.4 | All conditions supported, plus **prepaid-only coupons** | |
| 16.5 | Coupon codes only at launch | |

### Module 17 — Marketing

**17.1 — Homepage order** (conversion-sequenced, mobile-first):

1. Hero banner (3 slides, autoplay off on mobile — it costs data and hurts LCP)
2. Trust strip — COD available · Free shipping ₹699+ · 7-day returns
3. Shop by category — visual tiles
4. New arrivals
5. Bestsellers
6. Limited-time offer / countdown *(only rendered when a live offer exists)*
7. Shop by gender — Women / Men / Kids / Unisex
8. Trending now
9. Gift collection *(seasonal, admin-toggleable)*
10. Combo offers
11. Recently viewed *(only for returning visitors)*
12. Customer reviews with photos
13. Instagram feed
14. Newsletter
15. Footer

*Dropped from the homepage:* separate "Featured collections" and "Testimonials" blocks — both duplicate sections already present. **Recommended for you: never merchandise more than 12 rails.** Every extra rail pushes your bestsellers further down the phone screen.

| # | Decision |
|---|---|
| 17.2 | 3 hero banners, designed by me from your product photos |
| 17.3–17.5 | Referral, loyalty, gift cards → Phase 3. Data model leaves room |
| 17.6 | Entry popup: yes, first-order discount — **exit-intent on desktop, 20-second delay on mobile.** Never immediate (it hurts both conversion and Google rankings) |
| 17.7 | **Abandoned cart recovery: yes** — email at launch, WhatsApp in Phase 2. Highest-ROI feature on this list |
| 17.8 | ★ **Need your social handles** — Instagram especially, since it drives the homepage feed |

### Module 18 — Notifications

| # | Decision |
|---|---|
| 18.1 | Launch: **Email + SMS + on-site**. Phase 2: **WhatsApp**. Browser push: never (low value, high annoyance) |
| 18.2 | Full customer event matrix in §12 |
| 18.3 | Admin: new order, COD placed, payment failed, low stock, return request, daily sales summary |
| 18.4 | **Brevo** — one vendor for email *and* SMS, with a free tier that covers your volume. ★ Verify current limits |
| 18.5 | WhatsApp Business API via AiSensy or Interakt, Phase 2 — needs Meta approval and template review |
| 18.6 | From: `AtoZacc <orders@atozacc.com>`. SMS sender ID: `ATOZAC` (6 chars, requires DLT) |

**Why WhatsApp is Phase 2 despite being the best channel in India:** the Business API needs a Meta-approved account through a paid provider plus template approval. That's a launch-date risk, not a launch-day feature. The notification system is built channel-agnostic, so adding WhatsApp later is configuration, not a rewrite.

### Module 19 — Admin panel

| # | Decision | Reasoning |
|---|---|---|
| 19.1–19.2 | Single user, designed for low technical comfort | |
| 19.3 | **A — mobile-first admin** | You will process orders on your phone. This is a real design constraint, not a nice-to-have — most admin panels are unusable on a phone |
| 19.4 | Launch menu: Dashboard, Orders, Products, Categories, Inventory, Customers, Coupons, Reviews, Banners, Shipping, Reports, Settings | Brands folded into Products; Payments/Refunds folded into Orders; Offers folded into Coupons. Users & Roles, Audit Logs, Content → Phase 2 |
| 19.5 | **CSV import at launch** (simple: no variants). Full variant import Phase 2 | 200 products entered by hand is roughly 8–10 hours of your time |
| 19.6 | **Bill of Supply** now, **GST tax invoice** template ready and switchable | |
| 19.7 | **B — `ATZ-2026-0001`** | Year-prefixed, resets annually, reads cleanly on a courier label |

### Module 20 — Roles

| # | Decision |
|---|---|
| 20.1 | **Super Admin only at launch.** Role/permission tables built so Order Manager, Inventory Manager and Support drop in without migration |
| 20.2 | Pre-defined for Phase 2: Order Manager cannot see cost price or issue refunds; Support cannot edit products or prices |
| 20.3 | **Audit log on sensitive actions only** — price changes, refunds, deletions, stock adjustments, settings changes |
| 20.4 | Email OTP on admin login from an unrecognised device. Full TOTP 2FA in Phase 2 |

### Module 21 — Reports

| # | Decision |
|---|---|
| 21.1 | Launch: Sales summary, Orders, Product-wise sales, Inventory, COD performance (**including RTO rate**), Returns & refunds, Profit. Phase 2: category-wise, coupon usage, abandoned cart |
| 21.2 | CSV export everywhere; PDF for invoices and packing slips only |
| 21.3 | **Daily sales summary emailed at 9 PM** |
| 21.4 | ★ Ask your CA what export format they want before you register for GST |

**The COD report is the one to watch.** It tracks RTO rate per PIN code and per customer — the data that tells you where to stop offering COD.

### Module 22 — SEO

| # | Decision | Reasoning |
|---|---|---|
| 22.1 | **A — `/women/jewellery/oxidised-earrings`** | With one-primary-category enforced, this is safe. Slug history is stored so a category change auto-issues a 301 redirect and you never lose rankings |
| 22.2 | Brand new — no legacy redirects | |
| 22.3 | ★ Are you already on Amazon / Flipkart / Meesho? Affects duplicate-content handling |
| 22.4 | Blog structure built, empty at launch | |
| 22.5 | **Google Shopping feed: yes**, auto-generated — you ticked paid ads |
| 22.6 | Auto-generated first-draft descriptions and meta text, which you edit | Saves hours across 200 products |

### Module 23 — Design

| # | Decision | Reasoning |
|---|---|---|
| 23.1 | **Hybrid: premium-minimal foundation + vibrant conversion layer.** Detailed in §14 | You asked for premium *and* affordable *and* youthful. Those conflict, so the resolution is: premium in the *structure* (space, typography, image size), vibrant in the *accents* (badges, offer strips, the red) |
| 23.2 | Light theme. Dark mode Phase 3 | |
| 23.3 | **B** — image, name, price, MRP struck through, discount %, rating, wishlist heart | |
| 23.4 | NEW, TRENDING, BESTSELLER, SALE, LIMITED, EXCLUSIVE, "Only X left" | **HOT dropped** — it means the same as TRENDING, and two badges saying one thing dilutes both. Max one badge per card |
| 23.5 | **1:1 square images** | Your catalogue mixes earrings, bags, watches and scarves — wildly different shapes. Square is the only ratio that flatters all of them, it's the easiest for you to shoot consistently, and it fits a 2-up mobile grid |
| 23.6 | Quick view, quick add, wishlist heart, image zoom, size charts, recently viewed, sticky mobile bottom nav, sticky add-to-cart, WhatsApp float button. **Dropped:** 360° view, "frequently bought together" (needs order history you don't have yet) |
| 23.7 | **B — product comparison dropped** | It's an electronics pattern. Nobody compares two pairs of earrings on a spec table. It would cost build time and add a button nobody presses. Say the word and I'll add it |

### Module 24 — Domain & hosting

| # | Decision |
|---|---|
| 24.1 | ★ Buy `atozacc.com` (fallback `.in`) — availability unchecked |
| 24.2 | **B — fully managed.** No servers, no OS patching, no SSH |
| 24.3 | Target **₹0–500/month** at launch volume (§15) |
| 24.4 | Maintained by you, minimally technical → managed hosting is non-negotiable |
| 24.5 | Domain email via Zoho Mail free tier or Google Workspace |

### Module 25 — Technology ★

**25.1 — Decision: A, custom build on Next.js + PostgreSQL.**

I want to show my reasoning here, because this is reversible only at great cost.

| | Custom (chosen) | Shopify | WooCommerce |
|---|---|---|---|
| Monthly cost at your volume | **≈₹0–500** | ≈₹2,000 + apps (₹1,000–3,000) | ≈₹800 hosting |
| Your partial-payment rules | **Exactly as specified** | Not properly possible | Plugin, fragile |
| COD + OTP + RTO blocking | **Built in** | Paid app | Plugin |
| Stock ledger with cost price | **Built in** | Paid app | Plugin |
| Time to launch | 4–6 weeks | 1–2 weeks | 3–4 weeks |
| Security patching burden | **None (managed)** | None | **High — yours** |
| You own the code | **Yes** | No | Yes |

**Why custom wins for you specifically:** at 20 orders/day, Shopify's ₹2,000–5,000/month is ₹24,000–60,000/year against a ~₹500 AOV business — a meaningful share of your margin. The custom stack runs on free tiers at this volume. And Modules 8 and 10 (stock ledger, configurable partial payment) are exactly the things platforms charge apps for and still do badly.

**The honest counter-argument:** Shopify would have you live in two weeks, with payments, shipping and fraud handled by someone else. If launching in September matters more than owning the system or the running cost, **Shopify is the defensible choice** and I'll build you an excellent custom theme on it instead. Say so and I'll switch — but decide now, not later.

**WooCommerce I'd steer you away from:** the security patching burden lands on someone with, by your own answer, minimal technical knowledge. That's how small stores get compromised.

| # | Decision |
|---|---|
| 25.2 | **PostgreSQL** (Neon serverless — free tier, automatic daily backups, no admin) |
| 25.3 | **Cloudinary** — auto-converts to WebP/AVIF and resizes per device. Critical on Indian mobile networks |
| 25.4 | Mobile app "maybe later" → API-first structure so an app can consume the same endpoints |
| 25.5 | Daily automated backups, 7-day point-in-time recovery |

### Module 26 — Payment gateway

| # | Decision |
|---|---|
| 26.1 | **Razorpay** — best documentation, native support for payment links and partial payments, standard for Indian D2C |
| 26.2–26.3 | Not created. **Start this week** (§2.2) |
| 26.4 | Payment links: yes — required for partial-payment balance collection |
| 26.5 | Test mode: yes — you'll place fake orders end-to-end before going live |

The gateway sits behind an internal interface, so swapping to Cashfree or PhonePe later means writing one adapter, not touching checkout.

### Module 27 — Shipping provider

| # | Decision |
|---|---|
| 27.1 | No account yet → **Shiprocket** recommended, Phase 2 |
| 27.2 | **Launch: C (manual).** Phase 2: **B (click "Create shipment" per order)**. Never fully automatic — you want a human between "order placed" and "money spent on courier" |
| 27.3 | Launch: tracking number + courier link. Phase 2: tracking pulled onto your own site |
| 27.4 | **Packing slips and shipping labels printable from admin — at launch** |

### Module 28 — Legal

| # | Decision |
|---|---|
| 28.1 | I'll draft all 7 policy pages from these decisions. **★ Have your CA or a lawyer review before going live — I can't give legal advice, and these become binding on you** |
| 28.2 | **A — customer can cancel until the order is packed** |
| 28.3 | No cancellation charge (except a forfeited advance after dispatch, per 10.6) |
| 28.4 | Simple cookie notice — you're not running EU traffic |

### Module 29 — Analytics

GA4, Google Tag Manager, Meta Pixel, Search Console, Merchant Center, and **Microsoft Clarity** (free session recordings — the fastest way to see why people abandon your checkout). Full e-commerce event tracking: view_item, add_to_cart, begin_checkout, purchase.

### Module 30 — Future

**30.2 — Highest-priority future feature: WhatsApp commerce.** You gave a WhatsApp number, your audience lives there, and it's where abandoned-cart recovery pays best in India. Architecture reserves room for it.

Also structurally accommodated: multi-warehouse, loyalty, referral, affiliate, AI recommendations, Instagram Shopping, accounting integration, multi-vendor.

### Final section

| # | Decision |
|---|---|
| F.1 | **A/C hybrid — strong storefront first, admin depth in Phase 2.** Driven by your September target |
| F.2 | Deferred: partial payment (built, off), comparison (dropped), photo reviews, referral/loyalty, gift cards, advanced reports, WhatsApp, multi-role admin, variant CSV import |

---

## 4. Category structure

```
Women
├── Jewellery ──── Earrings · Necklaces · Rings · Bangles & Bracelets
│                  Anklets · Nose Pins · Jewellery Sets
├── Bags ───────── Handbags · Slings · Clutches · Totes · Backpacks
├── Hair Accessories ─ Clips · Bands · Pins · Scrunchies · Claw Clips
├── Watches
├── Sunglasses
├── Wallets & Purses
├── Belts
├── Scarves & Stoles
└── Other Accessories

Men
├── Wallets
├── Belts
├── Watches
├── Sunglasses
├── Bracelets
├── Bags ───────── Backpacks · Slings · Laptop Bags
├── Caps & Hats
└── Other Accessories

Kids
├── Girls ──────── Jewellery · Hair Accessories · Bags · Watches
└── Boys ───────── Watches · Caps · Bags · Belts

Unisex
├── Phone Accessories
├── Keychains
├── Socks
└── Lifestyle
```

**Collections** (cross-cutting, unlimited per product, admin-managed):
New Arrivals · Trending · Bestsellers · Gift Collection · Combo Offers · Festive · Seasonal · Traditional · Modern · Exclusive · Under ₹299 · Under ₹499

---

## 5. Sitemap

```
/                              Home
/shop                          All products
/{gender}                      /women /men /kids /unisex
/{gender}/{category}           /women/jewellery
/{gender}/{category}/{sub}     /women/jewellery/earrings
/{gender}/{category}/{slug}    Product detail
/collections/{slug}            /collections/gift-collection
/new-arrivals  /trending  /bestsellers  /offers  /deals  /combos
/search
/cart
/checkout
/order/success/{orderNumber}
/track-order
/wishlist
/account
  /profile  /orders  /orders/{id}  /addresses
  /wishlist  /reviews  /returns  /wallet  /coupons  /notifications
/login  /register
/about  /contact  /faq
/policy/shipping  /policy/returns  /policy/refunds
/policy/cancellation  /policy/privacy  /policy/terms

/admin
  /                  Dashboard
  /orders            List · Detail · Invoice · Packing slip
  /products          List · Add · Edit · Variants · CSV import
  /categories        Tree editor with drag-reorder
  /inventory         Stock · Movement ledger · Low stock
  /customers         List · Detail · Order history
  /coupons
  /reviews           Moderation queue
  /banners           Homepage merchandising
  /shipping          Zones · Rates · Serviceability
  /reports
  /settings          Business · Tax · Payment · COD · Shipping
                     · Returns · Notifications · SEO · Invoice
```

Machine routes: `/sitemap.xml`, `/robots.txt`, `/feed/google-merchant.xml`

---

## 6. Customer journey

```mermaid
flowchart TD
    A[Instagram / Google / WhatsApp] --> B[Home or Product page]
    B --> C{Interested?}
    C -->|Browse| D[Category + filters]
    C -->|Direct| E[Product detail]
    D --> E
    E --> F{Available?}
    F -->|No| G[Notify me when back]
    F -->|Yes| H[Select variant → Add to cart]
    H --> I[Cart: coupon, free-shipping nudge]
    I --> J{Login?}
    J -->|Guest| K[Mobile + address]
    J -->|Account| L[Saved address]
    K --> M[Payment method]
    L --> M
    M --> N{Which?}
    N -->|Prepaid| O[Razorpay → ₹25 off]
    N -->|COD| P[+₹40 fee → OTP verify]
    N -->|Partial| Q[Pay 25% now]
    O --> R[Order confirmed]
    P --> R
    Q --> R
    R --> S[Email + SMS confirmation]
    S --> T[Packed → Shipped → Delivered]
    T --> U[Review request after 3 days]
```

**Deliberate design choices along this path:**

- **Free-shipping nudge in cart** — "Add ₹199 more for free shipping" is shown with a progress bar. This is the mechanism that lifts your AOV from ₹500 toward ₹699.
- **Guest checkout** — no forced signup. An account is created silently from the mobile number, so you keep the customer record without paying the conversion cost.
- **Prepaid discount shown as a saving, not a COD penalty** — "Save ₹25, pay online" converts better than "COD costs ₹40 extra", even though the maths is identical.
- **Review request delayed 3 days after delivery** — immediate requests get ignored.

---

## 7. Admin journey — the daily loop

This is what your morning looks like, on a phone:

```mermaid
flowchart LR
    A[Open admin] --> B[Dashboard: new orders]
    B --> C[Verify COD orders]
    C --> D[Confirm orders]
    D --> E[Print packing slips]
    E --> F[Pack]
    F --> G[Book courier]
    G --> H[Enter tracking number]
    H --> I[Auto: customer notified]
    I --> J[Check low stock]
```

**Design target: under 60 seconds per order.** Bulk actions on the order list — select multiple, confirm all, print all slips at once — because doing this one order at a time twenty times a day is how people abandon their own admin panels.

---

## 8. Database architecture

### Core entity relationships

```mermaid
erDiagram
    CUSTOMER ||--o{ ORDER : places
    CUSTOMER ||--o{ ADDRESS : has
    CUSTOMER ||--o{ WISHLIST_ITEM : saves
    CUSTOMER ||--o{ REVIEW : writes
    CUSTOMER ||--|| WALLET : owns
    CATEGORY ||--o{ CATEGORY : parent_of
    CATEGORY ||--o{ PRODUCT : contains
    PRODUCT ||--o{ PRODUCT_VARIANT : has
    PRODUCT ||--o{ PRODUCT_IMAGE : has
    PRODUCT }o--o{ COLLECTION : tagged_in
    PRODUCT_VARIANT ||--o{ INVENTORY_TXN : moves
    ORDER ||--o{ ORDER_ITEM : contains
    ORDER ||--o{ PAYMENT : receives
    ORDER ||--o| SHIPMENT : ships_via
    ORDER ||--o{ RETURN_REQUEST : may_have
    RETURN_REQUEST ||--o{ REFUND : triggers
    COUPON ||--o{ COUPON_USAGE : tracked_by
```

### Table summary

**Identity & access**

| Table | Key fields |
|---|---|
| `customers` | id, mobile (unique), email, name, is_guest, cod_refusals_count, blocked_from_cod, created_at |
| `addresses` | id, customer_id, type, name, mobile, line1, line2, landmark, area, city, state, pincode, is_default |
| `admin_users` | id, email, password_hash, role_id, last_login, device_tokens |
| `roles` / `permissions` / `role_permissions` | Framework for Phase 2 |
| `sessions` | id, user_id, token_hash, expires_at, ip, user_agent |

**Catalogue**

| Table | Key fields |
|---|---|
| `categories` | id, parent_id, name, slug, image, position, is_active, seo_* |
| `collections` | id, name, slug, type (manual/auto), rules_json, is_active |
| `products` | id, sku, name, slug, category_id, brand_id, gender, description, short_description, mrp, price, cost_price, tax_rate, hsn, weight_g, status, is_featured, is_new, is_trending, is_bestseller, seo_*, created_at |
| `product_variants` | id, product_id, sku, colour, size, material, mrp, price, cost_price, stock, weight_g, barcode, image_id |
| `product_images` | id, product_id, variant_id (nullable), url, alt, position |
| `product_collections` | product_id, collection_id |
| `attributes` | Master lists — colours, sizes, materials |

**Inventory**

| Table | Key fields |
|---|---|
| `inventory` | variant_id, available, reserved, updated_at |
| `inventory_transactions` | id, variant_id, type (opening/purchase/sale/return/damage/adjustment/reservation/release), qty, stock_before, stock_after, reference_type, reference_id, note, admin_user_id, created_at |
| `stock_reservations` | id, variant_id, qty, cart_id, expires_at |

`inventory_transactions` is **append-only**. Current stock is always reconstructible from it — that's what makes discrepancies findable rather than mysterious.

**Orders**

| Table | Key fields |
|---|---|
| `orders` | id, order_number, customer_id, status, subtotal, product_discount, coupon_discount, prepaid_discount, shipping_charge, cod_fee, tax_amount, **total**, **paid_amount**, **balance_amount**, payment_method, payment_status, shipping_status, billing_address_json, shipping_address_json, coupon_id, notes, internal_notes, idempotency_key, placed_at, delivered_at |
| `order_items` | id, order_id, product_id, variant_id, name_snapshot, sku_snapshot, image_snapshot, unit_price, qty, discount, tax_rate, tax_amount, line_total |
| `order_status_history` | id, order_id, from_status, to_status, note, actor, created_at |
| `payments` | id, order_id, gateway, gateway_payment_id, gateway_order_id, amount, type (advance/full/balance/cod), status, method, raw_response_json, created_at |
| `refunds` | id, order_id, payment_id, amount, type (full/partial), destination (original/wallet/upi), status, gateway_refund_id, reason, admin_user_id |
| `shipments` | id, order_id, courier, awb, tracking_url, status, shipped_at, delivered_at, rto_at |

**Addresses are stored as JSON snapshots on the order**, not as foreign keys. If a customer edits their saved address later, historical orders and invoices must not silently change.

Likewise `order_items` snapshots the product name, SKU, image and price at the time of purchase. Renaming a product must never rewrite last month's invoices.

**Marketing & content**

`coupons`, `coupon_usage`, `reviews`, `review_images`, `wishlists`, `banners`, `notifications`, `notification_templates`, `newsletter_subscribers`, `abandoned_carts`, `back_in_stock_requests`, `settings`, `audit_logs`.

---

## 9. Payment flows

### 9.1 Prepaid

```mermaid
sequenceDiagram
    participant C as Customer
    participant S as Store
    participant R as Razorpay
    C->>S: Place order
    S->>S: Create order (status=pending)<br/>Reserve stock, 15-min hold
    S->>R: Create gateway order
    R-->>C: Payment UI
    C->>R: Pay
    R->>S: Webhook: payment.captured
    S->>S: Verify signature
    S->>S: Idempotency check on payment_id
    S->>S: status=confirmed, payment_status=paid<br/>Convert reservation to deduction
    S-->>C: Confirmation email + SMS
```

**Two safeguards you specifically asked for:**

- **The webhook is the source of truth, not the browser redirect.** If the customer closes the tab after paying, the order still confirms. Every real store gets this wrong at least once.
- **Every gateway payment ID is unique-indexed.** A duplicate webhook, a double-click, or a page refresh cannot create a second order. This is your "no duplicate orders from payment callbacks" requirement, enforced at the database level rather than in application logic where it can be bypassed.

### 9.2 Payment failure

Order moves to `payment_failed`, stock reservation is released after 15 minutes, cart is preserved, and a recovery link is emailed. **The order is never treated as paid.**

### 9.3 COD

```mermaid
flowchart TD
    A[COD selected] --> B{Eligible?<br/>₹199-3000, PIN ok,<br/>not blocked, no custom items}
    B -->|No| C[Show reason, offer prepaid]
    B -->|Yes| D[+₹40 COD fee]
    D --> E[Send OTP]
    E --> F{Verified in 24h?}
    F -->|No| G[Auto-cancel, release stock]
    F -->|Yes| H[Confirmed, payment_status=cod_pending]
    H --> I[Ship]
    I --> J{Delivered?}
    J -->|Yes| K[cod_collected, paid_amount=total]
    J -->|No| L[RTO: restock, increment refusal count]
    L --> M{Refusals ≥ 2?}
    M -->|Yes| N[Block COD for this customer]
```

### 9.4 Partial payment *(built, disabled at launch)*

```mermaid
flowchart TD
    A[Order > ₹1,500 and COD available at PIN] --> B[Offer partial payment]
    B --> C[Advance = 25% of total, min ₹200]
    C --> D[Pay advance online]
    D --> E{Success?}
    E -->|No| F[payment_status=failed, not confirmed]
    E -->|Yes| G[partially_paid<br/>paid=advance, balance=total−advance]
    G --> H{Balance method}
    H -->|COD| I[Ship, courier collects balance]
    H -->|Link| J[Payment link sent]
    J --> K{Paid in 3 days?}
    K -->|Yes| L[status=paid, ship]
    K -->|No| M[2 reminders → auto-cancel<br/>refund advance if pre-dispatch]
    I --> N[On delivery: paid, balance=0]
```

**The invariant enforced everywhere:** `paid_amount + balance_amount = total`, always. Every payment event recalculates both, and `payment_status` is *derived* from them rather than set independently. That's what stops the two numbers drifting apart — the bug that makes partial-payment systems untrustworthy.

---

## 10. Shipping flow

```mermaid
flowchart LR
    A[Confirmed] --> B[Packed]
    B --> C[Shipped + AWB]
    C --> D[In Transit]
    D --> E[Out for Delivery]
    E --> F{Delivered?}
    F -->|Yes| G[Delivered]
    F -->|No| H[Failed → Reattempt]
    H --> I[RTO]
    G --> J[Review request +3 days]
    I --> K[Restock + record refusal]
```

**Rate calculation order:**

1. Cart subtotal after discounts
2. Subtotal ≥ ₹699 → shipping = ₹0
3. Otherwise → ₹59
4. COD selected → +₹40
5. Zone determines the delivery estimate shown

---

## 11. Return & refund flow

```mermaid
flowchart TD
    A[Customer requests return<br/>within 7 days] --> B{Item returnable?}
    B -->|No: earrings/custom/combo| C[Blocked, reason shown]
    B -->|Yes| D[Select reason + photos]
    D --> E[Admin reviews]
    E -->|Reject| F[Reason sent to customer]
    E -->|Approve| G{Whose fault?}
    G -->|Ours| H[Free reverse pickup]
    G -->|Customer| I[Self-ship]
    H --> J[Inspect on receipt]
    I --> J
    J --> K{Condition}
    K -->|Sellable| L[Restock]
    K -->|Damaged| M[Damage ledger, no restock]
    L --> N{Exchange or refund?}
    M --> N
    N -->|Exchange| O[New order, no charge]
    N -->|Refund| P{Original method?}
    P -->|Prepaid| Q[Gateway refund]
    P -->|COD| R[UPI transfer or wallet credit]
```

**Note the inspection step.** Stock is restored on *inspection*, not on approval — a returned item that arrives broken must not silently re-enter sellable inventory. This is your "update inventory according to return condition" requirement.

---

## 12. Notification matrix

| Event | Email | SMS | WhatsApp | On-site |
|---|:-:|:-:|:-:|:-:|
| Order placed | ✅ | ✅ | P2 | ✅ |
| Payment received | ✅ | — | P2 | ✅ |
| Partial payment received | ✅ | ✅ | P2 | ✅ |
| Balance payment reminder | ✅ | ✅ | P2 | ✅ |
| COD OTP | — | ✅ | P2 | — |
| Order confirmed | ✅ | — | P2 | ✅ |
| Shipped + tracking | ✅ | ✅ | P2 | ✅ |
| Out for delivery | — | ✅ | P2 | ✅ |
| Delivered | ✅ | — | P2 | ✅ |
| Cancelled | ✅ | ✅ | P2 | ✅ |
| Return approved / rejected | ✅ | — | P2 | ✅ |
| Refund initiated / completed | ✅ | ✅ | P2 | ✅ |
| Back in stock | ✅ | — | P2 | — |
| Abandoned cart | ✅ | — | P2 | — |
| Review request | ✅ | — | P2 | — |

**Admin:** new order (push + email), COD placed, payment failed, low stock (daily digest), return request, daily 9 PM sales summary.

All templates editable from admin. Adding WhatsApp later means implementing one channel adapter — no changes to any calling code.

---

## 13. Security

| Area | Implementation |
|---|---|
| Passwords | bcrypt (cost 12). **No raw card data ever touches our database** — Razorpay's hosted checkout handles it, so we stay out of PCI scope |
| OTP | 6 digits, 5-minute expiry, max 3 attempts, 60-second resend cooldown, hashed at rest |
| Sessions | httpOnly + secure + sameSite cookies, 30-day customer / 8-hour admin, rotated on privilege change |
| Rate limiting | Login 5/15min, OTP 3/hour/number, checkout 10/hour/IP, search 30/min |
| Input validation | Zod schemas on every endpoint, server-side — never trust the client |
| SQL injection | Parameterised queries via ORM throughout |
| XSS | React auto-escaping; sanitised HTML rendering for admin-authored rich text only |
| CSRF | Token on all state-changing requests |
| Webhooks | HMAC signature verification; unsigned webhooks rejected outright |
| **Price integrity** | **All prices, discounts, shipping and totals recalculated server-side at checkout.** Client-submitted amounts are ignored entirely — this is the single most-exploited hole in small e-commerce sites |
| Admin access | Email OTP from unrecognised devices; audit log on sensitive actions |
| Uploads | Type + size validation, processed through Cloudinary, never executed |
| Headers | CSP, HSTS, X-Frame-Options, X-Content-Type-Options |
| Secrets | Environment variables only, never in the repository |

---

## 14. Design system

### 14.1 Reconciling premium + affordable + youthful

These pull in different directions, so each gets a distinct job:

- **Premium** lives in the *structure* — generous whitespace, large images, restrained typography, calm layout.
- **Youthful** lives in the *motion and colour* — the red, hover lifts, quick interactions.
- **Affordable** lives in the *information* — prices are large and confident, discounts are stated plainly. It never apologises for being affordable; it presents value as the point.

The failure mode to avoid is the generic Indian D2C template: eight colours, ten badges per card, blinking offer strips. This design uses **one accent colour and one badge per card**, and buys its energy from photography and space instead.

### 14.2 Palette

| Token | Hex | Use |
|---|---|---|
| Canvas | `#FFFFFF` | Page background |
| Surface | `#FDF7F5` | Warm off-white — sections, cards |
| Brand Red | `#D42A4C` | Primary CTA, badges, links, accents |
| Brand Red Deep | `#A81F3B` | Hover, pressed |
| Blush | `#FBEAEE` | Tints, sale strips |
| Gold | `#C9A227` | "Premium" accent — EXCLUSIVE badge, dividers. Used sparingly |
| Ink | `#1A1418` | Primary text (near-black, warm — never pure black) |
| Ink Muted | `#6B5F63` | Secondary text |
| Border | `#EFE4E0` | Hairlines |
| Success | `#1F7A5C` | In stock, delivered |
| Warning | `#B4690E` | Low stock, pending |

Warm off-white and warm near-black rather than clinical greys — that's what reads as premium rather than cheap, at no cost in legibility.

### 14.3 Typography

| Role | Choice |
|---|---|
| Display / headings | A high-contrast serif — editorial, premium |
| Body / UI | A clean geometric sans — modern, highly legible at small sizes |
| Prices | Sans, tabular figures, semibold |

Both self-hosted with `font-display: swap` — no external font CDN, since that's a render-blocking round trip on a slow Indian mobile connection.

### 14.4 Product card

```
┌─────────────────┐
│ [NEW]        ♡  │  1:1 image, badge top-left,
│                 │  wishlist top-right
│     IMAGE       │
│                 │
│  [ Quick Add ]  │  Appears on hover (desktop) /
├─────────────────┤  always visible (mobile)
│ Oxidised Jhumka │  2 lines max
│ ₹499  ₹899  44% │  Price · struck MRP · discount
│ ★ 4.5 (23)      │  Only if reviews exist
└─────────────────┘
```

**Rules:** one badge maximum. Discount shown only when ≥10%. Rating shown only with ≥3 reviews — "★ 5.0 (1)" reads as fake and costs trust.

### 14.5 Mobile

- Sticky bottom nav: Home · Categories · Search · Wishlist · Account
- Sticky add-to-cart bar on product pages
- 2-column product grid
- Filters in a bottom sheet, not a sidebar
- All tap targets ≥ 44px
- Floating WhatsApp button, bottom-right

### 14.6 Tagline options

1. **Accessories from A to Z** — literal, memorable, explains the name
2. **Everything that completes the look** — benefit-led
3. **A to Z. Head to toe.** — rhythmic, youthful
4. **Where every look finds its finish**

My pick: **#1**. It explains an otherwise cryptic brand name in four words, which for a new brand with no recognition is worth more than cleverness.

---

## 15. Technology & deployment

### 15.1 Stack

| Layer | Choice | Why |
|---|---|---|
| Framework | Next.js 15 (App Router) + TypeScript | Server rendering for SEO, one codebase for store + admin + API |
| Styling | Tailwind CSS | |
| Database | PostgreSQL on Neon | Serverless, free tier, automatic backups, zero administration |
| ORM | Prisma | Type-safe, migrations handled |
| Auth | Auth.js + custom mobile-OTP | |
| Images | Cloudinary | Auto WebP/AVIF, per-device resizing |
| Payments | Razorpay (behind an adapter interface) | |
| Email + SMS | Brevo / MSG91 | |
| Shipping | Manual → Shiprocket | |
| Hosting | Vercel | Global CDN, zero-config deploys, no servers |
| Monitoring | Sentry (free tier) | |

### 15.2 Performance targets

Non-negotiable, because your traffic is 85% mobile on Indian networks:

| Metric | Target |
|---|---|
| Largest Contentful Paint (4G) | < 2.5s |
| Interaction to Next Paint | < 200ms |
| Cumulative Layout Shift | < 0.1 |
| Homepage payload | < 500KB |
| Lighthouse mobile | > 90 |

Techniques: server components by default, lazy-loaded below-fold images with explicit dimensions (prevents layout shift), route-level code splitting, ISR on catalogue pages, no external font or script CDNs on the critical path.

### 15.3 Environments

| Environment | Purpose |
|---|---|
| Local | Development |
| Preview | Every change gets a shareable URL for you to review before it goes live |
| Production | `atozacc.com` |

Razorpay test keys in preview, live keys in production only.

### 15.4 Running cost (approximate — verify current pricing)

| Service | Launch tier | Cost |
|---|---|---|
| Vercel | Hobby → Pro when needed | ₹0 → ~₹1,700/mo |
| Neon PostgreSQL | Free | ₹0 |
| Cloudinary | Free | ₹0 |
| Brevo | Free (~300 emails/day) | ₹0 |
| MSG91 SMS | Pay per SMS | ~₹0.20 each |
| Domain | Annual | ~₹900/yr |
| Sentry | Free | ₹0 |
| **Fixed monthly at launch** | | **≈ ₹0–200** |
| Razorpay | Per transaction | ~2% + GST |
| Shipping | Per shipment | ~₹55–75 |

Compare against Shopify at ₹2,000–5,000/month before a single order ships.

---

## 16. Build phases

### Phase 1 — Launch *(4–5 weeks)*

Storefront: home, category, product, cart, checkout, order success, track order, account, wishlist, search & filters, all policy pages, full SEO, mobile-optimised.

Commerce: catalogue with variants, stock reservation, coupons, prepaid + COD, COD OTP, prepaid discount, shipping rules, invoices, order lifecycle.

Admin: dashboard, orders with bulk actions, products, CSV import, categories, inventory ledger, customers, coupons, reviews, banners, settings, packing slips.

Notifications: email + SMS across all order events.

### Phase 2 — *(weeks 6–10, post-launch)*

WhatsApp notifications · Shiprocket integration · on-site tracking · **partial payment switched on** · abandoned cart recovery · reviews with photos · admin roles · audit log · variant CSV import · advanced reports · blog.

### Phase 3 — *(as the business grows)*

Loyalty · referral · gift cards · wholesale pricing · AI recommendations · WhatsApp commerce · Instagram Shopping · multi-warehouse · mobile app.

**★ On the September target:** Phase 1 is 4–5 weeks of build. The genuine risk to that date is not code — it's product photography (§2.1) and gateway KYC (§2.2). Both are on you and both should start this week. If photos aren't ready, we can launch with a smaller catalogue and add products continuously; the store doesn't need 200 products to open.

---

## 17. Scalability

Nothing here is built for scale you don't have — but nothing blocks it either.

| Future need | Already accommodated |
|---|---|
| 10× orders | Serverless scales automatically; add Redis caching when needed |
| Multi-warehouse | `inventory` is keyed by variant; add a `location_id` column |
| Multi-vendor | Add `vendor_id` to products and orders |
| Multi-currency | Prices stored in paise as integers, currency-tagged |
| Multi-language | Translation-ready content structure |
| Mobile app | API-first — an app consumes the same endpoints |
| New payment gateway | One adapter behind the existing interface |
| New courier | Same adapter pattern |
| ERP / accounting | Append-only ledgers export cleanly |

---

## 18. What I need from you

### Blocking — please start now

| # | Item |
|---|---|
| 1 | **Start product photography** (§2.1) — the longest lead time in the project |
| 2 | **Buy the domain** — check `atozacc.com`, else `.in` |
| 3 | **Start Razorpay signup** with PAN + bank account (§2.2) |
| 4 | **Start SMS DLT registration** (§2.3) |
| 5 | Confirm both addresses and PIN codes (§2.5) |
| 6 | Instagram / social handles for the footer and homepage feed |

### Decisions to confirm

| # | Question | My answer |
|---|---|---|
| 1 | **Custom build, or Shopify?** (§25.1) | Custom — but Shopify is defensible if September is immovable |
| 2 | **₹40 COD fee + ₹25 prepaid discount?** (§2.6) | Yes — this is your main defence against RTO losses |
| 3 | **Free shipping above ₹699, else ₹59?** | Yes — the main lever on your ₹500 AOV |
| 4 | **Partial payment built but off until ₹1,500+ orders?** | Yes — it adds friction at ₹500 |
| 5 | **Product comparison dropped?** | Yes — it's an electronics feature |
| 6 | **Launch COD-only if the gateway isn't ready?** | Yes — don't let KYC set your launch date |
| 7 | **Which gender sections launch?** | Only those with 12+ products. Probably Women first |

### Not urgent

Logo brief · policy text review by your CA/lawyer · GST timing.

---

## 19. Approval

Reply with either:

- **"Approved, start building"** — I begin Phase 1, starting with the database schema and design system.
- **"Change module X to Y"** — I revise and re-issue this document first.

No code will be written until you approve.
