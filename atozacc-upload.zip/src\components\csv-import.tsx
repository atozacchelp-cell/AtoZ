"use client";

import { useActionState, useState } from "react";

import { CATEGORIES } from "@/data/catalog";
import { importProductsCsv, type ImportState } from "@/lib/product-actions";

/**
 * Bulk import. Entering 200 products by hand is 8–10 hours; this turns it
 * into one spreadsheet, which is also how most suppliers send their stock
 * lists in the first place.
 */
export function CsvImport() {
  const [state, action, pending] = useActionState<ImportState, FormData>(
    importProductsCsv,
    {},
  );
  const [showCategories, setShowCategories] = useState(false);

  return (
    <section className="rounded-[var(--radius-card)] border border-line bg-canvas p-5">
      <h2 className="font-display text-lg">Bulk import from a spreadsheet</h2>
      <p className="mt-1 max-w-prose text-[13px] text-ink-mute">
        Faster than the form once you have more than a handful. Save your sheet
        as CSV and upload it. Rows with a SKU that already exists are updated;
        everything else is added.
      </p>

      <div className="mt-4 overflow-x-auto rounded-[var(--radius-card)] border border-line bg-surface p-3">
        <p className="mb-1.5 text-[10.5px] font-bold uppercase tracking-[0.1em] text-ink-mute">
          Column headings
        </p>
        <code className="block whitespace-nowrap text-[11.5px] text-ink-mid">
          name, category, mrp, price, stock, sku, costprice, image,
          shortdescription, description, colours, sizes, material, weight,
          collections, returnable, cod
        </code>
        <p className="mt-2 text-[11.5px] text-ink-mute">
          Only <strong>name, category, mrp, price and stock</strong> are
          required. Prices in rupees. Leave <code>sku</code> blank and one is
          generated.
        </p>
      </div>

      <div className="mt-3 flex flex-wrap gap-3">
        <a
          href="/api/products/template"
          className="text-[12.5px] font-semibold text-brand hover:text-brand-deep"
        >
          Download a template ↓
        </a>
        <button
          type="button"
          onClick={() => setShowCategories((s) => !s)}
          className="text-[12.5px] font-semibold text-ink-mute hover:text-brand"
        >
          {showCategories ? "Hide" : "Show"} category codes
        </button>
      </div>

      {showCategories && (
        <div className="mt-3 max-h-56 overflow-y-auto rounded-[var(--radius-card)] border border-line">
          <table className="w-full text-[12px]">
            <tbody>
              {CATEGORIES.map((c) => (
                <tr key={c.slug} className="border-b border-line last:border-0">
                  <td className="px-3 py-1.5 font-mono text-[11.5px]">{c.slug}</td>
                  <td className="px-3 py-1.5 capitalize text-ink-mute">
                    {c.gender} · {c.name}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <form action={action} className="mt-4 flex flex-wrap items-center gap-3">
        <input
          type="file"
          name="file"
          accept=".csv,text/csv"
          required
          className="text-[12.5px] file:mr-3 file:rounded-[var(--radius-card)] file:border-0 file:bg-ink file:px-4 file:py-2 file:text-[12.5px] file:font-semibold file:text-canvas hover:file:bg-brand"
        />
        <button
          type="submit"
          disabled={pending}
          className="rounded-[var(--radius-card)] bg-brand px-4 py-2 text-[13px] font-semibold text-white hover:bg-brand-deep disabled:opacity-60"
        >
          {pending ? "Importing…" : "Import"}
        </button>
      </form>

      {state.error && (
        <p role="alert" className="mt-3 rounded-[var(--radius-card)] border border-brand bg-blush px-3.5 py-2.5 text-[12.5px] font-medium text-brand-deep">
          {state.error}
        </p>
      )}

      {state.summary && (
        <div className="mt-3 rounded-[var(--radius-card)] border border-line bg-surface p-3.5 text-[12.5px]">
          <p className="font-semibold">
            {state.summary.added} added, {state.summary.updated} updated
          </p>
          {state.summary.skipped.length > 0 && (
            <>
              {/* Skipped rows are listed individually rather than counted, so
                  a bad row can actually be found and fixed. */}
              <p className="mt-2 font-semibold text-warning">
                {state.summary.skipped.length} row
                {state.summary.skipped.length === 1 ? "" : "s"} skipped:
              </p>
              <ul className="mt-1 max-h-40 space-y-0.5 overflow-y-auto text-ink-mute">
                {state.summary.skipped.map((s, i) => (
                  <li key={i}>{s}</li>
                ))}
              </ul>
            </>
          )}
        </div>
      )}
    </section>
  );
}
