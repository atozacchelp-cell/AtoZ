import { promises as realFs } from "node:fs";
import path from "node:path";

import { onNetlify, readJson, writeJson } from "@/lib/storage";

/**
 * A drop-in stand-in for `node:fs` promises, for the JSON stores only.
 *
 * Nine stores had the same shape already: read a file, parse it, cache it
 * against the file's mtime, write it back on change. All of that logic is
 * correct — the only part that cannot survive Netlify is the assumption that
 * `data/*.json` is a writable disk.
 *
 * So rather than rewrite nine modules, this changes what `fs` means to them.
 * Locally it is genuinely the filesystem, so `data/` stays readable in an
 * editor. On Netlify the same calls land in Netlify Blobs. One import line
 * changes per store, and every cache, fallback and error path they already
 * had keeps working untouched.
 *
 * This is deliberately NOT a general filesystem shim. It handles the exact
 * shape those stores use — whole-file JSON read and write under `data/` — and
 * nothing else.
 */

/** `<cwd>/data/users.json` -> `users` */
function keyFor(filePath: string): string {
  return path.basename(filePath).replace(/\.json$/i, "");
}

/**
 * Stands in for a file's modification time.
 *
 * The stores use this to decide whether their cached copy is stale. Blobs
 * have no mtime, so this returns a number that changes when a write happens
 * and otherwise ticks over every few seconds — which gives the same
 * behaviour the mtime check gave: reuse the cache within a render, notice a
 * change shortly after one.
 */
const versions = new Map<string, number>();

export function fileMtime(filePath: string): number {
  if (!onNetlify()) {
    // Locally, the real thing. A genuine mtime is more precise than anything
    // synthesised, and it is what makes editing data/*.json by hand work.
    try {
      // eslint-disable-next-line @typescript-eslint/no-require-imports
      return require("node:fs").statSync(filePath).mtimeMs as number;
    } catch {
      return -1;
    }
  }

  const key = keyFor(filePath);
  const bumped = versions.get(key) ?? 0;
  // The 5-second bucket collapses one page render into one fetch without
  // pinning stale data for long.
  return bumped + Math.floor(Date.now() / 5_000);
}

export const fs = {
  async readFile(filePath: string, _encoding?: BufferEncoding): Promise<string> {
    if (!onNetlify()) return realFs.readFile(filePath, "utf8");

    const value = await readJson<unknown>(keyFor(filePath), null);
    // The callers all `JSON.parse` the result and catch failures, so a missing
    // blob must look like a missing file: throw, do not return "null".
    if (value === null) throw new Error(`No stored value for ${keyFor(filePath)}`);
    return JSON.stringify(value);
  },

  async writeFile(
    filePath: string,
    data: string,
    _encoding?: BufferEncoding,
  ): Promise<void> {
    if (!onNetlify()) return realFs.writeFile(filePath, data, "utf8");

    const key = keyFor(filePath);
    await writeJson(key, JSON.parse(data));
    // Makes the write immediately visible to this instance's next read,
    // rather than waiting out the 5-second bucket.
    versions.set(key, (versions.get(key) ?? 0) + 1_000_000);
  },

  async mkdir(dirPath: string, opts?: { recursive?: boolean }): Promise<void> {
    // Blobs have no directories. Locally this still needs to happen.
    if (onNetlify()) return;
    await realFs.mkdir(dirPath, opts);
  },
};
