import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "@prisma/client";

import { CATEGORIES, COLLECTIONS, PRODUCTS } from "../src/data/catalog";
import { DEFAULT_SETTINGS } from "../src/lib/settings";

/**
 * Seeds the database from the same catalogue the app reads today, so the
 * demo store and the seeded store are identical by construction.
 *
 * Run with:  npx prisma db seed
 *
 * Idempotent — every write is an upsert keyed on a natural unique field, so
 * running it twice does not duplicate anything.
 */

for (const file of [".env.local", ".env"]) {
  try {
    process.loadEnvFile(file);
  } catch {
    // absent is fine
  }
}

const connectionString = process.env.DATABASE_URL;
if (!connectionString) {
  console.error("DATABASE_URL is not set. Copy .env.example to .env.local first.");
  process.exit(1);
}

const db = new PrismaClient({ adapter: new PrismaPg({ connectionString }) });

const GENDER_ENUM = {
  women: "WOMEN",
  men: "MEN",
  kids: "KIDS",
  unisex: "UNISEX",
} as const;

async function main() {
  console.log("Seeding AtoZacc…");

  // --- settings ----------------------------------------------------------
  // Business rules become rows, so they are editable from admin rather than
  // requiring a deploy.
  for (const [key, value] of Object.entries(DEFAULT_SETTINGS)) {
    await db.setting.upsert({
      where: { key },
      create: { key, value: value as never, group: groupFor(key) },
      update: {}, // never overwrite a value the owner has already changed
    });
  }
  console.log(`  settings: ${Object.keys(DEFAULT_SETTINGS).length}`);

  // --- categories, parents before children -------------------------------
  const roots = CATEGORIES.filter((c) => !c.parent);
  const children = CATEGORIES.filter((c) => c.parent);
  const idBySlug = new Map<string, string>();

  for (const [i, cat] of roots.entries()) {
    const row = await db.category.upsert({
      where: { slug: cat.slug },
      create: {
        name: cat.name,
        slug: cat.slug,
        gender: GENDER_ENUM[cat.gender],
        image: cat.image,
        position: i,
        defaultTaxRate: cat.taxRate ?? null,
      },
      update: { name: cat.name, image: cat.image, position: i },
    });
    idBySlug.set(cat.slug, row.id);
  }

  for (const [i, cat] of children.entries()) {
    const row = await db.category.upsert({
      where: { slug: cat.slug },
      create: {
        name: cat.name,
        slug: cat.slug,
        gender: GENDER_ENUM[cat.gender],
        image: cat.image,
        position: i,
        parentId: idBySlug.get(cat.parent!) ?? null,
        defaultTaxRate: cat.taxRate ?? null,
      },
      update: {
        name: cat.name,
        parentId: idBySlug.get(cat.parent!) ?? null,
        position: i,
      },
    });
    idBySlug.set(cat.slug, row.id);
  }
  console.log(`  categories: ${CATEGORIES.length}`);

  // --- collections -------------------------------------------------------
  const collectionIdBySlug = new Map<string, string>();
  for (const [i, col] of COLLECTIONS.entries()) {
    const row = await db.collection.upsert({
      where: { slug: col.slug },
      create: { name: col.name, slug: col.slug, description: col.description, position: i },
      update: { name: col.name, description: col.description, position: i },
    });
    collectionIdBySlug.set(col.slug, row.id);
  }
  console.log(`  collections: ${COLLECTIONS.length}`);

  // --- products ----------------------------------------------------------
  for (const p of PRODUCTS) {
    const categoryId = idBySlug.get(p.category);
    if (!categoryId) {
      console.warn(`  ! skipping ${p.sku}: unknown category ${p.category}`);
      continue;
    }

    const product = await db.product.upsert({
      where: { sku: p.sku },
      create: {
        sku: p.sku,
        name: p.name,
        slug: p.slug,
        categoryId,
        gender: GENDER_ENUM[p.gender],
        shortDescription: p.shortDescription,
        description: p.description,
        careInstructions: p.care,
        features: p.features ?? [],
        tags: [],
        mrp: p.mrp,
        price: p.price,
        costPrice: p.costPrice ?? null,
        // Tax stays 0 until the business registers; the band lives on the
        // category, ready for that day.
        taxRate: 0,
        weightG: p.weightG,
        status: "ACTIVE",
        isNew: p.isNew ?? false,
        isTrending: p.isTrending ?? false,
        isBestseller: p.isBestseller ?? false,
        isExclusive: p.isExclusive ?? false,
        isReturnable: p.isReturnable !== false,
        isCodAllowed: p.isCodAllowed !== false,
        publishedAt: new Date(),
      },
      update: { name: p.name, mrp: p.mrp, price: p.price },
    });

    await db.productImage.upsert({
      where: { id: `${product.id}-main` },
      create: { id: `${product.id}-main`, productId: product.id, url: p.image, position: 0 },
      update: { url: p.image },
    });

    // Every product gets at least one variant, so orders and inventory always
    // point at the same shape whether or not options exist.
    const variant = await db.productVariant.upsert({
      where: { sku: `${p.sku}-V1` },
      create: {
        sku: `${p.sku}-V1`,
        productId: product.id,
        colour: p.colours?.[0] ?? null,
        size: p.sizes?.[0] ?? null,
        material: p.material ?? null,
      },
      update: {},
    });

    await db.inventory.upsert({
      where: { variantId: variant.id },
      create: { variantId: variant.id, available: p.stock },
      update: {},
    });

    // Opening balance in the append-only ledger, so current stock is
    // reconstructible from movement history from day one.
    const existingTxn = await db.inventoryTransaction.findFirst({
      where: { variantId: variant.id, type: "OPENING" },
    });
    if (!existingTxn) {
      await db.inventoryTransaction.create({
        data: {
          variantId: variant.id,
          type: "OPENING",
          qty: p.stock,
          stockBefore: 0,
          stockAfter: p.stock,
          referenceType: "SEED",
          note: "Opening stock",
        },
      });
    }

    for (const slug of p.collections ?? []) {
      const collectionId = collectionIdBySlug.get(slug);
      if (!collectionId) continue;
      await db.productCollection.upsert({
        where: { productId_collectionId: { productId: product.id, collectionId } },
        create: { productId: product.id, collectionId },
        update: {},
      });
    }
  }
  console.log(`  products: ${PRODUCTS.length}`);

  // --- shipping zone -----------------------------------------------------
  const zoneCount = await db.shippingZone.count();
  if (zoneCount === 0) {
    await db.shippingZone.createMany({
      data: [
        {
          name: "Delhi NCR",
          states: ["Delhi", "Haryana", "Uttar Pradesh"],
          pinPrefixes: ["110", "121", "122", "201"],
          baseRate: DEFAULT_SETTINGS.standardShippingRate,
          freeShippingAbove: DEFAULT_SETTINGS.freeShippingThreshold,
          minDays: 1,
          maxDays: 2,
          position: 0,
        },
        {
          name: "Rest of India",
          states: ["*"],
          pinPrefixes: [],
          baseRate: DEFAULT_SETTINGS.standardShippingRate,
          freeShippingAbove: DEFAULT_SETTINGS.freeShippingThreshold,
          minDays: 4,
          maxDays: 7,
          position: 99,
        },
      ],
    });
    console.log("  shipping zones: 2");
  }

  console.log("Done.");
}

function groupFor(key: string): string {
  if (key.startsWith("cod")) return "cod";
  if (key.startsWith("partial")) return "partial";
  if (key.includes("Shipping") || key.includes("shipping")) return "shipping";
  if (key.startsWith("gst") || key.includes("Tax")) return "tax";
  if (key.includes("return") || key.includes("refund")) return "returns";
  if (key.includes("prepaid") || key.includes("Payment")) return "payment";
  if (key.includes("stock") || key.includes("Stock")) return "inventory";
  return "general";
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => db.$disconnect());
