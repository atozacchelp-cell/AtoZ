import { revalidatePath } from "next/cache";

/**
 * Clears the rendered-page cache for the whole shop.
 *
 * This exists because the automatic sync runs on a timer, not inside a
 * request, and `revalidatePath` is only guaranteed to work from a request
 * context. The timer calls this route on itself once a sync succeeds, which
 * gives the revalidation the context it needs.
 *
 * It takes no input and reveals nothing — the worst anyone can do by calling
 * it is make the site re-render pages it was going to re-render anyway.
 */
export async function POST(): Promise<Response> {
  revalidatePath("/", "layout");
  return Response.json({ ok: true, at: new Date().toISOString() });
}
