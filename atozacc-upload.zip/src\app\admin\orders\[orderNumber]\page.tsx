import Link from "next/link";
import { notFound } from "next/navigation";

import { Card, PageHeader, Pill } from "@/components/admin-ui";
import { setOrderStatus } from "@/lib/admin-actions";
import { confirmPaymentReceived, rejectPaymentClaim } from "@/lib/upi-actions";
import { formatINR } from "@/lib/money";
import {
  getOrder,
  ORDER_STATUS_LABELS,
  PAYMENT_STATUS_LABELS,
  type OrderStatus,
} from "@/lib/orders";

export const metadata = { title: "Order", robots: { index: false } };

/** The next sensible action from each state, so the common path is one tap. */
const NEXT_ACTIONS: Partial<Record<OrderStatus, { to: OrderStatus; label: string }[]>> = {
  PENDING: [
    { to: "CONFIRMED", label: "Confirm order" },
    { to: "CANCELLED", label: "Cancel" },
  ],
  CONFIRMED: [
    { to: "PACKED", label: "Mark packed" },
    { to: "CANCELLED", label: "Cancel" },
  ],
  PACKED: [{ to: "SHIPPED", label: "Mark shipped" }],
  SHIPPED: [
    { to: "OUT_FOR_DELIVERY", label: "Out for delivery" },
    { to: "RTO", label: "Returned to us" },
  ],
  IN_TRANSIT: [{ to: "OUT_FOR_DELIVERY", label: "Out for delivery" }],
  OUT_FOR_DELIVERY: [
    { to: "DELIVERED", label: "Mark delivered" },
    { to: "FAILED_DELIVERY", label: "Delivery failed" },
  ],
  FAILED_DELIVERY: [
    { to: "OUT_FOR_DELIVERY", label: "Reattempt" },
    { to: "RTO", label: "Returned to us" },
  ],
};

export default async function AdminOrderDetail({
  params,
}: {
  params: Promise<{ orderNumber: string }>;
}) {
  const { orderNumber } = await params;
  const order = await getOrder(orderNumber);
  if (!order) notFound();

  const actions = NEXT_ACTIONS[order.status] ?? [];

  return (
    <>
      <Link href="/admin/orders" className="text-[12.5px] font-semibold text-ink-mute hover:text-brand">
        ← Orders
      </Link>

      <div className="mt-2">
        <PageHeader
          title={order.orderNumber}
          subtitle={`Placed ${new Date(order.placedAt).toLocaleString("en-IN")}`}
        />
      </div>

      {/* Payment verification comes before anything else: an unpaid order
          should not be packed, and this is the only place it becomes paid. */}
      {order.paymentClaimedAt && !order.paymentVerifiedAt && (
        <Card className="mb-5 border-warning/50 bg-gold-soft">
          <p className="mb-1 text-[10.5px] font-bold uppercase tracking-[0.1em] text-warning">
            Payment needs checking
          </p>
          <p className="text-[13px] text-ink-mid">
            The customer says they paid{" "}
            <strong className="tnum">{formatINR(order.onlineAmountDue)}</strong> by
            UPI.
          </p>
          <p className="mt-1.5 text-[12px] text-ink-mid">
            Find it in your UPI app by:
          </p>
          <ul className="mt-1 space-y-0.5 text-[12px] text-ink-mid">
            <li>
              • Amount{" "}
              <strong className="tnum">{formatINR(order.onlineAmountDue)}</strong>
            </li>
            <li>
              • Note{" "}
              <strong className="font-mono">Order {order.orderNumber}</strong>
            </li>
            {order.upiReference && order.upiReference !== "not provided" && (
              <li>
                • Reference{" "}
                <strong className="tnum font-mono">{order.upiReference}</strong>
              </li>
            )}
            <li>
              • Around{" "}
              {order.paymentClaimedAt
                ? new Date(order.paymentClaimedAt).toLocaleString("en-IN", {
                    day: "2-digit",
                    month: "short",
                    hour: "2-digit",
                    minute: "2-digit",
                  })
                : ""}
            </li>
          </ul>
          <p className="mt-2 text-[12px] text-ink-mute">
            Only confirm once you have actually seen the money.
          </p>

          <div className="mt-3 flex flex-wrap gap-2">
            <form action={confirmPaymentReceived}>
              <input type="hidden" name="orderNumber" value={order.orderNumber} />
              <button
                type="submit"
                className="rounded-[var(--radius-card)] bg-success px-4 py-2 text-[13px] font-semibold text-white hover:opacity-90"
              >
                Money received — mark paid
              </button>
            </form>
            <form action={rejectPaymentClaim}>
              <input type="hidden" name="orderNumber" value={order.orderNumber} />
              <input type="hidden" name="reason" value="Payment not found in account" />
              <button
                type="submit"
                className="rounded-[var(--radius-card)] border border-line px-4 py-2 text-[13px] font-semibold text-ink-mute hover:border-brand hover:text-brand"
              >
                Not received
              </button>
            </form>
          </div>
        </Card>
      )}

      {order.paymentRejectedReason && (
        <Card className="mb-5 border-brand bg-blush">
          <p className="text-[13px] font-semibold text-brand-deep">
            Payment claim rejected — {order.paymentRejectedReason}
          </p>
          <p className="mt-1 text-[12px] text-ink-mid">
            The order is unpaid. Contact the customer before cancelling.
          </p>
        </Card>
      )}

      {/* Actions first. This page exists to move an order forward. */}
      {actions.length > 0 && (
        <Card className="mb-5">
          <p className="mb-2.5 text-[10.5px] font-bold uppercase tracking-[0.1em] text-ink-mute">
            Next step
          </p>
          <div className="flex flex-wrap gap-2">
            {actions.map((a) => (
              <form key={a.to} action={setOrderStatus}>
                <input type="hidden" name="orderNumber" value={order.orderNumber} />
                <input type="hidden" name="status" value={a.to} />
                <button
                  type="submit"
                  className={
                    a.to === "CANCELLED" || a.to === "RTO" || a.to === "FAILED_DELIVERY"
                      ? "rounded-[var(--radius-card)] border border-line px-4 py-2 text-[13px] font-semibold text-ink-mute hover:border-brand hover:text-brand"
                      : "rounded-[var(--radius-card)] bg-brand px-4 py-2 text-[13px] font-semibold text-white hover:bg-brand-deep"
                  }
                >
                  {a.label}
                </button>
              </form>
            ))}
          </div>

          {order.status === "PENDING" && order.paymentMethod === "COD" && (
            <p className="mt-3 text-[12px] text-ink-mute">
              Call{" "}
              <a href={`tel:${order.shippingAddress.mobile}`} className="tnum font-semibold text-brand">
                {order.shippingAddress.mobile}
              </a>{" "}
              to verify this COD order before confirming.
            </p>
          )}
        </Card>
      )}

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1.5fr)_minmax(0,1fr)]">
        <div className="space-y-5">
          <Card>
            <h2 className="mb-3 font-display text-lg">Items</h2>
            <ul className="divide-y divide-line">
              {order.items.map((item, i) => (
                <li key={i} className="flex justify-between gap-3 py-2.5 text-[13px]">
                  <span className="min-w-0">
                    <span className="block font-medium">{item.name}</span>
                    <span className="tnum text-[11.5px] text-ink-mute">
                      {item.sku}
                      {item.variantLabel && ` · ${item.variantLabel}`}
                      {` · ${formatINR(item.unitPrice)} × ${item.qty}`}
                    </span>
                  </span>
                  <span className="tnum shrink-0 font-semibold">
                    {formatINR(item.lineTotal)}
                  </span>
                </li>
              ))}
            </ul>

            <dl className="tnum mt-4 space-y-1 border-t border-line pt-3 text-[13px]">
              <Line label="Subtotal" value={formatINR(order.subtotal + order.productDiscount)} />
              {order.productDiscount > 0 && (
                <Line label="Product discount" value={`−${formatINR(order.productDiscount)}`} />
              )}
              {order.couponDiscount > 0 && (
                <Line
                  label={`Coupon ${order.couponCode ?? ""}`}
                  value={`−${formatINR(order.couponDiscount)}`}
                />
              )}
              {order.prepaidDiscount > 0 && (
                <Line label="Prepaid discount" value={`−${formatINR(order.prepaidDiscount)}`} />
              )}
              <Line label="Shipping" value={formatINR(order.shippingCharge)} />
              {order.codFee > 0 && <Line label="COD fee" value={formatINR(order.codFee)} />}
              <div className="flex justify-between border-t border-line pt-1.5 text-[15px] font-bold">
                <span>Total</span>
                <span>{formatINR(order.total)}</span>
              </div>
            </dl>
          </Card>

          <Card>
            <h2 className="mb-3 font-display text-lg">History</h2>
            <ol className="space-y-2">
              {order.statusHistory.map((h, i) => (
                <li key={i} className="flex gap-3 text-[12.5px]">
                  <span className="tnum w-[130px] shrink-0 text-ink-mute">
                    {new Date(h.at).toLocaleString("en-IN", {
                      day: "2-digit",
                      month: "short",
                      hour: "2-digit",
                      minute: "2-digit",
                    })}
                  </span>
                  <span>
                    <span className="font-semibold">{ORDER_STATUS_LABELS[h.status]}</span>
                    {h.note && <span className="text-ink-mute"> — {h.note}</span>}
                  </span>
                </li>
              ))}
            </ol>
          </Card>
        </div>

        <div className="space-y-5">
          <Card>
            <h2 className="mb-3 font-display text-lg">Payment</h2>
            <div className="mb-3 flex flex-wrap gap-2">
              <Pill tone={order.paymentMethod === "COD" ? "warn" : "good"}>
                {order.paymentMethod}
              </Pill>
              <Pill tone={order.balanceAmount > 0 ? "bad" : "good"}>
                {PAYMENT_STATUS_LABELS[order.paymentStatus]}
              </Pill>
            </div>
            <dl className="tnum space-y-1 text-[13px]">
              <Line label="Order value" value={formatINR(order.total)} />
              <Line label="Paid" value={formatINR(order.paidAmount)} />
              <Line label="Balance due" value={formatINR(order.balanceAmount)} />
              {order.upiReference && (
                <Line label="UPI reference" value={order.upiReference} />
              )}
              {order.paymentVerifiedAt && (
                <Line
                  label="Verified"
                  value={new Date(order.paymentVerifiedAt).toLocaleString("en-IN")}
                />
              )}
            </dl>
          </Card>

          <Card>
            <h2 className="mb-2 font-display text-lg">Ship to</h2>
            <address className="text-[13px] not-italic leading-relaxed text-ink-mid">
              <strong className="block text-ink">{order.shippingAddress.name}</strong>
              {order.shippingAddress.line1}
              {order.shippingAddress.line2 && <>, {order.shippingAddress.line2}</>}
              <br />
              {order.shippingAddress.area && <>{order.shippingAddress.area}, </>}
              {order.shippingAddress.city}
              <br />
              {order.shippingAddress.state} —{" "}
              <span className="tnum">{order.shippingAddress.pincode}</span>
              <br />
              <a
                href={`tel:${order.shippingAddress.mobile}`}
                className="tnum font-semibold text-brand"
              >
                {order.shippingAddress.mobile}
              </a>
            </address>
            {order.customerNote && (
              <p className="mt-3 rounded-[var(--radius-card)] bg-surface px-3 py-2 text-[12.5px] text-ink-mid">
                <strong>Note:</strong> {order.customerNote}
              </p>
            )}
          </Card>
        </div>
      </div>
    </>
  );
}

function Line({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-3">
      <dt className="text-ink-mute">{label}</dt>
      <dd>{value}</dd>
    </div>
  );
}
