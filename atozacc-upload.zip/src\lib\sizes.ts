/**
 * Sizes, and stock held per size.
 *
 * An accessory has one stock number and that is the end of it. A garment does
 * not: three mediums and no larges is the normal state of a clothing shop, and
 * a shop that tracks only "6 in stock" will happily sell the large it does not
 * have. That sale then has to be cancelled by hand, refunded, and apologised
 * for — which is why this exists.
 *
 * So the sheet's `stock` cell accepts two shapes:
 *
 *   25                     one number, the whole product (accessories)
 *   S:5, M:8, L:3, XL:0    a number per size (garments)
 *
 * The second form also defines the sizes, so a t-shirt needs one cell edited
 * rather than two kept in step with each other.
 */

export type SizeStock = Record<string, number>;

export type ParsedStock = {
  /** Sizes in the order written, when the cell listed them. */
  sizes: string[];
  /** Units per size. Absent when the cell was a plain number. */
  sizeStock?: SizeStock;
  /** Units across every size — what the rest of the shop treats as stock. */
  total: number;
};

const toCount = (raw: string): number => {
  const n = Number(raw.replace(/[^\d-]/g, ""));
  return Number.isFinite(n) ? Math.max(0, Math.trunc(n)) : 0;
};

/**
 * Reads a `stock` cell.
 *
 * `sizesHint` is the separate `sizes` column, if the owner filled it in. A
 * size listed there but missing from a per-size stock cell is treated as zero
 * rather than dropped, so an unlisted size shows as sold out instead of
 * quietly disappearing from the page.
 */
export function parseStockCell(raw: string, sizesHint: string[] = []): ParsedStock {
  const cell = (raw ?? "").trim();

  // Per-size only when there is a size:count pair. A bare "25" stays a bare 25.
  const pairs = [...cell.matchAll(/([^,;\n|:=]+)\s*[:=]\s*(-?\d+)/g)];

  if (pairs.length === 0) {
    return { sizes: sizesHint, total: toCount(cell) };
  }

  const sizeStock: SizeStock = {};
  const order: string[] = [];

  for (const [, label, count] of pairs) {
    const size = label.trim();
    if (!size) continue;
    if (!(size in sizeStock)) order.push(size);
    sizeStock[size] = toCount(count);
  }

  // Sizes named in the sizes column but absent above: sold out, not missing.
  for (const size of sizesHint) {
    if (!(size in sizeStock)) {
      sizeStock[size] = 0;
      order.push(size);
    }
  }

  // The sizes column, where present, decides the order shown to customers —
  // S, M, L, XL is what a shopper expects, whatever order the stock was typed.
  const sizes = sizesHint.length
    ? [...sizesHint, ...order.filter((s) => !sizesHint.includes(s))]
    : order;

  const total = Object.values(sizeStock).reduce((n, v) => n + v, 0);
  return { sizes, sizeStock, total };
}

/** Units available in one size. Falls back to whole-product stock. */
export function stockForSize(
  product: { stock: number; sizeStock?: SizeStock },
  size?: string,
): number {
  if (!product.sizeStock) return product.stock;
  if (!size) return product.stock;
  return product.sizeStock[size] ?? 0;
}

/** Sizes with nothing left. Shown struck through rather than hidden. */
export function soldOutSizes(sizeStock?: SizeStock): string[] {
  if (!sizeStock) return [];
  return Object.entries(sizeStock)
    .filter(([, n]) => n <= 0)
    .map(([s]) => s);
}

/**
 * A size that means "one size fits all" and therefore needs no choosing.
 *
 * Pre-selecting a real size is how customers end up with the wrong one, so the
 * product page forces a deliberate pick — except here, where there is nothing
 * to decide and forcing a click would be pure friction.
 */
export function isFreeSize(sizes: string[]): boolean {
  if (sizes.length !== 1) return false;
  return /^(free\s*size|one\s*size|standard|adjustable)/i.test(sizes[0].trim());
}

/**
 * Writes a `stock` cell back out in the shape `parseStockCell` reads.
 *
 * Export → edit in the sheet → re-import has to be lossless. Writing a
 * garment's total here instead of its per-size breakdown would collapse
 * `S:5, M:8, L:0` into `13` on the first round trip, and silently restore the
 * large that is actually sold out.
 */
export function formatStockCell(product: {
  stock: number;
  sizes?: string[];
  sizeStock?: SizeStock;
}): string {
  if (!product.sizeStock) return String(product.stock);

  const order = product.sizes?.length
    ? [
        ...product.sizes,
        ...Object.keys(product.sizeStock).filter((s) => !product.sizes!.includes(s)),
      ]
    : Object.keys(product.sizeStock);

  return order.map((s) => `${s}:${product.sizeStock![s] ?? 0}`).join(", ");
}

/* -------------------------------------------------------------------------
   Size chart
   ------------------------------------------------------------------------- */

export type SizeChart = { headers: string[]; rows: string[][] };

/**
 * Reads a `sizechart` cell into a table.
 *
 * Rows are separated by `|` or a line break, cells by commas, and the first
 * row is the heading:
 *
 *   Size,Chest (in),Length (in)|S,36,26|M,38,27|L,40,28
 *
 * Measurements are the single biggest lever on clothing returns in India,
 * where a "large" varies by several inches between brands. A garment listed
 * without one will be returned, and a return costs more than the margin.
 */
export function parseSizeChart(raw: string): SizeChart | undefined {
  const cell = (raw ?? "").trim();
  if (!cell) return undefined;

  const rows = cell
    .split(/[|\n]/)
    .map((r) => r.split(",").map((c) => c.trim()))
    .filter((r) => r.some(Boolean));

  if (rows.length < 2) return undefined;

  const [headers, ...body] = rows;
  const width = headers.length;

  return {
    headers,
    // Ragged rows are padded rather than rejected — a missing measurement
    // should cost one blank cell, not the whole chart.
    rows: body.map((r) => Array.from({ length: width }, (_, i) => r[i] ?? "")),
  };
}

/** Writes a chart back into one cell, in the form `parseSizeChart` reads. */
export function formatSizeChart(chart?: SizeChart): string {
  if (!chart) return "";
  return [chart.headers, ...chart.rows].map((r) => r.join(",")).join("|");
}
