import { EmptyRow, PageHeader, Pill, Stat, Table } from "@/components/admin-ui";
import { formatINR } from "@/lib/money";
import { listOrders } from "@/lib/orders";

export const metadata = { title: "Customers", robots: { index: false } };

export default async function AdminCustomers() {
  const orders = await listOrders();

  // Customers are derived from orders until accounts exist. Mobile number is
  // the identity here, which is also how the database keys them.
  const byMobile = new Map<
    string,
    {
      name: string;
      mobile: string;
      city: string;
      orders: number;
      spent: number;
      due: number;
      cod: number;
      refused: number;
    }
  >();

  for (const o of orders) {
    const key = o.shippingAddress.mobile;
    const prev = byMobile.get(key) ?? {
      name: o.shippingAddress.name,
      mobile: key,
      city: o.shippingAddress.city,
      orders: 0,
      spent: 0,
      due: 0,
      cod: 0,
      refused: 0,
    };
    byMobile.set(key, {
      ...prev,
      orders: prev.orders + 1,
      spent: prev.spent + o.paidAmount,
      due: prev.due + o.balanceAmount,
      cod: prev.cod + (o.paymentMethod === "COD" ? 1 : 0),
      refused:
        prev.refused + (o.status === "RTO" || o.status === "FAILED_DELIVERY" ? 1 : 0),
    });
  }

  const customers = [...byMobile.values()].sort((a, b) => b.orders - a.orders);

  return (
    <>
      <PageHeader
        title="Customers"
        subtitle="Derived from orders until sign-in is live"
      />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Customers" value={String(customers.length)} />
        <Stat
          label="Repeat buyers"
          value={String(customers.filter((c) => c.orders > 1).length)}
        />
        <Stat
          label="Collected"
          value={formatINR(customers.reduce((s, c) => s + c.spent, 0))}
          tone="good"
        />
        <Stat
          label="Outstanding"
          value={formatINR(customers.reduce((s, c) => s + c.due, 0))}
          tone="warn"
        />
      </div>

      <div className="mt-6">
        <Table head={["Customer", "Mobile", "City", "Orders", "COD", "Paid", "Due", "Risk"]}>
          {customers.length === 0 ? (
            <EmptyRow colSpan={8}>No customers yet.</EmptyRow>
          ) : (
            customers.map((c) => (
              <tr key={c.mobile} className="border-b border-line last:border-0">
                <td className="px-3 py-2 font-medium">{c.name}</td>
                <td className="tnum px-3 py-2 text-ink-mute">{c.mobile}</td>
                <td className="px-3 py-2 text-ink-mute">{c.city}</td>
                <td className="tnum px-3 py-2 font-semibold">{c.orders}</td>
                <td className="px-3 py-2">
                  {c.cod > 0 ? (
                    <Pill tone="warn">{c.cod}</Pill>
                  ) : (
                    <span className="text-ink-mute">—</span>
                  )}
                </td>
                <td className="tnum px-3 py-2">{formatINR(c.spent)}</td>
                <td className="tnum px-3 py-2">
                  <span className={c.due > 0 ? "font-semibold text-brand" : "text-ink-mute"}>
                    {formatINR(c.due)}
                  </span>
                </td>
                <td className="px-3 py-2">
                  {/* Two refused deliveries is the point at which COD is
                      switched off for a number. */}
                  {c.refused >= 2 ? (
                    <Pill tone="bad">COD blocked</Pill>
                  ) : c.refused === 1 ? (
                    <Pill tone="warn">1 refused</Pill>
                  ) : (
                    <Pill tone="good">OK</Pill>
                  )}
                </td>
              </tr>
            ))
          )}
        </Table>
      </div>
    </>
  );
}
