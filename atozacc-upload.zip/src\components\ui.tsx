import Link from "next/link";

import { cn } from "@/lib/cn";

/* -------------------------------------------------------------------------
   Buttons
   ------------------------------------------------------------------------- */

type ButtonProps = {
  variant?: "primary" | "secondary" | "ghost" | "danger";
  size?: "sm" | "md" | "lg";
  full?: boolean;
};

const BASE =
  "inline-flex items-center justify-center gap-2 rounded-[var(--radius-card)] font-semibold transition-colors disabled:cursor-not-allowed disabled:opacity-45";

const VARIANTS: Record<NonNullable<ButtonProps["variant"]>, string> = {
  primary: "bg-brand text-white hover:bg-brand-deep",
  secondary: "border border-ink bg-canvas text-ink hover:bg-ink hover:text-canvas",
  ghost: "text-ink-mid hover:bg-surface hover:text-brand",
  danger: "border border-line text-ink-mute hover:border-brand hover:text-brand",
};

const SIZES: Record<NonNullable<ButtonProps["size"]>, string> = {
  sm: "px-3 py-1.5 text-[12.5px]",
  md: "px-4 py-2.5 text-[13.5px]",
  lg: "px-6 py-3.5 text-[15px]",
};

export function buttonClass({ variant = "primary", size = "md", full }: ButtonProps = {}) {
  return cn(BASE, VARIANTS[variant], SIZES[size], full && "w-full");
}

export function Button({
  variant,
  size,
  full,
  className,
  ...rest
}: ButtonProps & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return <button className={cn(buttonClass({ variant, size, full }), className)} {...rest} />;
}

export function ButtonLink({
  href,
  variant,
  size,
  full,
  className,
  children,
}: ButtonProps & { href: string; className?: string; children: React.ReactNode }) {
  return (
    <Link href={href} className={cn(buttonClass({ variant, size, full }), className)}>
      {children}
    </Link>
  );
}

/* -------------------------------------------------------------------------
   Layout
   ------------------------------------------------------------------------- */

export function Container({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return <div className={cn("mx-auto w-full max-w-7xl px-4 sm:px-6", className)}>{children}</div>;
}

export function SectionHeading({
  title,
  subtitle,
  href,
  linkLabel = "View all",
}: {
  title: string;
  subtitle?: string;
  href?: string;
  linkLabel?: string;
}) {
  return (
    <div className="mb-6 flex items-end justify-between gap-4">
      <div>
        <h2 className="font-display text-[26px] leading-tight sm:text-[30px]">{title}</h2>
        {subtitle && <p className="mt-1 text-[13.5px] text-ink-mute">{subtitle}</p>}
      </div>
      {href && (
        <Link
          href={href}
          className="shrink-0 whitespace-nowrap border-b border-brand pb-0.5 text-[13px] font-semibold text-brand hover:border-brand-deep hover:text-brand-deep"
        >
          {linkLabel}
        </Link>
      )}
    </div>
  );
}

export function Breadcrumbs({
  items,
}: {
  items: { label: string; href?: string }[];
}) {
  return (
    <nav aria-label="Breadcrumb" className="mb-5">
      <ol className="flex flex-wrap items-center gap-1.5 text-[12.5px] text-ink-mute">
        <li>
          <Link href="/" className="hover:text-brand">
            Home
          </Link>
        </li>
        {items.map((item, i) => (
          <li key={`${item.label}-${i}`} className="flex items-center gap-1.5">
            <span aria-hidden className="text-line-firm">
              /
            </span>
            {item.href ? (
              <Link href={item.href} className="hover:text-brand">
                {item.label}
              </Link>
            ) : (
              <span className="text-ink-mid">{item.label}</span>
            )}
          </li>
        ))}
      </ol>
    </nav>
  );
}

/* -------------------------------------------------------------------------
   States
   ------------------------------------------------------------------------- */

export function EmptyState({
  title,
  body,
  action,
}: {
  title: string;
  body: string;
  action?: { href: string; label: string };
}) {
  return (
    <div className="rounded-[var(--radius-card)] border border-dashed border-line-firm bg-surface px-6 py-16 text-center">
      <h2 className="font-display text-xl">{title}</h2>
      <p className="mx-auto mt-2 max-w-sm text-[13.5px] text-ink-mute">{body}</p>
      {action && (
        <div className="mt-6">
          <ButtonLink href={action.href} variant="primary">
            {action.label}
          </ButtonLink>
        </div>
      )}
    </div>
  );
}

/* -------------------------------------------------------------------------
   Trust strip — the three objections that stop an Indian D2C checkout
   ------------------------------------------------------------------------- */

export function TrustStrip({
  freeShippingLabel,
  returnDays,
}: {
  freeShippingLabel: string;
  returnDays: number;
}) {
  const items = [
    { title: "Cash on delivery", body: "Pay when it reaches you", d: "M2 7h20v10H2zM12 10a2 2 0 1 1 0 4 2 2 0 0 1 0-4z" },
    { title: `Free over ${freeShippingLabel}`, body: "Delivered across India", d: "M3 7h11v9H3zM14 10h4l3 3v3h-7zM7 19a2 2 0 1 0 0-4 2 2 0 0 0 0 4zM18 19a2 2 0 1 0 0-4 2 2 0 0 0 0 4z" },
    { title: `${returnDays}-day returns`, body: "Easy exchange or refund", d: "M3 12a9 9 0 1 1 3 6.7M3 12V6M3 12h6" },
    { title: "Secure payments", body: "UPI, cards and net banking", d: "M12 2 4 6v6c0 5 3.4 9.4 8 10 4.6-.6 8-5 8-10V6z" },
  ];

  return (
    <div className="grid grid-cols-2 gap-x-4 gap-y-5 border-y border-line py-6 lg:grid-cols-4">
      {items.map((it) => (
        <div key={it.title} className="flex items-start gap-3">
          <svg
            className="mt-0.5 shrink-0 text-brand"
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.5"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden
          >
            <path d={it.d} />
          </svg>
          <div>
            <p className="text-[13px] font-bold leading-tight">{it.title}</p>
            <p className="mt-0.5 text-[12px] text-ink-mute">{it.body}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

/* -------------------------------------------------------------------------
   Rating
   ------------------------------------------------------------------------- */

export function StarRating({
  rating,
  count,
  size = 13,
}: {
  rating: number;
  count?: number;
  size?: number;
}) {
  return (
    <span className="tnum inline-flex items-center gap-1 text-[12.5px]">
      <span className="inline-flex" aria-hidden>
        {[1, 2, 3, 4, 5].map((i) => (
          <svg
            key={i}
            width={size}
            height={size}
            viewBox="0 0 24 24"
            fill={i <= Math.round(rating) ? "currentColor" : "none"}
            stroke="currentColor"
            strokeWidth="1.5"
            className="text-gold"
          >
            <path d="m12 2 3 6.5 7 .9-5 4.8 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.8 7-.9z" />
          </svg>
        ))}
      </span>
      <span className="font-semibold text-ink-mid">{rating.toFixed(1)}</span>
      {count !== undefined && <span className="text-ink-mute">({count})</span>}
      <span className="sr-only">{rating} out of 5 stars</span>
    </span>
  );
}
