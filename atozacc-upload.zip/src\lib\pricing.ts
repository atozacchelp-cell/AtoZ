import { atLeastZero, extractTax, percentOf, roundToRupee } from "@/lib/money";
import type { Settings } from "@/lib/settings";

/**
 * The pricing engine.
 *
 * SECURITY: this must only ever run on the server. The client sends product
 * ids and quantities — never prices, never totals. Every amount a customer
 * pays is computed here from the catalogue and the settings store. Trusting a
 * client-submitted total is the single most-exploited hole in small
 * e-commerce sites, and the reason this module takes no money from its caller.
 */

export type PricedLine = {
  variantKey: string;
  name: string;
  imageUrl: string;
  href: string;
  /** Selling price per unit, tax-inclusive, in paise. */
  unitPrice: number;
  /** Struck-through price per unit, in paise. */
  unitMrp: number;
  qty: number;
  /** Basis points. */
  taxRate: number;
  lineTotal: number;
  lineMrpTotal: number;
  lineTax: number;
  outOfStock: boolean;
  /** Some items cannot ship COD (personalised goods). */
  codAllowed: boolean;
  /** Set when a supplier ships this rather than you. */
  supplier?: string;
  fulfilment?: "self" | "dropship";
};

export type CouponInput = {
  code: string;
  type: "PERCENT" | "FIXED" | "FREE_SHIPPING";
  /** PERCENT: basis points. FIXED: paise. */
  value: number;
  minOrderValue?: number;
  maxDiscount?: number;
  prepaidOnly?: boolean;
};

export type PaymentChoice = "PREPAID" | "COD" | "PARTIAL";

export type PriceBreakdown = {
  lines: PricedLine[];
  itemCount: number;

  /** Sum of selling prices. What the cart is "worth" before order-level maths. */
  subtotal: number;
  /** MRP minus selling price, summed. Shown as "you save". */
  productDiscount: number;
  couponDiscount: number;
  couponCode?: string;
  couponError?: string;
  prepaidDiscount: number;

  shippingCharge: number;
  shippingIsFree: boolean;
  /** Paise still to spend to earn free shipping. 0 once earned. */
  amountToFreeShipping: number;

  codFee: number;
  taxAmount: number;

  total: number;

  /** Partial payment, when eligible and enabled. */
  advanceAmount: number;
  balanceAmount: number;
  isPartial: boolean;
};

export type CodEligibility = {
  allowed: boolean;
  reason?: string;
};

// ---------------------------------------------------------------------------
// COD eligibility
// ---------------------------------------------------------------------------

/**
 * Runs before COD is offered at checkout. Every rejection returns a reason,
 * because "COD not available" with no explanation reads as a bug and loses
 * the order — telling someone the cart is ₹40 short of the minimum gives them
 * something to do about it.
 */
export function checkCodEligibility(
  lines: PricedLine[],
  cartTotal: number,
  settings: Settings,
  opts: {
    customerBlocked?: boolean;
    pincodeCodAvailable?: boolean;
    /** Supplier names that will not ship cash on delivery. */
    suppliersWithoutCod?: string[];
  } = {},
): CodEligibility {
  if (!settings.codEnabled) {
    return { allowed: false, reason: "Cash on delivery is currently unavailable." };
  }

  if (opts.customerBlocked) {
    return {
      allowed: false,
      reason:
        "Cash on delivery isn't available on this account. Paying online works as usual.",
    };
  }

  if (opts.pincodeCodAvailable === false) {
    return { allowed: false, reason: "Cash on delivery isn't available at this PIN code." };
  }

  const blocked = lines.find((l) => !l.codAllowed);
  if (blocked) {
    return {
      allowed: false,
      reason: `${blocked.name} can't be sent cash on delivery.`,
    };
  }

  // Dropshipped goods are only COD-able if the SUPPLIER will ship them that
  // way. Most Indian dropship suppliers want prepayment, and discovering that
  // after the customer has ordered leaves the order stuck with nobody having
  // told them. Refuse it at checkout instead, where it is still recoverable.
  const noCodSuppliers = new Set(
    (opts.suppliersWithoutCod ?? []).map((s) => s.toLowerCase()),
  );
  if (noCodSuppliers.size > 0) {
    const supplierBlocked = lines.find(
      (l) => l.supplier && noCodSuppliers.has(l.supplier.toLowerCase()),
    );
    if (supplierBlocked) {
      return {
        allowed: false,
        reason: `${supplierBlocked.name} is shipped by a supplier who does not accept cash on delivery. Paying online works.`,
      };
    }
  }

  if (cartTotal < settings.codMinOrderValue) {
    return {
      allowed: false,
      reason: `Cash on delivery starts at ₹${settings.codMinOrderValue / 100}.`,
    };
  }

  if (cartTotal > settings.codMaxOrderValue) {
    return {
      allowed: false,
      reason: `Cash on delivery is available up to ₹${settings.codMaxOrderValue / 100}. Please pay online for this order.`,
    };
  }

  return { allowed: true };
}

// ---------------------------------------------------------------------------
// Coupons
// ---------------------------------------------------------------------------

function applyCoupon(
  coupon: CouponInput | undefined,
  eligibleSubtotal: number,
  payment: PaymentChoice,
): { discount: number; freeShipping: boolean; error?: string } {
  if (!coupon) return { discount: 0, freeShipping: false };

  if (coupon.minOrderValue && eligibleSubtotal < coupon.minOrderValue) {
    return {
      discount: 0,
      freeShipping: false,
      error: `Add ₹${Math.ceil((coupon.minOrderValue - eligibleSubtotal) / 100)} more to use ${coupon.code}.`,
    };
  }

  if (coupon.prepaidOnly && payment !== "PREPAID") {
    return {
      discount: 0,
      freeShipping: false,
      error: `${coupon.code} is valid on prepaid orders only.`,
    };
  }

  if (coupon.type === "FREE_SHIPPING") {
    return { discount: 0, freeShipping: true };
  }

  let discount =
    coupon.type === "PERCENT"
      ? percentOf(eligibleSubtotal, coupon.value)
      : coupon.value;

  if (coupon.maxDiscount) discount = Math.min(discount, coupon.maxDiscount);

  // A coupon must never exceed the cart, or the order goes negative.
  discount = Math.min(discount, eligibleSubtotal);

  return { discount, freeShipping: false };
}

// ---------------------------------------------------------------------------
// The main calculation
// ---------------------------------------------------------------------------

export function priceCart(input: {
  lines: PricedLine[];
  settings: Settings;
  payment: PaymentChoice;
  coupon?: CouponInput;
  /** Overrides the default rate when a shipping zone matched. */
  shippingRateOverride?: number;
}): PriceBreakdown {
  const { lines, settings, payment, coupon } = input;

  const itemCount = lines.reduce((n, l) => n + l.qty, 0);
  const subtotal = lines.reduce((s, l) => s + l.lineTotal, 0);
  const mrpTotal = lines.reduce((s, l) => s + l.lineMrpTotal, 0);
  const productDiscount = atLeastZero(mrpTotal - subtotal);

  // --- coupon ------------------------------------------------------------
  const couponResult = applyCoupon(coupon, subtotal, payment);
  const couponDiscount = couponResult.discount;

  // --- prepaid nudge -----------------------------------------------------
  // Framed to the customer as a saving for paying online rather than a
  // penalty for COD. Same arithmetic; converts better.
  const prepaidDiscount =
    settings.prepaidDiscountEnabled && (payment === "PREPAID" || payment === "PARTIAL")
      ? Math.min(settings.prepaidDiscount, atLeastZero(subtotal - couponDiscount))
      : 0;

  const afterDiscounts = atLeastZero(subtotal - couponDiscount - prepaidDiscount);

  // --- shipping ----------------------------------------------------------
  // The threshold sits deliberately above the average order value, to pull a
  // second item into the basket. It is the highest-leverage number here.
  const baseRate = input.shippingRateOverride ?? settings.standardShippingRate;
  const earnedFreeShipping = afterDiscounts >= settings.freeShippingThreshold;
  const shippingIsFree = earnedFreeShipping || couponResult.freeShipping;

  const codBlocksFreeShipping = payment === "COD" && !settings.freeShippingAppliesToCod;
  const shippingCharge = shippingIsFree && !codBlocksFreeShipping ? 0 : baseRate;

  const amountToFreeShipping = earnedFreeShipping
    ? 0
    : atLeastZero(settings.freeShippingThreshold - afterDiscounts);

  // --- COD fee -----------------------------------------------------------
  const codFee = payment === "COD" ? settings.codFee : 0;

  // --- tax ---------------------------------------------------------------
  // Prices are tax-inclusive, so tax is EXTRACTED from the line totals rather
  // than added on top.
  //
  // Gated on registration: the catalogue carries a GST band per category so
  // it is ready the day the store registers, but an unregistered business
  // must not show tax on anything — its invoices are Bills of Supply. The
  // total is unaffected either way (tax comes out of the price, never on top),
  // so registering later changes no displayed price — only what the invoice
  // breaks out.
  const taxAmount = settings.gstRegistered
    ? lines.reduce((s, l) => s + extractTax(l.lineTotal, l.taxRate), 0)
    : 0;

  // --- total -------------------------------------------------------------
  const total = roundToRupee(afterDiscounts + shippingCharge + codFee);

  // --- partial payment ---------------------------------------------------
  const partialEligible =
    settings.partialPaymentEnabled &&
    payment === "PARTIAL" &&
    total >= settings.partialMinOrderValue;

  const advanceAmount = partialEligible
    ? roundToRupee(
        Math.min(
          total,
          Math.max(
            settings.partialMinAdvance,
            percentOf(total, settings.partialAdvancePercent),
          ),
        ),
      )
    : 0;

  // INVARIANT: paid + balance === total, always. Deriving balance by
  // subtraction rather than computing it independently is what guarantees it.
  const balanceAmount = partialEligible ? total - advanceAmount : 0;

  return {
    lines,
    itemCount,
    subtotal,
    productDiscount,
    couponDiscount,
    couponCode: couponDiscount > 0 || couponResult.freeShipping ? coupon?.code : undefined,
    couponError: couponResult.error,
    prepaidDiscount,
    shippingCharge,
    shippingIsFree: shippingCharge === 0,
    amountToFreeShipping,
    codFee,
    taxAmount,
    total,
    advanceAmount,
    balanceAmount,
    isPartial: partialEligible,
  };
}

/**
 * What the customer owes right now, versus later.
 * For a plain COD order the whole total is "later".
 */
export function paymentSplit(
  breakdown: PriceBreakdown,
  payment: PaymentChoice,
): { payNow: number; payLater: number } {
  if (payment === "COD") return { payNow: 0, payLater: breakdown.total };
  if (breakdown.isPartial) {
    return { payNow: breakdown.advanceAmount, payLater: breakdown.balanceAmount };
  }
  return { payNow: breakdown.total, payLater: 0 };
}
