import { ProductCard, type ProductCardData } from "@/components/product-card";
import { DEFAULT_SETTINGS } from "@/lib/settings";
import { formatINR } from "@/lib/money";

/**
 * Foundation preview — not the real homepage.
 *
 * The storefront needs a database and product photography, neither of which
 * exists yet. This page exercises the design tokens, the type pairing and the
 * product card against real numbers, so the visual direction can be approved
 * before twenty pages get built on top of it.
 */

const SAMPLE: ProductCardData[] = [
  {
    slug: "oxidised-jhumka-earrings",
    href: "/women/jewellery/oxidised-jhumka-earrings",
    name: "Oxidised Silver Jhumka Earrings with Pearl Drop",
    imageUrl: "/placeholders/earrings.svg",
    price: 49_900,
    mrp: 89_900,
    rating: 4.5,
    reviewCount: 23,
    isBestseller: true,
  },
  {
    slug: "quilted-sling-bag",
    href: "/women/bags/quilted-sling-bag",
    name: "Quilted Chain Sling Bag",
    imageUrl: "/placeholders/bag.svg",
    price: 89_900,
    mrp: 129_900,
    rating: 4.2,
    reviewCount: 8,
    isNew: true,
  },
  {
    slug: "minimal-mesh-watch",
    href: "/women/watches/minimal-mesh-watch",
    name: "Minimal Mesh Strap Analogue Watch",
    imageUrl: "/placeholders/watch.svg",
    price: 124_900,
    mrp: 249_900,
    rating: 4.7,
    reviewCount: 41,
  },
  {
    slug: "retro-square-sunglasses",
    href: "/unisex/sunglasses/retro-square-sunglasses",
    name: "Retro Square UV-Protected Sunglasses",
    imageUrl: "/placeholders/sunglass.svg",
    price: 39_900,
    mrp: 79_900,
    stockLeft: 2,
  },
  {
    slug: "temple-choker-set",
    href: "/women/jewellery/temple-choker-set",
    name: "Antique Temple Choker Necklace Set",
    imageUrl: "/placeholders/necklace.svg",
    price: 189_900,
    mrp: 299_900,
    rating: 4.8,
    reviewCount: 16,
    isExclusive: true,
  },
  {
    slug: "slim-leather-wallet",
    href: "/men/wallets/slim-leather-wallet",
    name: "Slim Bi-Fold Leather Wallet",
    imageUrl: "/placeholders/wallet.svg",
    price: 59_900,
    mrp: 99_900,
    rating: 4.1,
    reviewCount: 2,
    outOfStock: true,
  },
];

const PALETTE = [
  { name: "Canvas", value: "#FFFFFF", use: "Page ground" },
  { name: "Surface", value: "#FDF7F5", use: "Cards, sections" },
  { name: "Brand", value: "#D42A4C", use: "CTAs, badges, links" },
  { name: "Brand Deep", value: "#A81F3B", use: "Hover, pressed" },
  { name: "Blush", value: "#FBEAEE", use: "Tints, sale strips" },
  { name: "Gold", value: "#C9A227", use: "Premium accent, sparingly" },
  { name: "Ink", value: "#1A1418", use: "Primary text" },
  { name: "Ink Muted", value: "#6B5F63", use: "Secondary text" },
];

export default function FoundationPreview() {
  const s = DEFAULT_SETTINGS;

  return (
    <main className="mx-auto w-full max-w-6xl px-5 pb-24 pt-12 sm:px-8">
      {/* Masthead */}
      <header className="border-b border-line pb-8">
        <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-brand">
          Phase 1 · Foundation
        </p>
        <h1 className="mt-4 font-display text-4xl leading-[1.05] sm:text-5xl">
          AtoZacc
        </h1>
        <p className="mt-3 max-w-xl font-display text-lg italic text-ink-mid">
          Accessories from A to Z.
        </p>
        <p className="mt-5 max-w-2xl text-[14px] leading-relaxed text-ink-mid">
          Database schema, money handling, business-rule settings and the
          design system are in place. This page exists to get the visual
          direction approved before the storefront is built on it.
        </p>
      </header>

      {/* Palette */}
      <Section
        title="Palette"
        note="One accent colour, one gold highlight. The energy is meant to come from photography and space, not from more colours."
      >
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {PALETTE.map((c) => (
            <div
              key={c.name}
              className="overflow-hidden rounded-[var(--radius-card)] border border-line"
            >
              <div className="h-16 w-full" style={{ background: c.value }} />
              <div className="bg-canvas p-2.5">
                <p className="text-[12.5px] font-bold">{c.name}</p>
                <p className="tnum text-[11px] text-ink-mute">{c.value}</p>
                <p className="mt-0.5 text-[11px] text-ink-mute">{c.use}</p>
              </div>
            </div>
          ))}
        </div>
      </Section>

      {/* Type */}
      <Section
        title="Typography"
        note="Fraunces carries the premium half of the brand in headings; Manrope does the working text and every price."
      >
        <div className="space-y-5 rounded-[var(--radius-card)] border border-line bg-surface p-6">
          <div>
            <Label>Display · Fraunces</Label>
            <p className="font-display text-3xl">Festive Edit 2026</p>
          </div>
          <div>
            <Label>Heading · Fraunces</Label>
            <p className="font-display text-xl">Oxidised Jewellery</p>
          </div>
          <div>
            <Label>Body · Manrope</Label>
            <p className="max-w-[60ch] text-[14px] leading-relaxed text-ink-mid">
              Hand-finished oxidised silver jhumkas with a freshwater pearl
              drop. Lightweight enough for all-day wear, with a secure
              push-back clasp.
            </p>
          </div>
          <div>
            <Label>Price · Manrope, tabular</Label>
            <p className="tnum text-2xl font-bold">
              {formatINR(49_900)}{" "}
              <span className="text-base font-normal text-ink-mute line-through">
                {formatINR(89_900)}
              </span>{" "}
              <span className="text-base font-bold text-brand">44% off</span>
            </p>
          </div>
        </div>
      </Section>

      {/* Badges */}
      <Section
        title="Badges"
        note="A card shows at most one. Two badges saying nearly the same thing dilute both — which is why HOT was dropped as a duplicate of TRENDING."
      >
        <div className="flex flex-wrap gap-2">
          <span className="badge badge-new">New</span>
          <span className="badge badge-sale">44% Off</span>
          <span className="badge badge-bestseller">Bestseller</span>
          <span className="badge badge-exclusive">Exclusive</span>
          <span className="badge badge-limited">Only 2 left</span>
        </div>
      </Section>

      {/* Product cards */}
      <Section
        title="Product card"
        note="Square imagery, because the catalogue mixes earrings, bags, watches and wallets. Ratings appear only past three reviews — 5.0 from one review reads as fake."
      >
        <div className="grid grid-cols-2 gap-x-4 gap-y-8 sm:grid-cols-3 lg:grid-cols-4">
          {SAMPLE.map((p) => (
            <ProductCard key={p.slug} product={p} />
          ))}
        </div>
        <p className="mt-6 text-[12.5px] text-ink-mute">
          Placeholder art. Real product photography is the longest lead time in
          the project — see §2.1 of the requirements.
        </p>
      </Section>

      {/* Live business rules */}
      <Section
        title="Business rules, live"
        note="These are read from the settings store, not hard-coded in pricing logic. Every one is editable from the admin panel."
      >
        <div className="scroll-x rounded-[var(--radius-card)] border border-line">
          <table className="w-full text-[13.5px]">
            <tbody>
              <Rule
                label="Free shipping above"
                value={formatINR(s.freeShippingThreshold)}
                note="Set just above the ₹500 average order, to pull a second item into the basket"
              />
              <Rule
                label="Shipping below that"
                value={formatINR(s.standardShippingRate)}
              />
              <Rule
                label="COD fee"
                value={formatINR(s.codFee)}
                note="Set to zero in Settings to absorb it"
              />
              <Rule
                label="Prepaid discount"
                value={`− ${formatINR(s.prepaidDiscount)}`}
                note="The lever against COD return losses"
              />
              <Rule
                label="COD order range"
                value={`${formatINR(s.codMinOrderValue)} – ${formatINR(s.codMaxOrderValue)}`}
              />
              <Rule
                label="COD blocked after"
                value={`${s.codRefusalBlockThreshold} refused deliveries`}
              />
              <Rule
                label="Partial payment"
                value={s.partialPaymentEnabled ? "On" : "Built, switched off"}
                note={`Turns on above ${formatINR(s.partialMinOrderValue)}, taking ${s.partialAdvancePercent / 100}% as advance`}
              />
              <Rule
                label="Stock hold at checkout"
                value={`${s.stockReservationMinutes} minutes`}
              />
              <Rule label="Return window" value={`${s.returnWindowDays} days`} />
              <Rule
                label="GST"
                value={s.gstRegistered ? "Registered" : "Not registered — Bill of Supply"}
                note="Prices are tax-inclusive, so registering later changes no displayed price"
                last
              />
            </tbody>
          </table>
        </div>
      </Section>
    </main>
  );
}

function Section({
  title,
  note,
  children,
}: {
  title: string;
  note?: string;
  children: React.ReactNode;
}) {
  return (
    <section className="mt-14">
      <h2 className="border-t-2 border-ink pt-3 font-display text-2xl">
        {title}
      </h2>
      {note && (
        <p className="mb-6 mt-1.5 max-w-[68ch] text-[13.5px] text-ink-mute">
          {note}
        </p>
      )}
      {!note && <div className="mb-6" />}
      {children}
    </section>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return (
    <p className="mb-1 text-[10.5px] font-bold uppercase tracking-[0.12em] text-ink-mute">
      {children}
    </p>
  );
}

function Rule({
  label,
  value,
  note,
  last,
}: {
  label: string;
  value: string;
  note?: string;
  last?: boolean;
}) {
  return (
    <tr className={last ? "" : "border-b border-line"}>
      <td className="w-[40%] bg-surface px-4 py-3 align-top font-medium">
        {label}
      </td>
      <td className="px-4 py-3 align-top">
        <span className="tnum font-bold">{value}</span>
        {note && <p className="mt-0.5 text-[12px] text-ink-mute">{note}</p>}
      </td>
    </tr>
  );
}
