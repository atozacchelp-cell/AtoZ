/**
 * CSV parsing, shared by the file uploader and the Google Sheet sync.
 *
 * Hand-rolled rather than a dependency because the requirement is small and
 * exact: handle quoted fields, embedded commas, escaped quotes and CRLF.
 */

export function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let inQuotes = false;

  // Strip a UTF-8 BOM — Excel adds one, and it would corrupt the first header.
  const src = text.charCodeAt(0) === 0xfeff ? text.slice(1) : text;

  for (let i = 0; i < src.length; i++) {
    const ch = src[i];

    if (inQuotes) {
      if (ch === '"') {
        if (src[i + 1] === '"') {
          field += '"';
          i++;
        } else inQuotes = false;
      } else field += ch;
      continue;
    }

    if (ch === '"') inQuotes = true;
    else if (ch === ",") {
      row.push(field);
      field = "";
    } else if (ch === "\n") {
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
    } else if (ch !== "\r") field += ch;
  }

  if (field !== "" || row.length > 0) {
    row.push(field);
    rows.push(row);
  }

  return rows.filter((r) => r.some((c) => c.trim() !== ""));
}

/**
 * Turns rows into objects keyed by lower-cased header.
 * Headers are normalised so "Selling Price", "selling_price" and
 * "sellingprice" all resolve to the same key — people do not type headers
 * consistently, and rejecting a sheet over a space is needless friction.
 */
export function rowsToRecords(rows: string[][]): Record<string, string>[] {
  if (rows.length < 2) return [];

  const headers = rows[0].map(normaliseHeader);

  return rows.slice(1).map((row) => {
    const record: Record<string, string> = {};
    headers.forEach((h, i) => {
      if (h) record[h] = (row[i] ?? "").trim();
    });
    return record;
  });
}

export function normaliseHeader(raw: string): string {
  return raw.trim().toLowerCase().replace(/[\s_-]+/g, "");
}
