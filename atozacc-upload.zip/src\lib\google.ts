/**
 * Google Sheets and Drive plumbing.
 *
 * The whole point is that no API key, service account or OAuth is involved.
 * A sheet shared as "anyone with the link can view" can be exported as CSV
 * over plain HTTP, and a Drive file shared the same way has a direct image
 * URL. That keeps setup to two clicks for someone who is not technical.
 */

/* -------------------------------------------------------------------------
   Sheets
   ------------------------------------------------------------------------- */

export type SheetRef = { csvUrl: string; sheetId: string; gid: string };

/**
 * Accepts whatever the user pastes and works out the CSV export URL:
 *
 *   .../spreadsheets/d/{id}/edit#gid=123      → export?format=csv&gid=123
 *   .../spreadsheets/d/e/{pubId}/pubhtml      → .../pub?output=csv
 *   an already-direct CSV URL                 → used as-is
 *   a bare sheet id                           → export?format=csv
 */
export function resolveSheetUrl(input: string): SheetRef | null {
  const raw = input.trim();
  if (!raw) return null;

  // Already a CSV export link.
  if (/output=csv|format=csv/.test(raw)) {
    const id = raw.match(/\/d\/(?:e\/)?([a-zA-Z0-9-_]+)/)?.[1] ?? "";
    const gid = raw.match(/gid=([0-9]+)/)?.[1] ?? "0";
    return { csvUrl: raw, sheetId: id, gid };
  }

  // "Publish to web" links live under /d/e/{pubId}/ and need `pub?output=csv`.
  const published = raw.match(/\/spreadsheets\/d\/e\/([a-zA-Z0-9-_]+)/);
  if (published) {
    const gid = raw.match(/gid=([0-9]+)/)?.[1] ?? "0";
    return {
      csvUrl: `https://docs.google.com/spreadsheets/d/e/${published[1]}/pub?gid=${gid}&single=true&output=csv`,
      sheetId: published[1],
      gid,
    };
  }

  // Ordinary share link.
  const normal = raw.match(/\/spreadsheets\/d\/([a-zA-Z0-9-_]+)/);
  if (normal) {
    const gid = raw.match(/[#&?]gid=([0-9]+)/)?.[1] ?? "0";
    return {
      csvUrl: `https://docs.google.com/spreadsheets/d/${normal[1]}/export?format=csv&gid=${gid}`,
      sheetId: normal[1],
      gid,
    };
  }

  // A bare id.
  if (/^[a-zA-Z0-9-_]{20,}$/.test(raw)) {
    return {
      csvUrl: `https://docs.google.com/spreadsheets/d/${raw}/export?format=csv&gid=0`,
      sheetId: raw,
      gid: "0",
    };
  }

  return null;
}

export type FetchResult =
  | { ok: true; csv: string }
  | { ok: false; error: string };

export async function fetchSheetCsv(ref: SheetRef): Promise<FetchResult> {
  let response: Response;

  try {
    response = await fetch(ref.csvUrl, {
      redirect: "follow",
      // Always read the live sheet — a cached copy defeats the point of a
      // "sync now" button.
      cache: "no-store",
      headers: { "User-Agent": "AtoZacc-Sync" },
    });
  } catch (e) {
    return {
      ok: false,
      error: `Could not reach Google Sheets: ${e instanceof Error ? e.message : "network error"}`,
    };
  }

  // Google answers an unshared sheet with a sign-in page, not a 403, so a
  // 200 alone does not mean success — the content type has to be checked.
  const contentType = response.headers.get("content-type") ?? "";

  if (response.status === 401 || response.status === 403) {
    return { ok: false, error: SHARING_HELP };
  }
  if (response.status === 404) {
    return { ok: false, error: "That sheet does not exist. Check the link." };
  }
  if (!response.ok) {
    return { ok: false, error: `Google returned ${response.status}.` };
  }

  const body = await response.text();

  if (contentType.includes("text/html") || body.trimStart().startsWith("<")) {
    return { ok: false, error: SHARING_HELP };
  }
  if (!body.trim()) {
    return { ok: false, error: "That sheet (or tab) is empty." };
  }

  return { ok: true, csv: body };
}

const SHARING_HELP =
  'Google would not let us read that sheet. Open it, click Share, and set "General access" to "Anyone with the link" as Viewer — then try again.';

/* -------------------------------------------------------------------------
   Drive images
   ------------------------------------------------------------------------- */

const DRIVE_HOST = "https://lh3.googleusercontent.com/d/";

/**
 * Converts a Drive share link into a URL that actually serves the image.
 *
 *   drive.google.com/file/d/{id}/view?usp=sharing
 *   drive.google.com/open?id={id}
 *   drive.google.com/uc?export=view&id={id}
 *        → lh3.googleusercontent.com/d/{id}
 *
 * A plain /file/d/../view link renders Drive's HTML viewer, not the image,
 * so pasting one straight into a product would show a broken picture.
 * Anything that is not a Drive link is returned untouched.
 */
export function normaliseImageUrl(input: string): string {
  const url = input.trim();
  if (!url) return url;

  if (!url.includes("drive.google.com") && !url.includes("docs.google.com")) {
    return url;
  }

  const id =
    url.match(/\/file\/d\/([a-zA-Z0-9-_]+)/)?.[1] ??
    url.match(/[?&]id=([a-zA-Z0-9-_]+)/)?.[1] ??
    url.match(/\/d\/([a-zA-Z0-9-_]+)/)?.[1];

  if (!id) return url;

  // Ask Drive for a reasonably sized copy rather than the full original,
  // which for a phone photo can be several megabytes.
  return `${DRIVE_HOST}${id}=w1400`;
}

/** True when a URL will render as an image once normalised. */
export function looksLikeImageUrl(url: string): boolean {
  const u = url.trim();
  if (!u) return false;
  if (u.startsWith("/")) return true; // local file under /public
  return /^https?:\/\//i.test(u);
}
