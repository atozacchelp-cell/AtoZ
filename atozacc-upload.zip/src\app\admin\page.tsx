import Link from "next/link";

import { Card, EmptyRow, PageHeader, Pill, Stat, Table } from "@/components/admin-ui";
import { getAllProducts } from "@/lib/product-store";
import { formatINR } from "@/lib/money";
import { listOrders, ORDER_STATUS_LABELS } from "@/lib/orders";
import { getSettings } from "@/lib/settings";

export const metadata = { title: "Dashboard", robots: { index: false } };

export default async function AdminDashboard() {
  const [orders, settings] = await Promise.all([
    (listOrders()),
    getSettings(),
  ]);

  const today = new Date().toDateString();
  const todayOrders = orders.filter((o) => new Date(o.placedAt).toDateString() === today);

  const revenue = orders
    .filter((o) => o.status !== "CANCELLED")
    .reduce((s, o) => s + o.total, 0);
  const collected = orders.reduce((s, o) => s + o.paidAmount, 0);
  const outstanding = orders
    .filter((o) => o.status !== "CANCELLED")
    .reduce((s, o) => s + o.balanceAmount, 0);

  const pending = orders.filter((o) => o.status === "PENDING").length;
  const codOrders = orders.filter((o) => o.paymentMethod === "COD").length;

  const products = await getAllProducts();
  const outOfStock = products.filter((p) => p.stock <= 0);
  const lowStock = products.filter(
    (p) => p.stock > 0 && p.stock <= settings.lowStockThreshold,
  );

  return (
    <>
      <PageHeader
        title="Dashboard"
        subtitle={`${plural(orders.length, "order")} · ${plural(products.length, "product")}`}
      />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat
          label="Order value"
          value={formatINR(revenue)}
          sub={plural(orders.length, "order")}
        />
        <Stat
          label="Cash collected"
          value={formatINR(collected)}
          tone={collected > 0 ? "good" : "neutral"}
          sub="Money actually received"
        />
        <Stat
          label="Outstanding"
          value={formatINR(outstanding)}
          tone={outstanding > 0 ? "warn" : "neutral"}
          sub="Due on delivery"
          href="/admin/orders"
        />
        <Stat
          label="Today"
          value={String(todayOrders.length)}
          sub={formatINR(todayOrders.reduce((s, o) => s + o.total, 0))}
        />
      </div>

      {/* What needs doing, before what happened. An owner opening this at
          9am wants the queue, not the totals. */}
      <h2 className="mt-8 text-[11px] font-bold uppercase tracking-[0.11em] text-ink-mute">
        Needs attention
      </h2>
      <div className="mt-2 grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat
          label="Awaiting confirmation"
          value={String(pending)}
          tone={pending > 0 ? "bad" : "good"}
          sub="COD orders to verify"
          href="/admin/orders?status=PENDING"
        />
        <Stat
          label="Out of stock"
          value={String(outOfStock.length)}
          tone={outOfStock.length > 0 ? "bad" : "good"}
          href="/admin/inventory"
        />
        <Stat
          label="Low stock"
          value={String(lowStock.length)}
          tone={lowStock.length > 0 ? "warn" : "good"}
          sub={`At or below ${settings.lowStockThreshold}`}
          href="/admin/inventory"
        />
        <Stat label="COD orders" value={String(codOrders)} sub="Watch the RTO rate" />
      </div>

      <div className="mt-8 grid gap-5 lg:grid-cols-[minmax(0,1.6fr)_minmax(0,1fr)]">
        <section>
          <div className="mb-2 flex items-baseline justify-between">
            <h2 className="font-display text-lg">Recent orders</h2>
            <Link href="/admin/orders" className="text-[12.5px] font-semibold text-brand">
              View all
            </Link>
          </div>
          <Table head={["Order", "Customer", "Payment", "Status", "Total"]}>
            {orders.length === 0 ? (
              <EmptyRow colSpan={5}>
                No orders yet. Place a test order from the storefront to see it here.
              </EmptyRow>
            ) : (
              orders.slice(0, 8).map((o) => (
                <tr key={o.orderNumber} className="border-b border-line last:border-0">
                  <td className="px-3 py-2.5">
                    <Link
                      href={`/admin/orders/${o.orderNumber}`}
                      className="tnum font-semibold hover:text-brand"
                    >
                      {o.orderNumber}
                    </Link>
                  </td>
                  <td className="px-3 py-2.5">
                    <span className="block max-w-[140px] truncate">
                      {o.shippingAddress.name}
                    </span>
                    <span className="tnum text-[11.5px] text-ink-mute">
                      {o.shippingAddress.city}
                    </span>
                  </td>
                  <td className="px-3 py-2.5">
                    <Pill tone={o.paymentMethod === "COD" ? "warn" : "good"}>
                      {o.paymentMethod === "COD" ? "COD" : "Prepaid"}
                    </Pill>
                  </td>
                  <td className="px-3 py-2.5">
                    <Pill tone={o.status === "PENDING" ? "bad" : "neutral"}>
                      {ORDER_STATUS_LABELS[o.status]}
                    </Pill>
                  </td>
                  <td className="tnum px-3 py-2.5 font-semibold">{formatINR(o.total)}</td>
                </tr>
              ))
            )}
          </Table>
        </section>

        <section>
          <h2 className="mb-2 font-display text-lg">Stock alerts</h2>
          <Card>
            {outOfStock.length === 0 && lowStock.length === 0 ? (
              <p className="py-4 text-center text-[13px] text-ink-mute">
                Everything is in stock.
              </p>
            ) : (
              <ul className="space-y-2.5">
                {[...outOfStock, ...lowStock].slice(0, 8).map((p) => (
                  <li key={p.sku} className="flex items-center justify-between gap-3">
                    <span className="min-w-0 flex-1">
                      <span className="block truncate text-[12.5px] font-medium">
                        {p.name}
                      </span>
                      <span className="tnum text-[11px] text-ink-mute">{p.sku}</span>
                    </span>
                    <Pill tone={p.stock <= 0 ? "bad" : "warn"}>
                      {p.stock <= 0 ? "Out" : `${p.stock} left`}
                    </Pill>
                  </li>
                ))}
              </ul>
            )}
          </Card>

          <h2 className="mb-2 mt-6 font-display text-lg">Live rules</h2>
          <Card>
            <dl className="tnum space-y-1.5 text-[12.5px]">
              <Rule label="Free shipping above" value={formatINR(settings.freeShippingThreshold)} />
              <Rule label="Shipping rate" value={formatINR(settings.standardShippingRate)} />
              <Rule label="COD fee" value={formatINR(settings.codFee)} />
              <Rule label="Prepaid discount" value={formatINR(settings.prepaidDiscount)} />
              <Rule
                label="Online payment"
                value={settings.onlinePaymentEnabled ? "Live" : "Off"}
              />
              <Rule
                label="Partial payment"
                value={settings.partialPaymentEnabled ? "On" : "Off"}
              />
            </dl>
            <Link
              href="/admin/settings"
              className="mt-3 block text-[12.5px] font-semibold text-brand"
            >
              Change settings
            </Link>
          </Card>
        </section>
      </div>
    </>
  );
}

/** "1 order", not "1 orders". A dashboard is read constantly; the small
 *  wrongness gets noticed every single time. */
function plural(n: number, word: string): string {
  return `${n} ${word}${n === 1 ? "" : "s"}`;
}

function Rule({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between gap-3">
      <dt className="text-ink-mute">{label}</dt>
      <dd className="font-semibold">{value}</dd>
    </div>
  );
}
