import Image from "next/image";
import Link from "next/link";

import { WishlistHeart } from "@/components/wishlist-heart";
import { cn } from "@/lib/cn";
import { discountPercent, formatINR } from "@/lib/money";

/**
 * The most-repeated element in the store, so its rules matter more than any
 * single page's. From §14.4 and §23.3:
 *
 *   - ONE badge, maximum. Two badges saying nearly the same thing dilute both.
 *   - Discount shown only at 10% or more. "3% off" is not a reason to buy.
 *   - Rating shown only with 3+ reviews. "5.0 (1)" reads as fake and costs
 *     more trust than showing nothing.
 *   - 1:1 image. The catalogue mixes earrings, bags, watches and scarves —
 *     square is the only ratio that flatters all of them.
 */

export type ProductCardData = {
  slug: string;
  href: string;
  name: string;
  imageUrl: string;
  /** Paise. */
  price: number;
  /** Paise. Struck through when higher than price. */
  mrp: number;
  rating?: number;
  reviewCount?: number;
  outOfStock?: boolean;
  /** Remaining units, only shown when genuinely low. */
  stockLeft?: number;
  isNew?: boolean;
  isBestseller?: boolean;
  isExclusive?: boolean;
  /** Free-text badge from the sheet, e.g. "FESTIVE 20% OFF". */
  badgeText?: string;
};

/**
 * Picks the single badge to show, in priority order. Returning one value
 * rather than a list is what enforces the one-badge rule at the type level —
 * a caller cannot accidentally render three.
 */
function pickBadge(p: ProductCardData): { label: string; className: string } | null {
  // A badge typed into the sheet wins — if the shop has written "FESTIVE
  // SPECIAL" against a product, that is a deliberate merchandising decision
  // and it should beat anything computed here.
  if (p.badgeText?.trim()) {
    return { label: p.badgeText.trim(), className: "badge-sale" };
  }

  // Deliberately no automatic "% OFF" badge. The discount already sits next to
  // the price on every card, so a sale badge would print the same number twice
  // — the exact duplication the one-badge rule exists to prevent. The badge
  // slot is reserved for what the price row CANNOT say.
  if (p.isExclusive) return { label: "Exclusive", className: "badge-exclusive" };
  if (p.stockLeft !== undefined && p.stockLeft > 0 && p.stockLeft <= 3) {
    // Scarcity outranks status: it is the only one of these that is
    // time-sensitive, and it converts.
    return { label: `Only ${p.stockLeft} left`, className: "badge-limited" };
  }
  if (p.isBestseller) return { label: "Bestseller", className: "badge-bestseller" };
  if (p.isNew) return { label: "New", className: "badge-new" };
  return null;
}

export function ProductCard({
  product,
  prepaidDiscount = 0,
}: {
  product: ProductCardData;
  /**
   * Paise saved by paying online, from settings. Shown on the card rather
   * than saved for checkout: cash on delivery is what costs this shop money
   * — a refused parcel loses the shipping both ways — and the customer picks
   * their payment method in their head long before they reach the payment
   * page. Snapdeal and Meesho both put this on the tile for the same reason.
   */
  prepaidDiscount?: number;
}) {
  const discount = discountPercent(product.mrp, product.price);
  const badge = pickBadge(product);
  const showRating =
    product.rating !== undefined &&
    product.reviewCount !== undefined &&
    product.reviewCount >= 3;
  const showPrepaid = prepaidDiscount > 0 && !product.outOfStock;

  return (
    <article className="group relative">
      {/* The heart sits outside the link on purpose: a button nested inside an
          anchor is invalid HTML, and browsers resolve it by letting the
          navigation win — which is exactly the bug where tapping save opens
          the product instead. */}
      <WishlistHeart slug={product.slug} />

      <Link href={product.href} className="block">
        {/* Image. Fixed 1:1 box with explicit dimensions so nothing shifts
            as images stream in — CLS is a ranking factor and a mobile
            annoyance. */}
        <div className="relative aspect-square overflow-hidden rounded-[var(--radius-card)] bg-surface">
          <Image
            src={product.imageUrl}
            alt={product.name}
            fill
            sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 25vw"
            className={cn(
              "object-cover transition-transform duration-500 ease-[cubic-bezier(0.22,1,0.36,1)]",
              "group-hover:scale-[1.04]",
              product.outOfStock && "opacity-55",
            )}
          />

          {badge && !product.outOfStock && (
            <span className={cn("badge absolute left-2 top-2", badge.className)}>
              {badge.label}
            </span>
          )}

          {product.outOfStock && (
            <div className="absolute inset-x-0 bottom-0 bg-ink/85 py-1.5 text-center text-[11px] font-semibold uppercase tracking-[0.1em] text-white">
              Out of stock
            </div>
          )}
        </div>

        {/* Detail */}
        <div className="pt-3">
          <h3 className="line-clamp-2 font-sans text-[13.5px] font-medium leading-snug text-ink-mid">
            {product.name}
          </h3>

          <div className="tnum mt-1.5 flex items-baseline gap-2">
            <span className="text-[15px] font-bold text-ink">
              {formatINR(product.price)}
            </span>

            {discount > 0 && (
              <>
                <span className="text-[12.5px] text-ink-mute line-through">
                  {formatINR(product.mrp)}
                </span>
                {discount >= 10 && (
                  <span className="rounded-[3px] bg-blush px-1.5 py-[1px] text-[12px] font-bold text-brand-deep">
                    {discount}% off
                  </span>
                )}
              </>
            )}
          </div>

          {showPrepaid && (
            <p className="tnum mt-1 text-[11.5px] font-semibold text-success">
              {formatINR(prepaidDiscount)} off on UPI
            </p>
          )}

          {showRating && (
            <div className="tnum mt-1 flex items-center gap-1 text-[12px] text-ink-mute">
              <span aria-hidden className="text-gold">
                ★
              </span>
              <span className="font-medium text-ink-mid">
                {product.rating!.toFixed(1)}
              </span>
              <span>({product.reviewCount})</span>
            </div>
          )}
        </div>
      </Link>
    </article>
  );
}
