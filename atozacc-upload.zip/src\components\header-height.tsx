"use client";

import { useEffect } from "react";

/**
 * Publishes the sticky header's height as `--header-h` on the document root.
 *
 * Anything else that wants to stick below the header needs that number, and it
 * is not a constant: the announcement strip wraps to two lines on a narrow
 * phone, the search row only exists at some breakpoints, and the logo height
 * is an admin setting the owner can change at any time. A hard-coded offset
 * would be correct on exactly one device and silently wrong everywhere else —
 * either overlapping the header or leaving a gap under it.
 */
export function HeaderHeightVar({ selector = "header" }: { selector?: string }) {
  useEffect(() => {
    const el = document.querySelector(selector);
    if (!el) return;

    const publish = () => {
      document.documentElement.style.setProperty(
        "--header-h",
        `${Math.round(el.getBoundingClientRect().height)}px`,
      );
    };

    publish();

    // Fonts loading, the logo image arriving and rotation all change the
    // height after first paint, so one measurement is not enough.
    const ro = new ResizeObserver(publish);
    ro.observe(el);
    return () => ro.disconnect();
  }, [selector]);

  return null;
}
