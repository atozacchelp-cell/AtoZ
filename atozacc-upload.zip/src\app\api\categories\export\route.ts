import { allCategories } from "@/lib/taxonomy";

/**
 * Every valid category code, as a reference tab for the sheet. The `category`
 * column of the Products tab must contain one of these codes.
 */

function cell(value: string): string {
  return /[",\n]/.test(value) ? `"${value.replace(/"/g, '""')}"` : value;
}

export async function GET() {
  const byName = new Map(allCategories().map((c) => [c.slug, c.name]));

  const rows = [
    "category_code,gender,name,sits_under",
    ...allCategories().map((c) =>
      [
        c.slug,
        c.gender,
        c.name,
        c.parent ? (byName.get(c.parent) ?? c.parent) : "",
      ]
        .map(cell)
        .join(","),
    ),
  ].join("\n");

  return new Response(rows, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": 'attachment; filename="3-Category-codes.csv"',
    },
  });
}
