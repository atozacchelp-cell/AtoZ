import { requireAdmin } from "@/lib/session";
import { toRupees } from "@/lib/money";
import { getAllProducts } from "@/lib/product-store";
import { formatSizeChart, formatStockCell } from "@/lib/sizes";

/**
 * Exports the catalogue as CSV, in exactly the shape the importer accepts —
 * so export, edit in a spreadsheet, re-import is a working round trip.
 */

/**
 * Every column the importer understands, so export → edit → re-import is
 * lossless. A column missing here would silently blank that field on the
 * next sync.
 */
const HEADERS = [
  "sku", "slug", "name", "category", "mrp", "price", "costprice", "stock", "weight",
  "image", "image2", "image3", "image4", "image5",
  "shortdescription", "description", "colours", "sizes", "sizechart", "material",
  "features", "care", "collections", "badge",
  "new", "trending", "bestseller", "exclusive", "returnable", "cod",
  "supplier", "fulfilment", "dispatchdays",
] as const;

const yesNo = (v: boolean | undefined) => (v ? "yes" : "no");

/** Quotes a field only when it needs it, so the file stays readable. */
function cell(value: string | number | undefined): string {
  const s = value === undefined || value === null ? "" : String(value);
  return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
}

export async function GET() {
  // Customer data and cost prices. Admin only.
  const denied = await requireAdmin();
  if (denied) return denied;

  const products = await getAllProducts();

  const rows = [
    HEADERS.join(","),
    ...products.map((p) =>
      [
        p.sku,
        p.slug,
        p.name,
        p.category,
        toRupees(p.mrp),
        toRupees(p.price),
        p.costPrice ? toRupees(p.costPrice) : "",
        formatStockCell(p),
        p.weightG,
        p.image,
        ...[0, 1, 2, 3].map((i) => (p.extraImages ?? [])[i] ?? ""),
        p.shortDescription,
        p.description,
        (p.colours ?? []).join(", "),
        (p.sizes ?? []).join(", "),
        formatSizeChart(p.sizeChart),
        p.material ?? "",
        (p.features ?? []).join(", "),
        p.care ?? "",
        (p.collections ?? []).join(", "),
        p.badgeText ?? "",
        yesNo(p.isNew),
        yesNo(p.isTrending),
        yesNo(p.isBestseller),
        yesNo(p.isExclusive),
        p.isReturnable === false ? "no" : "yes",
        p.isCodAllowed === false ? "no" : "yes",
        p.supplier ?? "",
        p.fulfilment ?? "self",
        p.dispatchDays ?? "",
      ]
        .map(cell)
        .join(","),
    ),
  ].join("\n");

  const date = new Date().toISOString().slice(0, 10);

  return new Response(rows, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": `attachment; filename="atozacc-products-${date}.csv"`,
    },
  });
}
