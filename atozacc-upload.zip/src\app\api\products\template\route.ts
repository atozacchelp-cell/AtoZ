/**
 * A starter CSV with the right headings and two worked example rows, so the
 * first import is a matter of replacing rows rather than guessing a format.
 */
export async function GET() {
  const csv = [
    "sku,name,category,mrp,price,costprice,stock,weight,image,shortdescription,description,colours,sizes,sizechart,material,collections,returnable,cod",
    ',Oxidised Jhumka Earrings,women-earrings,899,499,160,24,30,,"Hand-finished oxidised jhumkas","A classic jhumka in oxidised silver finish.","Oxidised Silver",,,Brass,traditional,no,yes',
    ',Slim Leather Wallet,men-wallets,999,599,210,15,110,,"Genuine leather, slim enough for a front pocket","Six card slots and two note compartments.","Black, Brown",,,Genuine leather,,yes,yes',
    // A garment, showing the two things clothing needs that an accessory does
    // not: stock counted per size, and a measurements table.
    ',Cotton Oversized T-Shirt,men-tshirts,899,499,230,"S:4, M:9, L:6, XL:2, XXL:0",180,,"Heavy 240 GSM combed cotton, drop shoulder","Pre-shrunk, bio-washed, holds its shape after twenty washes.","Black, White","S, M, L, XL, XXL","Size,Chest (in),Length (in)|S,38,27|M,40,28|L,42,29|XL,44,30|XXL,46,31","100% cotton",,yes,yes',
  ].join("\n");

  return new Response(csv, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": 'attachment; filename="atozacc-product-template.csv"',
    },
  });
}
