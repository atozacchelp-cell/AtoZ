import { fs as fsp } from "@/lib/data-fs";
import path from "node:path";

import { getDb, isDatabaseConfigured } from "@/lib/db";
import { fileMtime } from "@/lib/data-fs";

const OVERRIDES_PATH = path.join(process.cwd(), "data", "settings.json");

/**
 * Business rules, as data.
 *
 * Every number the owner might reasonably want to change lives here and is
 * overridable from the admin panel — the COD fee, the prepaid discount, the
 * free-shipping threshold, the partial-payment rules. None of them are
 * hard-coded into pricing logic, because "change the COD fee" must never
 * mean "call your developer".
 *
 * The defaults below are the decisions recorded in
 * docs/SYSTEM-REQUIREMENTS.md §3. They are what the store runs on until a
 * row exists in the Setting table.
 */

export type Settings = {
  // --- Store identity ----------------------------------------------------
  storeName: string;
  supportEmail: string;
  supportPhone: string;
  whatsappNumber: string;
  supportHours: string;

  // --- Tax ---------------------------------------------------------------
  /** False until GST registration. Invoices are Bills of Supply meanwhile. */
  gstRegistered: boolean;
  gstin: string | null;
  /** Prices are tax-inclusive. Registering later must not change any price. */
  pricesIncludeTax: boolean;

  // --- Payment -----------------------------------------------------------
  /**
   * How online money is taken.
   *   "upi"  — your own QR / UPI ID, verified by you by hand
   *   "off"  — cash on delivery only
   * A gateway can be added later without changing anything else.
   */
  onlinePaymentMode: "upi" | "off";
  /** Your UPI ID, e.g. name@okhdfcbank. Used to build the payment QR. */
  upiId: string;
  /** Name shown in the customer’s UPI app when they scan. */
  upiPayeeName: string;
  /** Optional image of your own printed QR, shown as a fallback. */
  upiQrImageUrl: string;
  onlinePaymentEnabled: boolean;
  /** Instant discount for paying online. Paise. The lever against RTO. */
  prepaidDiscount: number;
  prepaidDiscountEnabled: boolean;

  // --- Cash on Delivery --------------------------------------------------
  codEnabled: boolean;
  /** Flat fee added to COD orders. Paise. Set to 0 to absorb it. */
  codFee: number;
  codMinOrderValue: number;
  codMaxOrderValue: number;
  /** OTP verification before a COD order is confirmed. */
  codOtpRequired: boolean;
  /** Unverified COD orders auto-cancel after this many hours. */
  codVerifyWindowHours: number;
  /** Customers with this many refused deliveries lose COD. */
  codRefusalBlockThreshold: number;

  // --- Shipping ----------------------------------------------------------
  /** Free above this cart subtotal. Paise. Set just above AOV on purpose. */
  freeShippingThreshold: number;
  /** Charged when below the threshold. Paise. */
  standardShippingRate: number;
  /** Free shipping applies to COD too, but the COD fee still stands. */
  freeShippingAppliesToCod: boolean;

  // --- Partial / advance payment ----------------------------------------
  /**
   * Built, but off at launch: on a ₹500 order, paying ₹200 now and ₹300 on
   * delivery is more friction than either full prepaid or plain COD.
   * It earns its place on hampers and sets above ₹1,500.
   */
  partialPaymentEnabled: boolean;
  /** Basis points of order value taken as advance. 2500 = 25%. */
  partialAdvancePercent: number;
  /** Floor on the advance, whatever the percentage works out to. Paise. */
  partialMinAdvance: number;
  /** Only offered above this order value. Paise. */
  partialMinOrderValue: number;
  /** Days before an unpaid balance auto-cancels the order. */
  partialBalanceWindowDays: number;

  // --- Inventory ---------------------------------------------------------
  /** Overridable per product. */
  lowStockThreshold: number;
  /** Minutes a checkout holds stock before the reservation is released. */
  stockReservationMinutes: number;

  // --- Returns -----------------------------------------------------------
  returnsEnabled: boolean;
  returnWindowDays: number;
  /** Shipping is refunded only when the return is our fault. */
  refundShippingOnOurFault: boolean;
  refundWindowDays: number;

  // --- Orders ------------------------------------------------------------
  /** ATZ-2026-0001 */
  orderNumberPrefix: string;
};

export const DEFAULT_SETTINGS: Settings = {
  storeName: "AtoZacc",
  supportEmail: "ujjwalakki9633@gmail.com",
  supportPhone: "8447920965",
  whatsappNumber: "8447920965",
  supportHours: "Mon–Sat, 10am–7pm",

  gstRegistered: false,
  gstin: null,
  pricesIncludeTax: true,

  // Your own UPI QR, verified by you. No gateway, no KYC wait.
  onlinePaymentMode: "upi",
  upiId: "",
  upiPayeeName: "AtoZacc",
  upiQrImageUrl: "",
  onlinePaymentEnabled: true,
  prepaidDiscount: 2_500, // ₹25
  prepaidDiscountEnabled: true,

  codEnabled: true,
  codFee: 4_000, // ₹40
  codMinOrderValue: 19_900, // ₹199
  codMaxOrderValue: 300_000, // ₹3,000
  codOtpRequired: true,
  codVerifyWindowHours: 24,
  codRefusalBlockThreshold: 2,

  freeShippingThreshold: 69_900, // ₹699
  standardShippingRate: 5_900, // ₹59
  freeShippingAppliesToCod: true,

  partialPaymentEnabled: false,
  partialAdvancePercent: 2_500, // 25%
  partialMinAdvance: 20_000, // ₹200
  partialMinOrderValue: 150_000, // ₹1,500
  partialBalanceWindowDays: 3,

  lowStockThreshold: 5,
  stockReservationMinutes: 15,

  returnsEnabled: true,
  returnWindowDays: 7,
  refundShippingOnOurFault: true,
  refundWindowDays: 7,

  orderNumberPrefix: "ATZ",
};

/**
 * Settings change rarely and are read on nearly every request, so they are
 * cached per process. `revalidateSettings()` clears it after an admin edit.
 */
let cache: { value: Settings; at: number; mtime: number } | null = null;
const CACHE_TTL_MS = 60_000;

export async function getSettings(): Promise<Settings> {
  const mtime = fileMtime(OVERRIDES_PATH);
  if (cache && cache.mtime === mtime && Date.now() - cache.at < CACHE_TTL_MS) {
    return cache.value;
  }

  // No database yet: defaults, plus whatever has been saved from admin.
  // The file is the same shape the Setting table will hold, so moving to
  // Postgres later changes where these come from and nothing else.
  if (!isDatabaseConfigured()) {
    const merged = { ...DEFAULT_SETTINGS, ...(await readOverrides()) };
    cache = { value: merged, at: Date.now(), mtime };
    return merged;
  }

  let merged: Settings = { ...DEFAULT_SETTINGS };

  try {
    const db = await getDb();
    if (!db) return { ...DEFAULT_SETTINGS };
    const rows = await (db as unknown as { setting: { findMany(): Promise<{ key: string; value: unknown }[]> } }).setting.findMany();
    for (const row of rows) {
      if (row.key in DEFAULT_SETTINGS) {
        // Stored as JSON so booleans and numbers survive the round trip.
        (merged as Record<string, unknown>)[row.key] = row.value;
      }
    }
  } catch {
    // No database yet, or the table is not migrated. Defaults are a complete,
    // working configuration — the store must not fall over because an
    // optional override table is missing.
    return { ...DEFAULT_SETTINGS };
  }

  cache = { value: merged, at: Date.now(), mtime };
  return merged;
}

async function readOverrides(): Promise<Partial<Settings>> {
  try {
    return JSON.parse(await fsp.readFile(OVERRIDES_PATH, "utf8")) as Partial<Settings>;
  } catch {
    return {};
  }
}

/** Persists changed settings. Only keys that exist in Settings are written. */
export async function saveSettings(partial: Partial<Settings>): Promise<void> {
  const current = await readOverrides();
  const next: Record<string, unknown> = { ...current };

  for (const [k, v] of Object.entries(partial)) {
    if (k in DEFAULT_SETTINGS) next[k] = v;
  }

  await fsp.mkdir(path.dirname(OVERRIDES_PATH), { recursive: true });
  await fsp.writeFile(OVERRIDES_PATH, JSON.stringify(next, null, 2), "utf8");
  cache = null;
}

/** Reads one setting. Convenience for call sites that need a single value. */
export async function getSetting<K extends keyof Settings>(
  key: K,
): Promise<Settings[K]> {
  const all = await getSettings();
  return all[key];
}

export function revalidateSettings(): void {
  cache = null;
}
