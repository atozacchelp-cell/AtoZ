import Link from "next/link";

import { Breadcrumbs, Container } from "@/components/ui";
import { getSettings } from "@/lib/settings";

export const metadata = {
  title: "Contact Us",
  description: "Get in touch with AtoZacc about an order, a return or a product question.",
};

export default async function ContactPage() {
  const settings = await getSettings();
  const waNumber = settings.whatsappNumber.replace(/\D/g, "");

  return (
    <Container className="max-w-3xl py-8">
      <Breadcrumbs items={[{ label: "Contact Us" }]} />

      <h1 className="font-display text-[30px] leading-tight sm:text-[36px]">Contact us</h1>
      <p className="mt-2 max-w-prose text-[14px] text-ink-mid">
        Have your order number ready if your question is about an order — it
        gets you an answer in one message instead of three.
      </p>

      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        <a
          href={`https://wa.me/91${waNumber}`}
          target="_blank"
          rel="noopener noreferrer"
          className="rounded-[var(--radius-card)] border border-line bg-surface p-5 transition-colors hover:border-brand"
        >
          <p className="text-[11px] font-bold uppercase tracking-[0.11em] text-ink-mute">
            WhatsApp
          </p>
          <p className="tnum mt-1 font-display text-xl">{settings.whatsappNumber}</p>
          <p className="mt-1 text-[12.5px] text-ink-mute">Usually the fastest reply</p>
        </a>

        <a
          href={`mailto:${settings.supportEmail}`}
          className="rounded-[var(--radius-card)] border border-line bg-surface p-5 transition-colors hover:border-brand"
        >
          <p className="text-[11px] font-bold uppercase tracking-[0.11em] text-ink-mute">
            Email
          </p>
          <p className="mt-1 break-all font-display text-xl">{settings.supportEmail}</p>
          <p className="mt-1 text-[12.5px] text-ink-mute">We reply within one working day</p>
        </a>

        <a
          href={`tel:${settings.supportPhone}`}
          className="rounded-[var(--radius-card)] border border-line bg-surface p-5 transition-colors hover:border-brand"
        >
          <p className="text-[11px] font-bold uppercase tracking-[0.11em] text-ink-mute">
            Phone
          </p>
          <p className="tnum mt-1 font-display text-xl">{settings.supportPhone}</p>
          <p className="mt-1 text-[12.5px] text-ink-mute">{settings.supportHours}</p>
        </a>

        <div className="rounded-[var(--radius-card)] border border-line bg-surface p-5">
          <p className="text-[11px] font-bold uppercase tracking-[0.11em] text-ink-mute">
            Track an order
          </p>
          <p className="mt-1 font-display text-xl">
            <Link href="/track-order" className="hover:text-brand">
              Track Order page
            </Link>
          </p>
          <p className="mt-1 text-[12.5px] text-ink-mute">
            Instant status with your order number
          </p>
        </div>
      </div>

      <section className="mt-10">
        <h2 className="font-display text-xl">Send us a message</h2>
        <form className="mt-4 grid gap-4 sm:grid-cols-2">
          <Field label="Your name" name="name" required />
          <Field label="Mobile number" name="mobile" inputMode="numeric" maxLength={10} required />
          <div className="sm:col-span-2">
            <Field label="Order number" name="order" placeholder="ATZ-2026-0001" />
          </div>
          <div className="sm:col-span-2">
            <label className="block">
              <span className="text-[12px] font-bold uppercase tracking-[0.09em] text-ink-mute">
                Message <span className="text-brand">*</span>
              </span>
              <textarea
                name="message"
                rows={5}
                required
                className="mt-1 w-full rounded-[var(--radius-card)] border border-line bg-surface px-3 py-2.5 text-[13.5px] focus:border-brand focus:bg-canvas focus:outline-none"
              />
            </label>
          </div>
          <div className="sm:col-span-2">
            <button
              type="submit"
              className="rounded-[var(--radius-card)] bg-brand px-6 py-3 text-[14px] font-semibold text-white transition-colors hover:bg-brand-deep"
            >
              Send message
            </button>
            {/* Stated rather than silently doing nothing: the form has no
                backend until the email provider is connected. */}
            <p className="mt-2 text-[12px] text-ink-mute">
              This form is not connected yet — please use WhatsApp or email for
              now, they reach us immediately.
            </p>
          </div>
        </form>
      </section>

      <section className="mt-10 border-t border-line pt-6">
        <h2 className="text-[11px] font-bold uppercase tracking-[0.11em] text-ink-mute">
          Registered address
        </h2>
        <address className="mt-2 text-[13.5px] not-italic leading-relaxed text-ink-mid">
          AtoZacc
          <br />
          Ansal Tower-38, 1324, Nehru Place
          <br />
          Delhi
        </address>
      </section>
    </Container>
  );
}

function Field({
  label,
  name,
  required,
  ...rest
}: { label: string; name: string; required?: boolean } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="block">
      <span className="text-[12px] font-bold uppercase tracking-[0.09em] text-ink-mute">
        {label} {required && <span className="text-brand">*</span>}
      </span>
      <input
        name={name}
        required={required}
        className="mt-1 w-full rounded-[var(--radius-card)] border border-line bg-surface px-3 py-2.5 text-[13.5px] focus:border-brand focus:bg-canvas focus:outline-none"
        {...rest}
      />
    </label>
  );
}
