import { promises as fs } from "node:fs";
import path from "node:path";

/**
 * Where the shop's data actually lives.
 *
 * Every store in this app kept its state in `data/*.json`, which works on a
 * laptop and fails completely on Netlify: a deployed function's filesystem is
 * read-only, and the one writable directory is wiped between invocations. The
 * shop would have browsed perfectly and lost every order.
 *
 * So the file path is no longer the interface — this is. Locally it is still
 * a JSON file, which keeps development inspectable with a text editor. On
 * Netlify it is Netlify Blobs, which persists across deploys and instances.
 *
 * Both backends are async, deliberately. A synchronous read is impossible
 * against a network store, and pretending otherwise would have meant a second
 * code path that only breaks in production.
 */

const DATA_DIR = path.join(process.cwd(), "data");

/** True when running inside a Netlify build or function. */
function onNetlify(): boolean {
  return process.env.NETLIFY === "true" || Boolean(process.env.NETLIFY_BLOBS_CONTEXT);
}

/* -------------------------------------------------------------------------
   Netlify Blobs
   ------------------------------------------------------------------------- */

type BlobStore = {
  get(key: string, opts?: { type: "json" }): Promise<unknown>;
  setJSON(key: string, value: unknown): Promise<unknown>;
};

let blobStore: BlobStore | null = null;
let blobStoreFailed = false;

async function getBlobStore(): Promise<BlobStore | null> {
  if (blobStore) return blobStore;
  if (blobStoreFailed) return null;

  try {
    // Imported lazily so a local `next dev` never loads it, and so a missing
    // Netlify context degrades to the file backend instead of crashing the
    // whole render.
    const { getStore } = await import("@netlify/blobs");
    blobStore = getStore({ name: "atozacc", consistency: "strong" }) as BlobStore;
    return blobStore;
  } catch {
    blobStoreFailed = true;
    return null;
  }
}

/* -------------------------------------------------------------------------
   The interface every store uses
   ------------------------------------------------------------------------- */

/**
 * Reads a stored value, or `fallback` when it has never been written.
 *
 * Never throws. A store that cannot be read must leave the shop browsable —
 * the alternative is one corrupted file taking the whole site down.
 */
export async function readJson<T>(key: string, fallback: T): Promise<T> {
  if (onNetlify()) {
    const store = await getBlobStore();
    if (store) {
      try {
        const value = await store.get(key, { type: "json" });
        return (value as T) ?? fallback;
      } catch {
        return fallback;
      }
    }
  }

  try {
    const raw = await fs.readFile(path.join(DATA_DIR, `${key}.json`), "utf8");
    return JSON.parse(raw) as T;
  } catch {
    return fallback;
  }
}

/**
 * Writes a stored value.
 *
 * Throws on failure rather than swallowing it: a lost order must surface as a
 * failed checkout the customer can retry, not a success message over a write
 * that silently went nowhere.
 */
export async function writeJson(key: string, value: unknown): Promise<void> {
  if (onNetlify()) {
    const store = await getBlobStore();
    if (store) {
      await store.setJSON(key, value);
      return;
    }
    throw new Error(
      `Cannot save "${key}": running on Netlify but the Blobs store is unavailable.`,
    );
  }

  await fs.mkdir(DATA_DIR, { recursive: true });
  await fs.writeFile(
    path.join(DATA_DIR, `${key}.json`),
    JSON.stringify(value, null, 2),
    "utf8",
  );
}

/**
 * A short in-memory cache in front of the store.
 *
 * The mtime check the file stores used cannot work against a network store,
 * and re-fetching the catalogue for every component on a page would be
 * absurd. A few seconds is long enough to collapse one page render into one
 * fetch, and short enough that a sheet sync shows up almost immediately.
 */
const TTL_MS = onNetlify() ? 5_000 : 0; // locally, always read through
const memo = new Map<string, { at: number; value: unknown }>();

export async function readCached<T>(key: string, fallback: T): Promise<T> {
  const hit = memo.get(key);
  if (hit && Date.now() - hit.at < TTL_MS) return hit.value as T;

  const value = await readJson<T>(key, fallback);
  memo.set(key, { at: Date.now(), value });
  return value;
}

/** Drops the cache for a key, so a write is visible to the next read. */
export function invalidate(key: string): void {
  memo.delete(key);
}

export async function writeAndInvalidate(key: string, value: unknown): Promise<void> {
  await writeJson(key, value);
  invalidate(key);
}

export { onNetlify };
