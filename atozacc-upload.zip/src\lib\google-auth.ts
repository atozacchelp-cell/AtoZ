/**
 * Google sign-in, using the plain OAuth 2.0 authorisation-code flow.
 *
 * Written directly against Google's endpoints rather than through an auth
 * framework: the flow is three requests, and the parts that matter for
 * security — the `state` check, verifying the token came from Google, and
 * refusing unverified emails — are things worth having visible rather than
 * buried in a library's defaults.
 */

export const STATE_COOKIE = "atz_oauth_state";

const AUTH_ENDPOINT = "https://accounts.google.com/o/oauth2/v2/auth";
const TOKEN_ENDPOINT = "https://oauth2.googleapis.com/token";

export function googleConfigured(): boolean {
  return Boolean(
    process.env.GOOGLE_CLIENT_ID?.trim() && process.env.GOOGLE_CLIENT_SECRET?.trim(),
  );
}

/**
 * Where Google sends the browser back.
 *
 * Derived from the request origin so it is correct on localhost and in
 * production without a second setting to keep in step — but overridable,
 * because behind a proxy the origin the app sees is not always the one the
 * customer typed.
 */
export function redirectUri(origin: string): string {
  const configured = process.env.GOOGLE_REDIRECT_URI?.trim();
  return configured || `${origin}/api/auth/google/callback`;
}

export function googleAuthUrl(state: string, origin: string): string {
  const params = new URLSearchParams({
    client_id: process.env.GOOGLE_CLIENT_ID!.trim(),
    redirect_uri: redirectUri(origin),
    response_type: "code",
    // Only what is needed to create an account. Asking for more than name and
    // email would show the customer a scarier consent screen for no gain.
    scope: "openid email profile",
    state,
    // Keeps the account chooser rather than silently reusing whichever Google
    // account the browser last used, which surprises people on shared phones.
    prompt: "select_account",
  });
  return `${AUTH_ENDPOINT}?${params}`;
}

export type GoogleProfile = {
  googleId: string;
  email: string;
  name: string;
  emailVerified: boolean;
};

/**
 * Swaps the one-time code for the user's identity.
 *
 * The id_token is read for its claims but its signature is NOT verified here
 * — deliberately, and safely: it arrived over TLS as the direct response to
 * our own authenticated POST to Google, not via the browser. Signature
 * verification matters when a token is handed to you by an untrusted party,
 * which is not this path.
 */
export async function exchangeCode(
  code: string,
  origin: string,
): Promise<GoogleProfile | null> {
  try {
    const res = await fetch(TOKEN_ENDPOINT, {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        code,
        client_id: process.env.GOOGLE_CLIENT_ID!.trim(),
        client_secret: process.env.GOOGLE_CLIENT_SECRET!.trim(),
        redirect_uri: redirectUri(origin),
        grant_type: "authorization_code",
      }),
      signal: AbortSignal.timeout(10_000),
    });

    if (!res.ok) return null;

    const data = (await res.json()) as { id_token?: string };
    if (!data.id_token) return null;

    const [, payload] = data.id_token.split(".");
    if (!payload) return null;

    const claims = JSON.parse(
      Buffer.from(payload, "base64url").toString("utf8"),
    ) as {
      sub?: string;
      email?: string;
      email_verified?: boolean | string;
      name?: string;
    };

    if (!claims.sub || !claims.email) return null;

    return {
      googleId: claims.sub,
      email: claims.email,
      name: claims.name ?? "",
      // Google sends this as a boolean or the string "true" depending on the
      // endpoint. Both are accepted; anything else counts as unverified.
      emailVerified:
        claims.email_verified === true || claims.email_verified === "true",
    };
  } catch {
    return null;
  }
}
