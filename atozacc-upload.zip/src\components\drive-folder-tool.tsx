"use client";

import { useState, useTransition } from "react";

import { listDriveFolder, type DriveFile } from "@/lib/drive-folder";

/**
 * Turns a shared Drive folder into a paste-ready list of image URLs.
 *
 * The point is to avoid clicking "Get link" a hundred times. Copy the URL
 * column, paste it down the `image` column of the sheet, and reorder to match
 * the products.
 */
export function DriveFolderTool() {
  const [url, setUrl] = useState("");
  const [files, setFiles] = useState<DriveFile[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);
  const [pending, start] = useTransition();

  function run() {
    setError(null);
    setFiles(null);
    start(async () => {
      const res = await listDriveFolder(url);
      if (res.ok) setFiles(res.files);
      else setError(res.error);
    });
  }

  async function copy(text: string, label: string) {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(label);
      setTimeout(() => setCopied(null), 2000);
    } catch {
      setCopied("Copy failed — select the text and copy manually");
    }
  }

  return (
    <section className="rounded-[var(--radius-card)] border border-line bg-canvas p-5">
      <h2 className="font-display text-lg">Get image links from a Drive folder</h2>
      <p className="mt-1 max-w-prose text-[12.5px] text-ink-mute">
        Optional. Paste a shared Drive folder and get every photo&apos;s link at
        once, ready to paste down the <code>image</code> column of your sheet.
      </p>

      <div className="mt-3 flex flex-wrap gap-2">
        <input
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && run()}
          placeholder="https://drive.google.com/drive/folders/…"
          className="min-w-0 flex-1 rounded-[var(--radius-card)] border border-line bg-surface px-3 py-2.5 text-[13px] focus:border-brand focus:bg-canvas focus:outline-none"
        />
        <button
          type="button"
          onClick={run}
          disabled={pending || !url.trim()}
          className="rounded-[var(--radius-card)] border border-ink px-4 py-2.5 text-[13px] font-semibold hover:bg-ink hover:text-canvas disabled:opacity-50"
        >
          {pending ? "Reading…" : "List photos"}
        </button>
      </div>

      {error && (
        <p role="alert" className="mt-3 rounded-[var(--radius-card)] border border-brand bg-blush px-3.5 py-2.5 text-[12.5px] text-brand-deep">
          {error}
        </p>
      )}

      {files && (
        <div className="mt-4">
          <div className="flex flex-wrap items-center gap-3">
            <p className="text-[13px] font-semibold text-success">
              {files.length} photo{files.length === 1 ? "" : "s"} found
            </p>
            <button
              type="button"
              onClick={() => copy(files.map((f) => f.url).join("\n"), "urls")}
              className="text-[12.5px] font-semibold text-brand hover:text-brand-deep"
            >
              Copy all URLs
            </button>
            <button
              type="button"
              onClick={() =>
                copy(
                  ["filename,image", ...files.map((f) => `${f.name},${f.url}`)].join("\n"),
                  "csv",
                )
              }
              className="text-[12.5px] font-semibold text-brand hover:text-brand-deep"
            >
              Copy as CSV
            </button>
            {copied && <span className="text-[12px] text-ink-mute">{copied === "urls" ? "URLs copied" : copied === "csv" ? "CSV copied" : copied}</span>}
          </div>

          <div className="mt-2 max-h-72 overflow-auto rounded-[var(--radius-card)] border border-line">
            <table className="w-full text-[12px]">
              <tbody>
                {files.map((f) => (
                  <tr key={f.id} className="border-b border-line last:border-0">
                    <td className="whitespace-nowrap px-3 py-1.5 font-medium">{f.name}</td>
                    <td className="px-3 py-1.5 font-mono text-[10.5px] text-ink-mute">
                      <span className="block max-w-[380px] truncate">{f.url}</span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <p className="mt-2 text-[11.5px] text-ink-mute">
            Name your photos after the product so the alphabetical order here
            lines up with your sheet — that turns this into one paste.
          </p>
        </div>
      )}
    </section>
  );
}
