import { NextResponse, type NextRequest } from "next/server";

/**
 * The lock on the admin panel, and the security headers for every response.
 *
 * Middleware runs on the Edge runtime, which has no `fs` and no bcrypt, so it
 * cannot load the user store to check whether a session belongs to an admin.
 * It therefore does the half it CAN do reliably — reject anyone with no valid
 * signed session at all, before the request reaches a page that would render
 * orders and customer addresses.
 *
 * The other half, "is this particular user an admin", is enforced in the
 * admin layout where the store is reachable. Both halves are required: this
 * one alone would let any signed-in customer through, and the layout alone
 * would mean every admin route depended on nobody ever forgetting the check.
 */

const SESSION_COOKIE = "atz_session";

/** Verifies the cookie's signature using Web Crypto, which the Edge does have. */
async function isSignedSession(token: string | undefined): Promise<boolean> {
  if (!token) return false;

  const secret = process.env.SESSION_SECRET;
  // Without the env secret the middleware cannot verify anything. It then
  // falls back to "there is a cookie shaped like a session", and the layout's
  // real check does the work. Refusing everyone would lock the owner out of
  // their own shop in development.
  if (!secret || secret.length < 32) return token.includes(".");

  const dot = token.indexOf(".");
  if (dot <= 0) return false;

  const body = token.slice(0, dot);
  const given = token.slice(dot + 1);

  try {
    const key = await crypto.subtle.importKey(
      "raw",
      new TextEncoder().encode(secret),
      { name: "HMAC", hash: "SHA-256" },
      false,
      ["sign"],
    );
    const sig = await crypto.subtle.sign("HMAC", key, new TextEncoder().encode(body));
    const expected = btoa(String.fromCharCode(...new Uint8Array(sig)))
      .replace(/\+/g, "-")
      .replace(/\//g, "_")
      .replace(/=+$/, "");

    if (expected.length !== given.length) return false;
    // Constant-time compare: no early exit on the first differing character.
    let diff = 0;
    for (let i = 0; i < expected.length; i++) {
      diff |= expected.charCodeAt(i) ^ given.charCodeAt(i);
    }
    if (diff !== 0) return false;

    const payload = JSON.parse(atob(body.replace(/-/g, "+").replace(/_/g, "/")));
    return typeof payload?.sub === "string" && Date.now() < payload.exp;
  } catch {
    return false;
  }
}

function harden(res: NextResponse): NextResponse {
  // Clickjacking: without this the shop can be framed invisibly over a
  // decoy page and a customer's clicks routed into it.
  res.headers.set("X-Frame-Options", "DENY");
  // Stops a browser second-guessing a Content-Type and running an uploaded
  // file as script.
  res.headers.set("X-Content-Type-Options", "nosniff");
  // Do not leak the page someone was on when they click out to a supplier.
  res.headers.set("Referrer-Policy", "strict-origin-when-cross-origin");
  // The shop asks for none of these; saying so stops an injected script from
  // asking on its behalf.
  res.headers.set(
    "Permissions-Policy",
    "camera=(), microphone=(), geolocation=(), payment=(), usb=()",
  );
  // Only meaningful over HTTPS, and ignored on localhost.
  if (process.env.NODE_ENV === "production") {
    res.headers.set(
      "Strict-Transport-Security",
      "max-age=31536000; includeSubDomains",
    );
  }
  return res;
}

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;

  const isAdminArea = pathname.startsWith("/admin");
  const isLoginPage = pathname === "/admin/login";

  if (isAdminArea && !isLoginPage) {
    const ok = await isSignedSession(req.cookies.get(SESSION_COOKIE)?.value);
    if (!ok) {
      const url = req.nextUrl.clone();
      url.pathname = "/admin/login";
      // Remembers where they were headed, so the login sends them onward
      // rather than always dumping them on the dashboard.
      url.search = `?next=${encodeURIComponent(pathname)}`;
      return harden(NextResponse.redirect(url));
    }
  }

  // The admin layout wraps /admin/login too, and it needs to know that in
  // order not to gate the page whose whole job is letting you through the
  // gate. A layout cannot read the pathname on its own, so it is passed here.
  const forwarded = new Headers(req.headers);
  forwarded.set("x-atz-pathname", pathname);

  return harden(NextResponse.next({ request: { headers: forwarded } }));
}

export const config = {
  // Everything except Next's own assets and the image optimiser, which are
  // served thousands of times per page view and need no headers from us.
  matcher: ["/((?!_next/static|_next/image|favicon.ico|placeholders|brand).*)"],
};
