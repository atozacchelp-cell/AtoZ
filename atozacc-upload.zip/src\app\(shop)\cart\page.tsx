import Link from "next/link";
import { cookies } from "next/headers";

import { CartLine } from "@/components/cart-line";
import { OrderSummary } from "@/components/order-summary";
import { ProductRail } from "@/components/product-rail";
import { Breadcrumbs, ButtonLink, Container, EmptyState } from "@/components/ui";
import { findCoupon } from "@/data/coupons";
import { applyCouponAction } from "@/lib/actions";
import { getCartLines } from "@/lib/cart";
import { listProducts } from "@/lib/catalog";
import { priceCart } from "@/lib/pricing";
import { getSettings } from "@/lib/settings";

export const metadata = {
  title: "Your Cart",
  robots: { index: false },
};

export default async function CartPage() {
  const [{ active, saved }, settings, store] = await Promise.all([
    getCartLines(),
    getSettings(),
    cookies(),
  ]);

  const coupon = findCoupon(store.get("atz_coupon")?.value);

  // Cart shows prepaid pricing, since that is the default choice at checkout.
  const breakdown = priceCart({
    lines: active,
    settings,
    payment: "PREPAID",
    coupon,
  });

  if (active.length === 0 && saved.length === 0) {
    const suggestions = await listProducts({ collection: "bestsellers" }, "bestselling", 1, 4);
    return (
      <Container className="py-8">
        <Breadcrumbs items={[{ label: "Cart" }]} />
        <EmptyState
          title="Your cart is empty"
          body="Nothing here yet. Have a look at what other people are buying."
          action={{ href: "/shop", label: "Start shopping" }}
        />
        <ProductRail title="Popular right now" products={suggestions.items} />
      </Container>
    );
  }

  const hasOutOfStock = active.some((l) => l.outOfStock);

  return (
    <Container className="py-6">
      <Breadcrumbs items={[{ label: "Cart" }]} />

      <h1 className="mb-6 font-display text-[30px] sm:text-[36px]">Your Cart</h1>

      <div className="lg:grid lg:grid-cols-[minmax(0,1fr)_340px] lg:gap-10">
        <div className="min-w-0">
          {active.length > 0 ? (
            <ul className="border-t border-line">
              {active.map((line) => (
                <CartLine key={line.variantKey} line={line} />
              ))}
            </ul>
          ) : (
            <p className="rounded-[var(--radius-card)] border border-dashed border-line-firm p-6 text-center text-[13.5px] text-ink-mute">
              Your cart is empty, but you have items saved for later below.
            </p>
          )}

          {/* Coupon */}
          <form action={applyCouponAction} className="mt-6 flex flex-wrap gap-2">
            <label htmlFor="coupon" className="sr-only">
              Coupon code
            </label>
            <input
              id="coupon"
              name="code"
              defaultValue={coupon?.code ?? ""}
              placeholder="Coupon code"
              className="min-w-0 flex-1 rounded-[var(--radius-card)] border border-line bg-surface px-3 py-2.5 text-[13.5px] uppercase tracking-wider focus:border-brand focus:bg-canvas focus:outline-none sm:max-w-[220px]"
            />
            <button
              type="submit"
              className="rounded-[var(--radius-card)] border border-ink px-4 py-2.5 text-[13px] font-semibold transition-colors hover:bg-ink hover:text-canvas"
            >
              Apply
            </button>
            <Link
              href="/offers"
              className="self-center text-[12.5px] font-semibold text-brand hover:text-brand-deep"
            >
              View offers
            </Link>
          </form>

          {breakdown.couponError && (
            <p className="mt-2 text-[12.5px] font-medium text-brand">
              {breakdown.couponError}
            </p>
          )}

          {saved.length > 0 && (
            <section className="mt-10">
              <h2 className="font-display text-xl">Saved for later</h2>
              <ul className="mt-2 border-t border-line">
                {saved.map((line) => (
                  <CartLine key={line.variantKey} line={line} saved />
                ))}
              </ul>
            </section>
          )}
        </div>

        {/* Summary. Sticky on desktop so the total stays visible while
            scrolling a long cart. */}
        <aside className="mt-8 lg:mt-0">
          <div className="lg:sticky lg:top-24">
            <OrderSummary breakdown={breakdown} />

            {hasOutOfStock ? (
              <p className="mt-3 rounded-[var(--radius-card)] border border-brand bg-blush px-3 py-2.5 text-center text-[12.5px] font-semibold text-brand-deep">
                Remove the out-of-stock item to continue
              </p>
            ) : (
              <ButtonLink href="/checkout" size="lg" full className="mt-3">
                Proceed to checkout
              </ButtonLink>
            )}

            <Link
              href="/shop"
              className="mt-3 block text-center text-[13px] font-semibold text-ink-mute hover:text-brand"
            >
              Continue shopping
            </Link>
          </div>
        </aside>
      </div>
    </Container>
  );
}
