import { Card, PageHeader, Table } from "@/components/admin-ui";
import { AutoSyncForm } from "@/components/auto-sync-form";
import { DriveFolderTool } from "@/components/drive-folder-tool";
import { ImageChecker } from "@/components/image-checker";
import { SheetSyncForm } from "@/components/sheet-sync-form";
import { allCategories } from "@/lib/taxonomy";
import { getAutoSyncStatus, getSyncConfig } from "@/lib/sheet-sync";
import { CONTENT_KEYS } from "@/lib/site-content";

// The schedule panel reports what the timer is doing right now, which a
// cached render cannot know.
export const dynamic = "force-dynamic";

export const metadata = { title: "Google Sheet", robots: { index: false } };

/** Every column the Products tab understands. */
const COLUMNS: { name: string; required?: boolean; note: string }[] = [
  { name: "name", required: true, note: "Product name shown to customers" },
  { name: "category", required: true, note: "Category code, or the category name" },
  { name: "mrp", required: true, note: "Struck-through price, in rupees" },
  { name: "price", required: true, note: "What the customer pays, in rupees" },
  {
    name: "stock",
    required: true,
    note: "One number — or per size for clothing: S:4, M:9, L:6, XL:0",
  },
  { name: "sku", note: "Leave blank and one is generated" },
  { name: "costprice", note: "What you paid. Drives margin and profit" },
  { name: "image", note: "Google Drive share link, or any image URL" },
  { name: "image2 … image5", note: "More photos for the product gallery" },
  { name: "shortdescription", note: "One line under the product name" },
  { name: "description", note: "The full description" },
  { name: "colours", note: "Comma separated: Gold, Silver, Rose Gold" },
  { name: "sizes", note: "Comma separated: S, M, L, XL. Blank means one size" },
  {
    name: "sizechart",
    note: "Measurements table: Size,Chest,Length|S,38,27|M,40,28",
  },
  { name: "material", note: "Brass with gold plating, genuine leather…" },
  { name: "features", note: "Comma separated bullet points" },
  { name: "care", note: "Care instructions" },
  { name: "weight", note: "Grams. Used for shipping rates. Defaults to 100" },
  { name: "collections", note: "gift-collection, festive, combo-offers…" },
  { name: "badge", note: "Custom badge text, e.g. FESTIVE 20% OFF" },
  { name: "new / trending / bestseller / exclusive", note: "yes to switch on" },
  { name: "returnable", note: "no for earrings, socks, personalised items" },
  { name: "cod", note: "no to block cash on delivery for this product" },
];

export default async function SyncPage() {
  const [config, autoStatus] = await Promise.all([
    getSyncConfig(),
    getAutoSyncStatus(),
  ]);

  return (
    <>
      <PageHeader
        title="Google Sheet"
        subtitle="Run your whole catalogue from a spreadsheet"
      />

      <div className="mb-5 rounded-[var(--radius-card)] border border-line bg-canvas p-5">
        <h2 className="font-display text-lg">Setting it up, once</h2>
        <ol className="mt-3 space-y-2 text-[13px] text-ink-mid">
          <Step n={1}>
            Make a Google Sheet with a <strong>Products</strong> tab. Put the
            column names below in row 1 — you only need the five marked
            required.
          </Step>
          <Step n={2}>
            Click <strong>Share</strong> → under &ldquo;General access&rdquo;
            choose <strong>Anyone with the link</strong> as{" "}
            <strong>Viewer</strong>. Without this Google will not let the site
            read it.
          </Step>
          <Step n={3}>
            Put your photos in a Google Drive folder and share that folder the
            same way. Copy each photo&apos;s link into the{" "}
            <code>image</code> column — the ordinary &ldquo;Get link&rdquo; one
            is fine, it gets converted automatically.
          </Step>
          <Step n={4}>
            Paste the sheet link below and press <strong>Sync now</strong>.
            Then set <strong>Automatic sync</strong> underneath, and the shop
            keeps itself matched to the sheet from that point on.
          </Step>
        </ol>
      </div>

      {/* The three files that turn an empty sheet into a working catalogue,
          downloadable here so they never have to be hunted for. */}
      <div className="mb-5 rounded-[var(--radius-card)] border border-line bg-canvas p-5">
        <h2 className="font-display text-lg">Download the starter files</h2>
        <p className="mt-1 text-[12.5px] text-ink-mute">
          In your sheet: <strong>File → Import → Upload</strong>, then choose{" "}
          <strong>Insert new sheet</strong> and rename the tab as shown.
        </p>
        <div className="mt-3 grid gap-2 sm:grid-cols-3">
          <DownloadCard
            href="/api/products/export"
            file="1-Products.csv"
            tab="Products"
            note="Your whole catalogue, all 28 columns"
          />
          <DownloadCard
            href="/api/content/template"
            file="2-Content.csv"
            tab="Content"
            note="Banner, heading and button wording"
          />
          <DownloadCard
            href="/api/categories/export"
            file="3-Category-codes.csv"
            tab="Categories"
            note="Reference only — valid category codes"
          />
        </div>
      </div>

      <SheetSyncForm config={config} />

      <AutoSyncForm
        minutes={config.autoSyncMinutes ?? 0}
        status={autoStatus}
      />

      {/* The destructive behaviour, stated before it happens rather than
          discovered afterwards. */}
      <div className="mt-5 rounded-[var(--radius-card)] border border-warning/40 bg-gold-soft p-4 text-[12.5px] text-ink-mid">
        <strong className="text-ink">A sync replaces the whole catalogue.</strong>{" "}
        The sheet becomes the truth: delete a row there and that product leaves
        the shop. Products added through the Add Product form will be wiped by
        the next sync, so pick one method and stay with it. If no row can be
        read at all, the sync is refused and your existing catalogue is left
        untouched.
      </div>

      <div className="mt-6">
        <DriveFolderTool />
      </div>

      <div className="mt-6">
        <ImageChecker />
      </div>

      <div className="mt-8 grid gap-5 lg:grid-cols-2">
        <section>
          <h2 className="mb-2 font-display text-lg">Product columns</h2>
          <Table head={["Column", "What it does"]}>
            {COLUMNS.map((c) => (
              <tr key={c.name} className="border-b border-line last:border-0">
                <td className="whitespace-nowrap px-3 py-2 font-mono text-[11.5px]">
                  {c.name}
                  {c.required && <span className="ml-1 text-brand">*</span>}
                </td>
                <td className="px-3 py-2 text-ink-mute">{c.note}</td>
              </tr>
            ))}
          </Table>
          <a
            href="/api/products/template"
            className="mt-2 inline-block text-[12.5px] font-semibold text-brand hover:text-brand-deep"
          >
            Download a starter sheet ↓
          </a>
        </section>

        <div className="space-y-5">
          <section>
            <h2 className="mb-2 font-display text-lg">Content tab</h2>
            <p className="mb-2 text-[12.5px] text-ink-mute">
              An optional second tab with two columns, <code>key</code> and{" "}
              <code>value</code>, controlling the wording customers read.
              Leave a cell blank to keep the current text.
            </p>
            <Table head={["key", "Where it appears"]}>
              {CONTENT_KEYS.map((c) => (
                <tr key={c.key} className="border-b border-line last:border-0">
                  <td className="whitespace-nowrap px-3 py-2 font-mono text-[11.5px]">
                    {c.key}
                  </td>
                  <td className="px-3 py-2 text-ink-mute">{c.where}</td>
                </tr>
              ))}
            </Table>
          </section>

          <section>
            <h2 className="mb-2 font-display text-lg">Reviews tab</h2>
            <p className="mb-2 text-[12.5px] text-ink-mute">
              Optional. One row per testimonial, on a tab named{" "}
              <strong>Reviews</strong>. Leave it empty and the section does not
              appear at all — better an honest gap than made-up praise.
            </p>
            <Table head={["Column", "What it does"]}>
              {[
                ["name", "Customer's name, as shown. Required"],
                ["review", "What they said. Required"],
                ["rating", "1 to 5. Defaults to 5"],
                ["city", "Shown after the name — Pune, Delhi…"],
                ["product", "Which item it is about"],
                ["verified", "yes only if they really ordered it"],
                ["date", "Optional, for your own records"],
              ].map(([k, v]) => (
                <tr key={k} className="border-b border-line last:border-0">
                  <td className="whitespace-nowrap px-3 py-2 font-mono text-[11.5px]">
                    {k}
                  </td>
                  <td className="px-3 py-2 text-ink-mute">{v}</td>
                </tr>
              ))}
            </Table>
            <p className="mt-2 text-[11.5px] text-ink-mute">
              &ldquo;From verified orders&rdquo; only appears when{" "}
              <em>every</em> review is marked verified.
            </p>
          </section>

          <Card>
            <h2 className="font-display text-lg">Category codes</h2>
            <p className="mt-1 text-[12px] text-ink-mute">
              Use the code, or just the name where it is unique.
            </p>
            <div className="mt-2 max-h-64 overflow-y-auto">
              <table className="w-full text-[12px]">
                <tbody>
                  {allCategories().map((c) => (
                    <tr key={c.slug} className="border-b border-line last:border-0">
                      <td className="px-1 py-1.5 font-mono text-[11px]">{c.slug}</td>
                      <td className="px-1 py-1.5 capitalize text-ink-mute">
                        {c.gender} · {c.name}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        </div>
      </div>
    </>
  );
}

function DownloadCard({
  href,
  file,
  tab,
  note,
}: {
  href: string;
  file: string;
  tab: string;
  note: string;
}) {
  return (
    <a
      href={href}
      download
      className="rounded-[var(--radius-card)] border border-line bg-surface p-3.5 transition-colors hover:border-brand"
    >
      <p className="flex items-center gap-1.5 text-[13px] font-bold">
        <svg
          width="14"
          height="14"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="shrink-0 text-brand"
          aria-hidden
        >
          <path d="M12 3v13M6 12l6 6 6-6M4 21h16" />
        </svg>
        {file}
      </p>
      <p className="mt-1 text-[11.5px] text-ink-mute">
        Tab name: <strong className="text-ink-mid">{tab}</strong>
      </p>
      <p className="mt-0.5 text-[11.5px] text-ink-mute">{note}</p>
    </a>
  );
}

function Step({ n, children }: { n: number; children: React.ReactNode }) {
  return (
    <li className="flex gap-3">
      <span className="grid h-5 w-5 shrink-0 place-items-center rounded-full bg-ink text-[10.5px] font-bold text-canvas">
        {n}
      </span>
      <span>{children}</span>
    </li>
  );
}
