import { redirect } from "next/navigation";

import { AdminLoginForm } from "@/components/admin-login-form";
import { currentUser } from "@/lib/session";
import { hasAdmin } from "@/lib/users";

export const metadata = { title: "Admin sign in", robots: { index: false } };

// Whether an admin exists changes as soon as one is claimed, and a cached
// version of this page would keep offering the setup form afterwards.
export const dynamic = "force-dynamic";

export default async function AdminLoginPage({
  searchParams,
}: PageProps<"/admin/login">) {
  const params = await searchParams;
  const user = await currentUser();

  // Already an admin: nothing to do here.
  if (user?.isAdmin) redirect("/admin");

  const adminExists = await hasAdmin();
  const next = typeof params.next === "string" ? params.next : "/admin";

  return (
    <div className="mx-auto flex min-h-screen max-w-md flex-col justify-center px-5 py-12">
      <div className="rounded-[var(--radius-card)] border border-line bg-canvas p-7">
        <p className="text-[11px] font-bold uppercase tracking-[0.14em] text-brand">
          AtoZacc Admin
        </p>

        {adminExists ? (
          <>
            <h1 className="mt-3 font-display text-2xl">Sign in</h1>
            <p className="mt-1.5 text-[13px] text-ink-mute">
              This panel holds every order, address and payment setting in the
              shop.
            </p>
            <AdminLoginForm mode="signin" next={next} />
          </>
        ) : (
          <>
            <h1 className="mt-3 font-display text-2xl">Create your admin account</h1>
            <p className="mt-1.5 text-[13px] text-ink-mute">
              No admin exists yet, so this form is open. It closes for good the
              moment you finish — do this now, before the site is public.
            </p>
            <AdminLoginForm mode="setup" next={next} />
          </>
        )}
      </div>

      {!adminExists && (
        <div className="mt-4 rounded-[var(--radius-card)] border border-warning/40 bg-gold-soft p-4 text-[12.5px] text-ink-mid">
          <p className="font-semibold text-ink">Why this form is open</p>
          <p className="mt-1">
            The admin panel had no password at all until now — anyone who
            guessed the address could read your customers&apos; names, phone
            numbers and addresses. Claiming it here is what closes that. Once
            an admin exists, this page only offers sign-in.
          </p>
        </div>
      )}
    </div>
  );
}
