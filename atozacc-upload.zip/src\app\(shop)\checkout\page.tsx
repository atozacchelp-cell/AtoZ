import { cookies } from "next/headers";
import { redirect } from "next/navigation";

import { CheckoutForm, type PaymentOption } from "@/components/checkout-form";
import { Breadcrumbs, Container } from "@/components/ui";
import { findCoupon } from "@/data/coupons";
import { getCartLines } from "@/lib/cart";
import { formatINR } from "@/lib/money";
import { checkCodEligibility, priceCart } from "@/lib/pricing";
import { getSettings } from "@/lib/settings";
import { getSuppliers } from "@/lib/suppliers";

export const metadata = {
  title: "Checkout",
  robots: { index: false },
};

export default async function CheckoutPage() {
  const [{ active }, settings, store] = await Promise.all([
    getCartLines(),
    getSettings(),
    cookies(),
  ]);

  if (active.length === 0) redirect("/cart");

  const coupon = findCoupon(store.get("atz_coupon")?.value);

  // One breakdown per method, computed server-side. The client switches
  // between them but never calculates one.
  const breakdowns = {
    PREPAID: priceCart({ lines: active, settings, payment: "PREPAID", coupon }),
    COD: priceCart({ lines: active, settings, payment: "COD", coupon }),
    PARTIAL: priceCart({ lines: active, settings, payment: "PARTIAL", coupon }),
  };

  // Suppliers who refuse COD block it for anything they ship.
  const suppliers = await getSuppliers();
  const suppliersWithoutCod = suppliers.filter((s) => !s.acceptsCod).map((s) => s.name);

  const codCheck = checkCodEligibility(active, breakdowns.PREPAID.total, settings, {
    suppliersWithoutCod,
  });

  const options: PaymentOption[] = [
    {
      value: "PREPAID",
      title: "Pay online",
      body: "UPI, cards, net banking and wallets",
      badge:
        settings.prepaidDiscountEnabled && breakdowns.PREPAID.prepaidDiscount > 0
          ? `Save ${formatINR(breakdowns.PREPAID.prepaidDiscount)}`
          : undefined,
    },
  ];

  if (settings.partialPaymentEnabled && breakdowns.PARTIAL.isPartial) {
    options.push({
      value: "PARTIAL",
      title: "Pay part now, rest on delivery",
      body: `Pay ${formatINR(breakdowns.PARTIAL.advanceAmount)} now and ${formatINR(
        breakdowns.PARTIAL.balanceAmount,
      )} when it arrives`,
    });
  }

  options.push({
    value: "COD",
    title: "Cash on delivery",
    body:
      settings.codFee > 0
        ? `Pay when it arrives · ${formatINR(settings.codFee)} handling fee`
        : "Pay when it arrives",
    disabled: !codCheck.allowed,
    disabledReason: codCheck.reason,
  });

  return (
    <Container className="py-6">
      <Breadcrumbs items={[{ label: "Cart", href: "/cart" }, { label: "Checkout" }]} />

      <h1 className="mb-6 font-display text-[30px] sm:text-[36px]">Checkout</h1>

      {!settings.onlinePaymentEnabled && (
        <p className="mb-6 rounded-[var(--radius-card)] border border-line bg-surface px-4 py-3 text-[12.5px] text-ink-mid">
          <strong>Note:</strong> online payment is not live yet — the payment
          gateway is still being set up. Cash on delivery works as normal, and
          online orders placed here are recorded but not charged.
        </p>
      )}

      <CheckoutForm
        breakdowns={breakdowns}
        paymentOptions={options}
        defaultPayment={codCheck.allowed && !settings.onlinePaymentEnabled ? "COD" : "PREPAID"}
      />
    </Container>
  );
}
