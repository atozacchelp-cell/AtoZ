import { CONTENT_KEYS, DEFAULT_CONTENT } from "@/lib/site-content";

/**
 * The Content tab as a CSV, pre-filled with the wording currently on the site.
 * Import it into a tab named "Content", edit the value column, sync.
 */

function cell(value: string): string {
  return /[",\n]/.test(value) ? `"${value.replace(/"/g, '""')}"` : value;
}

export async function GET() {
  const rows = [
    "key,value,where_it_appears",
    ...CONTENT_KEYS.map((c) =>
      [c.key, DEFAULT_CONTENT[c.key], c.where].map(cell).join(","),
    ),
  ].join("\n");

  return new Response(rows, {
    headers: {
      "Content-Type": "text/csv; charset=utf-8",
      "Content-Disposition": 'attachment; filename="2-Content.csv"',
    },
  });
}
