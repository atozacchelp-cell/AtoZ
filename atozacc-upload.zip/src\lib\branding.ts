import { fs } from "@/lib/data-fs";
import path from "node:path";

import { fileMtime } from "@/lib/data-fs";
import { FONT_PAIRS, type FontPairKey } from "@/lib/font-pairs";

/**
 * Look and feel, editable from admin.
 *
 * Logo, fonts, text size and the brand colour are the things an owner wants
 * to try three versions of on a Saturday. None of them should need a
 * developer, so they live here as data and reach the page as CSS variables.
 */

const BRANDING_PATH = path.join(process.cwd(), "data", "branding.json");

export { FONT_PAIRS, type FontPairKey } from "@/lib/font-pairs";

export type Branding = {
  /** Image logo. Blank falls back to the wordmark. Drive links are converted. */
  logoUrl: string;
  /** Wordmark shown when there is no logo image. */
  logoText: string;
  /** Logo height in pixels, 20–140. */
  logoHeight: number;
  /**
   * Width ÷ height of the logo image, measured when it is saved.
   *
   * Without this the header has to guess a container width, and a guess that
   * is too wide leaves the logo stranded in empty space with the navigation
   * pushed sideways — which is exactly what a fixed multiplier does to a wide
   * horizontal lockup.
   */
  logoAspect: number;

  fontPair: FontPairKey;
  /** Body text size in px, 13–18. Everything else scales from it. */
  baseFontSize: number;
  /** Multiplier on heading sizes, 0.85–1.25. */
  headingScale: number;

  brandColour: string;
  brandDeepColour: string;
  /** Corner rounding in px, 0–20. */
  cornerRadius: number;
};

export const DEFAULT_BRANDING: Branding = {
  logoUrl: "",
  logoText: "AtoZacc",
  logoHeight: 32,
  logoAspect: 3,

  fontPair: "editorial",
  baseFontSize: 15,
  headingScale: 1,

  brandColour: "#d42a4c",
  brandDeepColour: "#a81f3b",
  cornerRadius: 4,
};

let cache: Branding | null = null;
let cachedMtime = -1;

export async function getBranding(): Promise<Branding> {
  const mtime = fileMtime(BRANDING_PATH);
  if (cache && mtime === cachedMtime) return cache;

  let resolved: Branding;
  try {
    const stored = JSON.parse(await fs.readFile(BRANDING_PATH, "utf8"));
    resolved = { ...DEFAULT_BRANDING, ...stored };
  } catch {
    resolved = DEFAULT_BRANDING;
  }

  cache = resolved;
  cachedMtime = mtime;
  return resolved;
}

export async function saveBranding(partial: Partial<Branding>): Promise<void> {
  const current = await getBranding();
  const next = { ...current, ...partial };

  await fs.mkdir(path.dirname(BRANDING_PATH), { recursive: true });
  await fs.writeFile(BRANDING_PATH, JSON.stringify(next, null, 2), "utf8");
  cache = next;
  cachedMtime = fileMtime(BRANDING_PATH);
}

export function invalidateBranding(): void {
  cache = null;
}

/**
 * Turns branding into the CSS variables the stylesheet already reads, so a
 * change here repaints the whole site without touching a component.
 */
export function brandingToCss(b: Branding): string {
  const pair = FONT_PAIRS[b.fontPair] ?? FONT_PAIRS.editorial;

  return [
    `--font-display:${pair.display},Georgia,serif`,
    `--font-sans:${pair.body},ui-sans-serif,system-ui,sans-serif`,
    `--base-font-size:${b.baseFontSize}px`,
    `--heading-scale:${b.headingScale}`,
    `--color-brand:${b.brandColour}`,
    `--color-brand-deep:${b.brandDeepColour}`,
    `--radius-card:${b.cornerRadius}px`,
    `--logo-h:${b.logoHeight}px`,
    `--logo-aspect:${b.logoAspect || 3}`,
  ].join(";");
}
