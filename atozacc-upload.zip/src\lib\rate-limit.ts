import { headers } from "next/headers";

/**
 * A small in-memory rate limiter for the endpoints worth brute-forcing.
 *
 * Login is the one place where an attacker gets unlimited free guesses, and
 * bcrypt alone does not stop them — it only makes each guess cost 250ms, which
 * a hundred parallel connections turn back into hundreds per second. Counting
 * attempts is what actually closes it.
 *
 * In-memory, so it resets on restart and does not span multiple instances.
 * That is a real limitation and the right trade for a single-server shop: it
 * stops the attack that actually happens (a script hammering one endpoint)
 * without adding Redis to a site with no database yet.
 */

type Bucket = { count: number; resetAt: number };

const KEY = "__atzRateLimit";

function buckets(): Map<string, Bucket> {
  const g = globalThis as unknown as Record<string, Map<string, Bucket> | undefined>;
  // Survives hot reloads in development, which would otherwise clear the
  // counts every time a file was saved.
  g[KEY] ??= new Map();
  return g[KEY]!;
}

/** Best-effort client address. Spoofable, which is why it is not the only defence. */
export async function clientKey(): Promise<string> {
  const h = await headers();
  const forwarded = h.get("x-forwarded-for");
  // Left-most entry is the original client; the rest are proxies.
  const ip = forwarded?.split(",")[0]?.trim() || h.get("x-real-ip") || "unknown";
  return ip;
}

export type RateResult = { allowed: boolean; retryAfterSeconds: number };

/**
 * Counts one attempt against `name:key`.
 * Returns whether it is allowed, and how long to wait if not.
 */
export function hit(
  name: string,
  key: string,
  limit: number,
  windowMs: number,
): RateResult {
  const id = `${name}:${key}`;
  const now = Date.now();
  const map = buckets();
  const found = map.get(id);

  if (!found || now > found.resetAt) {
    map.set(id, { count: 1, resetAt: now + windowMs });
    return { allowed: true, retryAfterSeconds: 0 };
  }

  found.count++;
  if (found.count > limit) {
    return {
      allowed: false,
      retryAfterSeconds: Math.max(1, Math.ceil((found.resetAt - now) / 1000)),
    };
  }

  return { allowed: true, retryAfterSeconds: 0 };
}

/** Clears the counter after a success, so one good login forgives the fumbles. */
export function reset(name: string, key: string): void {
  buckets().delete(`${name}:${key}`);
}

/** Occasional sweep so a long-running process does not grow a bucket per IP forever. */
export function sweep(): void {
  const now = Date.now();
  for (const [id, b] of buckets()) if (now > b.resetAt) buckets().delete(id);
}
