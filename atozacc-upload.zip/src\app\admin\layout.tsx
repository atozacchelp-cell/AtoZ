import { headers } from "next/headers";
import Link from "next/link";
import { redirect } from "next/navigation";

import { currentUser } from "@/lib/session";
import { hasAdmin } from "@/lib/users";

/**
 * Admin chrome.
 *
 * Designed mobile-first, because the owner will process orders on a phone —
 * that is a real constraint here, not a nicety. The nav is a horizontal
 * scroller on small screens and a sidebar from `lg` up.
 */

const NAV = [
  { href: "/admin", label: "Dashboard", exact: true },
  { href: "/admin/orders", label: "Orders" },
  { href: "/admin/payments", label: "Payments" },
  { href: "/admin/products", label: "Products" },
  { href: "/admin/sync", label: "Google Sheet" },
  { href: "/admin/categories", label: "Categories" },
  { href: "/admin/inventory", label: "Inventory" },
  { href: "/admin/suppliers", label: "Suppliers" },
  { href: "/admin/customers", label: "Customers" },
  { href: "/admin/coupons", label: "Coupons" },
  { href: "/admin/reports", label: "Reports" },
  { href: "/admin/appearance", label: "Appearance" },
  { href: "/admin/settings", label: "Settings" },
];

export default async function AdminLayout({ children }: LayoutProps<"/admin">) {
  // The real authorisation check. Middleware can only confirm that SOME valid
  // session exists — it runs on the Edge and cannot reach the user store — so
  // "is this person an admin" is decided here, where it can be, and on every
  // single admin render rather than once at login.
  // The sign-in page lives under /admin but must not be gated by it, or the
  // redirect would point at a page that redirects to itself.
  const pathname = (await headers()).get("x-atz-pathname") ?? "";
  if (pathname.startsWith("/admin/login")) return <>{children}</>;

  const user = await currentUser();

  if (!user) redirect("/admin/login");

  if (!user.isAdmin) {
    // An account exists but is not an admin. Sending them to the shop rather
    // than to a login form avoids inviting them to keep guessing.
    if (await hasAdmin()) redirect("/");
    // No admin exists yet: the first account claims the panel through the
    // setup form rather than silently becoming one here.
    redirect("/admin/login?setup=1");
  }

  return (
    <div className="flex min-h-full flex-col bg-surface">
      <header className="border-b border-line bg-canvas">
        <div className="mx-auto flex max-w-7xl items-center gap-4 px-4 py-3">
          <Link href="/admin" className="font-display text-lg font-semibold">
            AtoZacc
            <span className="ml-2 rounded bg-ink px-1.5 py-0.5 align-middle text-[9.5px] font-bold uppercase tracking-[0.1em] text-canvas">
              Admin
            </span>
          </Link>
          <Link
            href="/"
            className="ml-auto text-[12.5px] font-semibold text-ink-mute hover:text-brand"
          >
            View store ↗
          </Link>
        </div>

        <nav className="scroll-x border-t border-line">
          <ul className="mx-auto flex max-w-7xl gap-1 px-3">
            {NAV.map((item) => (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className="block whitespace-nowrap px-3 py-2.5 text-[13px] font-semibold text-ink-mid transition-colors hover:text-brand"
                >
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </header>

      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-6">{children}</main>
    </div>
  );
}
