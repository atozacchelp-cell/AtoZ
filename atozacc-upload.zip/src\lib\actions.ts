"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";

import { getAllProducts } from "@/lib/product-store";
import {
  readCartCookie,
  readWishlist,
  variantKey,
  writeCartCookie,
  writeWishlist,
  type CartCookieItem,
} from "@/lib/cart";
import { isFreeSize, stockForSize } from "@/lib/sizes";

/**
 * Server actions.
 *
 * Every input is parsed with a schema before it touches state. The client is
 * never trusted for anything beyond identity and quantity — no prices, no
 * totals, no discounts.
 */

const AddToCartSchema = z.object({
  slug: z.string().min(1).max(200),
  colour: z.string().max(60).optional(),
  size: z.string().max(30).optional(),
  qty: z.coerce.number().int().min(1).max(10).default(1),
});

export type ActionResult = { ok: boolean; message?: string };

export async function addToCart(formData: FormData): Promise<ActionResult> {
  const parsed = AddToCartSchema.safeParse({
    slug: formData.get("slug"),
    colour: formData.get("colour") || undefined,
    size: formData.get("size") || undefined,
    qty: formData.get("qty") ?? 1,
  });

  if (!parsed.success) {
    return { ok: false, message: "That didn't look right. Please try again." };
  }

  const products = await getAllProducts();
  const product = products.find((p) => p.slug === parsed.data.slug);
  if (!product) return { ok: false, message: "This product is no longer available." };
  if (product.stock <= 0) return { ok: false, message: "This product is out of stock." };

  // Sizes are enforced here, not only in the form. The browser sends whatever
  // it likes, and a garment sold in a size that is not stocked has to be
  // cancelled and refunded by hand.
  const sizes = product.sizes ?? [];
  const needsChoice = sizes.length > 1 || (sizes.length === 1 && !isFreeSize(sizes));

  if (needsChoice && !parsed.data.size) {
    return { ok: false, message: "Choose a size first." };
  }
  if (parsed.data.size && sizes.length && !sizes.includes(parsed.data.size)) {
    return { ok: false, message: "That size is not available for this product." };
  }

  const available = stockForSize(product, parsed.data.size);
  if (available <= 0) {
    return {
      ok: false,
      message: parsed.data.size
        ? `Size ${parsed.data.size} is sold out.`
        : "This product is out of stock.",
    };
  }

  const items = await readCartCookie();
  const key = variantKey(parsed.data);
  const existing = items.find((i) => variantKey(i) === key);

  if (existing) {
    // Cap at available stock, so the cart can never promise more than exists.
    existing.qty = Math.min(10, available, existing.qty + parsed.data.qty);
    existing.savedForLater = false;
  } else {
    items.push({
      slug: parsed.data.slug,
      colour: parsed.data.colour,
      size: parsed.data.size,
      qty: Math.min(parsed.data.qty, available),
    });
  }

  await writeCartCookie(items);
  revalidatePath("/cart");
  revalidatePath("/", "layout");
  return { ok: true, message: "Added to cart" };
}

const KeySchema = z.object({ key: z.string().min(1).max(300) });

export async function removeFromCart(formData: FormData): Promise<ActionResult> {
  const parsed = KeySchema.safeParse({ key: formData.get("key") });
  if (!parsed.success) return { ok: false };

  const items = (await readCartCookie()).filter(
    (i) => variantKey(i) !== parsed.data.key,
  );
  await writeCartCookie(items);
  revalidatePath("/cart");
  revalidatePath("/", "layout");
  return { ok: true, message: "Removed" };
}

const QtySchema = z.object({
  key: z.string().min(1).max(300),
  qty: z.coerce.number().int().min(0).max(10),
});

export async function updateCartQty(formData: FormData): Promise<ActionResult> {
  const parsed = QtySchema.safeParse({
    key: formData.get("key"),
    qty: formData.get("qty"),
  });
  if (!parsed.success) return { ok: false };

  let items = await readCartCookie();

  if (parsed.data.qty === 0) {
    items = items.filter((i) => variantKey(i) !== parsed.data.key);
  } else {
    const item = items.find((i) => variantKey(i) === parsed.data.key);
    if (item) {
      const product = (await getAllProducts()).find((p) => p.slug === item.slug);
      item.qty = Math.min(parsed.data.qty, product?.stock ?? parsed.data.qty);
    }
  }

  await writeCartCookie(items);
  revalidatePath("/cart");
  revalidatePath("/", "layout");
  return { ok: true };
}

export async function toggleSaveForLater(formData: FormData): Promise<ActionResult> {
  const parsed = KeySchema.safeParse({ key: formData.get("key") });
  if (!parsed.success) return { ok: false };

  const items = await readCartCookie();
  const item = items.find((i) => variantKey(i) === parsed.data.key);
  if (item) item.savedForLater = !item.savedForLater;

  await writeCartCookie(items);
  revalidatePath("/cart");
  revalidatePath("/", "layout");
  return { ok: true };
}

const SlugSchema = z.object({ slug: z.string().min(1).max(200) });

export async function toggleWishlist(formData: FormData): Promise<ActionResult> {
  const parsed = SlugSchema.safeParse({ slug: formData.get("slug") });
  if (!parsed.success) return { ok: false };

  const list = await readWishlist();
  const next = list.includes(parsed.data.slug)
    ? list.filter((s) => s !== parsed.data.slug)
    : [...list, parsed.data.slug];

  await writeWishlist(next);
  revalidatePath("/wishlist");
  revalidatePath("/", "layout");
  return {
    ok: true,
    message: next.includes(parsed.data.slug) ? "Saved to wishlist" : "Removed from wishlist",
  };
}

const CouponSchema = z.object({ code: z.string().max(40) });

/** Used directly as a `<form action>`, so it must resolve to void. */
export async function applyCouponAction(formData: FormData): Promise<void> {
  const parsed = CouponSchema.safeParse({ code: formData.get("code") });
  if (!parsed.success) return;

  const { cookies } = await import("next/headers");
  const store = await cookies();
  const code = parsed.data.code.trim().toUpperCase();

  if (code === "") store.delete("atz_coupon");
  else store.set("atz_coupon", code, { path: "/", maxAge: 60 * 60 * 24, sameSite: "lax" });

  revalidatePath("/cart");
  revalidatePath("/checkout");
}
