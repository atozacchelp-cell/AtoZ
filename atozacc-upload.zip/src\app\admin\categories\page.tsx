import Link from "next/link";

import { EmptyRow, PageHeader, Table } from "@/components/admin-ui";
import { allCategories } from "@/lib/taxonomy";
import { getAllProducts } from "@/lib/product-store";
import { categoryHref } from "@/lib/catalog";

export const metadata = { title: "Categories", robots: { index: false } };

export default async function AdminCategories() {
  const products = await getAllProducts();
  const counts = new Map<string, number>();
  for (const p of products) counts.set(p.category, (counts.get(p.category) ?? 0) + 1);

  const roots = allCategories().filter((c) => !c.parent);

  return (
    <>
      <PageHeader
        title="Categories"
        subtitle={`${allCategories().length} categories across 4 gender groups`}
      />

      <Table head={["Category", "Gender", "Level", "Products", "GST band", "URL"]}>
        {roots.length === 0 ? (
          <EmptyRow colSpan={6}>No categories.</EmptyRow>
        ) : (
          roots.flatMap((root) => {
            const children = allCategories().filter((c) => c.parent === root.slug);
            return [root, ...children].map((cat) => {
              const own = counts.get(cat.slug) ?? 0;
              const total = cat.parent
                ? own
                : own + children.reduce((s, c) => s + (counts.get(c.slug) ?? 0), 0);
              return (
                <tr key={cat.slug} className="border-b border-line last:border-0">
                  <td className="px-3 py-2">
                    <span className={cat.parent ? "pl-5 text-ink-mid" : "font-semibold"}>
                      {cat.parent && <span className="mr-1.5 text-line-firm">└</span>}
                      {cat.name}
                    </span>
                  </td>
                  <td className="px-3 py-2 capitalize text-ink-mute">{cat.gender}</td>
                  <td className="px-3 py-2 text-ink-mute">
                    {cat.parent ? "Sub" : "Top"}
                  </td>
                  <td className="tnum px-3 py-2 font-semibold">{total}</td>
                  <td className="tnum px-3 py-2 text-ink-mute">
                    {cat.taxRate ? `${cat.taxRate / 100}%` : "—"}
                  </td>
                  <td className="px-3 py-2">
                    <Link
                      href={categoryHref(cat)}
                      className="text-[11.5px] text-brand hover:underline"
                    >
                      {categoryHref(cat)}
                    </Link>
                  </td>
                </tr>
              );
            });
          })
        )}
      </Table>

      <p className="mt-4 rounded-[var(--radius-card)] border border-line bg-canvas px-4 py-3 text-[12.5px] text-ink-mute">
        GST bands are stored per category so the store is ready the day it
        registers — nothing is charged while the business is unregistered.
        Drag-to-reorder and inline editing arrive with the database.
      </p>
    </>
  );
}
