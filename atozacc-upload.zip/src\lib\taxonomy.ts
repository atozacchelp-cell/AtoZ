import { readFileSync } from "node:fs";
import path from "node:path";

import {
  CATEGORIES,
  COLLECTIONS,
  categoryIndex as rawCategoryIndex,
  registerCategories,
  registerCollections,
  type SeedCategory,
  type SeedCollection,
} from "@/data/catalog";
import { fileMtime } from "@/lib/data-fs";
import { onNetlify, readJson } from "@/lib/storage";

/**
 * Makes the categories and collections created from the sheet visible to
 * whatever is about to read them.
 *
 * The obvious place to load these is server startup, and that was tried: it
 * does not work. Next does not guarantee that the module instance running
 * `instrumentation.ts` is the one a page renders from, so categories pushed
 * into the array at boot were simply absent by the time a request looked —
 * `/women/gifts` 404'd for a category that unquestionably existed on disk.
 * This is the third time that trap has caught this codebase.
 *
 * So the file is the source of truth and the read path checks it, with an
 * mtime guard so the cost is one `stat` per call rather than a parse. The
 * same shape as the product, settings and orders stores, for the same reason.
 *
 * Synchronous on purpose: the callers are ordinary lookups like "what is this
 * category's name", used inside non-async helpers. Two small JSON files read
 * at most once per mtime change is not worth making the whole catalogue API
 * async to avoid.
 */

const CATEGORY_PATH = path.join(process.cwd(), "data", "categories.json");
const COLLECTION_PATH = path.join(process.cwd(), "data", "collections.json");

let seenCategoryMtime = -2;
let seenCollectionMtime = -2;

function readArray<T>(file: string, key: string): T[] {
  try {
    const parsed = JSON.parse(readFileSync(file, "utf8")) as Record<string, unknown>;
    const list = parsed[key];
    return Array.isArray(list) ? (list as T[]) : [];
  } catch {
    return [];
  }
}

/**
 * The async loader, used where the store is not a local disk.
 *
 * Netlify Blobs can only be read asynchronously, and the callers of
 * `ensureTaxonomy` below are synchronous helpers like "what is this
 * category's name" that cannot await anything. So on Netlify the loading
 * happens here instead, hung off `getAllProducts()` — which is already async
 * and is called by every catalogue read before any of those helpers run.
 */
export async function loadTaxonomy(): Promise<void> {
  if (!onNetlify()) return ensureTaxonomy();

  const [cats, cols] = await Promise.all([
    readJson<{ categories?: SeedCategory[] }>("categories", {}),
    readJson<{ collections?: SeedCollection[] }>("collections", {}),
  ]);

  if (Array.isArray(cats.categories)) registerCategories(cats.categories);
  if (Array.isArray(cols.collections)) registerCollections(cols.collections);
}

/**
 * Cheap enough to call on every read. Does real work only when a file changes.
 * A no-op on Netlify, where `loadTaxonomy` does the work instead.
 */
export function ensureTaxonomy(): void {
  if (onNetlify()) return;

  const catMtime = fileMtime(CATEGORY_PATH);
  if (catMtime !== seenCategoryMtime) {
    seenCategoryMtime = catMtime;
    if (catMtime !== -1) {
      registerCategories(readArray<SeedCategory>(CATEGORY_PATH, "categories"));
    }
  }

  const colMtime = fileMtime(COLLECTION_PATH);
  if (colMtime !== seenCollectionMtime) {
    seenCollectionMtime = colMtime;
    if (colMtime !== -1) {
      registerCollections(readArray<SeedCollection>(COLLECTION_PATH, "collections"));
    }
  }
}

/** Slug -> category, including anything the sheet added. */
export function categoryIndex(): Map<string, SeedCategory> {
  ensureTaxonomy();
  return rawCategoryIndex();
}

export function allCategories(): SeedCategory[] {
  ensureTaxonomy();
  return CATEGORIES;
}

export function allCollections(): SeedCollection[] {
  ensureTaxonomy();
  return COLLECTIONS;
}
