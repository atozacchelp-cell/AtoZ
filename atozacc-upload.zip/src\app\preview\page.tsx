import Image from "next/image";
import Link from "next/link";

import { Marquee, Reveal, Tilt } from "@/app/preview/motion";
import { Container } from "@/components/ui";
import {
  getCategoryTree,
  getShowcaseImages,
  listProducts,
  type ProductListItem,
} from "@/lib/catalog";
import { discountPercent, formatINR } from "@/lib/money";
import { getSettings } from "@/lib/settings";
import { getContent } from "@/lib/site-content";

/**
 * A DEMO of a different visual direction. Nothing links to it.
 *
 * It reads exactly the same live data as the real homepage — same products,
 * same prices, same photos — so what you are judging is the design and not a
 * mock-up that would fall apart on contact with the catalogue. Deleting
 * `src/app/preview/` reverts every trace of it.
 */
export const metadata = {
  title: { absolute: "AtoZacc — new look preview" },
  robots: { index: false },
};

export const dynamic = "force-dynamic";

export default async function PreviewPage() {
  const [settings, content, tree, best, newIn] = await Promise.all([
    getSettings(),
    getContent(),
    getCategoryTree(),
    listProducts({ collection: "bestsellers" }, "bestselling", 1, 8),
    listProducts({ collection: "new-arrivals" }, "newest", 1, 4),
  ]);

  const hero = await getShowcaseImages(5);
  const cats = tree.filter((c) => c.productCount > 0).slice(0, 6);
  const products = (best.items.length ? best.items : newIn.items).slice(0, 8);

  return (
    <div className="atz-preview">
      {/* Scoped styles. Nothing here leaks into the live site — every rule is
          nested under .atz-preview or a preview-only keyframe name. */}
      <style>{CSS}</style>

      <div className="bg-ink text-canvas">
        <Marquee
          items={[
            `Free shipping over ${formatINR(settings.freeShippingThreshold)}`,
            "Cash on delivery across India",
            `${formatINR(settings.prepaidDiscount)} off when you pay by UPI`,
            `${settings.returnWindowDays}-day returns`,
            "Hand-picked accessories, A to Z",
          ]}
        />
      </div>

      <Container className="pb-20">
        {/* ---------------------------------------------------------------
            Hero. Depth comes from overlapping planes and a soft light
            source rather than a 3D library — it loads instantly and does
            not fight the product photography for attention.
            --------------------------------------------------------------- */}
        <section className="atz-hero relative mt-6 overflow-hidden rounded-3xl px-6 py-14 sm:px-12 sm:py-20">
          <div className="atz-orb atz-orb-1" aria-hidden />
          <div className="atz-orb atz-orb-2" aria-hidden />

          <div className="relative grid items-center gap-12 lg:grid-cols-[1.05fr_1fr]">
            <Reveal>
              <p className="text-[11px] font-bold uppercase tracking-[0.22em] text-brand">
                {content.heroEyebrow}
              </p>
              <h1 className="atz-display mt-5 text-[clamp(2.4rem,7vw,4.4rem)] leading-[0.98]">
                {content.heroHeading}{" "}
                <span className="atz-shine">{content.heroHighlight}</span>
              </h1>
              <p className="mt-6 max-w-md text-[15px] leading-relaxed text-ink-mid">
                {content.heroBody}
              </p>

              <div className="mt-9 flex flex-wrap gap-3">
                <Link href="/shop" className="atz-btn atz-btn-primary">
                  {content.heroCta}
                </Link>
                <Link href="/offers" className="atz-btn atz-btn-ghost">
                  {content.heroCtaSecondary}
                </Link>
              </div>

              <dl className="mt-10 flex gap-8 border-t border-line pt-6">
                <Stat n={`${products.length * 4}+`} label="Pieces in stock" />
                <Stat n="4–7" label="Day delivery" />
                <Stat n="COD" label="Available" />
              </dl>
            </Reveal>

            {/* Staggered photo stack. Each tile sits on its own plane, so
                moving the cursor across them separates them in depth. */}
            <Reveal delay={120}>
              <div className="atz-stack">
                {hero.slice(0, 5).map((src, i) => (
                  <Tilt key={src} max={10} className={`atz-tile atz-tile-${i + 1}`}>
                    <Image
                      src={src}
                      alt=""
                      fill
                      sizes="(max-width:1024px) 45vw, 24vw"
                      priority={i < 2}
                      className="object-cover"
                    />
                  </Tilt>
                ))}
              </div>
            </Reveal>
          </div>
        </section>

        {/* --------------------------------------------------------------- */}
        <Reveal className="mt-24">
          <SectionTitle kicker="Browse" title="Shop by category" href="/shop" />
          <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
            {cats.map((c, i) => (
              <Reveal key={c.slug} delay={i * 60}>
                <Link href={c.href} className="group block">
                  <Tilt max={12}>
                    <div className="atz-cat relative aspect-[4/5] overflow-hidden rounded-2xl">
                      {c.image && (
                        <Image
                          src={c.image}
                          alt=""
                          fill
                          sizes="(max-width:640px) 45vw, 16vw"
                          className="object-cover transition-transform duration-[900ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-110"
                        />
                      )}
                      <div className="atz-cat-veil" />
                      <div className="absolute inset-x-0 bottom-0 p-3">
                        <p className="text-[13px] font-bold leading-tight text-white drop-shadow">
                          {c.name}
                        </p>
                        <p className="text-[10.5px] text-white/75">
                          {c.productCount} item{c.productCount === 1 ? "" : "s"}
                        </p>
                      </div>
                    </div>
                  </Tilt>
                </Link>
              </Reveal>
            ))}
          </div>
        </Reveal>

        {/* --------------------------------------------------------------- */}
        <Reveal className="mt-24">
          <SectionTitle
            kicker="Loved most"
            title="Bestsellers"
            href="/bestsellers"
          />
          <div className="mt-8 grid grid-cols-2 gap-x-5 gap-y-10 lg:grid-cols-4">
            {products.map((p, i) => (
              <Reveal key={p.slug} delay={(i % 4) * 70}>
                <PreviewCard product={p} prepaid={settings.prepaidDiscount} />
              </Reveal>
            ))}
          </div>
        </Reveal>

        {/* --------------------------------------------------------------- */}
        <Reveal className="mt-24">
          <div className="atz-band relative overflow-hidden rounded-3xl px-8 py-14 text-center sm:py-20">
            <div className="atz-orb atz-orb-3" aria-hidden />
            <p className="relative text-[11px] font-bold uppercase tracking-[0.22em] text-white/70">
              Pay online, pay less
            </p>
            <p className="atz-display relative mt-4 text-[clamp(1.9rem,5vw,3rem)] leading-tight text-white">
              {formatINR(settings.prepaidDiscount)} off every UPI order
            </p>
            <p className="relative mx-auto mt-4 max-w-md text-[14px] text-white/75">
              Free shipping over {formatINR(settings.freeShippingThreshold)}. Cash
              on delivery still available on everything.
            </p>
            <Link href="/shop" className="atz-btn atz-btn-light relative mt-8">
              Start shopping
            </Link>
          </div>
        </Reveal>
      </Container>
    </div>
  );
}

/* ------------------------------------------------------------------------ */

function Stat({ n, label }: { n: string; label: string }) {
  return (
    <div>
      <dt className="atz-display text-[26px] leading-none">{n}</dt>
      <dd className="mt-1 text-[11px] uppercase tracking-[0.09em] text-ink-mute">
        {label}
      </dd>
    </div>
  );
}

function SectionTitle({
  kicker,
  title,
  href,
}: {
  kicker: string;
  title: string;
  href: string;
}) {
  return (
    <div className="flex items-end justify-between gap-4">
      <div>
        <p className="text-[11px] font-bold uppercase tracking-[0.22em] text-brand">
          {kicker}
        </p>
        <h2 className="atz-display mt-2 text-[clamp(1.7rem,4vw,2.6rem)] leading-none">
          {title}
        </h2>
      </div>
      <Link
        href={href}
        className="shrink-0 border-b border-brand pb-0.5 text-[13px] font-semibold text-brand"
      >
        View all
      </Link>
    </div>
  );
}

function PreviewCard({
  product,
  prepaid,
}: {
  product: ProductListItem;
  prepaid: number;
}) {
  const off = discountPercent(product.mrp, product.price);

  return (
    <Link href={product.href} className="group block">
      <Tilt max={9}>
        <div className="atz-card relative aspect-square overflow-hidden rounded-2xl">
          <Image
            src={product.imageUrl}
            alt={product.name}
            fill
            sizes="(max-width:640px) 45vw, 22vw"
            className="object-cover transition-transform duration-[900ms] ease-[cubic-bezier(0.22,1,0.36,1)] group-hover:scale-[1.08]"
          />
          {off >= 10 && <span className="atz-off">{off}% off</span>}
          {product.outOfStock && (
            <span className="absolute inset-x-0 bottom-0 bg-ink/85 py-1.5 text-center text-[11px] font-bold uppercase tracking-[0.1em] text-white">
              Out of stock
            </span>
          )}
        </div>
      </Tilt>

      <h3 className="mt-3 line-clamp-2 text-[13.5px] font-medium leading-snug text-ink-mid">
        {product.name}
      </h3>
      <div className="tnum mt-1.5 flex items-baseline gap-2">
        <span className="text-[16px] font-bold">{formatINR(product.price)}</span>
        {off > 0 && (
          <span className="text-[12.5px] text-ink-mute line-through">
            {formatINR(product.mrp)}
          </span>
        )}
      </div>
      {prepaid > 0 && !product.outOfStock && (
        <p className="tnum mt-1 text-[11.5px] font-semibold text-success">
          {formatINR(prepaid)} off on UPI
        </p>
      )}
    </Link>
  );
}

/* ------------------------------------------------------------------------ */

const CSS = `
@keyframes atz-marquee { from { transform: translateX(0) } to { transform: translateX(-50%) } }
@keyframes atz-float { 0%,100% { transform: translateY(0) } 50% { transform: translateY(-14px) } }

.atz-preview { --atz-ease: cubic-bezier(0.22,1,0.36,1); }
.atz-preview .atz-display {
  font-family: var(--font-display), Georgia, serif;
  font-weight: 500;
  letter-spacing: -0.025em;
}

/* Hero ground: a warm wash with two soft light sources behind it. */
.atz-preview .atz-hero {
  background:
    radial-gradient(120% 90% at 12% 0%, color-mix(in srgb, var(--color-brand) 9%, transparent), transparent 60%),
    linear-gradient(160deg, var(--color-surface) 0%, var(--color-canvas) 70%);
  border: 1px solid var(--color-line);
}
.atz-preview .atz-orb {
  position: absolute; border-radius: 999px; filter: blur(60px);
  pointer-events: none; opacity: .5;
}
.atz-preview .atz-orb-1 {
  width: 340px; height: 340px; top: -110px; right: 8%;
  background: color-mix(in srgb, var(--color-brand) 40%, transparent);
}
.atz-preview .atz-orb-2 {
  width: 260px; height: 260px; bottom: -120px; left: -60px;
  background: color-mix(in srgb, var(--color-gold, #C9A227) 32%, transparent);
}
.atz-preview .atz-orb-3 {
  width: 420px; height: 420px; top: -160px; left: 50%; transform: translateX(-50%);
  background: rgba(255,255,255,.16); filter: blur(70px); opacity: 1;
}

/* Photo stack: five tiles on five planes. */
.atz-preview .atz-stack {
  position: relative; height: 420px; transform-style: preserve-3d;
}
@media (max-width: 640px) { .atz-preview .atz-stack { height: 320px; } }
.atz-preview .atz-tile {
  position: absolute; overflow: hidden; border-radius: 18px;
  border: 1px solid var(--color-line); background: var(--color-canvas);
  box-shadow: 0 18px 40px -22px rgba(26,20,24,.45);
  will-change: transform;
}
.atz-preview .atz-tile-1 { width: 46%; aspect-ratio: 1; top: 0;    left: 2%;  z-index: 3; animation: atz-float 7s ease-in-out infinite; }
.atz-preview .atz-tile-2 { width: 40%; aspect-ratio: 1; top: 8%;   right: 0;  z-index: 2; animation: atz-float 9s ease-in-out infinite .8s; }
.atz-preview .atz-tile-3 { width: 38%; aspect-ratio: 1; bottom: 2%; left: 12%; z-index: 4; animation: atz-float 8s ease-in-out infinite .4s; }
.atz-preview .atz-tile-4 { width: 34%; aspect-ratio: 1; bottom: 8%; right: 6%; z-index: 1; animation: atz-float 10s ease-in-out infinite 1.2s; }
.atz-preview .atz-tile-5 { display: none; }
@media (min-width: 1024px) {
  .atz-preview .atz-tile-5 { display: block; width: 26%; aspect-ratio: 1; top: 40%; left: -6%; z-index: 5; animation: atz-float 11s ease-in-out infinite .2s; }
}
@media (prefers-reduced-motion: reduce) {
  .atz-preview .atz-tile { animation: none !important; }
}

.atz-preview .atz-shine {
  background: linear-gradient(100deg, var(--color-brand), var(--color-brand-deep) 55%, var(--color-brand));
  -webkit-background-clip: text; background-clip: text; color: transparent;
}

.atz-preview .atz-btn {
  display: inline-flex; align-items: center; justify-content: center;
  padding: 14px 30px; border-radius: 999px;
  font-size: 14.5px; font-weight: 700; text-decoration: none;
  transition: transform 260ms var(--atz-ease), box-shadow 260ms var(--atz-ease), background 200ms;
}
.atz-preview .atz-btn:hover { transform: translateY(-2px); }
.atz-preview .atz-btn-primary {
  background: var(--color-brand); color: #fff;
  box-shadow: 0 12px 26px -12px color-mix(in srgb, var(--color-brand) 80%, transparent);
}
.atz-preview .atz-btn-primary:hover { box-shadow: 0 18px 34px -12px color-mix(in srgb, var(--color-brand) 85%, transparent); }
.atz-preview .atz-btn-ghost { border: 1px solid var(--color-ink); color: var(--color-ink); }
.atz-preview .atz-btn-ghost:hover { background: var(--color-ink); color: var(--color-canvas); }
.atz-preview .atz-btn-light { background: #fff; color: var(--color-ink); }

.atz-preview .atz-cat, .atz-preview .atz-card {
  border: 1px solid var(--color-line); background: var(--color-surface);
  box-shadow: 0 10px 30px -20px rgba(26,20,24,.5);
  will-change: transform;
}
.atz-preview .atz-cat-veil {
  position: absolute; inset: 0;
  background: linear-gradient(to top, rgba(20,14,18,.72) 0%, rgba(20,14,18,.12) 45%, transparent 70%);
}
.atz-preview .atz-off {
  position: absolute; left: 10px; top: 10px;
  background: var(--color-brand); color: #fff;
  font-size: 11px; font-weight: 800; letter-spacing: .04em;
  padding: 4px 9px; border-radius: 999px;
}

.atz-preview .atz-band {
  background:
    radial-gradient(90% 120% at 50% 0%, color-mix(in srgb, var(--color-brand) 70%, #2a0f18), #2a0f18);
}
`;
