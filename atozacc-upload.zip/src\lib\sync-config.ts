import { fs } from "@/lib/data-fs";
import path from "node:path";

/** Remembers which sheet to sync from, so the link is pasted once. */

const CONFIG_PATH = path.join(process.cwd(), "data", "sync.json");

export type SyncConfig = {
  productsUrl?: string;
  contentUrl?: string;
  /** Optional tab holding customer testimonials. */
  reviewsUrl?: string;
  lastSyncedAt?: string;
  lastCount?: number;
  /**
   * How often the site re-reads the sheet on its own, in minutes.
   * 0 or absent means never — only the Sync now button.
   */
  autoSyncMinutes?: number;
};

export async function readSyncConfig(): Promise<SyncConfig> {
  try {
    return JSON.parse(await fs.readFile(CONFIG_PATH, "utf8")) as SyncConfig;
  } catch {
    return {};
  }
}

/**
 * Merges into the saved config rather than replacing it.
 *
 * A sync writes back the link and the timestamp; the auto-sync interval is
 * written by a different form. Replacing the file would mean each one silently
 * erased the other's setting.
 */
export async function writeSyncConfig(patch: SyncConfig): Promise<void> {
  const next = { ...(await readSyncConfig()), ...patch };
  await fs.mkdir(path.dirname(CONFIG_PATH), { recursive: true });
  await fs.writeFile(CONFIG_PATH, JSON.stringify(next, null, 2), "utf8");
}
