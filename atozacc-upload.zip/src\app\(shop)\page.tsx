import Image from "next/image";
import Link from "next/link";

import { ProductRail } from "@/components/product-rail";
import { ButtonLink, Container, SectionHeading, StarRating, TrustStrip } from "@/components/ui";
import {
  getCategoryTree,
  getGenders,
  getShowcaseImages,
  listProducts,
} from "@/lib/catalog";
import { formatINR } from "@/lib/money";
import { getSettings } from "@/lib/settings";
import { getReviews } from "@/lib/reviews";
import { getContent, type SiteContent } from "@/lib/site-content";

export const metadata = {
  // `absolute` opts out of the "%s · AtoZacc" template — this title already
  // carries the brand, and the template would print it twice.
  title: { absolute: "AtoZacc — Accessories from A to Z" },
  description:
    "Fashion jewellery, bags, watches, sunglasses and everyday accessories for women, men and kids. Cash on delivery available across India.",
};

export default async function HomePage() {
  const [settings, content] = await Promise.all([getSettings(), getContent()]);

  // Every rail is one query. At this catalogue size they are cheap; when this
  // moves to Postgres they become a single grouped query.
  const [newIn, bestsellers, trending, gifts, combos, festive, tree] = await Promise.all([
    listProducts({ collection: "new-arrivals" }, "newest", 1, 8),
    listProducts({ collection: "bestsellers" }, "bestselling", 1, 8),
    listProducts({ collection: "trending" }, "relevance", 1, 8),
    listProducts({ collection: "gift-collection" }, "relevance", 1, 8),
    listProducts({ collection: "combo-offers" }, "relevance", 1, 8),
    listProducts({ collection: "festive" }, "relevance", 1, 8),
    getCategoryTree(),
  ]);

  const genders = getGenders();
  const topCategories = tree.filter((c) => c.productCount > 0).slice(0, 8);

  // Categories that need their gender spelled out because another tile reads
  // almost the same. Keyed on the FIRST word, not the whole name: the pair
  // that actually confuses people is "Wallets & Purses" next to "Wallets",
  // and those are different strings.
  const headWord = (name: string) => name.split(/[\s&]+/)[0].toLowerCase();
  const headCounts = new Map<string, number>();
  for (const c of topCategories) {
    headCounts.set(headWord(c.name), (headCounts.get(headWord(c.name)) ?? 0) + 1);
  }
  const ambiguous = new Set(
    topCategories
      .filter((c) => (headCounts.get(headWord(c.name)) ?? 0) > 1)
      .map((c) => c.name),
  );

  return (
    <Container className="pb-4">
      <Hero content={content} freeShippingLabel={formatINR(settings.freeShippingThreshold)} />

      <div className="mt-10">
        <TrustStrip
          freeShippingLabel={formatINR(settings.freeShippingThreshold)}
          returnDays={settings.returnWindowDays}
        />
      </div>

      {/* Shop by category */}
      <section className="mt-14">
        <SectionHeading
          title="Shop by category"
          subtitle="Everything from earrings to everyday carry"
          href="/shop"
          linkLabel="All products"
        />
        <div className="grid grid-cols-3 gap-3 sm:grid-cols-4 lg:grid-cols-8">
          {topCategories.map((cat) => (
            <Link key={cat.slug} href={cat.href} className="group text-center">
              <div className="relative aspect-square overflow-hidden rounded-full border border-line bg-surface">
                {cat.image && (
                  <Image
                    src={cat.image}
                    alt=""
                    fill
                    sizes="(max-width: 640px) 30vw, 12vw"
                    className="object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                )}
              </div>
              <p className="mt-2 text-[12px] font-semibold leading-tight text-ink-mid group-hover:text-brand">
                {cat.name}
              </p>
              {/* This rail mixes genders, so "Wallets & Purses" and "Wallets"
                  sit side by side meaning different things. Only the ones
                  that actually collide are labelled — putting the gender on
                  every tile would be noise on the seven that are unique. */}
              {ambiguous.has(cat.name) && (
                <p className="text-[10.5px] uppercase tracking-[0.08em] text-ink-mute">
                  {cat.gender}
                </p>
              )}
            </Link>
          ))}
        </div>
      </section>

      <ProductRail
        title={content.newArrivalsTitle}
        subtitle="Just landed this month"
        href="/new-arrivals"
        products={newIn.items}
      />

      <ProductRail
        title={content.bestsellersTitle}
        subtitle="What people keep coming back for"
        href="/bestsellers"
        products={bestsellers.items}
      />

      {/* Offer band. The prepaid saving is stated as a saving, never as a COD
          penalty — same arithmetic, better conversion. */}
      <OfferBand
        prepaid={formatINR(settings.prepaidDiscount)}
        freeShipping={formatINR(settings.freeShippingThreshold)}
      />

      {/* Shop by gender */}
      <section className="mt-14">
        <SectionHeading title="Shop for" />
        <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
          {genders.map((g) => (
            <Link
              key={g.slug}
              href={`/${g.slug}`}
              className="group relative overflow-hidden rounded-[var(--radius-card)] border border-line bg-surface p-6 transition-colors hover:border-brand"
            >
              <h3 className="font-display text-2xl">{g.name}</h3>
              <p className="mt-1 text-[12.5px] text-ink-mute">{g.tagline}</p>
              <span className="mt-4 inline-block border-b border-brand pb-0.5 text-[12.5px] font-semibold text-brand">
                Shop {g.name}
              </span>
            </Link>
          ))}
        </div>
      </section>

      <ProductRail
        title={content.trendingTitle}
        subtitle="Moving fast this week"
        href="/trending"
        products={trending.items}
      />

      <ProductRail
        title="Gift collection"
        subtitle="Ready to give, boxed and wrapped"
        href="/collections/gift-collection"
        products={gifts.items}
      />

      <ProductRail
        title="Festive edit"
        subtitle="Oxidised, temple and antique-finish pieces"
        href="/collections/festive"
        products={festive.items}
      />

      <ProductRail
        title="Combo offers"
        subtitle="Sets that cost less together"
        href="/collections/combo-offers"
        products={combos.items}
      />

      <Reviews />
      <SocialStrip />
    </Container>
  );
}

/* ------------------------------------------------------------------------ */

async function Hero({
  content,
  freeShippingLabel,
}: {
  content: SiteContent;
  freeShippingLabel: string;
}) {
  // Four real products, one per category, instead of four line drawings. The
  // top of the shop was the one place showing no actual merchandise.
  const heroImages = await getShowcaseImages(4);

  return (
    <section className="mt-6 overflow-hidden rounded-[var(--radius-card)] border border-line bg-surface">
      <div className="grid items-center gap-8 p-7 sm:p-10 lg:grid-cols-[1.05fr_1fr] lg:p-14">
        <div>
          <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-brand">
            {content.heroEyebrow}
          </p>
          <h1 className="mt-4 font-display text-[38px] leading-[1.03] sm:text-[52px]">
            {content.heroHeading}{" "}
            <span className="relative whitespace-nowrap">
              {content.heroHighlight}
              <span
                aria-hidden
                className="absolute inset-x-0 -bottom-1 h-[3px] rounded bg-brand"
              />
            </span>
          </h1>
          <p className="mt-5 max-w-md text-[14.5px] leading-relaxed text-ink-mid">
            {content.heroBody}
          </p>

          <div className="mt-7 flex flex-wrap gap-3">
            <ButtonLink href="/shop" size="lg">
              {content.heroCta}
            </ButtonLink>
            <ButtonLink href="/offers" variant="secondary" size="lg">
              {content.heroCtaSecondary}
            </ButtonLink>
          </div>

          <p className="mt-5 text-[12.5px] text-ink-mute">
            Free shipping over {freeShippingLabel} · Cash on delivery available
          </p>
        </div>

        {/* Product collage rather than a single banner: it shows the range,
            which is the actual selling point of an A-to-Z accessories store. */}
        <div className="grid grid-cols-2 gap-3">
          {heroImages.map((src, i) => (
            <div
              key={src}
              className={`relative aspect-square overflow-hidden rounded-[var(--radius-card)] border border-line bg-canvas ${
                i % 3 === 0 ? "translate-y-3" : ""
              }`}
            >
              <Image
                src={src}
                alt=""
                fill
                sizes="(max-width: 1024px) 45vw, 22vw"
                priority={i < 2}
                className="object-cover"
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

function OfferBand({ prepaid, freeShipping }: { prepaid: string; freeShipping: string }) {
  const offers = [
    { big: prepaid, label: "off when you pay online", sub: "Applied automatically at checkout" },
    { big: freeShipping, label: "for free shipping", sub: "On every order across India" },
    { big: "COD", label: "available", sub: "Pay when the parcel arrives" },
  ];

  return (
    <section className="mt-14 rounded-[var(--radius-card)] bg-blush px-6 py-8 sm:px-10">
      <div className="grid gap-6 sm:grid-cols-3">
        {offers.map((o) => (
          <div key={o.label} className="text-center sm:text-left">
            <p className="tnum font-display text-3xl text-brand-deep">{o.big}</p>
            <p className="mt-0.5 text-[13.5px] font-bold text-ink">{o.label}</p>
            <p className="mt-0.5 text-[12px] text-ink-mute">{o.sub}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

/**
 * Customer testimonials, from the Reviews tab of the sheet.
 *
 * Renders nothing at all when there are none. The previous version shipped
 * three invented customers praising products the shop does not stock, under
 * a heading claiming they came from verified orders — an empty section is
 * infinitely better than a fabricated one.
 */
async function Reviews() {
  const reviews = await getReviews();
  if (reviews.length === 0) return null;

  // Only claim verification where the shop has actually confirmed the order.
  const allVerified = reviews.every((r) => r.verified);

  return (
    <section className="mt-14">
      <SectionHeading
        title="What customers say"
        subtitle={allVerified ? "From verified orders" : undefined}
      />
      <div className="grid gap-4 sm:grid-cols-3">
        {reviews.slice(0, 6).map((r, i) => (
          <figure
            key={`${r.name}-${i}`}
            className="rounded-[var(--radius-card)] border border-line bg-surface p-5"
          >
            <StarRating rating={r.rating} />
            <blockquote className="mt-3 text-[13.5px] leading-relaxed text-ink-mid">
              “{r.body}”
            </blockquote>
            <figcaption className="mt-4 border-t border-line pt-3 text-[12px]">
              <span className="font-bold text-ink">{r.name}</span>
              {r.city && <span className="text-ink-mute"> · {r.city}</span>}
              {r.verified && (
                <span className="ml-1.5 text-[10.5px] font-bold uppercase tracking-[0.06em] text-success">
                  Verified
                </span>
              )}
              {r.product && <p className="mt-0.5 text-ink-mute">{r.product}</p>}
            </figcaption>
          </figure>
        ))}
      </div>
    </section>
  );
}

async function SocialStrip() {
  const tiles = await getShowcaseImages(6);
  if (tiles.length === 0) return null;

  return (
    <section className="mt-14">
      <SectionHeading title="@atozacc" subtitle="Tag us to be featured" />
      <div className="grid grid-cols-3 gap-2 sm:grid-cols-6">
        {tiles.map((src) => (
          <div
            key={src}
            className="relative aspect-square overflow-hidden rounded-[var(--radius-card)] border border-line bg-surface"
          >
            <Image src={src} alt="" fill sizes="(max-width: 640px) 32vw, 16vw" className="object-cover" />
          </div>
        ))}
      </div>
    </section>
  );
}
