import { notFound } from "next/navigation";

import { ProductDetailView } from "@/components/product-detail";
import { ProductListing, type SearchParamsShape } from "@/components/product-listing";
import type { Gender } from "@/data/catalog";
import {
  getCategoryBySegments,
  getGenders,
  getProduct,
  productHref,
} from "@/lib/catalog";

/**
 * One catch-all resolves two different page types, because they collide:
 *
 *   /women/jewellery/earrings                  -> sub-category listing
 *   /women/jewellery/oxidised-silver-jhumka…   -> product detail
 *
 * Both are three segments. A product slug wins if one matches exactly;
 * otherwise the segments are read as a category path. Resolving in this order
 * means a category can never shadow a real product page.
 */

const VALID = new Set(getGenders().map((g) => g.slug));

async function resolve(gender: string, rest: string[]) {
  if (!VALID.has(gender as Gender)) return { kind: "none" } as const;
  if (rest.length === 0 || rest.length > 2) {
    // /gender/a/b/c is deeper than the tree goes.
    if (rest.length > 2) return { kind: "none" } as const;
  }

  const last = rest[rest.length - 1];

  // Product first.
  const product = await getProduct(last);
  if (product) {
    // Canonical guard: the product must actually live at this path, so
    // /men/wallets/oxidised-jhumkas does not render a valid-looking page.
    const canonical = productHref({
      gender: product.gender,
      category: product.categorySlug,
      slug: product.slug,
    });
    if (canonical !== `/${gender}/${rest.join("/")}`) {
      return { kind: "redirect", to: canonical } as const;
    }
    return { kind: "product", product } as const;
  }

  const category = await getCategoryBySegments(gender as Gender, rest);
  if (category) return { kind: "category", category } as const;

  return { kind: "none" } as const;
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ gender: string; rest: string[] }>;
}) {
  const { gender, rest } = await params;
  const found = await resolve(gender, rest);

  if (found.kind === "product") {
    return {
      title: found.product.name,
      description: found.product.shortDescription,
      openGraph: {
        title: found.product.name,
        description: found.product.shortDescription,
        images: [found.product.imageUrl],
      },
    };
  }
  if (found.kind === "category") {
    return {
      title: `${found.category.name} for ${cap(gender)}`,
      description: `Shop ${found.category.name.toLowerCase()} for ${gender} at AtoZacc.`,
    };
  }
  return { title: "Not found" };
}

export default async function GenderCatchAll({
  params,
  searchParams,
}: {
  params: Promise<{ gender: string; rest: string[] }>;
  searchParams: Promise<SearchParamsShape>;
}) {
  const [{ gender, rest }, sp] = await Promise.all([params, searchParams]);
  const found = await resolve(gender, rest);

  if (found.kind === "product") {
    return <ProductDetailView product={found.product} />;
  }

  if (found.kind === "redirect") {
    const { redirect } = await import("next/navigation");
    redirect(found.to);
  }

  if (found.kind === "category") {
    const cat = found.category;
    const crumbs = [{ label: cap(gender), href: `/${gender}` }];
    if (rest.length > 1) {
      crumbs.push({ label: cap(rest[0].replace(/-/g, " ")), href: `/${gender}/${rest[0]}` });
    }
    crumbs.push({ label: cat.name, href: undefined as unknown as string });

    return (
      <ProductListing
        title={cat.name}
        description={`${cat.name} for ${gender}.`}
        breadcrumbs={crumbs}
        searchParams={sp}
        baseFilters={{ gender: gender as Gender, category: cat.slug }}
        emptyAction={{ href: `/${gender}`, label: `Browse all ${gender}` }}
      />
    );
  }

  notFound();
}

function cap(s: string) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}
