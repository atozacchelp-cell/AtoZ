"use server";

import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { z } from "zod";

import { findCoupon } from "@/data/coupons";
import { getCartLines, writeCartCookie } from "@/lib/cart";
import { createOrder, type OrderAddress } from "@/lib/orders";
import { checkCodEligibility, priceCart, type PaymentChoice } from "@/lib/pricing";
import { getSettings } from "@/lib/settings";
import { getSuppliers } from "@/lib/suppliers";

/**
 * Placing an order.
 *
 * The form supplies an address and a payment choice. It supplies NO money.
 * Totals are recomputed here from the cart and the settings store, so a
 * tampered form cannot change what is charged.
 */

const AddressSchema = z.object({
  name: z.string().trim().min(2, "Please enter your full name").max(80),
  mobile: z
    .string()
    .trim()
    .regex(/^[6-9][0-9]{9}$/, "Enter a 10-digit Indian mobile number"),
  email: z.string().trim().email("Enter a valid email").optional().or(z.literal("")),
  line1: z.string().trim().min(1, "House or flat number is required").max(120),
  line2: z.string().trim().max(120).optional(),
  area: z.string().trim().max(120).optional(),
  landmark: z.string().trim().max(120).optional(),
  city: z.string().trim().min(1, "City is required").max(80),
  state: z.string().trim().min(1, "State is required").max(80),
  pincode: z
    .string()
    .trim()
    .regex(/^[1-9][0-9]{5}$/, "Enter a valid 6-digit PIN code"),
});

const CheckoutSchema = z.object({
  payment: z.enum(["PREPAID", "COD", "PARTIAL"]),
  note: z.string().trim().max(500).optional(),
  billingSame: z.string().optional(),
});

export type CheckoutState = {
  errors?: Record<string, string>;
  formError?: string;
};

export async function placeOrder(
  _prev: CheckoutState,
  formData: FormData,
): Promise<CheckoutState> {
  const settings = await getSettings();

  const addressResult = AddressSchema.safeParse({
    name: formData.get("name"),
    mobile: formData.get("mobile"),
    email: formData.get("email") ?? "",
    line1: formData.get("line1"),
    line2: formData.get("line2") ?? "",
    area: formData.get("area") ?? "",
    landmark: formData.get("landmark") ?? "",
    city: formData.get("city"),
    state: formData.get("state"),
    pincode: formData.get("pincode"),
  });

  const checkoutResult = CheckoutSchema.safeParse({
    payment: formData.get("payment"),
    note: formData.get("note") ?? "",
    billingSame: formData.get("billingSame") ?? undefined,
  });

  if (!addressResult.success || !checkoutResult.success) {
    const errors: Record<string, string> = {};
    if (!addressResult.success) {
      for (const issue of addressResult.error.issues) {
        const key = String(issue.path[0]);
        errors[key] ??= issue.message;
      }
    }
    if (!checkoutResult.success) errors.payment = "Choose a payment method";
    return { errors };
  }

  const { active } = await getCartLines();

  if (active.length === 0) {
    return { formError: "Your cart is empty." };
  }
  if (active.some((l) => l.outOfStock)) {
    return { formError: "An item in your cart is out of stock. Please remove it." };
  }

  const store = await cookies();
  const coupon = findCoupon(store.get("atz_coupon")?.value);
  const payment = checkoutResult.data.payment as PaymentChoice;

  // Priced twice on purpose: once to know the cart total for the COD rules,
  // then again with the chosen method so fees and discounts land correctly.
  const provisional = priceCart({ lines: active, settings, payment: "PREPAID", coupon });

  if (payment === "COD") {
    // Re-checked on the server: the checkout page only decides what to SHOW.
    const suppliers = await getSuppliers();
    const eligibility = checkCodEligibility(active, provisional.total, settings, {
      suppliersWithoutCod: suppliers.filter((s) => !s.acceptsCod).map((s) => s.name),
    });
    if (!eligibility.allowed) {
      return { formError: eligibility.reason };
    }
  }

  if (payment === "PARTIAL" && !settings.partialPaymentEnabled) {
    return { formError: "Partial payment isn't available right now." };
  }

  const breakdown = priceCart({ lines: active, settings, payment, coupon });

  const address: OrderAddress = {
    ...addressResult.data,
    email: addressResult.data.email || undefined,
    country: "India",
  };

  const order = await createOrder({
    breakdown,
    payment,
    shippingAddress: address,
    billingAddress: address,
    customerNote: checkoutResult.data.note || undefined,
    orderNumberPrefix: settings.orderNumberPrefix,
  });

  await writeCartCookie([]);
  store.delete("atz_coupon");

  if (payment === "PREPAID" || payment === "PARTIAL") {
    redirect(`/checkout/payment/${order.orderNumber}`);
  } else {
    redirect(`/order/success/${order.orderNumber}`);
  }
}
