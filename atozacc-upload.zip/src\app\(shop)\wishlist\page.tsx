import { ProductGrid, ProductRail } from "@/components/product-rail";
import { Breadcrumbs, Container, EmptyState } from "@/components/ui";
import { readWishlist } from "@/lib/cart";
import { getProduct, listProducts, type ProductListItem } from "@/lib/catalog";

export const metadata = {
  title: "Wishlist",
  robots: { index: false },
};

export default async function WishlistPage() {
  const slugs = await readWishlist();

  const products = (
    await Promise.all(slugs.map((slug) => getProduct(slug)))
  ).filter((p): p is NonNullable<typeof p> => p !== null);

  if (products.length === 0) {
    const suggestions = await listProducts({ collection: "trending" }, "relevance", 1, 4);
    return (
      <Container className="py-8">
        <Breadcrumbs items={[{ label: "Wishlist" }]} />
        <EmptyState
          title="Nothing saved yet"
          body="Tap the heart on any product to keep it here for later."
          action={{ href: "/shop", label: "Browse products" }}
        />
        <ProductRail title="Trending now" products={suggestions.items} />
      </Container>
    );
  }

  // ProductDetail extends ProductListItem, so it renders in the grid directly.
  const items: ProductListItem[] = products;

  return (
    <Container className="py-6">
      <Breadcrumbs items={[{ label: "Wishlist" }]} />
      <h1 className="font-display text-[30px] sm:text-[36px]">Wishlist</h1>
      <p className="tnum mt-1.5 text-[13.5px] text-ink-mute">
        {items.length} {items.length === 1 ? "item" : "items"} saved
      </p>
      <div className="mt-7">
        <ProductGrid products={items} />
      </div>
    </Container>
  );
}
