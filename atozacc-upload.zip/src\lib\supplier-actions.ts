"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";

import { deleteSupplier, saveSupplier } from "@/lib/suppliers";

export type SupplierState = { ok?: boolean; error?: string };

const Schema = z.object({
  name: z.string().trim().min(1, "Give the supplier a name").max(60),
  contactName: z.string().trim().max(60).optional(),
  email: z.string().trim().max(120).optional(),
  phone: z.string().trim().max(20).optional(),
  whatsapp: z.string().trim().max(20).optional(),
  city: z.string().trim().max(60).optional(),
  dispatchDays: z.coerce.number().int().min(0).max(30),
  acceptsCod: z.string().optional(),
  notes: z.string().trim().max(400).optional(),
});

export async function upsertSupplier(
  _prev: SupplierState,
  formData: FormData,
): Promise<SupplierState> {
  const parsed = Schema.safeParse({
    name: formData.get("name"),
    contactName: formData.get("contactName") ?? "",
    email: formData.get("email") ?? "",
    phone: formData.get("phone") ?? "",
    whatsapp: formData.get("whatsapp") ?? "",
    city: formData.get("city") ?? "",
    dispatchDays: formData.get("dispatchDays") ?? 2,
    acceptsCod: formData.get("acceptsCod") ?? undefined,
    notes: formData.get("notes") ?? "",
  });

  if (!parsed.success) {
    return { error: parsed.error.issues[0]?.message ?? "Those details were not valid." };
  }

  const d = parsed.data;
  await saveSupplier({
    name: d.name,
    contactName: d.contactName || undefined,
    email: d.email || undefined,
    phone: d.phone || undefined,
    whatsapp: d.whatsapp || undefined,
    city: d.city || undefined,
    dispatchDays: d.dispatchDays,
    acceptsCod: d.acceptsCod === "on",
    notes: d.notes || undefined,
  });

  // Supplier terms change delivery estimates and COD availability on the
  // storefront, so the whole site revalidates rather than just this page.
  revalidatePath("/", "layout");
  revalidatePath("/admin/suppliers");

  return { ok: true };
}

export async function removeSupplier(formData: FormData): Promise<void> {
  const name = String(formData.get("name") ?? "");
  if (!name) return;
  await deleteSupplier(name);
  revalidatePath("/", "layout");
  revalidatePath("/admin/suppliers");
}
