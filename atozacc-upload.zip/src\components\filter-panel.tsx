"use client";

import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";

import { cn } from "@/lib/cn";
import { formatINR } from "@/lib/money";
import type { Facets } from "@/lib/catalog";
import { SORT_OPTIONS } from "@/lib/catalog-constants";

/**
 * Filters live in the URL, not in component state. That makes a filtered grid
 * shareable, back-button-correct and indexable, and it means the server does
 * the filtering — the client never holds a second copy of the catalogue.
 */

function useQueryUpdater() {
  const router = useRouter();
  const pathname = usePathname();
  const params = useSearchParams();

  return (mutate: (p: URLSearchParams) => void) => {
    const next = new URLSearchParams(params.toString());
    mutate(next);
    next.delete("page"); // any filter change returns to page 1
    const qs = next.toString();
    router.push(qs ? `${pathname}?${qs}` : pathname, { scroll: false });
  };
}

function toggleValue(params: URLSearchParams, key: string, value: string) {
  const current = params.getAll(key);
  params.delete(key);
  const next = current.includes(value)
    ? current.filter((v) => v !== value)
    : [...current, value];
  for (const v of next) params.append(key, v);
}

export function SortSelect() {
  const params = useSearchParams();
  const update = useQueryUpdater();
  const current = params.get("sort") ?? "relevance";

  return (
    <label className="flex items-center gap-2 text-[12.5px] text-ink-mute">
      <span className="hidden sm:inline">Sort</span>
      <select
        value={current}
        onChange={(e) =>
          update((p) => {
            if (e.target.value === "relevance") p.delete("sort");
            else p.set("sort", e.target.value);
          })
        }
        className="rounded-[var(--radius-card)] border border-line bg-canvas px-2.5 py-1.5 text-[12.5px] font-medium text-ink focus:border-brand focus:outline-none"
      >
        {SORT_OPTIONS.map((o) => (
          <option key={o.key} value={o.key}>
            {o.label}
          </option>
        ))}
      </select>
    </label>
  );
}

export function FilterPanel({
  facets,
  totalCount,
}: {
  facets: Facets;
  totalCount: number;
}) {
  const params = useSearchParams();
  const update = useQueryUpdater();
  const [openOnMobile, setOpenOnMobile] = useState(false);

  const activeCount =
    params.getAll("colour").length +
    params.getAll("size").length +
    params.getAll("material").length +
    (params.get("maxPrice") ? 1 : 0) +
    (params.get("minRating") ? 1 : 0) +
    (params.get("minDiscount") ? 1 : 0) +
    (params.get("inStock") ? 1 : 0);

  const priceBands = buildPriceBands(facets.priceMin, facets.priceMax);

  const body = (
    <div className="space-y-6">
      {activeCount > 0 && (
        <button
          type="button"
          onClick={() =>
            update((p) => {
              for (const k of [
                "colour",
                "size",
                "material",
                "minPrice",
                "maxPrice",
                "minRating",
                "minDiscount",
                "inStock",
              ]) {
                p.delete(k);
              }
            })
          }
          className="text-[12.5px] font-semibold text-brand hover:text-brand-deep"
        >
          Clear all filters ({activeCount})
        </button>
      )}

      <Group title="Price">
        {priceBands.map((band) => {
          const checked = params.get("maxPrice") === String(band.max);
          return (
            <Check
              key={band.label}
              label={band.label}
              checked={checked}
              onChange={() =>
                update((p) => {
                  if (checked) {
                    p.delete("maxPrice");
                  } else {
                    p.set("maxPrice", String(band.max));
                  }
                })
              }
            />
          );
        })}
      </Group>

      {facets.colours.length > 0 && (
        <Group title="Colour">
          {facets.colours.map((c) => (
            <Check
              key={c.value}
              label={c.value}
              count={c.count}
              checked={params.getAll("colour").includes(c.value)}
              onChange={() => update((p) => toggleValue(p, "colour", c.value))}
            />
          ))}
        </Group>
      )}

      {facets.sizes.length > 0 && (
        <Group title="Size">
          {facets.sizes.map((s) => (
            <Check
              key={s.value}
              label={s.value}
              count={s.count}
              checked={params.getAll("size").includes(s.value)}
              onChange={() => update((p) => toggleValue(p, "size", s.value))}
            />
          ))}
        </Group>
      )}

      {facets.materials.length > 0 && (
        <Group title="Material">
          {facets.materials.map((m) => (
            <Check
              key={m.value}
              label={m.value}
              count={m.count}
              checked={params.getAll("material").includes(m.value)}
              onChange={() => update((p) => toggleValue(p, "material", m.value))}
            />
          ))}
        </Group>
      )}

      <Group title="Discount">
        {[20, 30, 40, 50].map((d) => (
          <Check
            key={d}
            label={`${d}% and above`}
            checked={params.get("minDiscount") === String(d)}
            onChange={() =>
              update((p) =>
                params.get("minDiscount") === String(d)
                  ? p.delete("minDiscount")
                  : p.set("minDiscount", String(d)),
              )
            }
          />
        ))}
      </Group>

      <Group title="Rating">
        {[4, 3].map((r) => (
          <Check
            key={r}
            label={`${r}★ and above`}
            checked={params.get("minRating") === String(r)}
            onChange={() =>
              update((p) =>
                params.get("minRating") === String(r)
                  ? p.delete("minRating")
                  : p.set("minRating", String(r)),
              )
            }
          />
        ))}
      </Group>

      <Group title="Availability">
        <Check
          label="In stock only"
          checked={params.get("inStock") === "1"}
          onChange={() =>
            update((p) =>
              params.get("inStock") === "1" ? p.delete("inStock") : p.set("inStock", "1"),
            )
          }
        />
      </Group>
    </div>
  );

  return (
    <>
      {/* Mobile: a bottom sheet, not a sidebar. A sidebar on a 375px screen
          leaves no room for the grid it is filtering. */}
      <button
        type="button"
        onClick={() => setOpenOnMobile(true)}
        className="flex items-center gap-2 rounded-[var(--radius-card)] border border-line px-3 py-1.5 text-[12.5px] font-semibold lg:hidden"
      >
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" aria-hidden>
          <path d="M3 6h18M6 12h12M10 18h4" />
        </svg>
        Filters
        {activeCount > 0 && (
          <span className="tnum grid h-[17px] min-w-[17px] place-items-center rounded-full bg-brand px-1 text-[10px] text-white">
            {activeCount}
          </span>
        )}
      </button>

      {openOnMobile && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <button
            type="button"
            aria-label="Close filters"
            className="absolute inset-0 bg-ink/40"
            onClick={() => setOpenOnMobile(false)}
          />
          <div className="absolute inset-x-0 bottom-0 max-h-[82vh] overflow-y-auto rounded-t-2xl bg-canvas p-5">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-display text-lg">Filters</h2>
              <button
                type="button"
                onClick={() => setOpenOnMobile(false)}
                className="text-[12.5px] font-semibold text-ink-mute"
              >
                Close
              </button>
            </div>
            {body}
            <button
              type="button"
              onClick={() => setOpenOnMobile(false)}
              className="mt-6 w-full rounded-[var(--radius-card)] bg-brand py-3 text-[14px] font-semibold text-white"
            >
              Show {totalCount} {totalCount === 1 ? "product" : "products"}
            </button>
          </div>
        </div>
      )}

      <aside className="hidden lg:block">{body}</aside>
    </>
  );
}

function Group({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="mb-2 text-[11px] font-bold uppercase tracking-[0.1em] text-ink">
        {title}
      </h3>
      <div className="space-y-1">{children}</div>
    </div>
  );
}

function Check({
  label,
  count,
  checked,
  onChange,
}: {
  label: string;
  count?: number;
  checked: boolean;
  onChange: () => void;
}) {
  return (
    <label className="flex cursor-pointer items-center gap-2 py-0.5 text-[13px]">
      <input
        type="checkbox"
        checked={checked}
        onChange={onChange}
        className="h-3.5 w-3.5 shrink-0 accent-[--color-brand]"
      />
      <span className={cn("flex-1", checked ? "font-semibold text-ink" : "text-ink-mid")}>
        {label}
      </span>
      {count !== undefined && <span className="tnum text-[11.5px] text-ink-mute">{count}</span>}
    </label>
  );
}

/** Bands adapt to what the current result set actually contains. */
function buildPriceBands(min: number, max: number) {
  const candidates = [19_900, 29_900, 49_900, 99_900, 199_900, 299_900];
  return candidates
    .filter((c) => c > min && c < max * 1.5)
    .map((c) => ({ label: `Under ${formatINR(c)}`, max: c }));
}
