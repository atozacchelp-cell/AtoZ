"use server";

import { normaliseImageUrl } from "@/lib/google";

/**
 * Lists the files in a publicly shared Google Drive folder.
 *
 * A folder link is not enough to put photos on products — each product needs
 * its own image URL. This reads the folder once and hands back a filename →
 * URL table, so the links can be pasted into the sheet in one go instead of
 * copying "Get link" a hundred times.
 *
 * CAVEAT, stated plainly because it matters: this reads Drive's
 * `embeddedfolderview` page, which Google publishes for embedding but does
 * not document as an API. It works today and could change without notice.
 * Nothing else in the store depends on it — it is a one-time convenience for
 * filling the sheet, and if it ever breaks, per-photo "Get link" still works.
 */

export type DriveFile = { name: string; id: string; url: string };

export type FolderListResult =
  | { ok: true; files: DriveFile[]; folderId: string }
  | { ok: false; error: string };

export async function extractFolderId(input: string): Promise<string | null> {
  const raw = input.trim();
  if (!raw) return null;

  return (
    raw.match(/\/folders\/([a-zA-Z0-9-_]+)/)?.[1] ??
    raw.match(/[?&]id=([a-zA-Z0-9-_]+)/)?.[1] ??
    (/^[a-zA-Z0-9-_]{20,}$/.test(raw) ? raw : null)
  );
}

const IMAGE_EXT = /\.(jpe?g|png|webp|avif|gif|heic)$/i;

export async function listDriveFolder(input: string): Promise<FolderListResult> {
  const folderId = await extractFolderId(input);
  if (!folderId) {
    return {
      ok: false,
      error:
        "That does not look like a Drive folder link. It should contain /folders/ — open the folder in Drive and copy the address bar link.",
    };
  }

  let html: string;
  try {
    const res = await fetch(
      `https://drive.google.com/embeddedfolderview?id=${folderId}#list`,
      { cache: "no-store", headers: { "User-Agent": "Mozilla/5.0 AtoZacc-Sync" } },
    );

    if (res.status === 404) {
      return { ok: false, error: "That folder does not exist. Check the link." };
    }
    if (!res.ok) {
      return { ok: false, error: `Google returned ${res.status} for that folder.` };
    }

    html = await res.text();
  } catch (e) {
    return {
      ok: false,
      error: `Could not reach Google Drive: ${e instanceof Error ? e.message : "network error"}`,
    };
  }

  // Each entry looks like:  <div class="flip-entry" id="entry-{FILE_ID}">
  //   … <div class="flip-entry-title">name.jpg</div>
  const files: DriveFile[] = [];
  const seen = new Set<string>();

  const entryPattern = /id="entry-([a-zA-Z0-9-_]+)"[\s\S]*?flip-entry-title[^>]*>([^<]+)</g;
  let match: RegExpExecArray | null;

  while ((match = entryPattern.exec(html)) !== null) {
    const [, id, rawName] = match;
    if (seen.has(id)) continue;
    seen.add(id);

    const name = decodeHtml(rawName.trim());
    // Folders and stray files appear here too; only images are useful.
    if (!IMAGE_EXT.test(name)) continue;

    files.push({
      name,
      id,
      url: normaliseImageUrl(`https://drive.google.com/file/d/${id}/view`),
    });
  }

  if (files.length === 0) {
    // An unshared folder returns a page with no entries rather than a 403,
    // so an empty result is much more likely a sharing problem than an
    // actually empty folder. Say the likely cause, not just the symptom.
    return {
      ok: false,
      error:
        'No images found. Either the folder is empty, or it is not shared — open it in Drive, click Share, and set "Anyone with the link" as Viewer.',
    };
  }

  files.sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));

  return { ok: true, files, folderId };
}

function decodeHtml(s: string): string {
  return s
    .replace(/&amp;/g, "&")
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&nbsp;/g, " ");
}
