import Image from "next/image";
import Link from "next/link";

import { AddToCartForm } from "@/components/add-to-cart-form";
import { PincodeCheck } from "@/components/pincode-check";
import { ProductRail } from "@/components/product-rail";
import { Breadcrumbs, Container, StarRating } from "@/components/ui";
import { readWishlist } from "@/lib/cart";
import { getRelatedProducts, type ProductDetail as Detail } from "@/lib/catalog";
import { formatINR } from "@/lib/money";
import { getSettings } from "@/lib/settings";
import { deliveryEstimate, findSupplier } from "@/lib/suppliers";

export async function ProductDetailView({ product }: { product: Detail }) {
  const [settings, related, wishlist, supplier] = await Promise.all([
    getSettings(),
    getRelatedProducts(product),
    readWishlist(),
    findSupplier(product.supplier),
  ]);

  // A dropshipped item waits on the supplier before it even reaches a
  // courier, so its estimate must be longer than your own stock. Showing the
  // same dates for both is a promise the second one cannot keep.
  const dispatchDays =
    product.dispatchDays ?? supplier?.dispatchDays ?? (product.fulfilment === "dropship" ? 2 : 0);
  const ncr = deliveryEstimate(dispatchDays, "ncr");
  const metro = deliveryEstimate(dispatchDays, "metro");
  const rest = deliveryEstimate(dispatchDays, "rest");

  const saving = product.mrp - product.price;

  // Product schema for rich results. Built from the same values shown on the
  // page — if the badge says in stock, the markup says in stock.
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: product.name,
    description: product.shortDescription,
    sku: product.sku,
    image: product.imageUrl,
    brand: { "@type": "Brand", name: "AtoZacc" },
    offers: {
      "@type": "Offer",
      price: (product.price / 100).toFixed(2),
      priceCurrency: "INR",
      availability: product.outOfStock
        ? "https://schema.org/OutOfStock"
        : "https://schema.org/InStock",
    },
    ...(product.rating && product.reviewCount && product.reviewCount >= 3
      ? {
          aggregateRating: {
            "@type": "AggregateRating",
            ratingValue: product.rating,
            reviewCount: product.reviewCount,
          },
        }
      : {}),
  };

  return (
    <Container className="py-6">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      <Breadcrumbs
        items={[
          { label: capitalise(product.gender), href: `/${product.gender}` },
          { label: product.categoryName },
          { label: product.name },
        ]}
      />

      <div className="lg:grid lg:grid-cols-2 lg:gap-12">
        {/* Gallery */}
        <div>
          <div className="relative aspect-square overflow-hidden rounded-[var(--radius-card)] border border-line bg-surface">
            <Image
              src={product.imageUrl}
              alt={product.name}
              fill
              priority
              sizes="(max-width: 1024px) 100vw, 45vw"
              className="object-cover"
            />
            {product.outOfStock && (
              <div className="absolute inset-x-0 bottom-0 bg-ink/85 py-2 text-center text-[12px] font-bold uppercase tracking-[0.1em] text-white">
                Out of stock
              </div>
            )}
          </div>

          {/* Thumbnails only when there is genuinely more than one photo.
              Repeating the same image four times pretends at a gallery the
              product does not have. */}
          {product.images.length > 1 && (
            <div className="mt-3 grid grid-cols-4 gap-3">
              {product.images.slice(0, 8).map((src, i) => (
                <div
                  key={`${src}-${i}`}
                  className="relative aspect-square overflow-hidden rounded-[var(--radius-card)] border border-line bg-surface"
                >
                  <Image
                    src={src}
                    alt={`${product.name} — view ${i + 1}`}
                    fill
                    sizes="12vw"
                    className="object-cover"
                  />
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Detail */}
        <div className="mt-8 lg:mt-0">
          <h1 className="font-display text-[27px] leading-[1.15] sm:text-[32px]">
            {product.name}
          </h1>

          <p className="mt-2 text-[14px] text-ink-mid">{product.shortDescription}</p>

          {product.rating && product.reviewCount && product.reviewCount >= 3 && (
            <div className="mt-3">
              <StarRating rating={product.rating} count={product.reviewCount} />
            </div>
          )}

          <div className="tnum mt-5 flex flex-wrap items-baseline gap-3">
            <span className="font-display text-[32px] leading-none">
              {formatINR(product.price)}
            </span>
            {saving > 0 && (
              <>
                <span className="text-[16px] text-ink-mute line-through">
                  {formatINR(product.mrp)}
                </span>
                <span className="text-[15px] font-bold text-brand">
                  {product.discount}% off
                </span>
              </>
            )}
          </div>

          {saving > 0 && (
            <p className="tnum mt-1 text-[12.5px] text-success">
              You save {formatINR(saving)}
            </p>
          )}

          <p className="mt-1 text-[11.5px] text-ink-mute">
            {settings.gstRegistered
              ? "Inclusive of all taxes"
              : "Price inclusive of all applicable taxes"}
          </p>

          <AddToCartForm
            slug={product.slug}
            colours={product.colours}
            sizes={product.sizes}
            sizeStock={product.sizeStock}
            outOfStock={product.outOfStock}
            stock={product.stock}
            inWishlist={wishlist.includes(product.slug)}
          />

          {product.sizeChart && <SizeChartTable chart={product.sizeChart} />}

          <PincodeCheck
            codAllowed={product.isCodAllowed && settings.codEnabled}
            freeShippingLabel={formatINR(settings.freeShippingThreshold)}
          />

          {/* Delivery and returns, stated plainly on the page rather than
              buried in a policy nobody opens before buying. */}
          <dl className="mt-6 space-y-2 border-t border-line pt-5 text-[13px]">
            <Row
              label="Delivery"
              value={`Delhi NCR ${ncr.label} · Metros ${metro.label} · Rest of India ${rest.label}`}
            />
            <Row
              label="Shipping"
              value={`Free over ${formatINR(settings.freeShippingThreshold)}, else ${formatINR(settings.standardShippingRate)}`}
            />
            <Row
              label="Returns"
              value={
                product.isReturnable
                  ? `${settings.returnWindowDays}-day returns and exchanges`
                  : "Not returnable — hygiene and personalised items"
              }
            />
            {settings.codEnabled && (
              <Row
                label="Cash on delivery"
                value={
                  !product.isCodAllowed
                    ? "Not available on this item"
                    : supplier && !supplier.acceptsCod
                      ? "Not available — this item ships from a supplier"
                      : `Available · ${formatINR(settings.codFee)} fee`
                }
              />
            )}
          </dl>

          {!product.isReturnable && (
            <p className="mt-4 rounded-[var(--radius-card)] border border-line bg-surface px-3.5 py-2.5 text-[12.5px] text-ink-mid">
              This item cannot be returned once delivered. Please check the size
              and colour before ordering.
            </p>
          )}
        </div>
      </div>

      {/* Description */}
      <section className="mt-14 grid gap-10 lg:grid-cols-2">
        <div>
          <h2 className="font-display text-2xl">Details</h2>
          <p className="mt-3 max-w-prose text-[14px] leading-relaxed text-ink-mid">
            {product.description}
          </p>

          {product.features.length > 0 && (
            <ul className="mt-5 space-y-1.5">
              {product.features.map((f) => (
                <li key={f} className="flex gap-2 text-[13.5px] text-ink-mid">
                  <span aria-hidden className="text-brand">
                    ·
                  </span>
                  {f}
                </li>
              ))}
            </ul>
          )}

          {product.care && (
            <>
              <h3 className="mt-6 text-[11px] font-bold uppercase tracking-[0.11em] text-ink-mute">
                Care
              </h3>
              <p className="mt-1.5 text-[13.5px] text-ink-mid">{product.care}</p>
            </>
          )}
        </div>

        <div>
          <h2 className="font-display text-2xl">Specifications</h2>
          <div className="mt-3 overflow-hidden rounded-[var(--radius-card)] border border-line">
            <table className="w-full text-[13px]">
              <tbody>
                <Spec label="SKU" value={product.sku} />
                <Spec label="Category" value={product.categoryName} />
                {product.material && <Spec label="Material" value={product.material} />}
                {product.colours.length > 0 && (
                  <Spec label="Colours" value={product.colours.join(", ")} />
                )}
                {product.sizes.length > 0 && (
                  <Spec label="Sizes" value={product.sizes.join(", ")} />
                )}
                <Spec label="Weight" value={`${product.weightG} g`} />
                <Spec label="Country of origin" value="India" last />
              </tbody>
            </table>
          </div>

          {product.collections.length > 0 && (
            <div className="mt-5 flex flex-wrap gap-2">
              {product.collections.map((c) => (
                <Link
                  key={c}
                  href={`/collections/${c}`}
                  className="rounded-[var(--radius-pill)] border border-line px-3 py-1 text-[12px] text-ink-mute hover:border-brand hover:text-brand"
                >
                  {c.replace(/-/g, " ")}
                </Link>
              ))}
            </div>
          )}
        </div>
      </section>

      <ProductRail title="You may also like" products={related} />
    </Container>
  );
}

/**
 * The measurements table, collapsed by default.
 *
 * In India a "large" varies by several inches between brands, so the size a
 * customer normally wears tells them nothing. Measurements do — and a wrong
 * size is a return, which on a ₹400 t-shirt costs more than the margin. It
 * sits behind a summary because it matters intensely to the person about to
 * buy and not at all to anyone else.
 */
function SizeChartTable({
  chart,
}: {
  chart: { headers: string[]; rows: string[][] };
}) {
  return (
    <details className="group mt-4 rounded-[var(--radius-card)] border border-line bg-surface">
      <summary className="cursor-pointer list-none px-4 py-3 text-[13px] font-semibold text-ink-mid hover:text-brand">
        <span className="inline-flex items-center gap-2">
          <svg
            width="13"
            height="13"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="2.2"
            strokeLinecap="round"
            className="transition-transform group-open:rotate-90"
            aria-hidden
          >
            <path d="M9 6l6 6-6 6" />
          </svg>
          Size guide &amp; measurements
        </span>
      </summary>

      {/* A measurements table is wider than a phone. It scrolls inside its own
          box so the page itself never does. */}
      <div className="overflow-x-auto border-t border-line">
        <table className="w-full min-w-[320px] text-[12.5px]">
          <thead>
            <tr className="bg-canvas text-left">
              {chart.headers.map((h) => (
                <th
                  key={h}
                  scope="col"
                  className="whitespace-nowrap px-3.5 py-2 font-bold uppercase tracking-[0.06em] text-[11px] text-ink-mute"
                >
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {chart.rows.map((row, i) => (
              <tr key={i} className="border-t border-line">
                {row.map((cell, j) => (
                  <td
                    key={j}
                    className={
                      j === 0
                        ? "whitespace-nowrap px-3.5 py-2 font-semibold"
                        : "tnum whitespace-nowrap px-3.5 py-2 text-ink-mid"
                    }
                  >
                    {cell || "—"}
                  </td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <p className="px-4 py-2.5 text-[11.5px] text-ink-mute">
        Measured flat, in inches. Allow up to half an inch either way.
      </p>
    </details>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex gap-3">
      <dt className="w-[110px] shrink-0 font-semibold text-ink">{label}</dt>
      <dd className="text-ink-mid">{value}</dd>
    </div>
  );
}

function Spec({ label, value, last }: { label: string; value: string; last?: boolean }) {
  return (
    <tr className={last ? "" : "border-b border-line"}>
      <td className="w-[42%] bg-surface px-3.5 py-2.5 font-medium text-ink-mid">{label}</td>
      <td className="px-3.5 py-2.5">{value}</td>
    </tr>
  );
}

function capitalise(s: string) {
  return s.charAt(0).toUpperCase() + s.slice(1);
}
