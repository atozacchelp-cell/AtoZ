import QRCode from "qrcode";

/**
 * UPI payment links and QR codes.
 *
 * A printed static QR asks the customer to type the amount themselves, which
 * they get wrong often enough to matter — and a ₹50 shortfall on a ₹499 order
 * costs more to chase than it is worth. A per-order UPI link carries the exact
 * amount and the order number, so the payment arrives correct and identifiable.
 */

export type UpiParams = {
  upiId: string;
  payeeName: string;
  /** Paise. Converted to rupees for the link, which UPI expects. */
  amountPaise: number;
  orderNumber: string;
};

/** Rejects obviously wrong ids before they reach a customer's UPI app. */
export function isValidUpiId(id: string): boolean {
  return /^[a-zA-Z0-9.\-_]{2,64}@[a-zA-Z]{2,32}$/.test(id.trim());
}

/**
 * Builds the `upi://pay` deep link.
 *
 * On a phone this opens GPay / PhonePe / Paytm directly with everything
 * filled in. On a desktop it is the payload encoded into the QR.
 */
export function buildUpiLink({
  upiId,
  payeeName,
  amountPaise,
  orderNumber,
}: UpiParams): string {
  const rupees = (amountPaise / 100).toFixed(2);

  const params = new URLSearchParams({
    pa: upiId.trim(),
    pn: payeeName.trim(),
    am: rupees,
    cu: "INR",
    // Shown in the customer's app and on your statement, so a payment can be
    // matched to an order without asking them.
    tn: `Order ${orderNumber}`,
  });

  return `upi://pay?${params.toString()}`;
}

/** Renders the link as a QR data URI, for scanning from another device. */
export async function buildUpiQr(params: UpiParams): Promise<string> {
  return QRCode.toDataURL(buildUpiLink(params), {
    errorCorrectionLevel: "M",
    margin: 1,
    width: 480,
    color: { dark: "#1a1418", light: "#ffffff" },
  });
}

/**
 * A UPI reference (UTR) is 12 digits. Checking the shape catches a customer
 * pasting the wrong thing, but it proves nothing about whether money moved —
 * only your bank statement does.
 */
export function looksLikeUtr(ref: string): boolean {
  return /^[0-9]{12}$/.test(ref.trim());
}
