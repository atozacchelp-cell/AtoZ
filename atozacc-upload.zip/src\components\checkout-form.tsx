"use client";

import { useActionState, useState } from "react";

import { OrderSummary } from "@/components/order-summary";
import { placeOrder, type CheckoutState } from "@/lib/checkout-action";
import { cn } from "@/lib/cn";
import { formatINR } from "@/lib/money";
import type { PriceBreakdown } from "@/lib/pricing";

const INDIAN_STATES = [
  "Andhra Pradesh", "Arunachal Pradesh", "Assam", "Bihar", "Chhattisgarh", "Delhi",
  "Goa", "Gujarat", "Haryana", "Himachal Pradesh", "Jharkhand", "Karnataka", "Kerala",
  "Madhya Pradesh", "Maharashtra", "Manipur", "Meghalaya", "Mizoram", "Nagaland",
  "Odisha", "Punjab", "Rajasthan", "Sikkim", "Tamil Nadu", "Telangana", "Tripura",
  "Uttar Pradesh", "Uttarakhand", "West Bengal", "Andaman and Nicobar Islands",
  "Chandigarh", "Dadra and Nagar Haveli and Daman and Diu", "Jammu and Kashmir",
  "Ladakh", "Lakshadweep", "Puducherry",
];

export type PaymentOption = {
  value: "PREPAID" | "COD" | "PARTIAL";
  title: string;
  body: string;
  badge?: string;
  disabled?: boolean;
  disabledReason?: string;
};

export function CheckoutForm({
  breakdowns,
  paymentOptions,
  defaultPayment,
}: {
  /** One priced breakdown per payment method, computed on the server. */
  breakdowns: Record<string, PriceBreakdown>;
  paymentOptions: PaymentOption[];
  defaultPayment: "PREPAID" | "COD" | "PARTIAL";
}) {
  const [state, formAction, pending] = useActionState<CheckoutState, FormData>(
    placeOrder,
    {},
  );
  const [payment, setPayment] = useState(defaultPayment);

  // The summary updates as the method changes, because the COD fee and the
  // prepaid discount both move the total. Showing one number and charging
  // another is how carts get abandoned at the last step.
  const breakdown = breakdowns[payment] ?? breakdowns[defaultPayment];
  const payNow =
    payment === "COD" ? 0 : breakdown.isPartial ? breakdown.advanceAmount : breakdown.total;
  const payLater = breakdown.total - payNow;

  const err = (field: string) => state.errors?.[field];

  return (
    <form action={formAction} className="lg:grid lg:grid-cols-[minmax(0,1fr)_340px] lg:gap-10">
      <div className="min-w-0 space-y-8">
        {state.formError && (
          <p role="alert" className="rounded-[var(--radius-card)] border border-brand bg-blush px-4 py-3 text-[13.5px] font-medium text-brand-deep">
            {state.formError}
          </p>
        )}

        <section>
          <h2 className="font-display text-xl">Contact</h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <Field label="Full name" name="name" error={err("name")} autoComplete="name" required />
            <Field
              label="Mobile number"
              name="mobile"
              error={err("mobile")}
              inputMode="numeric"
              maxLength={10}
              autoComplete="tel-national"
              hint="For delivery updates"
              required
            />
            <div className="sm:col-span-2">
              <Field
                label="Email"
                name="email"
                type="email"
                error={err("email")}
                autoComplete="email"
                hint="Optional — for the order confirmation and invoice"
              />
            </div>
          </div>
        </section>

        <section>
          <h2 className="font-display text-xl">Delivery address</h2>
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <Field label="House / Flat number" name="line1" error={err("line1")} autoComplete="address-line1" required />
            <Field label="Street" name="line2" error={err("line2")} autoComplete="address-line2" />
            <Field label="Area / Locality" name="area" error={err("area")} />
            <Field label="Landmark" name="landmark" error={err("landmark")} hint="Optional, helps the courier" />
            <Field label="PIN code" name="pincode" error={err("pincode")} inputMode="numeric" maxLength={6} autoComplete="postal-code" required />
            <Field label="City" name="city" error={err("city")} autoComplete="address-level2" required />
            <div className="sm:col-span-2">
              <label className="block">
                <span className="text-[12px] font-bold uppercase tracking-[0.09em] text-ink-mute">
                  State <span className="text-brand">*</span>
                </span>
                <select
                  name="state"
                  required
                  defaultValue=""
                  autoComplete="address-level1"
                  className={inputClass(!!err("state"))}
                >
                  <option value="" disabled>
                    Select state
                  </option>
                  {INDIAN_STATES.map((s) => (
                    <option key={s} value={s}>
                      {s}
                    </option>
                  ))}
                </select>
                {err("state") && <ErrorText>{err("state")}</ErrorText>}
              </label>
            </div>
          </div>

          <label className="mt-4 flex items-center gap-2 text-[13px] text-ink-mid">
            <input
              type="checkbox"
              name="billingSame"
              defaultChecked
              className="h-3.5 w-3.5 accent-[--color-brand]"
            />
            Billing address is the same as delivery address
          </label>
        </section>

        <section>
          <h2 className="font-display text-xl">Payment</h2>
          <div className="mt-4 space-y-3">
            {paymentOptions.map((opt) => {
              const optBreakdown = breakdowns[opt.value];
              return (
                <label
                  key={opt.value}
                  className={cn(
                    "flex cursor-pointer gap-3 rounded-[var(--radius-card)] border p-4 transition-colors",
                    opt.disabled
                      ? "cursor-not-allowed border-line bg-surface opacity-70"
                      : payment === opt.value
                        ? "border-brand bg-blush"
                        : "border-line hover:border-ink",
                  )}
                >
                  <input
                    type="radio"
                    name="payment"
                    value={opt.value}
                    disabled={opt.disabled}
                    checked={payment === opt.value}
                    onChange={() => setPayment(opt.value)}
                    className="mt-1 h-4 w-4 shrink-0 accent-[--color-brand]"
                  />
                  <span className="min-w-0 flex-1">
                    <span className="flex flex-wrap items-center gap-2">
                      <span className="text-[14px] font-bold">{opt.title}</span>
                      {opt.badge && !opt.disabled && (
                        <span className="badge badge-sale">{opt.badge}</span>
                      )}
                    </span>
                    <span className="mt-0.5 block text-[12.5px] text-ink-mute">
                      {opt.disabled ? opt.disabledReason : opt.body}
                    </span>
                  </span>
                  {optBreakdown && !opt.disabled && (
                    <span className="tnum shrink-0 self-center text-[14px] font-bold">
                      {formatINR(optBreakdown.total)}
                    </span>
                  )}
                </label>
              );
            })}
          </div>
          {err("payment") && <ErrorText>{err("payment")}</ErrorText>}
        </section>

        <section>
          <label className="block">
            <span className="text-[12px] font-bold uppercase tracking-[0.09em] text-ink-mute">
              Order note
            </span>
            <textarea
              name="note"
              rows={2}
              placeholder="Anything the packer should know?"
              className={inputClass(false)}
            />
          </label>
        </section>
      </div>

      <aside className="mt-8 lg:mt-0">
        <div className="lg:sticky lg:top-24">
          <OrderSummary breakdown={breakdown} payNow={payNow} payLater={payLater} showTax />

          <button
            type="submit"
            disabled={pending}
            className="mt-3 w-full rounded-[var(--radius-card)] bg-brand px-6 py-4 text-[15px] font-bold text-white transition-colors hover:bg-brand-deep disabled:opacity-60"
          >
            {pending
              ? "Placing order…"
              : payment === "COD"
                ? `Place order · ${formatINR(breakdown.total)} on delivery`
                : `Pay ${formatINR(payNow)}`}
          </button>

          <p className="mt-3 text-center text-[11.5px] text-ink-mute">
            By placing this order you agree to our Terms and Privacy Policy.
          </p>
        </div>
      </aside>
    </form>
  );
}

/* ------------------------------------------------------------------------ */

function inputClass(hasError: boolean) {
  return cn(
    "mt-1 w-full rounded-[var(--radius-card)] border bg-surface px-3 py-2.5 text-[13.5px] focus:bg-canvas focus:outline-none",
    hasError ? "border-brand" : "border-line focus:border-brand",
  );
}

function Field({
  label,
  name,
  error,
  hint,
  required,
  ...rest
}: {
  label: string;
  name: string;
  error?: string;
  hint?: string;
  required?: boolean;
} & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="block">
      <span className="text-[12px] font-bold uppercase tracking-[0.09em] text-ink-mute">
        {label} {required && <span className="text-brand">*</span>}
      </span>
      <input
        name={name}
        required={required}
        aria-invalid={!!error}
        className={inputClass(!!error)}
        {...rest}
      />
      {error ? (
        <ErrorText>{error}</ErrorText>
      ) : hint ? (
        <span className="mt-1 block text-[11.5px] text-ink-mute">{hint}</span>
      ) : null}
    </label>
  );
}

function ErrorText({ children }: { children: React.ReactNode }) {
  return (
    <span role="alert" className="mt-1 block text-[11.5px] font-medium text-brand">
      {children}
    </span>
  );
}
