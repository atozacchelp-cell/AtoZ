import {
  type Gender,
  type SeedCategory,
  type SeedCollection,
  type SeedProduct,
} from "@/data/catalog";
import {
  addCategories,
  addCollections,
  deriveCategory,
  deriveCollection,
} from "@/lib/category-store";
import { parseCsv, rowsToRecords } from "@/lib/csv";
import { categoryIndex } from "@/lib/taxonomy";
import { fetchSheetCsv, normaliseImageUrl, resolveSheetUrl } from "@/lib/google";
import { parsePriceToPaise } from "@/lib/money";
import { makeSlug, nextSku, replaceAll } from "@/lib/product-store";
import { buildReviews, saveReviews } from "@/lib/reviews";
import { saveContent, type SiteContent } from "@/lib/site-content";
import {
  collectionHint,
  resolveCategory,
  resolveCollection,
  suggestCategory,
} from "@/lib/category-match";
import { parseSizeChart, parseStockCell } from "@/lib/sizes";
import { writeSyncConfig } from "@/lib/sync-config";

/**
 * Google Sheet → catalogue.
 *
 * The sheet is the source of truth once connected: a sync REPLACES the
 * catalogue rather than merging into it, so deleting a row in the sheet
 * removes the product from the shop. Anything else and the sheet stops
 * matching the site, which is the one thing this feature exists to prevent.
 *
 * This module holds the work itself, with no dependency on being inside a
 * form submission — the automatic timer in `auto-sync.ts` runs exactly the
 * same code path as the Sync now button, so scheduled and manual syncs can
 * never drift apart in behaviour.
 */

export type RowIssue = { row: number; product: string; problem: string };

export type SyncResult = {
  ok: boolean;
  error?: string;
  imported: number;
  skipped: RowIssue[];
  /**
   * Rows that imported fine but had something in them worth knowing about —
   * a collection code that matches nothing, say. These must never drop a
   * product: a mistyped tag is not a reason to take a sellable item off the
   * shop. But it must not pass in silence either, which is what happened
   * before, leaving products tagged for pages they never appeared on.
   */
  warnings: RowIssue[];
  contentKeys: number;
  reviewCount: number;
  syncedAt: string;
};

// Rebuilt whenever the sheet adds a category, so a page never renders from
// a snapshot taken before it existed.
const categoryBySlug = { get: (k: string) => categoryIndex().get(k), has: (k: string) => categoryIndex().has(k) };

const splitList = (raw: string | undefined): string[] | undefined => {
  const list = (raw ?? "")
    .split(/[,\n|]/)
    .map((s) => s.trim())
    .filter(Boolean);
  return list.length ? list : undefined;
};

const isNo = (v: string | undefined) =>
  ["no", "false", "0", "n"].includes((v ?? "").trim().toLowerCase());

const isYes = (v: string | undefined) =>
  ["yes", "true", "1", "y"].includes((v ?? "").trim().toLowerCase());

/**
 * Maps whatever was typed in the collections column onto real collections,
 * and reports the ones that match nothing.
 *
 * Never drops the product — a tag that goes nowhere is a smaller problem than
 * an item missing from the shop.
 */
function resolveCollections(raw: string[] | undefined): string[] | undefined {
  if (!raw?.length) return undefined;

  const kept: string[] = [];
  for (const entry of raw) {
    // By this point every collection named anywhere in the sheet exists, so
    // anything still unmatched is empty or punctuation.
    const hit = resolveCollection(entry);
    if (hit && !kept.includes(hit)) kept.push(hit);
  }

  return kept.length ? kept : undefined;
}

/* -------------------------------------------------------------------------
   Products
   ------------------------------------------------------------------------- */

async function buildProducts(
  records: Record<string, string>[],
): Promise<{ products: SeedProduct[]; skipped: RowIssue[]; warnings: RowIssue[] }> {
  const products: SeedProduct[] = [];
  const skipped: RowIssue[] = [];
  const warnings: RowIssue[] = [];
  const seenSku = new Set<string>();

  for (const [i, r] of records.entries()) {
    const rowNo = i + 2; // +1 for the header, +1 because sheets are 1-indexed
    const name = r.name ?? r.productname ?? "";
    const label = name || `Row ${rowNo}`;

    const push = (problem: string) =>
      skipped.push({ row: rowNo, product: label, problem });
    const warn = (problem: string) =>
      warnings.push({ row: rowNo, product: label, problem });

    if (!name) {
      push("No product name");
      continue;
    }

    const category = resolveCategory(r.category ?? "", r.gender ?? "");
    if (!category) {
      // "Not recognised" leaves the owner to hunt through a list of forty
      // codes. Naming the nearest one turns the report into the fix.
      const asCollection = collectionHint(r.category ?? "");
      const guess = suggestCategory(r.category ?? "", r.gender ?? "");
      push(
        `Category "${r.category ?? ""}" not recognised` +
          (asCollection
            ? ` — "${asCollection}" is a collection, not a category. Put a real category here and "${asCollection}" in the collections column.`
            : guess
              ? ` — did you mean ${guess}?`
              : ""),
      );
      continue;
    }

    const mrp = parsePriceToPaise(r.mrp ?? "");
    const price = parsePriceToPaise(r.price ?? r.sellingprice ?? "");

    if (mrp === null) {
      push("MRP is missing or not a number");
      continue;
    }
    if (price === null) {
      push("Selling price is missing or not a number");
      continue;
    }
    if (price > mrp) {
      push("Selling price is higher than MRP");
      continue;
    }
    if (price <= 0) {
      push("Selling price must be more than zero");
      continue;
    }

    // Stock is either one number or a number per size — `S:5, M:8, L:0` —
    // and the per-size form also supplies the sizes.
    const sizesHint = splitList(r.sizes ?? r.size) ?? [];
    const stockCell = r.stock ?? r.quantity ?? "0";
    const parsedStock = parseStockCell(stockCell, sizesHint);

    if (parsedStock.total === 0 && !parsedStock.sizeStock && stockCell.trim() && !/^0+$/.test(stockCell.trim())) {
      push(`Stock "${stockCell}" is not a number, or a list like S:5, M:8`);
      continue;
    }

    let sku = (r.sku ?? "").trim();
    if (!sku) sku = await nextSku(category);
    if (seenSku.has(sku)) {
      push(`SKU ${sku} appears more than once`);
      continue;
    }
    seenSku.add(sku);

    // Up to five images: image, image2..image5 — or one cell of several URLs.
    const imageCells = [
      r.image ?? r.imageurl ?? r.photo ?? "",
      r.image2 ?? "",
      r.image3 ?? "",
      r.image4 ?? "",
      r.image5 ?? "",
    ];
    const images = imageCells
      .flatMap((cell) => cell.split(/[\n|]/))
      .map((s) => s.trim())
      .filter(Boolean)
      .map(normaliseImageUrl);

    const cat = categoryBySlug.get(category)!;

    products.push({
      sku,
      slug: (r.slug ?? "").trim() || (await makeSlug(name, sku)),
      name,
      category,
      gender: cat.gender as Gender,
      shortDescription: r.shortdescription ?? r.tagline ?? name,
      description: r.description ?? r.shortdescription ?? name,
      image: images[0] ?? "/placeholders/lifestyle.svg",
      extraImages: images.slice(1),
      mrp,
      price,
      costPrice: parsePriceToPaise(r.costprice ?? r.cost ?? "") ?? undefined,
      stock: parsedStock.total,
      weightG: Number(r.weight ?? r.weightg ?? "") || 100,
      colours: splitList(r.colours ?? r.color ?? r.colour),
      sizes: parsedStock.sizes.length ? parsedStock.sizes : undefined,
      sizeStock: parsedStock.sizeStock,
      sizeChart: parseSizeChart(r.sizechart ?? r.sizeguide ?? ""),
      material: (r.material ?? "").trim() || undefined,
      features: splitList(r.features),
      care: (r.care ?? r.careinstructions ?? "").trim() || undefined,
      collections: resolveCollections(splitList(r.collections ?? r.tags)),
      isNew: isYes(r.new ?? r.isnew),
      isTrending: isYes(r.trending ?? r.istrending),
      isBestseller: isYes(r.bestseller ?? r.isbestseller),
      isExclusive: isYes(r.exclusive ?? r.isexclusive),
      // Default to allowed unless explicitly switched off.
      isReturnable: !isNo(r.returnable),
      isCodAllowed: !isNo(r.cod ?? r.codallowed),
      badgeText: (r.badge ?? r.offertext ?? "").trim() || undefined,

      // Fulfilment. Anything with a supplier named is treated as dropshipped
      // unless the sheet says otherwise — naming a supplier and still holding
      // the stock yourself is the rarer case, and defaulting the other way
      // would quietly promise same-day dispatch on goods you do not have.
      fulfilment:
        (r.fulfilment ?? r.fulfillment ?? "").trim().toLowerCase() === "dropship" ||
        ((r.supplier ?? "").trim() !== "" &&
          (r.fulfilment ?? r.fulfillment ?? "").trim() === "")
          ? "dropship"
          : "self",
      supplier: (r.supplier ?? "").trim() || undefined,
      dispatchDays: Number(r.dispatchdays ?? r.dispatchday ?? "") || undefined,
    });
  }

  return { products, skipped, warnings };
}

/* -------------------------------------------------------------------------
   Content tab
   ------------------------------------------------------------------------- */

function buildContent(records: Record<string, string>[]): Partial<SiteContent> {
  const content: Record<string, string> = {};

  for (const r of records) {
    const key = (r.key ?? r.setting ?? r.name ?? "").trim();
    const value = (r.value ?? r.text ?? r.content ?? "").trim();
    if (key && value) content[key] = value;
  }

  return content as Partial<SiteContent>;
}

/* -------------------------------------------------------------------------
   The sync itself
   ------------------------------------------------------------------------- */

const fail = (error: string, skipped: RowIssue[] = []): SyncResult => ({
  ok: false,
  error,
  imported: 0,
  skipped,
  warnings: [],
  contentKeys: 0,
  reviewCount: 0,
  syncedAt: new Date().toISOString(),
});

/**
 * Creates any category the sheet names that does not exist yet.
 *
 * Runs before the rows are read, so a product needing a brand-new category
 * imports on the FIRST sync rather than being skipped once and working the
 * second time — which would look like a bug even though it eventually worked.
 *
 * Only cells that the fuzzy matcher could not place reach here, so a typo
 * like "women-earings" still lands on Earrings instead of founding a new
 * category next to it.
 */
async function createMissingCategories(
  records: Record<string, string>[],
): Promise<SeedCategory[]> {
  const wanted = new Map<string, SeedCategory>();

  for (const r of records) {
    const raw = (r.category ?? "").trim();
    if (!raw) continue;
    if (resolveCategory(raw, r.gender ?? "")) continue;

    // Note there is deliberately no "that looks like a collection, refuse"
    // check here. It was tried, and it meant a sheet saying `women-gifts`
    // had its product dropped on the grounds that gifting is a collection —
    // technically defensible, and useless to someone who just wants their
    // gift hampers on the site. Whatever is in the category column is a
    // category. A collection of the same name can exist alongside it.
    const derived = deriveCategory(raw, r.gender ?? "");
    if (derived && !wanted.has(derived.slug)) wanted.set(derived.slug, derived);
  }

  if (wanted.size === 0) return [];
  return addCategories([...wanted.values()]);
}

/**
 * Creates any collection the sheet tags that does not exist yet.
 *
 * The same argument as categories, with a lower risk: a collection is a
 * cross-cutting tag, so a spurious one costs an extra page nobody visits
 * rather than a product filed in the wrong department. The previous behaviour
 * — accepting the tag and silently doing nothing with it — was the worst of
 * the options, because the shop looked tagged and wasn't.
 */
async function createMissingCollections(
  records: Record<string, string>[],
): Promise<SeedCollection[]> {
  const wanted = new Map<string, SeedCollection>();

  for (const r of records) {
    for (const tag of splitList(r.collections ?? r.tags) ?? []) {
      if (resolveCollection(tag)) continue;
      const derived = deriveCollection(tag);
      if (derived && !wanted.has(derived.slug)) wanted.set(derived.slug, derived);
    }
  }

  if (wanted.size === 0) return [];
  return addCollections([...wanted.values()]);
}

export async function runSync(
  productsInput: string,
  contentInput?: string,
  reviewsInput?: string,
): Promise<SyncResult> {
  const productsUrl = productsInput.trim();
  const contentUrl = (contentInput ?? "").trim();
  const reviewsUrl = (reviewsInput ?? "").trim();

  if (!productsUrl) return fail("Paste the link to your Google Sheet first.");

  const productsRef = resolveSheetUrl(productsUrl);
  if (!productsRef) {
    return fail(
      "That does not look like a Google Sheets link. It should start with https://docs.google.com/spreadsheets/",
    );
  }

  const fetched = await fetchSheetCsv(productsRef);
  if (!fetched.ok) return fail(fetched.error);

  const records = rowsToRecords(parseCsv(fetched.csv));
  if (records.length === 0) {
    return fail("The sheet has a header row but no products under it.");
  }

  const created = await createMissingCategories(records);
  const newCollections = await createMissingCollections(records);
  const { products, skipped, warnings } = await buildProducts(records);

  for (const c of created) {
    warnings.push({
      row: 0,
      product: c.name,
      problem: `New category "${c.slug}" created from your sheet — it is now in the menu.`,
    });
  }

  if (newCollections.length > 0) {
    warnings.push({
      row: 0,
      product: "Collections",
      problem: `${newCollections.length} new collection${newCollections.length === 1 ? "" : "s"} created: ${newCollections.map((c) => c.slug).join(", ")} — each now has its own page at /collections/…`,
    });
  }

  // Refuse to wipe a working shop because of a bad paste or a renamed column.
  if (products.length === 0) {
    return fail(
      "No row in that sheet could be read as a product, so the catalogue was left alone. Check the column headings against the template.",
      skipped,
    );
  }

  await replaceAll(products);

  // Optional second tab for the customer-facing wording.
  let contentKeys = 0;
  if (contentUrl) {
    const contentRef = resolveSheetUrl(contentUrl);
    if (contentRef) {
      const contentCsv = await fetchSheetCsv(contentRef);
      if (contentCsv.ok) {
        const content = buildContent(rowsToRecords(parseCsv(contentCsv.csv)));
        contentKeys = Object.keys(content).length;
        if (contentKeys > 0) await saveContent(content);
      }
    }
  }

  // Optional third tab: customer testimonials.
  let reviewCount = 0;
  if (reviewsUrl) {
    const reviewsRef = resolveSheetUrl(reviewsUrl);
    if (reviewsRef) {
      const reviewsCsv = await fetchSheetCsv(reviewsRef);
      if (reviewsCsv.ok) {
        const reviews = buildReviews(rowsToRecords(parseCsv(reviewsCsv.csv)));
        reviewCount = reviews.length;
        // Written even when empty — clearing the tab must clear the section,
        // or a review deleted for being wrong would stay on the site.
        await saveReviews(reviews);
      }
    }
  }

  const syncedAt = new Date().toISOString();
  await writeSyncConfig({
    productsUrl,
    contentUrl: contentUrl || undefined,
    reviewsUrl: reviewsUrl || undefined,
    lastSyncedAt: syncedAt,
    lastCount: products.length,
  });

  return {
    ok: true,
    imported: products.length,
    skipped,
    warnings,
    contentKeys,
    reviewCount,
    syncedAt,
  };
}
