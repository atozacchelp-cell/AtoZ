import Link from "next/link";

import { Breadcrumbs, ButtonLink, Container } from "@/components/ui";
import { StatusPill } from "@/components/order-detail";
import { readWishlist } from "@/lib/cart";
import { formatINR } from "@/lib/money";
import { listOrdersForEmail } from "@/lib/orders";
import { currentUser } from "@/lib/session";
import { getSettings } from "@/lib/settings";

export const metadata = {
  title: "My Account",
  robots: { index: false },
};

export default async function AccountPage() {
  const user = await currentUser();

  // Only ever this person's orders. The previous version listed every order
  // in the shop to every visitor.
  const [orders, wishlist, settings] = await Promise.all([
    Promise.resolve(user ? await listOrdersForEmail(user.email) : []),
    readWishlist(),
    getSettings(),
  ]);

  return (
    <Container className="max-w-4xl py-6">
      <Breadcrumbs items={[{ label: "My Account" }]} />
      <h1 className="font-display text-[30px] sm:text-[36px]">My Account</h1>

      {/* Sign-in is not built yet, so this says so plainly rather than
          showing a login form that cannot work. */}
      <div className="mt-5 rounded-[var(--radius-card)] border border-line bg-surface px-4 py-3.5 text-[13px] text-ink-mid">
        <strong className="text-ink">Sign-in is coming.</strong> Mobile OTP login
        needs SMS DLT approval, which is still in progress. Until then you can
        order as a guest and track any order with its number.
      </div>

      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        <Tile label="Orders" value={String(orders.length)} href="#orders" />
        <Tile label="Wishlist" value={String(wishlist.length)} href="/wishlist" />
        <Tile label="Store credit" value={formatINR(0)} />
      </div>

      <section id="orders" className="mt-10 scroll-mt-24">
        <h2 className="font-display text-xl">Recent orders</h2>

        {orders.length === 0 ? (
          <div className="mt-3 rounded-[var(--radius-card)] border border-dashed border-line-firm px-5 py-10 text-center">
            <p className="text-[13.5px] text-ink-mute">
              No orders yet on this device.
            </p>
            <ButtonLink href="/shop" className="mt-4">
              Start shopping
            </ButtonLink>
          </div>
        ) : (
          <ul className="mt-3 space-y-3">
            {orders.map((o) => (
              <li
                key={o.orderNumber}
                className="rounded-[var(--radius-card)] border border-line p-4"
              >
                <div className="flex flex-wrap items-baseline justify-between gap-2">
                  <Link
                    href={`/track-order?order=${o.orderNumber}`}
                    className="tnum font-semibold hover:text-brand"
                  >
                    {o.orderNumber}
                  </Link>
                  <StatusPill status={o.status} />
                </div>
                <p className="tnum mt-1.5 text-[12.5px] text-ink-mute">
                  {new Date(o.placedAt).toLocaleDateString("en-IN", {
                    day: "numeric",
                    month: "short",
                    year: "numeric",
                  })}
                  {" · "}
                  {o.items.length} {o.items.length === 1 ? "item" : "items"}
                  {" · "}
                  {formatINR(o.total)}
                  {o.balanceAmount > 0 && (
                    <span className="font-semibold text-brand">
                      {" · "}
                      {formatINR(o.balanceAmount)} due
                    </span>
                  )}
                </p>
              </li>
            ))}
          </ul>
        )}
      </section>

      <section className="mt-10">
        <h2 className="font-display text-xl">Help</h2>
        <ul className="mt-3 grid gap-2 sm:grid-cols-2">
          {[
            { href: "/track-order", label: "Track an order" },
            { href: "/policy/returns", label: "Return an item" },
            { href: "/policy/refunds", label: "Refund status" },
            { href: "/contact", label: `Contact us · ${settings.supportPhone}` },
          ].map((l) => (
            <li key={l.href}>
              <Link
                href={l.href}
                className="block rounded-[var(--radius-card)] border border-line px-4 py-3 text-[13.5px] font-medium transition-colors hover:border-brand hover:text-brand"
              >
                {l.label}
              </Link>
            </li>
          ))}
        </ul>
      </section>
    </Container>
  );
}

function Tile({ label, value, href }: { label: string; value: string; href?: string }) {
  const inner = (
    <>
      <p className="text-[11px] font-bold uppercase tracking-[0.11em] text-ink-mute">
        {label}
      </p>
      <p className="tnum mt-1 font-display text-2xl">{value}</p>
    </>
  );

  return href ? (
    <Link
      href={href}
      className="rounded-[var(--radius-card)] border border-line bg-surface p-4 transition-colors hover:border-brand"
    >
      {inner}
    </Link>
  ) : (
    <div className="rounded-[var(--radius-card)] border border-line bg-surface p-4">{inner}</div>
  );
}
