"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { z } from "zod";

import { type Gender, type SeedProduct } from "@/data/catalog";
import { allCategories } from "@/lib/taxonomy";
import { normaliseImageUrl } from "@/lib/google";
import { parsePriceToPaise } from "@/lib/money";
import {
  bulkUpsert,
  deleteProduct,
  findProductBySku,
  makeSlug,
  nextSku,
  saveProduct,
} from "@/lib/product-store";

/**
 * Adding and editing products.
 *
 * Prices arrive as rupees typed by a person ("499", "₹1,299") and are stored
 * as integer paise. That conversion happens exactly here, at the edge — never
 * deeper in, where a stray float would spread.
 */

const CATEGORY_SLUGS = allCategories().map((c) => c.slug);

export type ProductFormState = {
  errors?: Record<string, string>;
  formError?: string;
  success?: string;
};

const ProductSchema = z
  .object({
    sku: z.string().trim().max(40).optional(),
    name: z.string().trim().min(3, "Give the product a name").max(140),
    category: z.string().refine((v) => CATEGORY_SLUGS.includes(v), "Pick a category"),
    shortDescription: z.string().trim().max(200).optional(),
    description: z.string().trim().max(4000).optional(),
    image: z.string().trim().min(1, "An image is required").max(500),
    mrp: z.string().trim().min(1, "Enter the MRP"),
    price: z.string().trim().min(1, "Enter the selling price"),
    costPrice: z.string().trim().optional(),
    stock: z.coerce.number().int().min(0, "Stock cannot be negative").max(100000),
    weightG: z.coerce.number().int().min(1, "Weight must be at least 1g").max(50000),
    colours: z.string().trim().max(300).optional(),
    sizes: z.string().trim().max(200).optional(),
    material: z.string().trim().max(120).optional(),
    features: z.string().trim().max(1000).optional(),
    care: z.string().trim().max(500).optional(),
    collections: z.array(z.string()).optional(),
    isNew: z.string().optional(),
    isTrending: z.string().optional(),
    isBestseller: z.string().optional(),
    isExclusive: z.string().optional(),
    isReturnable: z.string().optional(),
    isCodAllowed: z.string().optional(),
  })
  .transform((data, ctx) => {
    const mrp = parsePriceToPaise(data.mrp);
    const price = parsePriceToPaise(data.price);
    const costPrice = data.costPrice ? parsePriceToPaise(data.costPrice) : undefined;

    if (mrp === null) {
      ctx.addIssue({ code: "custom", path: ["mrp"], message: "Enter a valid amount" });
    }
    if (price === null) {
      ctx.addIssue({ code: "custom", path: ["price"], message: "Enter a valid amount" });
    }
    if (data.costPrice && costPrice === null) {
      ctx.addIssue({ code: "custom", path: ["costPrice"], message: "Enter a valid amount" });
    }
    // A selling price above MRP means a negative discount, which the badge
    // maths and the "you save" line cannot represent honestly.
    if (mrp !== null && price !== null && price > mrp) {
      ctx.addIssue({
        code: "custom",
        path: ["price"],
        message: "Selling price cannot be higher than MRP",
      });
    }

    return { ...data, mrpPaise: mrp ?? 0, pricePaise: price ?? 0, costPaise: costPrice };
  });

const splitList = (raw: string | undefined): string[] | undefined => {
  if (!raw?.trim()) return undefined;
  const list = raw
    .split(/[,\n]/)
    .map((s) => s.trim())
    .filter(Boolean);
  return list.length ? list : undefined;
};

function fieldsFrom(formData: FormData) {
  return {
    sku: (formData.get("sku") as string) || undefined,
    name: formData.get("name"),
    category: formData.get("category"),
    shortDescription: formData.get("shortDescription") ?? "",
    description: formData.get("description") ?? "",
    image: formData.get("image"),
    mrp: formData.get("mrp"),
    price: formData.get("price"),
    costPrice: formData.get("costPrice") ?? "",
    stock: formData.get("stock") ?? 0,
    weightG: formData.get("weightG") ?? 100,
    colours: formData.get("colours") ?? "",
    sizes: formData.get("sizes") ?? "",
    material: formData.get("material") ?? "",
    features: formData.get("features") ?? "",
    care: formData.get("care") ?? "",
    collections: formData.getAll("collections") as string[],
    isNew: formData.get("isNew") ?? undefined,
    isTrending: formData.get("isTrending") ?? undefined,
    isBestseller: formData.get("isBestseller") ?? undefined,
    isExclusive: formData.get("isExclusive") ?? undefined,
    isReturnable: formData.get("isReturnable") ?? undefined,
    isCodAllowed: formData.get("isCodAllowed") ?? undefined,
  };
}

export async function upsertProduct(
  _prev: ProductFormState,
  formData: FormData,
): Promise<ProductFormState> {
  const parsed = ProductSchema.safeParse(fieldsFrom(formData));

  if (!parsed.success) {
    const errors: Record<string, string> = {};
    for (const issue of parsed.error.issues) {
      const key = String(issue.path[0]);
      errors[key] ??= issue.message;
    }
    return { errors };
  }

  const d = parsed.data;
  const category = allCategories().find((c) => c.slug === d.category)!;

  const existingSku = d.sku?.trim();
  const sku = existingSku || (await nextSku(d.category));
  const existing = existingSku ? await findProductBySku(existingSku) : null;

  const product: SeedProduct = {
    sku,
    // Keep the slug stable across edits: changing it silently breaks every
    // link and every search result already pointing at this product.
    slug: existing?.slug ?? (await makeSlug(d.name, sku)),
    name: d.name,
    category: d.category,
    gender: category.gender as Gender,
    shortDescription: d.shortDescription || d.name,
    description: d.description || d.shortDescription || d.name,
    image: d.image,
    mrp: d.mrpPaise,
    price: d.pricePaise,
    costPrice: d.costPaise ?? undefined,
    stock: d.stock,
    weightG: d.weightG,
    colours: splitList(d.colours),
    sizes: splitList(d.sizes),
    material: d.material || undefined,
    features: splitList(d.features),
    care: d.care || undefined,
    collections: d.collections?.length ? d.collections : undefined,
    // Ratings are earned by customers, never typed in by the shop.
    rating: existing?.rating,
    reviewCount: existing?.reviewCount,
    isNew: d.isNew === "on",
    isTrending: d.isTrending === "on",
    isBestseller: d.isBestseller === "on",
    isExclusive: d.isExclusive === "on",
    isReturnable: d.isReturnable === "on",
    isCodAllowed: d.isCodAllowed === "on",
  };

  await saveProduct(product);

  revalidatePath("/admin/products");
  revalidatePath("/", "layout");

  redirect(`/admin/products?saved=${encodeURIComponent(sku)}`);
}

export async function removeProduct(formData: FormData): Promise<void> {
  const sku = String(formData.get("sku") ?? "");
  if (!sku) return;

  await deleteProduct(sku);
  revalidatePath("/admin/products");
  revalidatePath("/", "layout");
  redirect("/admin/products?deleted=1");
}

/* -------------------------------------------------------------------------
   CSV import
   ------------------------------------------------------------------------- */

/** Minimal CSV parser: handles quoted fields and embedded commas. */
function parseCsv(text: string): string[][] {
  const rows: string[][] = [];
  let row: string[] = [];
  let field = "";
  let inQuotes = false;

  for (let i = 0; i < text.length; i++) {
    const ch = text[i];

    if (inQuotes) {
      if (ch === '"') {
        if (text[i + 1] === '"') {
          field += '"';
          i++;
        } else inQuotes = false;
      } else field += ch;
      continue;
    }

    if (ch === '"') inQuotes = true;
    else if (ch === ",") {
      row.push(field);
      field = "";
    } else if (ch === "\n") {
      row.push(field);
      rows.push(row);
      row = [];
      field = "";
    } else if (ch !== "\r") field += ch;
  }

  if (field || row.length) {
    row.push(field);
    rows.push(row);
  }

  return rows.filter((r) => r.some((c) => c.trim() !== ""));
}

export type ImportState = {
  error?: string;
  summary?: { added: number; updated: number; skipped: string[] };
};

export async function importProductsCsv(
  _prev: ImportState,
  formData: FormData,
): Promise<ImportState> {
  const file = formData.get("file");
  if (!(file instanceof File) || file.size === 0) {
    return { error: "Choose a CSV file to upload." };
  }
  if (file.size > 2_000_000) {
    return { error: "That file is over 2 MB. Split it into smaller batches." };
  }

  const rows = parseCsv(await file.text());
  if (rows.length < 2) {
    return { error: "The file needs a header row and at least one product." };
  }

  const header = rows[0].map((h) => h.trim().toLowerCase());
  const col = (name: string) => header.indexOf(name);

  const required = ["name", "category", "mrp", "price", "stock"];
  const missing = required.filter((r) => col(r) === -1);
  if (missing.length) {
    return { error: `Missing column${missing.length > 1 ? "s" : ""}: ${missing.join(", ")}` };
  }

  const products: SeedProduct[] = [];
  const skipped: string[] = [];

  for (const [i, row] of rows.slice(1).entries()) {
    const get = (name: string) => (col(name) === -1 ? "" : (row[col(name)] ?? "").trim());
    const lineNo = i + 2;

    const name = get("name");
    const categorySlug = get("category");
    const category = allCategories().find((c) => c.slug === categorySlug);
    const mrp = parsePriceToPaise(get("mrp"));
    const price = parsePriceToPaise(get("price"));
    const stock = Number(get("stock"));

    if (!name) {
      skipped.push(`Row ${lineNo}: no name`);
      continue;
    }
    if (!category) {
      skipped.push(`Row ${lineNo}: unknown category "${categorySlug}"`);
      continue;
    }
    if (mrp === null || price === null) {
      skipped.push(`Row ${lineNo}: bad price`);
      continue;
    }
    if (price > mrp) {
      skipped.push(`Row ${lineNo}: price is above MRP`);
      continue;
    }

    const sku = get("sku") || (await nextSku(categorySlug));
    const existing = await findProductBySku(sku);

    // Every column the exporter writes must be read back here, or an
    // export → edit → import round trip silently blanks whatever is missing.
    const images = ["image", "image2", "image3", "image4", "image5"]
      .map((c) => normaliseImageUrl(get(c)))
      .filter(Boolean);

    const yes = (col: string) => ["yes", "true", "1", "y"].includes(get(col).toLowerCase());

    products.push({
      sku,
      // Keep an existing product's slug: changing it breaks every link and
      // search result already pointing at it.
      // An explicit slug column wins, then the existing slug, then one
      // generated from the name. That makes the product URL something the
      // sheet controls rather than something that silently changes.
      slug: get("slug") || existing?.slug || (await makeSlug(name, sku)),
      name,
      category: categorySlug,
      gender: category.gender as Gender,
      shortDescription: get("shortdescription") || name,
      description: get("description") || get("shortdescription") || name,
      image: images[0] ?? "/placeholders/lifestyle.svg",
      extraImages: images.slice(1),
      mrp,
      price,
      costPrice: parsePriceToPaise(get("costprice")) ?? undefined,
      stock: Number.isFinite(stock) ? Math.max(0, Math.trunc(stock)) : 0,
      weightG: Number(get("weight")) || 100,
      colours: splitList(get("colours")),
      sizes: splitList(get("sizes")),
      material: get("material") || undefined,
      features: splitList(get("features")),
      care: get("care") || undefined,
      collections: splitList(get("collections")),
      badgeText: get("badge") || undefined,
      isNew: yes("new"),
      isTrending: yes("trending"),
      isBestseller: yes("bestseller"),
      isExclusive: yes("exclusive"),
      // Ratings are earned by customers and never come from a spreadsheet.
      rating: existing?.rating,
      reviewCount: existing?.reviewCount,
      isReturnable: get("returnable").toLowerCase() !== "no",
      isCodAllowed: get("cod").toLowerCase() !== "no",
    });
  }

  if (products.length === 0) {
    return { error: "Nothing could be imported.", summary: { added: 0, updated: 0, skipped } };
  }

  const { added, updated } = await bulkUpsert(products);

  revalidatePath("/admin/products");
  revalidatePath("/", "layout");

  return { summary: { added, updated, skipped } };
}
