import Link from "next/link";

import { Breadcrumbs, Container } from "@/components/ui";
import { formatINR } from "@/lib/money";
import { getSettings } from "@/lib/settings";

export const metadata = {
  title: "FAQ",
  description:
    "Answers about shipping, cash on delivery, returns, refunds and orders at AtoZacc.",
};

export default async function FaqPage() {
  const s = await getSettings();

  const groups: { title: string; items: { q: string; a: string }[] }[] = [
    {
      title: "Orders",
      items: [
        {
          q: "Do I need an account to order?",
          a: "No. You can check out as a guest with just your mobile number and address. You can track the order afterwards using the order number we send you.",
        },
        {
          q: "How do I track my order?",
          a: "Use the Track Order page and enter your order number — it looks like ATZ-2026-0001 and is in your confirmation message.",
        },
        {
          q: "Can I change or cancel my order?",
          a: "Yes, free of charge, at any point before the order is packed. Message us with your order number as soon as you can. Once it is handed to the courier we cannot cancel it.",
        },
        {
          q: "Can I change the delivery address after ordering?",
          a: "Only before dispatch. After that the parcel is with the courier and the address is fixed.",
        },
      ],
    },
    {
      title: "Payment",
      items: [
        {
          q: "What payment methods do you accept?",
          a: s.onlinePaymentEnabled
            ? "UPI, credit and debit cards, net banking and wallets. Cash on delivery is also available."
            : "Cash on delivery is available now. Online payment — UPI, cards, net banking and wallets — is being set up and will be switched on shortly.",
        },
        {
          q: "Is there a discount for paying online?",
          a: s.prepaidDiscountEnabled
            ? `Yes — ${formatINR(s.prepaidDiscount)} off, applied automatically at checkout when you choose to pay online.`
            : "Not at the moment.",
        },
        {
          q: "Is there a fee for cash on delivery?",
          a: s.codEnabled && s.codFee > 0
            ? `Yes, a ${formatINR(s.codFee)} handling fee. It covers what the courier charges us to collect and remit cash.`
            : "No.",
        },
        {
          q: "Are my card details safe?",
          a: "We never see or store your card number, CVV or UPI PIN. Payments are handled entirely by the payment gateway.",
        },
      ],
    },
    {
      title: "Shipping",
      items: [
        {
          q: "How much is shipping?",
          a: `Free over ${formatINR(s.freeShippingThreshold)}. Below that it is a flat ${formatINR(s.standardShippingRate)} anywhere in India.`,
        },
        {
          q: "How long will delivery take?",
          a: "Delhi NCR 1–2 working days, metro cities 3–4, rest of India 4–7, counted from dispatch. Orders placed before 2 PM on a working day usually go out the same or next day.",
        },
        {
          q: "Do you deliver to my PIN code?",
          a: "We ship anywhere in India. You can check the estimate for your PIN code on any product page.",
        },
        {
          q: "Do you ship internationally?",
          a: "Not yet. India only for now.",
        },
      ],
    },
    {
      title: "Returns and refunds",
      items: [
        {
          q: "What is your return window?",
          a: `${s.returnWindowDays} days from delivery, on items that are eligible for return.`,
        },
        {
          q: "Which items cannot be returned?",
          a: "Earrings and pierced jewellery, socks, personalised items and gift hampers — all for hygiene or resale reasons. Where an item cannot be returned, the product page says so before you buy.",
        },
        {
          q: "Who pays for return shipping?",
          a: "We do, if the item arrived damaged, faulty or wrong. If you changed your mind or ordered the wrong size, you cover the return postage.",
        },
        {
          q: "How am I refunded for a cash-on-delivery order?",
          a: "There is no payment to reverse, so you choose: a UPI transfer to an ID you give us, or store credit in your AtoZacc account.",
        },
        {
          q: "How long do refunds take?",
          a: `We process the refund within ${s.refundWindowDays} working days of receiving and inspecting the item. Your bank then usually takes another 2–5 working days.`,
        },
      ],
    },
    {
      title: "Products",
      items: [
        {
          q: "Will the colour match the photograph?",
          a: "We photograph products as accurately as we can, but screens differ. Small variations in shade are normal. If what arrives is genuinely not what was shown, that counts as our fault and we cover the return.",
        },
        {
          q: "Is the jewellery real gold or silver?",
          a: "No. Our jewellery is fashion jewellery — brass and alloy with gold-tone, silver-tone or oxidised finishes. It is described that way on every product page.",
        },
        {
          q: "Will it cause skin irritation?",
          a: "Most pieces use nickel-free posts and findings, and we note this in the product features. If you have a known metal sensitivity, check the material listed in the specifications before ordering.",
        },
        {
          q: "An item is out of stock — will it come back?",
          a: "Often, yes. Use the Notify me option on the product page and we will message you when it does.",
        },
      ],
    },
  ];

  // FAQPage schema, built from the same content shown on the page.
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: groups.flatMap((g) =>
      g.items.map((item) => ({
        "@type": "Question",
        name: item.q,
        acceptedAnswer: { "@type": "Answer", text: item.a },
      })),
    ),
  };

  return (
    <Container className="max-w-3xl py-8">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
      />

      <Breadcrumbs items={[{ label: "FAQ" }]} />
      <h1 className="font-display text-[30px] leading-tight sm:text-[36px]">
        Frequently asked questions
      </h1>

      <div className="mt-9 space-y-10">
        {groups.map((group) => (
          <section key={group.title}>
            <h2 className="text-[11px] font-bold uppercase tracking-[0.11em] text-brand">
              {group.title}
            </h2>
            <div className="mt-3 divide-y divide-line border-y border-line">
              {group.items.map((item) => (
                <details key={item.q} className="group py-3.5">
                  <summary className="flex cursor-pointer list-none items-start justify-between gap-4 text-[14px] font-semibold">
                    {item.q}
                    <span
                      aria-hidden
                      className="mt-0.5 shrink-0 text-ink-mute transition-transform group-open:rotate-45"
                    >
                      +
                    </span>
                  </summary>
                  <p className="mt-2 max-w-prose text-[13.5px] leading-relaxed text-ink-mid">
                    {item.a}
                  </p>
                </details>
              ))}
            </div>
          </section>
        ))}
      </div>

      <div className="mt-10 rounded-[var(--radius-card)] border border-line bg-surface p-5 text-[13.5px] text-ink-mid">
        Still stuck?{" "}
        <Link href="/contact" className="font-semibold text-brand hover:text-brand-deep">
          Contact us
        </Link>{" "}
        — {s.supportHours}.
      </div>
    </Container>
  );
}
