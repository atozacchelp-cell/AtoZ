import { Breadcrumbs, ButtonLink, Container } from "@/components/ui";
import { getSettings } from "@/lib/settings";

export const metadata = {
  title: "About Us",
  description:
    "AtoZacc is a Delhi-based accessories brand selling jewellery, bags, watches and everyday pieces across India.",
};

export default async function AboutPage() {
  const settings = await getSettings();

  return (
    <Container className="max-w-3xl py-8">
      <Breadcrumbs items={[{ label: "About Us" }]} />

      <h1 className="font-display text-[32px] leading-tight sm:text-[40px]">
        Accessories from A to Z
      </h1>

      <div className="mt-6 space-y-4 text-[15px] leading-relaxed text-ink-mid">
        <p>
          AtoZacc started with a simple frustration: finding one good pair of
          earrings is easy, but finding the earrings, the bag and the watch that
          work together — at a price that lets you buy all three — is not.
        </p>
        <p>
          So we built a shop around the whole look rather than the single piece.
          Jewellery, bags, watches, wallets, belts, hair accessories and the
          small everyday things, for women, men and kids, from one place.
        </p>
        <p>
          We are based in Delhi and ship across India. Every piece is chosen by
          hand, photographed as it actually looks, and priced so that buying the
          set is not a decision you have to save up for.
        </p>
      </div>

      <div className="mt-10 grid gap-4 sm:grid-cols-3">
        {[
          {
            title: "Chosen, not listed",
            body: "We buy and check each piece ourselves. If it would not survive a season of real wear, it does not go up.",
          },
          {
            title: "Honest photographs",
            body: "Products are shot as they are. What arrives should be what you saw.",
          },
          {
            title: "Priced to wear",
            body: "Accessories should be worn, not kept for special occasions. We price accordingly.",
          },
        ].map((c) => (
          <div key={c.title} className="rounded-[var(--radius-card)] border border-line bg-surface p-5">
            <h2 className="font-display text-lg">{c.title}</h2>
            <p className="mt-1.5 text-[13px] text-ink-mute">{c.body}</p>
          </div>
        ))}
      </div>

      <section className="mt-12">
        <h2 className="font-display text-2xl">How we work</h2>
        <dl className="mt-4 space-y-3 text-[14px]">
          {[
            ["Shipping", `Free over ₹${settings.freeShippingThreshold / 100}, dispatched within 1–2 working days from Delhi.`],
            ["Payment", settings.codEnabled ? "Pay online or by cash on delivery — whichever you prefer." : "Secure online payment."],
            ["Returns", `${settings.returnWindowDays} days on most items. Some pieces are non-returnable for hygiene, and we say so on the product page rather than in the small print.`],
            ["Support", `${settings.supportHours}. A real person replies.`],
          ].map(([label, body]) => (
            <div key={label} className="flex flex-col gap-1 border-b border-line pb-3 sm:flex-row sm:gap-6">
              <dt className="w-32 shrink-0 font-bold text-ink">{label}</dt>
              <dd className="text-ink-mid">{body}</dd>
            </div>
          ))}
        </dl>
      </section>

      <div className="mt-10 flex flex-wrap gap-3">
        <ButtonLink href="/shop" size="lg">
          Browse the shop
        </ButtonLink>
        <ButtonLink href="/contact" variant="secondary" size="lg">
          Get in touch
        </ButtonLink>
      </div>
    </Container>
  );
}
