import Link from "next/link";

import { getCartCount } from "@/lib/cart";

/**
 * Sticky bottom navigation. Mobile is ~85% of this store's traffic, so this
 * is the primary navigation, not a fallback for the desktop header.
 * Every target is at least 44px.
 */
export async function MobileNav() {
  const cartCount = await getCartCount();

  return (
    <nav
      aria-label="Primary"
      className="fixed inset-x-0 bottom-0 z-40 border-t border-line bg-canvas/97 backdrop-blur lg:hidden"
      style={{ paddingBottom: "env(safe-area-inset-bottom)" }}
    >
      <ul className="mx-auto grid max-w-lg grid-cols-5">
        <Item href="/" label="Home" d="M3 10.5 12 3l9 7.5V21a1 1 0 0 1-1 1h-5v-7H9v7H4a1 1 0 0 1-1-1z" />
        <Item href="/shop" label="Shop" d="M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z" />
        <Item href="/search" label="Search" d="M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14zM20 20l-3.5-3.5" />
        <Item
          href="/wishlist"
          label="Saved"
          d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1L12 21l7.7-7.7 1.1-1a5.5 5.5 0 0 0 0-7.8z"
        />
        <Item
          href="/cart"
          label="Cart"
          badge={cartCount}
          d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4zM3 6h18M16 10a4 4 0 0 1-8 0"
        />
      </ul>
    </nav>
  );
}

function Item({
  href,
  label,
  d,
  badge,
}: {
  href: string;
  label: string;
  d: string;
  badge?: number;
}) {
  return (
    <li>
      <Link
        href={href}
        className="relative flex min-h-[56px] flex-col items-center justify-center gap-1 text-ink-mute transition-colors hover:text-brand active:text-brand"
      >
        <span className="relative">
          <svg
            width="20"
            height="20"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.6"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden
          >
            <path d={d} />
          </svg>
          {badge !== undefined && badge > 0 && (
            <span className="tnum absolute -right-2 -top-1.5 grid h-[16px] min-w-[16px] place-items-center rounded-full bg-brand px-1 text-[9.5px] font-bold text-white">
              {badge > 99 ? "99+" : badge}
            </span>
          )}
        </span>
        <span className="text-[10.5px] font-medium">{label}</span>
      </Link>
    </li>
  );
}
