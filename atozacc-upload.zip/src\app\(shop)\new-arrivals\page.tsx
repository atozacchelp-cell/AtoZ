import { ProductListing, type SearchParamsShape } from "@/components/product-listing";

export const metadata = {
  title: "New Arrivals",
  description: "The newest accessories at AtoZacc, updated as stock lands.",
};

export default async function Page({
  searchParams,
}: {
  searchParams: Promise<SearchParamsShape>;
}) {
  const sp = await searchParams;
  return (
    <ProductListing
      title={"New Arrivals"}
      description={"Just landed. The newest pieces across every category."}
      breadcrumbs={[{ label: "New Arrivals" }]}
      searchParams={sp}
      baseFilters={{ collection: "new-arrivals" }}
    />
  );
}
