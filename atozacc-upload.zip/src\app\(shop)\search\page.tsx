import { ProductListing, type SearchParamsShape } from "@/components/product-listing";
import { Container, EmptyState } from "@/components/ui";
import { getCollections } from "@/lib/catalog";
import Link from "next/link";

export const metadata = {
  title: "Search",
  description: "Search AtoZacc accessories by name, category or SKU.",
  robots: { index: false },
};

export default async function SearchPage({
  searchParams,
}: {
  searchParams: Promise<SearchParamsShape>;
}) {
  const sp = await searchParams;
  const q = (Array.isArray(sp.q) ? sp.q[0] : sp.q)?.trim() ?? "";

  if (!q) {
    return (
      <Container className="py-10">
        <h1 className="font-display text-[30px]">Search</h1>
        <div className="mt-6">
          <EmptyState
            title="What are you looking for?"
            body="Search by product name, category or SKU — try “earrings”, “wallet” or “oxidised”."
            action={{ href: "/shop", label: "Browse all products" }}
          />
        </div>

        <h2 className="mt-10 text-[11px] font-bold uppercase tracking-[0.11em] text-ink-mute">
          Popular collections
        </h2>
        <div className="mt-3 flex flex-wrap gap-2">
          {getCollections().map((c) => (
            <Link
              key={c.slug}
              href={`/collections/${c.slug}`}
              className="rounded-[var(--radius-pill)] border border-line px-3.5 py-1.5 text-[12.5px] font-medium text-ink-mid hover:border-brand hover:text-brand"
            >
              {c.name}
            </Link>
          ))}
        </div>
      </Container>
    );
  }

  return (
    <ProductListing
      title={`Results for “${q}”`}
      breadcrumbs={[{ label: "Search" }]}
      searchParams={sp}
      baseFilters={{ q }}
    />
  );
}
