"use client";

import { useState } from "react";

import type { Supplier } from "@/lib/suppliers";

/**
 * The daily job of dropshipping: turning your orders into messages a supplier
 * can act on.
 *
 * One customer order can contain items from several suppliers, so it has to be
 * split by supplier before it can be forwarded — sending a supplier a list
 * containing another supplier's products is how wrong parcels get shipped.
 */

type Line = { name: string; sku: string; qty: number; supplier: string | null };

export type ForwardOrder = {
  orderNumber: string;
  placedAt: string;
  status: string;
  paymentMethod: string;
  address: {
    name: string;
    mobile: string;
    line1: string;
    line2?: string;
    area?: string;
    landmark?: string;
    city: string;
    state: string;
    pincode: string;
  };
  items: Line[];
};

export function ForwardOrders({
  orders,
  suppliers,
}: {
  orders: ForwardOrder[];
  suppliers: Supplier[];
}) {
  const [copied, setCopied] = useState<string | null>(null);

  // Group order lines by supplier. Only lines that actually have one.
  const bySupplier = new Map<string, { order: ForwardOrder; lines: Line[] }[]>();

  for (const order of orders) {
    const grouped = new Map<string, Line[]>();
    for (const item of order.items) {
      if (!item.supplier) continue;
      const key = item.supplier;
      grouped.set(key, [...(grouped.get(key) ?? []), item]);
    }
    for (const [supplier, lines] of grouped) {
      bySupplier.set(supplier, [...(bySupplier.get(supplier) ?? []), { order, lines }]);
    }
  }

  if (bySupplier.size === 0) {
    return (
      <section className="rounded-[var(--radius-card)] border border-line bg-canvas p-5">
        <h2 className="font-display text-lg">Orders to forward</h2>
        <p className="mt-1.5 text-[13px] text-ink-mute">
          Nothing waiting. Orders containing a dropshipped product appear here,
          split by supplier and ready to send.
        </p>
      </section>
    );
  }

  function messageFor(
    supplier: string,
    entries: { order: ForwardOrder; lines: Line[] }[],
  ): string {
    const s = suppliers.find(
      (x) => x.name.trim().toLowerCase() === supplier.trim().toLowerCase(),
    );

    const parts = [`Order forward — AtoZacc`, ``];

    for (const { order, lines } of entries) {
      const a = order.address;
      parts.push(`Order ${order.orderNumber}`);
      for (const l of lines) parts.push(`  ${l.qty} x ${l.name} (${l.sku})`);
      parts.push(`Ship to:`);
      parts.push(`  ${a.name}`);
      parts.push(
        `  ${[a.line1, a.line2, a.area].filter(Boolean).join(", ")}`,
      );
      if (a.landmark) parts.push(`  Landmark: ${a.landmark}`);
      parts.push(`  ${a.city}, ${a.state} - ${a.pincode}`);
      parts.push(`  Phone: ${a.mobile}`);
      // The supplier has to know whether to collect money at the door.
      parts.push(
        `Payment: ${order.paymentMethod === "COD" ? "COLLECT CASH ON DELIVERY" : "Already paid — do not collect"}`,
      );
      parts.push(``);
    }

    if (s?.acceptsCod === false) {
      parts.push(`(Note: prepaid supplier — no COD orders should appear here.)`);
    }

    return parts.join("\n");
  }

  async function copy(key: string, text: string) {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(key);
      setTimeout(() => setCopied(null), 2000);
    } catch {
      setCopied("failed");
    }
  }

  return (
    <section className="rounded-[var(--radius-card)] border border-line bg-canvas p-5">
      <h2 className="font-display text-lg">Orders to forward</h2>
      <p className="mt-1.5 max-w-prose text-[12.5px] text-ink-mute">
        Grouped by supplier, with the address and whether cash must be collected.
        Copy and send by WhatsApp or email.
      </p>

      <div className="mt-4 space-y-4">
        {[...bySupplier.entries()].map(([supplier, entries]) => {
          const s = suppliers.find(
            (x) => x.name.trim().toLowerCase() === supplier.trim().toLowerCase(),
          );
          const text = messageFor(supplier, entries);
          const codCount = entries.filter((e) => e.order.paymentMethod === "COD").length;
          const wa = s?.whatsapp?.replace(/\D/g, "");

          return (
            <div
              key={supplier}
              className="rounded-[var(--radius-card)] border border-line bg-surface p-4"
            >
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div>
                  <p className="text-[14px] font-bold">{supplier}</p>
                  <p className="tnum text-[11.5px] text-ink-mute">
                    {entries.length} {entries.length === 1 ? "order" : "orders"}
                    {s ? ` · dispatches in ${s.dispatchDays}d` : " · not set up"}
                  </p>
                </div>
                <div className="flex flex-wrap gap-2">
                  <button
                    type="button"
                    onClick={() => copy(supplier, text)}
                    className="rounded-[var(--radius-card)] border border-ink px-3 py-1.5 text-[12.5px] font-semibold hover:bg-ink hover:text-canvas"
                  >
                    {copied === supplier ? "Copied" : "Copy message"}
                  </button>
                  {wa && (
                    <a
                      href={`https://wa.me/91${wa}?text=${encodeURIComponent(text)}`}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="rounded-[var(--radius-card)] bg-brand px-3 py-1.5 text-[12.5px] font-semibold text-white hover:bg-brand-deep"
                    >
                      Send on WhatsApp
                    </a>
                  )}
                </div>
              </div>

              {/* The mismatch that strands an order: a COD sale routed to a
                  supplier who will not ship COD. */}
              {s?.acceptsCod === false && codCount > 0 && (
                <p className="mt-2 rounded-[var(--radius-card)] border border-brand bg-blush px-3 py-2 text-[12px] font-medium text-brand-deep">
                  {codCount} of these {codCount === 1 ? "is" : "are"} cash on
                  delivery, but this supplier is prepaid only. Pay them yourself
                  and collect from the customer, or cancel and refund.
                </p>
              )}

              <pre className="mt-3 max-h-56 overflow-auto rounded-[var(--radius-card)] border border-line bg-canvas p-3 font-mono text-[11px] leading-relaxed text-ink-mid">
                {text}
              </pre>
            </div>
          );
        })}
      </div>

      {copied === "failed" && (
        <p className="mt-2 text-[12px] text-brand">
          Copy failed — select the text in the box and copy manually.
        </p>
      )}
    </section>
  );
}
