# AtoZacc

Indian D2C storefront for fashion accessories — women, men and kids.

**Status:** Phase 1 complete and running. Storefront, checkout and admin all
work end to end. Not yet connected to a database — see *Data* below.

Full specification: [`docs/SYSTEM-REQUIREMENTS.md`](docs/SYSTEM-REQUIREMENTS.md)

---

## Running it

```bash
npm run dev
```

Then open http://localhost:3000. The admin panel is at `/admin`.

| Script | Does |
| --- | --- |
| `npm run dev` | Dev server |
| `npm run build` | Production build |
| `npm run typecheck` | TypeScript, no emit |
| `npm run db:migrate` | Create and apply a migration |
| `npm run db:seed` | Load the catalogue into Postgres |

---

## What works

**Storefront** — home, gender landings, category and sub-category listings
with filters and sort, product detail, search, cart, checkout, order
confirmation, order tracking, wishlist, account, FAQ, about, contact and six
policy pages.

**Commerce** — the full pricing engine: product discounts, coupons, the
prepaid discount, free-shipping threshold, COD fee and eligibility rules,
tax-inclusive pricing, and partial payment (built, switched off).

**Admin** — dashboard, order queue with one-tap status transitions, order
detail, products, categories, inventory, customers, coupons, reports
(including the COD/RTO report) and settings.

---

## Data

The catalogue lives in `src/data/catalog.ts` and the app reads it directly.
`prisma/seed.ts` writes that same file into Postgres, so the demo catalogue
and the seeded catalogue cannot drift apart.

Orders are held in memory (`src/lib/orders.ts`) and do not survive a restart.
Both of these are deliberate seams: each function maps one-to-one onto a model
in `prisma/schema.prisma`, so connecting the database is a change inside those
two files.

To connect it:

```bash
cp .env.example .env.local
```

Fill in `DATABASE_URL` from Neon, then:

```bash
npm run db:migrate && npm run db:seed
```

---

## Four rules that must not be broken

These are load-bearing. Breaking one produces wrong invoices or lost money.

**1. Money is always an integer number of paise.**
Never a float, never rupees. `0.1 + 0.2 !== 0.3`. Rupees exist only at the
edges — parsing admin input and rendering to screen. See `src/lib/money.ts`.

**2. Prices are computed on the server, never accepted from the client.**
The cart cookie holds product identity and quantity only. Every amount is
re-derived from the catalogue and the settings store. This is the most
exploited hole in small e-commerce sites.

**3. `InventoryTransaction` is append-only.**
Never update or delete a row. Current stock is a cache the ledger can rebuild.
That is what makes a discrepancy findable rather than mysterious.

**4. `paidAmount + balanceAmount === total`, always.**
`paymentStatus` is *derived* from those numbers, never set independently. That
invariant is what keeps partial-payment records honest.

Orders also snapshot everything — addresses as JSON, and product name, SKU,
image and price on each line. Renaming a product or editing a saved address
must never rewrite an old invoice.

---

## Layout

```
prisma/schema.prisma     41 models — catalogue, orders, inventory, returns
prisma/seed.ts           Loads src/data/catalog.ts into Postgres
prisma.config.ts         Prisma 7 moved connection config out of the schema

src/data/catalog.ts      Categories, collections and 37 products
src/data/coupons.ts      Launch coupons
src/data/policies.ts     Policy text, generated from live settings

src/lib/money.ts         Paise arithmetic, INR formatting, GST extraction
src/lib/pricing.ts       The pricing engine — server-only
src/lib/settings.ts      Business rules as data, with working defaults
src/lib/catalog.ts       Catalogue reads, filtering, faceting
src/lib/cart.ts          Cookie-backed cart
src/lib/orders.ts        Order store and payment state machine

src/app/(shop)/          Storefront
src/app/admin/           Admin panel
src/components/          UI
```

---

## Business rules live in settings, not in code

The COD fee, prepaid discount, free-shipping threshold and partial-payment
rules are all values in `src/lib/settings.ts`, overridable per-row from the
`Setting` table once the database is connected.

"Change the COD fee" must never mean "call your developer."

Current defaults: free shipping over ₹699, ₹59 below that, ₹40 COD fee, ₹25
off for paying online, COD between ₹199 and ₹3,000, COD blocked after 2
refused deliveries.

---

## Prices are tax-inclusive

The store is not GST-registered, so tax is zero and invoices are Bills of
Supply. Because prices are tax-*inclusive*, registering later extracts GST
from the existing price rather than adding it on top — **no displayed price
changes on registration day.** Each category already carries its GST band,
ready for that day.

---

## Before this can go live

Four things block launch, and none of them are code:

1. **Product photography** — the longest lead time in the project. The site
   currently ships generated placeholder art.
2. **Razorpay KYC** — needs PAN, a bank account and address proof. Online
   payment is switched off in settings until the keys are live; COD works.
3. **SMS DLT registration** — required for OTP on Indian networks. Until it
   clears there is no mobile login and no COD OTP.
4. **Domain purchase.**

Two things block it that *are* code, and are the next work:

- **Admin authentication.** `/admin` is currently unprotected. This must be
  built before deploying anywhere public.
- **Database.** Orders do not survive a restart until Postgres is connected.

Detail in §2 of the requirements document.
