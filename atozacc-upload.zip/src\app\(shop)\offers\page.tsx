import { ProductListing, type SearchParamsShape } from "@/components/product-listing";
import { Container } from "@/components/ui";
import { COUPONS } from "@/data/coupons";
import { formatINR } from "@/lib/money";
import { getSettings } from "@/lib/settings";

export const metadata = {
  title: "Offers & Deals",
  description: "Current discounts, coupon codes and combo offers at AtoZacc.",
};

export default async function OffersPage({
  searchParams,
}: {
  searchParams: Promise<SearchParamsShape>;
}) {
  const [sp, settings] = await Promise.all([searchParams, getSettings()]);

  return (
    <>
      <Container className="pt-6">
        <h1 className="font-display text-[30px] leading-tight sm:text-[36px]">
          Offers &amp; Deals
        </h1>
        <p className="mt-1.5 max-w-2xl text-[13.5px] text-ink-mute">
          Coupon codes, automatic savings and everything currently discounted by
          20% or more.
        </p>

        {/* Coupons. Codes are shown in full rather than hidden behind a
            "reveal" — making someone click to see a code they then have to
            remember is friction with no upside. */}
        <div className="mt-7 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {COUPONS.map((c) => (
            <div
              key={c.code}
              className="rounded-[var(--radius-card)] border border-dashed border-brand bg-blush p-4"
            >
              <p className="font-display text-xl text-brand-deep">
                {c.type === "PERCENT"
                  ? `${c.value / 100}% off`
                  : c.type === "FIXED"
                    ? `${formatINR(c.value)} off`
                    : "Free shipping"}
              </p>
              <p className="tnum mt-2 inline-block rounded border border-brand/40 bg-canvas px-2 py-1 text-[13px] font-bold tracking-wider text-ink">
                {c.code}
              </p>
              <ul className="mt-2.5 space-y-0.5 text-[11.5px] text-ink-mute">
                {c.minOrderValue && <li>On orders over {formatINR(c.minOrderValue)}</li>}
                {c.maxDiscount && <li>Up to {formatINR(c.maxDiscount)} off</li>}
                {c.prepaidOnly && <li>Prepaid orders only</li>}
              </ul>
            </div>
          ))}
        </div>

        <div className="mt-4 rounded-[var(--radius-card)] border border-line bg-surface px-4 py-3 text-[12.5px] text-ink-mid">
          Always on: <strong>{formatINR(settings.prepaidDiscount)} off</strong> when
          you pay online, and <strong>free shipping</strong> over{" "}
          {formatINR(settings.freeShippingThreshold)}. One coupon per order.
        </div>
      </Container>

      <ProductListing
        title="On sale now"
        breadcrumbs={[{ label: "Offers" }]}
        searchParams={sp}
        baseFilters={{ minDiscount: 20 }}
      />
    </>
  );
}
