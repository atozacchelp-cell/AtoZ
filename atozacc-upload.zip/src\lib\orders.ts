import { readJson, writeAndInvalidate } from "@/lib/storage";

import type { PaymentChoice, PriceBreakdown } from "@/lib/pricing";

/**
 * Order storage.
 *
 * File-backed until Postgres is connected. Every function here maps one-to-one
 * onto the `Order` model in prisma/schema.prisma, so wiring the database is a
 * change inside this file and nowhere else.
 */

export type OrderAddress = {
  name: string;
  mobile: string;
  email?: string;
  line1: string;
  line2?: string;
  area?: string;
  landmark?: string;
  city: string;
  state: string;
  pincode: string;
  country: string;
};

export type OrderStatus =
  | "PENDING"
  | "CONFIRMED"
  | "PACKED"
  | "SHIPPED"
  | "IN_TRANSIT"
  | "OUT_FOR_DELIVERY"
  | "DELIVERED"
  | "FAILED_DELIVERY"
  | "RTO"
  | "CANCELLED";

export type PaymentStatus =
  | "PENDING"
  | "PROCESSING"
  | "PAID"
  | "PARTIALLY_PAID"
  | "FAILED"
  | "REFUNDED"
  | "PARTIALLY_REFUNDED"
  | "COD_PENDING"
  | "COD_COLLECTED";

export type StoredOrder = {
  orderNumber: string;
  status: OrderStatus;
  paymentStatus: PaymentStatus;
  paymentMethod: PaymentChoice;

  items: {
    name: string;
    sku: string;
    imageUrl: string;
    href: string;
    variantLabel?: string;
    unitPrice: number;
    unitMrp: number;
    qty: number;
    lineTotal: number;
  }[];

  subtotal: number;
  productDiscount: number;
  couponDiscount: number;
  couponCode?: string;
  prepaidDiscount: number;
  shippingCharge: number;
  codFee: number;
  taxAmount: number;
  total: number;

  /** INVARIANT: paidAmount + balanceAmount === total. Always. */
  paidAmount: number;
  balanceAmount: number;
  /**
   * What the gateway should charge for this order right now — the full total
   * for prepaid, the advance for partial, zero for COD. Distinct from
   * `paidAmount`, which is what has actually arrived.
   */
  onlineAmountDue: number;
  balanceCollectionMethod?: "COD" | "LINK" | "ACCOUNT";

  shippingAddress: OrderAddress;
  billingAddress: OrderAddress;

  customerNote?: string;
  placedAt: string;
  /** COD orders are only confirmed once the OTP is verified. */
  codVerifiedAt?: string;

  statusHistory: { at: string; status: OrderStatus; note?: string }[];
  gatewayOrderId?: string;

  // --- UPI payment claim -------------------------------------------------
  /**
   * What the CUSTOMER says they paid. A claim, not a fact: the site cannot
   * see your bank account, so this stays unverified until you check.
   */
  upiReference?: string;
  paymentClaimedAt?: string;
  /** Set only when a human confirms the money actually arrived. */
  paymentVerifiedAt?: string;
  paymentRejectedReason?: string;
  /** Every gateway payment id already applied — the idempotency guard. */
  gatewayPaymentIds?: string[];
};

/**
 * Orders are persisted to a file, not held in memory.
 *
 * Two reasons, both discovered the hard way: route handlers and server
 * components run in separate module instances, so an in-memory Map is not
 * shared between them — the CSV export saw an empty shop while admin showed
 * orders. And orders vanished on every restart, which is unacceptable even in
 * testing. Synchronous I/O is fine at this size; a shop doing twenty orders a
 * day will never notice, and it keeps every caller unchanged.
 */
const ORDERS_KEY = "orders";

async function loadOrders(): Promise<Map<string, StoredOrder>> {
  const raw = await readJson<StoredOrder[]>(ORDERS_KEY, []);
  return new Map(raw.map((o) => [o.orderNumber, o]));
}

/**
 * Saves the order book.
 *
 * Deliberately NOT wrapped in a try/catch. A write that fails has lost an
 * order, and the customer must see a failed checkout they can retry rather
 * than a confirmation for something that was never recorded.
 */
async function persist(map: Map<string, StoredOrder>): Promise<void> {
  await writeAndInvalidate(ORDERS_KEY, [...map.values()]);
}

/**
 * Read fresh from disk on EVERY access rather than caching in a module
 * request.
 *
 * Route handlers and server components are separate module instances, so a
 * cached Map goes stale the moment the other instance writes — an order
 * verified in admin still read as unpaid in the CSV export. The file is the
 * single source of truth; a short cache in the storage layer keeps one page
 * render down to one fetch.
 */
async function readAll(): Promise<Map<string, StoredOrder>> {
  return loadOrders();
}

/** ATZ-2026-0001. Derived from what is on disk, so numbers never collide. */
export async function nextOrderNumber(prefix = "ATZ"): Promise<string> {
  const highest = [...(await readAll()).values()].reduce((max, o) => {
    const n = Number(o.orderNumber.split("-").pop());
    return Number.isFinite(n) ? Math.max(max, n) : max;
  }, 0);

  const year = new Date().getFullYear();
  return `${prefix}-${year}-${String(highest + 1).padStart(4, "0")}`;
}

/**
 * Derives payment status from the money, never sets it independently.
 *
 * This is the rule that keeps partial-payment records honest: status is a
 * function of (paid, total, method), so the two numbers and the label cannot
 * disagree with each other.
 */
export function derivePaymentStatus(
  paid: number,
  total: number,
  method: PaymentChoice,
): PaymentStatus {
  if (method === "COD" && paid === 0) return "COD_PENDING";
  if (paid <= 0) return "PENDING";
  if (paid >= total) return method === "COD" ? "COD_COLLECTED" : "PAID";
  return "PARTIALLY_PAID";
}

export async function createOrder(input: {
  breakdown: PriceBreakdown;
  payment: PaymentChoice;
  shippingAddress: OrderAddress;
  billingAddress: OrderAddress;
  customerNote?: string;
  orderNumberPrefix?: string;
  gatewayOrderId?: string;
}): Promise<StoredOrder> {
  const { breakdown: b, payment } = input;

  // NOTHING has been received at the moment an order is created — not even on
  // a prepaid order, because the customer has not reached the gateway yet.
  // Setting paidAmount to the total here would mark every prepaid order PAID
  // before payment, and a failed payment would still read as paid.
  const paidAmount = 0;
  const balanceAmount = b.total;

  // What the gateway should charge now: the whole total for a prepaid order,
  // just the advance for a partial one, nothing for COD.
  const onlineAmountDue =
    payment === "COD" ? 0 : b.isPartial ? b.advanceAmount : b.total;

  const now = new Date().toISOString();
  const orderNumber = await nextOrderNumber(input.orderNumberPrefix);

  // Every order starts PENDING. COD waits on phone/OTP verification; prepaid
  // and partial wait on the gateway. Confirmation is something that happens
  // TO an order, never its starting state.
  const status: OrderStatus = "PENDING";

  const order: StoredOrder = {
    orderNumber,
    status,
    paymentStatus: derivePaymentStatus(paidAmount, b.total, payment),
    paymentMethod: payment,

    items: b.lines.map((l) => {
      const [, colour, size] = l.variantKey.split("|");
      return {
        // Snapshotted: renaming or repricing a product later must not rewrite
        // this order.
        name: l.name,
        sku: l.variantKey.split("|")[0],
        imageUrl: l.imageUrl,
        href: l.href,
        variantLabel: [colour, size].filter(Boolean).join(" · ") || undefined,
        unitPrice: l.unitPrice,
        unitMrp: l.unitMrp,
        qty: l.qty,
        lineTotal: l.lineTotal,
      };
    }),

    subtotal: b.subtotal,
    productDiscount: b.productDiscount,
    couponDiscount: b.couponDiscount,
    couponCode: b.couponCode,
    prepaidDiscount: b.prepaidDiscount,
    shippingCharge: b.shippingCharge,
    codFee: b.codFee,
    taxAmount: b.taxAmount,
    total: b.total,

    paidAmount,
    balanceAmount,
    onlineAmountDue,
    balanceCollectionMethod: payment === "COD" ? "COD" : undefined,

    shippingAddress: input.shippingAddress,
    billingAddress: input.billingAddress,
    customerNote: input.customerNote,
    placedAt: now,

    statusHistory: [{ at: now, status, note: "Order placed" }],
    gatewayOrderId: input.gatewayOrderId,
  };

  const all = (await readAll());
  all.set(orderNumber, order);
  await persist(all);
  return order;
}

export async function getOrder(orderNumber: string): Promise<StoredOrder | null> {
  return (await readAll()).get(orderNumber.trim().toUpperCase()) ?? null;
}

/**
 * EVERY order in the shop. Admin only.
 *
 * This was being called from the customer-facing account page, which put
 * every customer's name, phone number and delivery address on a page anyone
 * could open. Callers outside /admin want `listOrdersForEmail`.
 */
export async function listOrders(): Promise<StoredOrder[]> {
  return [...(await readAll()).values()].sort((a, b) => b.placedAt.localeCompare(a.placedAt));
}

/**
 * One customer's orders, matched on the email the order was placed with.
 *
 * An empty or missing email returns nothing rather than everything — the
 * failure mode of a filter like this must be "shows too little".
 */
export async function listOrdersForEmail(email: string | undefined): Promise<StoredOrder[]> {
  const wanted = (email ?? "").trim().toLowerCase();
  if (!wanted) return [];

  return (await listOrders()).filter(
    (o) => (o.shippingAddress.email ?? "").trim().toLowerCase() === wanted,
  );
}

export async function updateOrderStatus(
  orderNumber: string,
  status: OrderStatus,
  note?: string,
): Promise<StoredOrder | null> {
  const orders = (await readAll());
  const order = orders.get(orderNumber);
  if (!order) return null;

  order.statusHistory.push({ at: new Date().toISOString(), status, note });
  order.status = status;

  // Delivering a COD order is the moment the money arrives.
  if (status === "DELIVERED" && order.paymentMethod === "COD") {
    order.paidAmount = order.total;
    order.balanceAmount = 0;
    order.paymentStatus = "COD_COLLECTED";
  }

  await persist(orders);
  return order;
}

/**
 * Records money actually received, and derives everything else from it.
 *
 * This is the ONLY way an order becomes paid. Callers pass the amount that
 * arrived; status is computed, never supplied — so the label can never
 * disagree with the numbers.
 *
 * Idempotent by payment id: a replayed gateway callback, a double-click or a
 * refreshed return page cannot add the same money twice.
 */
export async function recordPayment(
  orderNumber: string,
  amount: number,
  gatewayPaymentId?: string,
): Promise<StoredOrder | null> {
  const orders = (await readAll());
  const order = orders.get(orderNumber.trim().toUpperCase());
  if (!order) return null;

  if (gatewayPaymentId) {
    if (order.gatewayPaymentIds?.includes(gatewayPaymentId)) return order;
    order.gatewayPaymentIds = [...(order.gatewayPaymentIds ?? []), gatewayPaymentId];
  }

  // Never let a payment push paidAmount past the total, or the invariant
  // paidAmount + balanceAmount === total breaks.
  order.paidAmount = Math.min(order.total, order.paidAmount + amount);
  order.balanceAmount = order.total - order.paidAmount;
  order.paymentStatus = derivePaymentStatus(
    order.paidAmount,
    order.total,
    order.paymentMethod,
  );

  // Money arriving is what confirms an order.
  if (order.status === "PENDING") {
    order.status = "CONFIRMED";
    order.statusHistory.push({
      at: new Date().toISOString(),
      status: "CONFIRMED",
      note: `Payment received: ${amount / 100} INR`,
    });
  }

  await persist(orders);
  return order;
}

/** Marks a gateway attempt as failed. The order stays unpaid and unconfirmed. */
export async function recordPaymentFailure(
  orderNumber: string,
  reason?: string,
): Promise<StoredOrder | null> {
  const orders = (await readAll());
  const order = orders.get(orderNumber.trim().toUpperCase());
  if (!order) return null;

  // Deliberately does NOT touch paidAmount. A failed attempt moves no money.
  order.paymentStatus = order.paidAmount > 0 ? "PARTIALLY_PAID" : "FAILED";
  order.statusHistory.push({
    at: new Date().toISOString(),
    status: order.status,
    note: reason ? `Payment failed: ${reason}` : "Payment failed",
  });

  await persist(orders);
  return order;
}

/**
 * The customer says they have paid, and supplies their UPI reference.
 *
 * This moves NO money and marks nothing paid — it records the claim and flags
 * the order for checking. Treating a click as proof of payment would let
 * anyone take goods for free, so verification stays a human step.
 */
export async function claimUpiPayment(
  orderNumber: string,
  reference: string,
): Promise<StoredOrder | null> {
  const orders = (await readAll());
  const order = orders.get(orderNumber.trim().toUpperCase());
  if (!order) return null;

  const at = new Date().toISOString();
  const ref = reference.trim();
  const hasRef = ref !== "" && ref !== "not provided";

  order.upiReference = ref;
  order.paymentClaimedAt = at;
  order.paymentStatus = "PROCESSING";
  order.statusHistory.push({
    at,
    status: order.status,
    note: hasRef
      ? `Customer says they paid — UPI reference ${ref}. Needs checking`
      : "Customer says they paid — no reference given. Needs checking",
  });

  await persist(orders);
  return order;
}

/**
 * You have seen the money arrive. This is the only route to PAID.
 *
 * `recordPayment` re-reads from disk, so the verification stamp has to be
 * written AFTER it — setting it on a copy beforehand would be discarded by
 * that reload, and the order would read as paid with no record of who
 * confirmed it or when.
 */
export async function verifyUpiPayment(orderNumber: string): Promise<StoredOrder | null> {
  const existing = (await readAll()).get(orderNumber.trim().toUpperCase());
  if (!existing) return null;

  const paid = recordPayment(orderNumber, existing.onlineAmountDue);
  if (!paid) return null;

  const all = (await readAll());
  const order = all.get(orderNumber.trim().toUpperCase());
  if (!order) return null;

  order.paymentVerifiedAt = new Date().toISOString();
  order.paymentRejectedReason = undefined;
  all.set(order.orderNumber, order);
  await persist(all);

  return order;
}

/** The money never arrived. The order stays unpaid and unconfirmed. */
export async function rejectUpiPayment(
  orderNumber: string,
  reason: string,
): Promise<StoredOrder | null> {
  const failed = recordPaymentFailure(orderNumber, reason);
  if (!failed) return null;

  const all = (await readAll());
  const order = all.get(orderNumber.trim().toUpperCase());
  if (!order) return null;

  order.paymentRejectedReason = reason;
  order.paymentVerifiedAt = undefined;
  all.set(order.orderNumber, order);
  await persist(all);

  return order;
}

export const ORDER_STATUS_LABELS: Record<OrderStatus, string> = {
  PENDING: "Pending",
  CONFIRMED: "Confirmed",
  PACKED: "Packed",
  SHIPPED: "Shipped",
  IN_TRANSIT: "In transit",
  OUT_FOR_DELIVERY: "Out for delivery",
  DELIVERED: "Delivered",
  FAILED_DELIVERY: "Delivery failed",
  RTO: "Returned to us",
  CANCELLED: "Cancelled",
};

export const PAYMENT_STATUS_LABELS: Record<PaymentStatus, string> = {
  PENDING: "Payment pending",
  PROCESSING: "Processing",
  PAID: "Paid",
  PARTIALLY_PAID: "Partially paid",
  FAILED: "Payment failed",
  REFUNDED: "Refunded",
  PARTIALLY_REFUNDED: "Partially refunded",
  // Not "Cash on delivery" — that is the payment METHOD, and repeating it as
  // the status makes two rows say the same word while answering different
  // questions. The status answers "has the money arrived?".
  COD_PENDING: "Awaiting collection",
  COD_COLLECTED: "Cash collected",
};

/** The customer-facing tracking steps, in order. */
export const TRACKING_STEPS: OrderStatus[] = [
  "CONFIRMED",
  "PACKED",
  "SHIPPED",
  "OUT_FOR_DELIVERY",
  "DELIVERED",
];
