import { fs } from "@/lib/data-fs";
import path from "node:path";

import { fileMtime } from "@/lib/data-fs";

/**
 * Customer testimonials, from the sheet.
 *
 * These were previously three invented people saying flattering things about
 * products the shop does not stock, under a heading reading "From verified
 * orders". That is a fabricated endorsement on a live storefront — illegal
 * under the Consumer Protection Act's rules on misleading advertisements, and
 * the sort of thing a customer only has to catch once.
 *
 * So: no defaults, and no placeholder examples. An empty Reviews tab means
 * the section does not render at all. A shop with no reviews yet should look
 * like a shop with no reviews yet.
 */

const REVIEWS_PATH = path.join(process.cwd(), "data", "reviews.json");

export type Review = {
  name: string;
  city?: string;
  /** 1–5. Out-of-range values are clamped rather than dropped. */
  rating: number;
  body: string;
  /** Which product it is about. Free text — shown under the name. */
  product?: string;
  /**
   * Only true when the shop confirms this person actually ordered. Nothing
   * claims to be verified on its own.
   */
  verified?: boolean;
  date?: string;
};

type Store = { reviews: Review[] };

let cache: Store | null = null;
let cachedMtime = -1;

export async function getReviews(): Promise<Review[]> {
  const mtime = fileMtime(REVIEWS_PATH);
  if (cache && mtime === cachedMtime) return cache.reviews;

  let resolved: Store;
  try {
    resolved = JSON.parse(await fs.readFile(REVIEWS_PATH, "utf8")) as Store;
    if (!Array.isArray(resolved.reviews)) resolved = { reviews: [] };
  } catch {
    resolved = { reviews: [] };
  }

  cache = resolved;
  cachedMtime = mtime;
  return resolved.reviews;
}

export async function saveReviews(reviews: Review[]): Promise<void> {
  await fs.mkdir(path.dirname(REVIEWS_PATH), { recursive: true });
  await fs.writeFile(REVIEWS_PATH, JSON.stringify({ reviews }, null, 2), "utf8");
  cache = { reviews };
  cachedMtime = fileMtime(REVIEWS_PATH);
}

/** Turns rows from the Reviews tab into reviews. Unusable rows are dropped. */
export function buildReviews(records: Record<string, string>[]): Review[] {
  const out: Review[] = [];

  for (const r of records) {
    const name = (r.name ?? r.customer ?? r.customername ?? "").trim();
    const body = (r.review ?? r.body ?? r.comment ?? r.text ?? "").trim();
    // A testimonial with no words is not a testimonial.
    if (!name || !body) continue;

    const raw = Number((r.rating ?? r.stars ?? "5").replace(/[^\d.]/g, ""));
    const rating = Number.isFinite(raw) ? Math.min(5, Math.max(1, Math.round(raw))) : 5;

    out.push({
      name,
      city: (r.city ?? r.location ?? "").trim() || undefined,
      rating,
      body,
      product: (r.product ?? r.item ?? "").trim() || undefined,
      verified: ["yes", "true", "1", "y"].includes(
        (r.verified ?? "").trim().toLowerCase(),
      ),
      date: (r.date ?? "").trim() || undefined,
    });
  }

  return out;
}
