import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Without this, Turbopack walks up and finds the unrelated package-lock.json
  // in the parent folder (which belongs to the MNF Metals site) and warns.
  turbopack: {
    root: __dirname,
  },
  images: {
    // Placeholder art is SVG until real product photography arrives.
    // These are our own files under /public, not remote input — and the CSP
    // below keeps the optimizer from executing anything inside them.
    dangerouslyAllowSVG: true,
    contentDispositionType: "attachment",
    contentSecurityPolicy: "default-src 'self'; script-src 'none'; sandbox;",
    // AVIF first: meaningfully smaller than WebP, and this store is served
    // to mobile users on Indian networks where every KB is latency.
    formats: ["image/avif", "image/webp"],
    // Product photos live in Google Drive. Next fetches each one ONCE, then
    // serves its own optimised copy — so Drive is not hit on every pageview,
    // which is what makes hosting images there workable at all.
    remotePatterns: [
      { protocol: "https", hostname: "lh3.googleusercontent.com" },
      { protocol: "https", hostname: "drive.google.com" },
      { protocol: "https", hostname: "res.cloudinary.com" },
      { protocol: "https", hostname: "ik.imagekit.io" },
    ],
    // Cache an optimised image for 30 days rather than the 60-second default.
    minimumCacheTTL: 60 * 60 * 24 * 30,
  },
};

export default nextConfig;
