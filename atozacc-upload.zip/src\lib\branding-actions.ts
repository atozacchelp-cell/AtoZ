"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";

import { saveBranding } from "@/lib/branding";
import { FONT_PAIRS, type FontPairKey } from "@/lib/font-pairs";
import { normaliseImageUrl } from "@/lib/google";

export type BrandingState = { ok?: boolean; error?: string };

const HEX = /^#[0-9a-fA-F]{6}$/;

const Schema = z.object({
  logoUrl: z.string().trim().max(500),
  logoText: z.string().trim().max(40),
  logoHeight: z.coerce.number().int().min(20).max(140),
  // Clamped: a broken measurement must not produce a logo wider than the header.
  logoAspect: z.coerce.number().min(0.3).max(12).default(3),
  fontPair: z.string().refine((v) => v in FONT_PAIRS, "Unknown font pairing"),
  baseFontSize: z.coerce.number().int().min(13).max(18),
  headingScale: z.coerce.number().min(0.85).max(1.25),
  brandColour: z.string().trim().regex(HEX, "Use a colour like #d42a4c"),
  brandDeepColour: z.string().trim().regex(HEX, "Use a colour like #a81f3b"),
  cornerRadius: z.coerce.number().int().min(0).max(20),
});

export async function updateBranding(
  _prev: BrandingState,
  formData: FormData,
): Promise<BrandingState> {
  const parsed = Schema.safeParse({
    logoUrl: formData.get("logoUrl") ?? "",
    logoText: formData.get("logoText") ?? "",
    logoHeight: formData.get("logoHeight") ?? 32,
    logoAspect: formData.get("logoAspect") ?? 3,
    fontPair: formData.get("fontPair") ?? "editorial",
    baseFontSize: formData.get("baseFontSize") ?? 15,
    headingScale: formData.get("headingScale") ?? 1,
    brandColour: formData.get("brandColour") ?? "#d42a4c",
    brandDeepColour: formData.get("brandDeepColour") ?? "#a81f3b",
    cornerRadius: formData.get("cornerRadius") ?? 4,
  });

  if (!parsed.success) {
    return { error: parsed.error.issues[0]?.message ?? "Those settings were not valid." };
  }

  await saveBranding({
    ...parsed.data,
    fontPair: parsed.data.fontPair as FontPairKey,
    // A Drive share link renders Drive's HTML viewer, not the image, so the
    // logo would silently break. Convert it the same way product images are.
    logoUrl: parsed.data.logoUrl ? normaliseImageUrl(parsed.data.logoUrl) : "",
  });

  // Branding is applied in the root layout, so every page has to revalidate.
  revalidatePath("/", "layout");

  return { ok: true };
}
