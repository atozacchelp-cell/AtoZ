"use client";

import Image from "next/image";
import Link from "next/link";
import { useActionState, useState } from "react";

import { submitUpiReference, type ClaimState } from "@/lib/upi-actions";
import { formatINR } from "@/lib/money";

/**
 * Pay by UPI.
 *
 * The honest shape of this: we show a QR carrying the exact amount, the
 * customer pays in their own app, and then they tell us the reference. The
 * site never learns on its own whether money moved — so nothing here claims
 * the order is paid. It says "we will confirm", because that is the truth.
 */
export function UpiPayment({
  orderNumber,
  amount,
  upiId,
  upiLink,
  qrDataUri,
  fallbackQrImage,
  supportPhone,
  alreadyClaimed,
}: {
  orderNumber: string;
  amount: number;
  upiId: string;
  upiLink: string;
  qrDataUri: string;
  fallbackQrImage?: string;
  supportPhone: string;
  alreadyClaimed?: string;
}) {
  const [state, action, pending] = useActionState<ClaimState, FormData>(
    submitUpiReference,
    {},
  );
  const [copied, setCopied] = useState(false);

  if (state.ok || alreadyClaimed) {
    return (
      <div className="rounded-[var(--radius-card)] border border-success/40 bg-success/10 p-6 text-center">
        <h1 className="font-display text-2xl text-success">Thank you</h1>
        <p className="mx-auto mt-2 max-w-md text-[13.5px] text-ink-mid">
          We have your payment reference for order{" "}
          <strong className="tnum">{orderNumber}</strong>. We check payments by
          hand and confirm within a few hours during working times — you will
          get a message once it clears, and the order ships after that.
        </p>
        <div className="mt-5 flex flex-wrap justify-center gap-3">
          <Link
            href={`/order/success/${orderNumber}`}
            className="rounded-[var(--radius-card)] bg-brand px-5 py-2.5 text-[13.5px] font-semibold text-white hover:bg-brand-deep"
          >
            View order
          </Link>
          <Link
            href="/shop"
            className="rounded-[var(--radius-card)] border border-ink px-5 py-2.5 text-[13.5px] font-semibold hover:bg-ink hover:text-canvas"
          >
            Keep shopping
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]">
      {/* --- Pay --- */}
      <section className="rounded-[var(--radius-card)] border border-line bg-canvas p-5">
        <p className="text-[11.5px] font-bold uppercase tracking-[0.1em] text-ink-mute">
          Step 1 — Pay
        </p>
        <h1 className="tnum mt-1 font-display text-[30px] leading-none">
          {formatINR(amount)}
        </h1>
        <p className="tnum mt-1 text-[12.5px] text-ink-mute">
          Order {orderNumber}
        </p>

        {/* On a phone this opens GPay / PhonePe / Paytm with the amount and
            order number already filled in. */}
        <a
          href={upiLink}
          className="mt-4 flex w-full items-center justify-center rounded-[var(--radius-card)] bg-brand px-5 py-3.5 text-[15px] font-semibold text-white hover:bg-brand-deep sm:hidden"
        >
          Pay {formatINR(amount)} in your UPI app
        </a>

        <div className="mt-4 rounded-[var(--radius-card)] border border-line bg-surface p-4 text-center">
          <p className="text-[12.5px] font-semibold text-ink-mid">
            <span className="sm:hidden">Or scan</span>
            <span className="hidden sm:inline">Scan with any UPI app</span>
          </p>
          <span className="relative mx-auto mt-3 block h-[220px] w-[220px]">
            <Image
              src={qrDataUri || fallbackQrImage || ""}
              alt={`UPI QR code for ${formatINR(amount)}`}
              fill
              unoptimized
              className="object-contain"
            />
          </span>
          <p className="tnum mt-3 text-[12.5px] text-ink-mid">
            The amount is already set to <strong>{formatINR(amount)}</strong>
          </p>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-2 text-[12.5px]">
          <span className="text-ink-mute">Or pay to</span>
          <code className="rounded bg-surface-2 px-2 py-1 font-mono text-[12px]">
            {upiId}
          </code>
          <button
            type="button"
            onClick={async () => {
              try {
                await navigator.clipboard.writeText(upiId);
                setCopied(true);
                setTimeout(() => setCopied(false), 2000);
              } catch {
                /* selection fallback is fine */
              }
            }}
            className="font-semibold text-brand hover:text-brand-deep"
          >
            {copied ? "Copied" : "Copy"}
          </button>
        </div>
      </section>

      {/* --- Confirm --- */}
      <section className="rounded-[var(--radius-card)] border border-line bg-canvas p-5">
        <p className="text-[11.5px] font-bold uppercase tracking-[0.1em] text-ink-mute">
          Step 2 — Tell us
        </p>
        <h2 className="mt-1 font-display text-xl">Done paying?</h2>
        <p className="mt-1.5 text-[13px] text-ink-mid">
          Tap the button once your payment has gone through. That is all we
          need — your order number is already attached to the payment.
        </p>

        <form action={action} className="mt-4">
          <input type="hidden" name="orderNumber" value={orderNumber} />

          {/* The button comes first, because it is the only required step.
              The reference sits underneath as an optional extra rather than a
              gate — most people cannot find a UTR, and blocking on it loses
              the order for no gain. */}
          <button
            type="submit"
            disabled={pending}
            className="w-full rounded-[var(--radius-card)] bg-brand px-5 py-4 text-[15px] font-bold text-white transition-colors hover:bg-brand-deep disabled:opacity-60"
          >
            {pending ? "Submitting…" : `I have paid ${formatINR(amount)}`}
          </button>

          <details className="mt-3">
            <summary className="cursor-pointer text-[12.5px] font-semibold text-ink-mute hover:text-brand">
              Have a UPI reference number? Add it (optional)
            </summary>
            <input
              name="reference"
              inputMode="numeric"
              placeholder="e.g. 412345678901"
              className="tnum mt-2 w-full rounded-[var(--radius-card)] border border-line bg-surface px-3 py-2.5 text-[14px] focus:border-brand focus:bg-canvas focus:outline-none"
            />
            <span className="mt-1 block text-[11.5px] text-ink-mute">
              Shown in your UPI app as the transaction or UTR number. It helps
              us find your payment faster, but is not required.
            </span>
          </details>

          {state.error && (
            <p role="alert" className="mt-2 text-[12.5px] font-medium text-brand">
              {state.error}
            </p>
          )}
        </form>

        {/* Said plainly, because a customer who expects instant confirmation
            and does not get it assumes the payment failed and pays twice. */}
        <div className="mt-4 rounded-[var(--radius-card)] border border-line bg-surface p-3.5 text-[12.5px] text-ink-mid">
          <p className="font-semibold text-ink">What happens next</p>
          <p className="mt-1">
            We check the payment against our account by hand and confirm it —
            usually within a few hours. Your order ships once it clears. Nothing
            is charged automatically and your order is already saved.
          </p>
          <p className="mt-2">
            Trouble? WhatsApp <strong className="tnum">{supportPhone}</strong>{" "}
            with your order number.
          </p>
        </div>
      </section>
    </div>
  );
}
