import { randomBytes } from "node:crypto";
import { cookies } from "next/headers";
import { NextResponse, type NextRequest } from "next/server";

import { googleConfigured, googleAuthUrl, STATE_COOKIE } from "@/lib/google-auth";

/**
 * Starts a Google sign-in.
 *
 * The `state` parameter is a random value stored in a short-lived cookie and
 * echoed back by Google. On return the two must match. Without it, an
 * attacker can send a victim a pre-made callback URL carrying the ATTACKER's
 * authorisation code, and the victim silently ends up signed into the
 * attacker's account — every order they then place lands in someone else's
 * history. That is CSRF on login, and `state` is the whole defence.
 */
export async function GET(req: NextRequest) {
  if (!googleConfigured()) {
    return NextResponse.redirect(
      new URL("/signin?error=google-not-configured", req.nextUrl.origin),
    );
  }

  const state = randomBytes(24).toString("base64url");
  const next = req.nextUrl.searchParams.get("next") ?? "/account";

  const jar = await cookies();
  jar.set(STATE_COOKIE, `${state}|${next.startsWith("/") && !next.startsWith("//") ? next : "/account"}`, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    path: "/",
    maxAge: 600, // ten minutes is ample for a sign-in round trip
  });

  return NextResponse.redirect(googleAuthUrl(state, req.nextUrl.origin));
}
