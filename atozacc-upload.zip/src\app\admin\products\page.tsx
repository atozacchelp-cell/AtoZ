import Image from "next/image";
import Link from "next/link";

import { EmptyRow, PageHeader, Pill, Table } from "@/components/admin-ui";
import { CsvImport } from "@/components/csv-import";
import { allCategories } from "@/lib/taxonomy";
import { discountPercent, formatINR } from "@/lib/money";
import { getAllProducts } from "@/lib/product-store";
import { getSettings } from "@/lib/settings";

export const metadata = { title: "Products", robots: { index: false } };

const categoryName = new Map(allCategories().map((c) => [c.slug, c.name]));

export default async function AdminProducts({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; gender?: string; saved?: string; deleted?: string }>;
}) {
  const [{ q, gender, saved, deleted }, settings, all] = await Promise.all([
    searchParams,
    getSettings(),
    getAllProducts(),
  ]);

  const products = all.filter((p) => {
    if (gender && p.gender !== gender) return false;
    if (q) {
      const hay = `${p.name} ${p.sku} ${p.category}`.toLowerCase();
      if (!hay.includes(q.toLowerCase())) return false;
    }
    return true;
  });

  // Only real cost prices are counted. Guessing a cost for products that lack
  // one and calling the result "stock at cost" would put a made-up number in
  // front of someone about to make a buying decision with it.
  const withCost = all.filter((p) => p.costPrice);
  const stockAtCost = withCost.reduce(
    (s, p) => s + (p.costPrice ?? 0) * Math.max(0, p.stock),
    0,
  );
  const missingCost = all.length - withCost.length;

  return (
    <>
      <PageHeader
        title="Products"
        subtitle={
          withCost.length > 0
            ? `${all.length} products · ${formatINR(stockAtCost)} of stock at cost`
            : `${all.length} products`
        }
        action={{ href: "/admin/products/new", label: "Add product" }}
      />

      {saved && (
        <p className="mb-4 rounded-[var(--radius-card)] border border-success/40 bg-success/10 px-4 py-2.5 text-[13px] font-medium text-success">
          Saved. <span className="tnum">{saved}</span> is live in the shop.
        </p>
      )}
      {deleted && (
        <p className="mb-4 rounded-[var(--radius-card)] border border-line bg-surface px-4 py-2.5 text-[13px] text-ink-mid">
          Product deleted.
        </p>
      )}

      <div className="mb-4 flex flex-wrap items-start gap-2">
        <form method="get" className="flex flex-1 flex-wrap gap-2">
          <input
            name="q"
            defaultValue={q ?? ""}
            placeholder="Search name or SKU"
            className="min-w-0 flex-1 rounded-[var(--radius-card)] border border-line bg-canvas px-3 py-2 text-[13px] focus:border-brand focus:outline-none sm:max-w-xs"
          />
          <select
            name="gender"
            defaultValue={gender ?? ""}
            className="rounded-[var(--radius-card)] border border-line bg-canvas px-3 py-2 text-[13px]"
          >
            <option value="">All</option>
            <option value="women">Women</option>
            <option value="men">Men</option>
            <option value="kids">Kids</option>
            <option value="unisex">Unisex</option>
          </select>
          <button
            type="submit"
            className="rounded-[var(--radius-card)] bg-ink px-4 py-2 text-[13px] font-semibold text-canvas"
          >
            Filter
          </button>
        </form>

        <a
          href="/api/products/export"
          className="rounded-[var(--radius-card)] border border-line bg-canvas px-4 py-2 text-[13px] font-semibold hover:border-brand hover:text-brand"
        >
          Export CSV
        </a>
      </div>

      {missingCost > 0 && (
        <p className="mb-4 rounded-[var(--radius-card)] border border-warning/40 bg-gold-soft px-4 py-2.5 text-[12.5px] text-ink-mid">
          <strong>{missingCost}</strong>{" "}
          {missingCost === 1 ? "product has" : "products have"} no cost price, so
          they are missing from margin and profit figures. Add what you paid your
          supplier when you edit them.
        </p>
      )}

      <Table
        head={["Product", "SKU", "Category", "MRP", "Price", "Off", "Margin", "Stock", "Status"]}
      >
        {products.length === 0 ? (
          <EmptyRow colSpan={9}>
            {all.length === 0 ? (
              <>
                No products yet.{" "}
                <Link href="/admin/products/new" className="font-semibold text-brand">
                  Add your first one
                </Link>
                .
              </>
            ) : (
              "No products match that search."
            )}
          </EmptyRow>
        ) : (
          products.map((p) => {
            const cost = p.costPrice;
            const margin = cost ? Math.round(((p.price - cost) / p.price) * 100) : null;
            return (
              <tr key={p.sku} className="border-b border-line last:border-0">
                <td className="px-3 py-2">
                  <div className="flex items-center gap-2.5">
                    <span className="relative h-9 w-9 shrink-0 overflow-hidden rounded border border-line bg-surface">
                      <Image src={p.image} alt="" fill sizes="36px" className="object-cover" />
                    </span>
                    <Link
                      href={`/admin/products/${encodeURIComponent(p.sku)}`}
                      className="block max-w-[200px] truncate font-medium hover:text-brand"
                    >
                      {p.name}
                    </Link>
                  </div>
                </td>
                <td className="tnum whitespace-nowrap px-3 py-2 text-[11.5px] text-ink-mute">
                  {p.sku}
                </td>
                <td className="whitespace-nowrap px-3 py-2 text-ink-mute">
                  {categoryName.get(p.category) ?? p.category}
                </td>
                <td className="tnum px-3 py-2 text-ink-mute">{formatINR(p.mrp)}</td>
                <td className="tnum px-3 py-2 font-semibold">{formatINR(p.price)}</td>
                <td className="tnum px-3 py-2">{discountPercent(p.mrp, p.price)}%</td>
                <td className="tnum px-3 py-2">
                  {/* Margin matters more than revenue at a ~₹500 order, where
                      fulfilment eats roughly ₹95 before product cost. */}
                  {margin === null ? (
                    <span className="text-ink-mute">—</span>
                  ) : (
                    <span className={margin < 40 ? "font-semibold text-brand" : ""}>
                      {margin}%
                    </span>
                  )}
                </td>
                <td className="tnum px-3 py-2">{p.stock}</td>
                <td className="px-3 py-2">
                  {p.stock <= 0 ? (
                    <Pill tone="bad">Out</Pill>
                  ) : p.stock <= settings.lowStockThreshold ? (
                    <Pill tone="warn">Low</Pill>
                  ) : (
                    <Pill tone="good">Active</Pill>
                  )}
                </td>
              </tr>
            );
          })
        )}
      </Table>

      <div className="mt-8">
        <CsvImport />
      </div>
    </>
  );
}
