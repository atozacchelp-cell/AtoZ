/**
 * Shared between the admin form and the server.
 *
 * It lives apart from `sync-config.ts` because that module reads the file
 * system, and a client component cannot import anything that touches `fs`.
 */

/** How often the shop may re-read the sheet, in minutes. 0 means never. */
export const AUTO_SYNC_CHOICES = [0, 2, 5, 15, 30, 60] as const;

export const AUTO_SYNC_LABELS: Record<number, string> = {
  0: "Off — only when I press Sync now",
  2: "Every 2 minutes",
  5: "Every 5 minutes",
  15: "Every 15 minutes",
  30: "Every 30 minutes",
  60: "Every hour",
};
