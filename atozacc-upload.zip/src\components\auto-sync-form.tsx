"use client";

import { useActionState } from "react";

import { updateAutoSync, type AutoSyncState } from "@/lib/sheet-sync";
import { AUTO_SYNC_CHOICES, AUTO_SYNC_LABELS } from "@/lib/sync-constants";

type Status = {
  minutes: number;
  active: boolean;
  running: boolean;
  lastResult?: { at: string; ok: boolean; message: string };
};

/**
 * The schedule for automatic syncing.
 *
 * Kept as a separate form from the sheet links on purpose: changing how often
 * the shop re-reads the sheet should not require re-submitting, and therefore
 * re-validating, the links themselves.
 */
export function AutoSyncForm({
  minutes,
  status,
}: {
  minutes: number;
  status: Status;
}) {
  const [state, action, pending] = useActionState<AutoSyncState, FormData>(
    updateAutoSync,
    {},
  );

  const current = state.minutes ?? minutes;

  return (
    <form
      action={action}
      className="mt-5 rounded-[var(--radius-card)] border border-line bg-canvas p-5"
    >
      <div className="flex flex-wrap items-baseline justify-between gap-2">
        <h2 className="font-display text-lg">Automatic sync</h2>
        <span
          className={`rounded-full px-2.5 py-0.5 text-[11.5px] font-bold ${
            current > 0
              ? "bg-success/12 text-success"
              : "bg-surface text-ink-mute"
          }`}
        >
          {current > 0 ? `On · every ${current} min` : "Off"}
        </span>
      </div>

      <p className="mt-1 max-w-prose text-[12.5px] text-ink-mute">
        Re-reads the sheet on its own, so an edit in Google Sheets reaches the
        shop without anyone opening this page. A failed read never empties the
        catalogue — the last good version stays live.
      </p>

      <div className="mt-3 flex flex-wrap items-center gap-2">
        <select
          name="autoSyncMinutes"
          defaultValue={String(minutes)}
          className="rounded-[var(--radius-card)] border border-line bg-surface px-3 py-2.5 text-[13px] focus:border-brand focus:bg-canvas focus:outline-none"
        >
          {AUTO_SYNC_CHOICES.map((m) => (
            <option key={m} value={m}>
              {AUTO_SYNC_LABELS[m]}
            </option>
          ))}
        </select>

        <button
          type="submit"
          disabled={pending}
          className="rounded-[var(--radius-card)] border border-ink px-4 py-2.5 text-[13px] font-semibold hover:bg-ink hover:text-canvas disabled:opacity-50"
        >
          {pending ? "Saving…" : "Save schedule"}
        </button>
      </div>

      {state.error && (
        <p
          role="alert"
          className="mt-3 rounded-[var(--radius-card)] border border-brand bg-blush px-3.5 py-2.5 text-[12.5px] text-brand-deep"
        >
          {state.error}
        </p>
      )}

      {state.ok && (
        <p className="mt-3 text-[12.5px] font-semibold text-success">
          {current > 0
            ? `Saved. The shop will re-read your sheet every ${current} minutes.`
            : "Saved. Automatic syncing is off."}
        </p>
      )}

      {/* What the timer has actually been doing. Without this, "on" is a claim
          rather than something the owner can check. */}
      <dl className="mt-4 grid gap-x-6 gap-y-1.5 border-t border-line pt-3 text-[12.5px] sm:grid-cols-2">
        <Row label="Timer">
          {status.running
            ? "Syncing right now"
            : status.active
              ? `Running every ${status.minutes} min`
              : "Not scheduled"}
        </Row>
        <Row label="Last automatic run">
          {status.lastResult ? (
            <>
              <span className={status.lastResult.ok ? "text-success" : "text-brand"}>
                {status.lastResult.message}
              </span>
              <span className="tnum text-ink-mute">
                {" "}
                · {new Date(status.lastResult.at).toLocaleString("en-IN")}
              </span>
            </>
          ) : (
            <span className="text-ink-mute">
              None yet since the server started
            </span>
          )}
        </Row>
      </dl>
    </form>
  );
}

function Row({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <dt className="text-[11px] font-bold uppercase tracking-[0.08em] text-ink-mute">
        {label}
      </dt>
      <dd className="mt-0.5">{children}</dd>
    </div>
  );
}
