import { ProductCard } from "@/components/product-card";
import { SectionHeading } from "@/components/ui";
import type { ProductListItem } from "@/lib/catalog";
import { getSettings } from "@/lib/settings";

/**
 * How much a customer saves by paying online, or 0 when that lever is off.
 *
 * Read here rather than passed down from each page: a card renders on the
 * homepage, in search, on every category and under every product, and making
 * a dozen callers responsible for one setting is how one of them ends up
 * silently omitting it.
 */
async function prepaidSaving(): Promise<number> {
  const s = await getSettings();
  const on =
    s.prepaidDiscountEnabled && s.onlinePaymentEnabled && s.onlinePaymentMode !== "off";
  return on ? s.prepaidDiscount : 0;
}

/**
 * Horizontal rail on mobile, grid on desktop.
 *
 * Mobile gets a scroller rather than a wrapped grid because a rail keeps the
 * section header, the first two products and the *next* section all reachable
 * without a long scroll — which matters when the homepage carries a dozen
 * sections and 85% of traffic is on a phone.
 */
export async function ProductRail({
  title,
  subtitle,
  href,
  linkLabel,
  products,
}: {
  title: string;
  subtitle?: string;
  href?: string;
  linkLabel?: string;
  products: ProductListItem[];
}) {
  if (products.length === 0) return null;
  const prepaid = await prepaidSaving();

  return (
    <section className="mt-14">
      <SectionHeading title={title} subtitle={subtitle} href={href} linkLabel={linkLabel} />

      {/* Mobile: snap rail. Negative margin lets cards bleed to the screen
          edge, which signals scrollability better than a contained row. */}
      <div className="-mx-4 flex snap-x snap-mandatory gap-4 overflow-x-auto px-4 pb-2 sm:hidden">
        {products.map((p) => (
          <div key={p.slug} className="w-[46%] shrink-0 snap-start">
            <ProductCard product={p} prepaidDiscount={prepaid} />
          </div>
        ))}
      </div>

      {/* Desktop: grid */}
      <div className="hidden gap-x-5 gap-y-9 sm:grid sm:grid-cols-3 lg:grid-cols-4">
        {products.slice(0, 8).map((p) => (
          <ProductCard key={p.slug} product={p} prepaidDiscount={prepaid} />
        ))}
      </div>
    </section>
  );
}

/** Plain responsive grid, for listing pages. */
export async function ProductGrid({ products }: { products: ProductListItem[] }) {
  const prepaid = await prepaidSaving();

  return (
    <div className="grid grid-cols-2 gap-x-4 gap-y-9 sm:grid-cols-3 lg:grid-cols-4">
      {products.map((p) => (
        <ProductCard key={p.slug} product={p} prepaidDiscount={prepaid} />
      ))}
    </div>
  );
}
