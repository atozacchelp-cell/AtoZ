import { fileMtime, fs } from "@/lib/data-fs";
import path from "node:path";

import { PRODUCTS, type SeedProduct } from "@/data/catalog";
import { loadTaxonomy } from "@/lib/taxonomy";

/**
 * Where products actually live.
 *
 * Until Postgres is connected, the catalogue is a JSON file on disk that the
 * admin panel reads and writes. That lets the shop owner build a real
 * catalogue today — adding, editing and deleting products through a form
 * rather than editing TypeScript.
 *
 * IMPORTANT LIMIT: this works on a local machine, not on Vercel, whose
 * filesystem is read-only at runtime. It is a staging step — build the
 * catalogue locally, then `npm run db:seed` pushes it to Postgres, and this
 * file's job is done.
 */

const STORE_PATH = path.join(process.cwd(), "data", "products.json");

/** Cached, but re-read whenever the file changes underneath us. */
let cache: SeedProduct[] | null = null;
let cachedMtime = -1;

async function readStore(): Promise<SeedProduct[] | null> {
  try {
    const raw = await fs.readFile(STORE_PATH, "utf8");
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? (parsed as SeedProduct[]) : null;
  } catch {
    // No file yet — first run.
    return null;
  }
}

async function writeStore(products: SeedProduct[]): Promise<void> {
  await fs.mkdir(path.dirname(STORE_PATH), { recursive: true });
  await fs.writeFile(STORE_PATH, JSON.stringify(products, null, 2), "utf8");
  cache = products;
  cachedMtime = fileMtime(STORE_PATH);
}

/**
 * The catalogue. Falls back to the bundled sample products the first time,
 * so a fresh clone has something to look at rather than an empty shop.
 */
export async function getAllProducts(): Promise<SeedProduct[]> {
  // Every catalogue read goes through here, which makes it the one reliable
  // place to pull in categories and collections on a host where they cannot
  // be read synchronously.
  await loadTaxonomy();

  const mtime = fileMtime(STORE_PATH);
  if (cache && mtime === cachedMtime) return cache;

  const stored = await readStore();
  cachedMtime = mtime;
  if (stored) {
    cache = stored;
    return stored;
  }

  cache = PRODUCTS;
  return PRODUCTS;
}

/** Synchronous read for call sites already inside a request that loaded it. */
export function getCachedProducts(): SeedProduct[] {
  return cache ?? PRODUCTS;
}

export async function findProduct(slug: string): Promise<SeedProduct | null> {
  const all = await getAllProducts();
  return all.find((p) => p.slug === slug) ?? null;
}

export async function findProductBySku(sku: string): Promise<SeedProduct | null> {
  const all = await getAllProducts();
  return all.find((p) => p.sku === sku) ?? null;
}

export async function saveProduct(product: SeedProduct): Promise<void> {
  const all = [...(await getAllProducts())];
  const index = all.findIndex((p) => p.sku === product.sku);

  if (index >= 0) all[index] = product;
  else all.unshift(product); // newest first, so a just-added product is visible

  await writeStore(all);
}

export async function deleteProduct(sku: string): Promise<boolean> {
  const all = await getAllProducts();
  const next = all.filter((p) => p.sku !== sku);
  if (next.length === all.length) return false;
  await writeStore(next);
  return true;
}

export async function bulkUpsert(products: SeedProduct[]): Promise<{
  added: number;
  updated: number;
}> {
  const all = [...(await getAllProducts())];
  let added = 0;
  let updated = 0;

  for (const product of products) {
    const index = all.findIndex((p) => p.sku === product.sku);
    if (index >= 0) {
      all[index] = product;
      updated++;
    } else {
      all.unshift(product);
      added++;
    }
  }

  await writeStore(all);
  return { added, updated };
}

/** Resets to the bundled sample catalogue. Used by "start from scratch". */
export async function replaceAll(products: SeedProduct[]): Promise<void> {
  await writeStore(products);
}

export function invalidate(): void {
  cache = null;
}

/**
 * Generates the next SKU for a category, e.g. ATZ-WJE-0007.
 * Uses the category slug's initials so a SKU is readable on a packing slip.
 */
export async function nextSku(categorySlug: string): Promise<string> {
  const all = await getAllProducts();

  const code = categorySlug
    .split("-")
    .map((part) => part[0]?.toUpperCase() ?? "")
    .join("")
    .padEnd(3, "X")
    .slice(0, 3);

  const prefix = `ATZ-${code}-`;
  const highest = all
    .filter((p) => p.sku.startsWith(prefix))
    .map((p) => Number(p.sku.slice(prefix.length)))
    .filter((n) => Number.isFinite(n))
    .reduce((max, n) => Math.max(max, n), 0);

  return `${prefix}${String(highest + 1).padStart(4, "0")}`;
}

/** URL-safe slug from a product name, made unique against the catalogue. */
export async function makeSlug(name: string, ignoreSku?: string): Promise<string> {
  const base = name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 70) || "product";

  const all = await getAllProducts();
  const taken = new Set(
    all.filter((p) => p.sku !== ignoreSku).map((p) => p.slug),
  );

  if (!taken.has(base)) return base;

  let n = 2;
  while (taken.has(`${base}-${n}`)) n++;
  return `${base}-${n}`;
}
