import Link from "next/link";

import { cn } from "@/lib/cn";

/** Shared admin primitives. Data-dense, scanned rather than read. */

export function PageHeader({
  title,
  subtitle,
  action,
}: {
  title: string;
  subtitle?: string;
  action?: { href: string; label: string };
}) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-3">
      <div>
        <h1 className="font-display text-[26px] leading-tight">{title}</h1>
        {subtitle && <p className="mt-0.5 text-[13px] text-ink-mute">{subtitle}</p>}
      </div>
      {action && (
        <Link
          href={action.href}
          className="rounded-[var(--radius-card)] bg-ink px-4 py-2 text-[13px] font-semibold text-canvas hover:bg-brand"
        >
          {action.label}
        </Link>
      )}
    </div>
  );
}

export function Card({
  children,
  className,
}: {
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "rounded-[var(--radius-card)] border border-line bg-canvas p-4",
        className,
      )}
    >
      {children}
    </div>
  );
}

/**
 * A metric tile. `tone` encodes state in colour as well as number, so what
 * needs attention reads at a glance instead of requiring the number to be
 * compared against a threshold in the reader's head.
 */
export function Stat({
  label,
  value,
  sub,
  tone = "neutral",
  href,
}: {
  label: string;
  value: string;
  sub?: string;
  tone?: "neutral" | "good" | "warn" | "bad";
  href?: string;
}) {
  const tones = {
    neutral: "border-line",
    good: "border-l-[3px] border-l-success",
    warn: "border-l-[3px] border-l-warning",
    bad: "border-l-[3px] border-l-brand",
  };

  const body = (
    <>
      <p className="text-[10.5px] font-bold uppercase tracking-[0.1em] text-ink-mute">
        {label}
      </p>
      <p className="tnum mt-1 font-display text-[26px] leading-none">{value}</p>
      {sub && <p className="mt-1 text-[11.5px] text-ink-mute">{sub}</p>}
    </>
  );

  const className = cn(
    "rounded-[var(--radius-card)] border bg-canvas p-4 transition-colors",
    tones[tone],
    href && "hover:border-brand",
  );

  return href ? (
    <Link href={href} className={className}>
      {body}
    </Link>
  ) : (
    <div className={className}>{body}</div>
  );
}

export function Table({
  head,
  children,
}: {
  head: string[];
  children: React.ReactNode;
}) {
  return (
    <div className="scroll-x rounded-[var(--radius-card)] border border-line bg-canvas">
      <table className="w-full text-[13px]">
        <thead>
          <tr className="border-b border-line bg-surface">
            {head.map((h) => (
              <th
                key={h}
                className="whitespace-nowrap px-3 py-2.5 text-left text-[10.5px] font-bold uppercase tracking-[0.09em] text-ink-mute"
              >
                {h}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>{children}</tbody>
      </table>
    </div>
  );
}

export function Pill({
  children,
  tone = "neutral",
}: {
  children: React.ReactNode;
  tone?: "neutral" | "good" | "warn" | "bad";
}) {
  const tones = {
    neutral: "bg-surface-2 text-ink-mid",
    good: "bg-success/12 text-success",
    warn: "bg-gold-soft text-warning",
    bad: "bg-blush text-brand-deep",
  };
  return (
    <span
      className={cn(
        "inline-block whitespace-nowrap rounded-[var(--radius-pill)] px-2 py-0.5 text-[10.5px] font-bold uppercase tracking-[0.06em]",
        tones[tone],
      )}
    >
      {children}
    </span>
  );
}

export function EmptyRow({ colSpan, children }: { colSpan: number; children: React.ReactNode }) {
  return (
    <tr>
      <td colSpan={colSpan} className="px-3 py-10 text-center text-[13px] text-ink-mute">
        {children}
      </td>
    </tr>
  );
}
