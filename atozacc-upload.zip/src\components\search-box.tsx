"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export function SearchBox({ initialQuery = "" }: { initialQuery?: string }) {
  const router = useRouter();
  const [q, setQ] = useState(initialQuery);

  return (
    <form
      role="search"
      onSubmit={(e) => {
        e.preventDefault();
        const term = q.trim();
        router.push(term ? `/search?q=${encodeURIComponent(term)}` : "/shop");
      }}
      className="relative"
    >
      <label htmlFor="site-search" className="sr-only">
        Search products
      </label>
      <input
        id="site-search"
        type="search"
        value={q}
        onChange={(e) => setQ(e.target.value)}
        placeholder="Search earrings, wallets, watches…"
        className="w-full rounded-[var(--radius-pill)] border border-line bg-surface py-2 pl-9 pr-3 text-[13px] text-ink placeholder:text-ink-mute focus:border-brand focus:bg-canvas focus:outline-none"
      />
      <svg
        className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-ink-mute"
        width="15"
        height="15"
        viewBox="0 0 24 24"
        fill="none"
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        aria-hidden
      >
        <circle cx="11" cy="11" r="7" />
        <path d="m20 20-3.5-3.5" />
      </svg>
    </form>
  );
}
