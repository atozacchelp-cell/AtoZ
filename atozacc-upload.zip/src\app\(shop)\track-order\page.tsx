import { OrderDetail } from "@/components/order-detail";
import { Breadcrumbs, Container, EmptyState } from "@/components/ui";
import { getOrder } from "@/lib/orders";

export const metadata = {
  title: "Track Order",
  description: "Track an AtoZacc order using your order number.",
};

export default async function TrackOrderPage({
  searchParams,
}: {
  searchParams: Promise<{ order?: string }>;
}) {
  const { order: orderNumber } = await searchParams;
  const order = orderNumber ? await getOrder(orderNumber) : null;

  return (
    <Container className="max-w-3xl py-8">
      <Breadcrumbs items={[{ label: "Track Order" }]} />
      <h1 className="font-display text-[30px] sm:text-[36px]">Track your order</h1>
      <p className="mt-1.5 text-[13.5px] text-ink-mute">
        Enter the order number from your confirmation message.
      </p>

      <form method="get" className="mt-5 flex flex-wrap gap-2">
        <label htmlFor="order" className="sr-only">
          Order number
        </label>
        <input
          id="order"
          name="order"
          defaultValue={orderNumber ?? ""}
          placeholder="ATZ-2026-0001"
          className="tnum min-w-0 flex-1 rounded-[var(--radius-card)] border border-line bg-surface px-3.5 py-2.5 text-[14px] uppercase tracking-wider focus:border-brand focus:bg-canvas focus:outline-none sm:max-w-xs"
        />
        <button
          type="submit"
          className="rounded-[var(--radius-card)] bg-brand px-5 py-2.5 text-[13.5px] font-semibold text-white transition-colors hover:bg-brand-deep"
        >
          Track
        </button>
      </form>

      <div className="mt-8">
        {order ? (
          <OrderDetail order={order} />
        ) : orderNumber ? (
          <EmptyState
            title="We couldn't find that order"
            body="Check the order number and try again. It looks like ATZ-2026-0001 and is in your confirmation email or SMS."
            action={{ href: "/contact", label: "Contact support" }}
          />
        ) : null}
      </div>
    </Container>
  );
}
