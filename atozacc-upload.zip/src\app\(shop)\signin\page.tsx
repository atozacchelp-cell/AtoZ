import { redirect } from "next/navigation";

import { SignInForm } from "@/components/signin-form";
import { Container } from "@/components/ui";
import { googleConfigured } from "@/lib/google-auth";
import { currentUser } from "@/lib/session";

export const metadata = { title: "Sign in", robots: { index: false } };
export const dynamic = "force-dynamic";

/** Reasons the Google round trip can come back unhappy, in plain words. */
const ERRORS: Record<string, string> = {
  "google-not-configured": "Google sign-in is not set up on this store yet.",
  "state-mismatch":
    "That sign-in link did not start here, so it was refused. Please try again.",
  cancelled: "Google sign-in was cancelled.",
  "no-code": "Google did not send anything back. Please try again.",
  "exchange-failed": "Could not complete Google sign-in. Please try again.",
  "email-not-verified":
    "That Google account has an unverified email address, so it cannot be used to sign in.",
};

export default async function SignInPage({ searchParams }: PageProps<"/signin">) {
  const params = await searchParams;
  const user = await currentUser();
  if (user) redirect("/account");

  const next = typeof params.next === "string" ? params.next : "/account";
  const errorKey = typeof params.error === "string" ? params.error : undefined;

  return (
    <Container className="max-w-md py-10">
      <h1 className="font-display text-[30px]">Sign in</h1>
      <p className="mt-1.5 text-[13.5px] text-ink-mute">
        To see your orders and keep your wishlist across devices.
      </p>

      {errorKey && (
        <p
          role="alert"
          className="mt-5 rounded-[var(--radius-card)] border border-brand bg-blush px-3.5 py-2.5 text-[12.5px] text-brand-deep"
        >
          {ERRORS[errorKey] ?? "Something went wrong. Please try again."}
        </p>
      )}

      <SignInForm next={next} googleEnabled={googleConfigured()} />

      <p className="mt-8 text-[12px] text-ink-mute">
        You can still order without an account — every order is trackable with
        its order number.
      </p>
    </Container>
  );
}
