import Link from "next/link";

import { EmptyRow, PageHeader, Pill, Stat, Table } from "@/components/admin-ui";
import { PaymentSettingsForm } from "@/components/payment-settings-form";
import { formatINR } from "@/lib/money";
import { listOrders } from "@/lib/orders";
import { getSettings } from "@/lib/settings";

export const metadata = { title: "Payments", robots: { index: false } };

export default async function PaymentsPage() {
  const [settings, orders] = await Promise.all([
    getSettings(),
    (listOrders()),
  ]);

  // The queue that matters: money claimed but not yet checked against your
  // account. Anything here is an order that should not ship yet.
  const awaiting = orders.filter((o) => o.paymentClaimedAt && !o.paymentVerifiedAt);
  const verified = orders.filter((o) => o.paymentVerifiedAt);
  const collected = orders.reduce((s, o) => s + o.paidAmount, 0);

  return (
    <>
      <PageHeader
        title="Payments"
        subtitle="Your own UPI account — no gateway, no commission"
      />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat
          label="Awaiting your check"
          value={String(awaiting.length)}
          tone={awaiting.length > 0 ? "bad" : "good"}
          sub="Do not ship these yet"
        />
        <Stat label="Verified" value={String(verified.length)} tone="good" />
        <Stat label="Money received" value={formatINR(collected)} />
        <Stat
          label="Online payment"
          value={settings.onlinePaymentMode === "upi" ? "UPI QR" : "Off"}
          tone={settings.onlinePaymentMode === "upi" ? "good" : "neutral"}
          sub={settings.upiId || "No UPI ID set"}
        />
      </div>

      <h2 className="mt-8 font-display text-xl">Payments to check</h2>
      <p className="mb-3 max-w-prose text-[12.5px] text-ink-mute">
        The site cannot see your bank account, so it never marks a payment
        received on its own. Open your UPI app, find the reference, and confirm
        it here — that is the only thing that marks an order paid.
      </p>

      <Table head={["Order", "Customer", "Amount", "UPI reference", "Claimed", ""]}>
        {awaiting.length === 0 ? (
          <EmptyRow colSpan={6}>
            Nothing waiting. Payments appear here the moment a customer submits
            their reference.
          </EmptyRow>
        ) : (
          awaiting.map((o) => (
            <tr key={o.orderNumber} className="border-b border-line last:border-0">
              <td className="px-3 py-2.5">
                <Link
                  href={`/admin/orders/${o.orderNumber}`}
                  className="tnum font-semibold hover:text-brand"
                >
                  {o.orderNumber}
                </Link>
              </td>
              <td className="px-3 py-2.5">
                <span className="block max-w-[150px] truncate">
                  {o.shippingAddress.name}
                </span>
                <span className="tnum text-[11.5px] text-ink-mute">
                  {o.shippingAddress.mobile}
                </span>
              </td>
              <td className="tnum px-3 py-2.5 font-semibold">
                {formatINR(o.onlineAmountDue)}
              </td>
              <td className="tnum px-3 py-2.5 font-mono text-[12px]">
                {o.upiReference && o.upiReference !== "not provided" ? (
                  o.upiReference
                ) : (
                  <span className="font-sans text-ink-mute">
                    match by amount
                  </span>
                )}
              </td>
              <td className="tnum px-3 py-2.5 text-[12px] text-ink-mute">
                {o.paymentClaimedAt
                  ? new Date(o.paymentClaimedAt).toLocaleString("en-IN", {
                      day: "2-digit",
                      month: "short",
                      hour: "2-digit",
                      minute: "2-digit",
                    })
                  : "—"}
              </td>
              <td className="px-3 py-2.5">
                <Link
                  href={`/admin/orders/${o.orderNumber}`}
                  className="rounded-[var(--radius-card)] bg-ink px-3 py-1.5 text-[12px] font-semibold text-canvas hover:bg-brand"
                >
                  Check
                </Link>
              </td>
            </tr>
          ))
        )}
      </Table>

      <div className="mt-6 flex flex-wrap gap-3">
        <a
          href="/api/orders/export"
          className="rounded-[var(--radius-card)] border border-line bg-canvas px-4 py-2 text-[13px] font-semibold hover:border-brand hover:text-brand"
        >
          Export orders CSV
        </a>
        <span className="self-center text-[12px] text-ink-mute">
          Includes a paid yes/no column — import it into your Google Sheet.
        </span>
      </div>

      <h2 className="mt-10 mb-3 font-display text-xl">Settings</h2>
      <PaymentSettingsForm settings={settings} />

      <div className="mt-6 rounded-[var(--radius-card)] border border-warning/40 bg-gold-soft p-4 text-[12.5px] text-ink-mid">
        <p className="font-semibold text-ink">Why confirmation is manual</p>
        <p className="mt-1">
          A payment gateway tells a website when money arrives. A plain UPI
          transfer does not — nothing calls your site back. So if the site
          marked orders paid when someone clicked &ldquo;I have paid&rdquo;,
          anyone could take goods for free. Checking each reference against your
          UPI app is what keeps that honest. It costs you a few seconds per
          order and no commission.
        </p>
      </div>
    </>
  );
}
