"use client";

import Image from "next/image";
import { useActionState, useState } from "react";

import type { Branding } from "@/lib/branding";
import { FONT_PAIRS, type FontPairKey } from "@/lib/font-pairs";
import { updateBranding, type BrandingState } from "@/lib/branding-actions";
import { cn } from "@/lib/cn";

function driveToDirect(url: string): string {
  const u = url.trim();
  if (!u.includes("drive.google.com") && !u.includes("docs.google.com")) return u;
  const id =
    u.match(/\/file\/d\/([a-zA-Z0-9-_]+)/)?.[1] ??
    u.match(/[?&]id=([a-zA-Z0-9-_]+)/)?.[1] ??
    u.match(/\/d\/([a-zA-Z0-9-_]+)/)?.[1];
  return id ? `https://lh3.googleusercontent.com/d/${id}=w1400` : u;
}

/** Preview font stacks mirror the server pairing, so what you see is what saves. */
const PREVIEW_FONTS: Record<FontPairKey, { display: string; body: string }> = {
  editorial: { display: "var(--font-fraunces)", body: "var(--font-manrope)" },
  classic: { display: "var(--font-playfair)", body: "var(--font-jost)" },
  modern: { display: "var(--font-dmserif)", body: "var(--font-dmsans)" },
  fashion: { display: "var(--font-cormorant)", body: "var(--font-jost)" },
  friendly: { display: "var(--font-poppins)", body: "var(--font-poppins)" },
};

export function AppearanceForm({ branding }: { branding: Branding }) {
  const [state, action, pending] = useActionState<BrandingState, FormData>(
    updateBranding,
    {},
  );

  const [logoUrl, setLogoUrl] = useState(branding.logoUrl);
  const [logoText, setLogoText] = useState(branding.logoText);
  const [logoHeight, setLogoHeight] = useState(branding.logoHeight);
  const [logoAspect, setLogoAspect] = useState(branding.logoAspect || 3);
  const [fontPair, setFontPair] = useState<FontPairKey>(branding.fontPair);
  const [baseFontSize, setBaseFontSize] = useState(branding.baseFontSize);
  const [headingScale, setHeadingScale] = useState(branding.headingScale);
  const [brandColour, setBrandColour] = useState(branding.brandColour);
  const [brandDeep, setBrandDeep] = useState(branding.brandDeepColour);
  const [radius, setRadius] = useState(branding.cornerRadius);

  const fonts = PREVIEW_FONTS[fontPair];

  return (
    <form action={action} className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_380px]">
      <div className="space-y-5">
        {/* --- Logo --- */}
        <Section title="Logo">
          <label className="block">
            <Label>Logo image</Label>
            <input
              name="logoUrl"
              value={logoUrl}
              onChange={(e) => setLogoUrl(driveToDirect(e.target.value))}
              onBlur={(e) => setLogoUrl(driveToDirect(e.target.value))}
              placeholder="Paste a Google Drive link, or leave blank for text"
              className={input}
            />
            {/* Measured from the loaded image in the preview, so the header
                box matches the artwork instead of guessing a width. */}
            <input type="hidden" name="logoAspect" value={logoAspect} />
            <Hint>
              A Drive share link converts automatically. Leave this empty to use
              the wordmark below instead — which is often the better choice
              until you have a logo you actually like.
            </Hint>
          </label>

          <div className="grid gap-4 sm:grid-cols-2">
            <label className="block">
              <Label>Wordmark text</Label>
              <input
                name="logoText"
                value={logoText}
                onChange={(e) => setLogoText(e.target.value)}
                className={input}
              />
              <Hint>Used when there is no logo image.</Hint>
            </label>

            <Slider
              name="logoHeight"
              label="Logo height"
              value={logoHeight}
              onChange={setLogoHeight}
              min={20}
              max={140}
              suffix="px"
              hint="A logo with a tagline usually needs 70px or more to stay legible"
            />
          </div>
        </Section>

        {/* --- Type --- */}
        <Section title="Fonts">
          <div className="space-y-2">
            {(Object.keys(FONT_PAIRS) as FontPairKey[]).map((key) => {
              const pair = FONT_PAIRS[key];
              const preview = PREVIEW_FONTS[key];
              return (
                <label
                  key={key}
                  className={cn(
                    "flex cursor-pointer items-center gap-3 rounded-[var(--radius-card)] border p-3.5 transition-colors",
                    fontPair === key ? "border-brand bg-blush" : "border-line hover:border-ink",
                  )}
                >
                  <input
                    type="radio"
                    name="fontPair"
                    value={key}
                    checked={fontPair === key}
                    onChange={() => setFontPair(key)}
                    className="h-4 w-4 shrink-0 accent-[--color-brand]"
                  />
                  <span className="min-w-0 flex-1">
                    {/* Each option is set in its own fonts — the only way to
                        choose type is to see it. */}
                    <span
                      className="block text-[19px] leading-tight"
                      style={{ fontFamily: preview.display }}
                    >
                      Oxidised Jhumka Earrings
                    </span>
                    <span
                      className="mt-0.5 block text-[12px] text-ink-mute"
                      style={{ fontFamily: preview.body }}
                    >
                      {pair.label} — {pair.note}
                    </span>
                  </span>
                </label>
              );
            })}
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <Slider
              name="baseFontSize"
              label="Body text size"
              value={baseFontSize}
              onChange={setBaseFontSize}
              min={13}
              max={18}
              suffix="px"
              hint="15px is the default. 16 reads easier on phones."
            />
            <Slider
              name="headingScale"
              label="Heading size"
              value={headingScale}
              onChange={setHeadingScale}
              min={0.85}
              max={1.25}
              step={0.05}
              format={(v) => `${Math.round(v * 100)}%`}
              hint="Scales headings without touching body text."
            />
          </div>
        </Section>

        {/* --- Colour --- */}
        <Section title="Colour and shape">
          <div className="grid gap-4 sm:grid-cols-2">
            <ColourField
              name="brandColour"
              label="Brand colour"
              value={brandColour}
              onChange={setBrandColour}
              hint="Buttons, badges, links, prices."
            />
            <ColourField
              name="brandDeepColour"
              label="Hover colour"
              value={brandDeep}
              onChange={setBrandDeep}
              hint="A darker version of the brand colour."
            />
          </div>

          <Slider
            name="cornerRadius"
            label="Corner rounding"
            value={radius}
            onChange={setRadius}
            min={0}
            max={20}
            suffix="px"
            hint="0 is sharp and formal. Above 12 starts to read as playful."
          />
        </Section>

        {state.error && (
          <p role="alert" className="rounded-[var(--radius-card)] border border-brand bg-blush px-4 py-3 text-[13px] font-medium text-brand-deep">
            {state.error}
          </p>
        )}
        {state.ok && (
          <p className="rounded-[var(--radius-card)] border border-success/40 bg-success/10 px-4 py-3 text-[13px] font-medium text-success">
            Saved. Open the storefront to see it.
          </p>
        )}
      </div>

      {/* --- Live preview --- */}
      <aside>
        <div
          className="lg:sticky lg:top-6"
          style={
            {
              "--preview-brand": brandColour,
              "--preview-deep": brandDeep,
              "--preview-radius": `${radius}px`,
            } as React.CSSProperties
          }
        >
          <p className="mb-2 text-[10.5px] font-bold uppercase tracking-[0.1em] text-ink-mute">
            Live preview
          </p>

          <div className="overflow-hidden rounded-[var(--radius-card)] border border-line bg-canvas">
            {/* Header strip */}
            <div
              className="flex items-center justify-between px-4 py-3"
              style={{ borderBottom: "1px solid var(--color-line)" }}
            >
              {logoUrl ? (
                <span
                  className="relative block"
                  style={{ height: logoHeight, aspectRatio: String(logoAspect), width: "auto" }}
                >
                  {/* Measured here rather than guessed: the natural size of the
                      file decides how wide the header box should be. */}
                  <Image
                    src={logoUrl}
                    alt=""
                    fill
                    sizes="320px"
                    className="object-contain object-left"
                    unoptimized
                    onLoad={(e) => {
                      const img = e.currentTarget;
                      if (img.naturalWidth && img.naturalHeight) {
                        setLogoAspect(
                          Math.min(12, Math.max(0.3, img.naturalWidth / img.naturalHeight)),
                        );
                      }
                    }}
                  />
                </span>
              ) : (
                <span
                  className="font-semibold tracking-tight"
                  style={{ fontFamily: fonts.display, fontSize: logoHeight * 0.78 }}
                >
                  {logoText || "AtoZacc"}
                </span>
              )}
            </div>

            <div className="p-4" style={{ fontSize: baseFontSize }}>
              <p
                className="uppercase tracking-[0.16em]"
                style={{ fontFamily: fonts.body, fontSize: 10, color: brandColour, fontWeight: 700 }}
              >
                Festive Edit
              </p>
              <h2
                className="mt-2 leading-tight"
                style={{ fontFamily: fonts.display, fontSize: 30 * headingScale, fontWeight: 500 }}
              >
                Accessories from A to Z
              </h2>
              <p className="mt-2 text-ink-mid" style={{ fontFamily: fonts.body, fontSize: baseFontSize }}>
                Hand-picked jewellery, bags and watches — priced so you can buy
                the whole look.
              </p>

              <button
                type="button"
                className="mt-4 px-4 py-2.5 font-semibold text-white"
                style={{
                  fontFamily: fonts.body,
                  background: brandColour,
                  borderRadius: radius,
                  fontSize: baseFontSize - 1,
                }}
              >
                Shop the edit
              </button>

              {/* A product card, since that is what most of the site is */}
              <div className="mt-5 w-[52%]">
                <div
                  className="relative aspect-square overflow-hidden bg-surface"
                  style={{ borderRadius: radius }}
                >
                  <Image src="/placeholders/earrings.svg" alt="" fill sizes="160px" className="object-cover" />
                  <span
                    className="absolute left-1.5 top-1.5 px-1.5 py-0.5 text-[9px] font-bold uppercase tracking-wider text-white"
                    style={{ background: brandColour, borderRadius: Math.min(radius, 3) }}
                  >
                    New
                  </span>
                </div>
                <p className="mt-1.5 leading-snug" style={{ fontFamily: fonts.body, fontSize: baseFontSize - 2 }}>
                  Oxidised Jhumka Earrings
                </p>
                <p className="tnum mt-0.5" style={{ fontFamily: fonts.body, fontSize: baseFontSize - 1 }}>
                  <strong>₹499</strong>{" "}
                  <span className="text-ink-mute line-through">₹899</span>{" "}
                  <strong style={{ color: brandColour }}>44% off</strong>
                </p>
              </div>
            </div>
          </div>

          <button
            type="submit"
            disabled={pending}
            className="mt-3 w-full rounded-[var(--radius-card)] bg-brand px-5 py-3 text-[14px] font-semibold text-white hover:bg-brand-deep disabled:opacity-60"
          >
            {pending ? "Saving…" : "Save appearance"}
          </button>
        </div>
      </aside>
    </form>
  );
}

/* ------------------------------------------------------------------------ */

const input =
  "mt-1 w-full rounded-[var(--radius-card)] border border-line bg-surface px-3 py-2.5 text-[13px] focus:border-brand focus:bg-canvas focus:outline-none";

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-[var(--radius-card)] border border-line bg-canvas p-5">
      <h2 className="mb-4 font-display text-lg">{title}</h2>
      <div className="space-y-4">{children}</div>
    </section>
  );
}

function Label({ children }: { children: React.ReactNode }) {
  return (
    <span className="text-[11.5px] font-bold uppercase tracking-[0.09em] text-ink-mute">
      {children}
    </span>
  );
}

function Hint({ children }: { children: React.ReactNode }) {
  return <span className="mt-1 block text-[11.5px] text-ink-mute">{children}</span>;
}

function Slider({
  name, label, value, onChange, min, max, step = 1, suffix = "", hint, format,
}: {
  name: string;
  label: string;
  value: number;
  onChange: (v: number) => void;
  min: number;
  max: number;
  step?: number;
  suffix?: string;
  hint?: string;
  format?: (v: number) => string;
}) {
  return (
    <label className="block">
      <span className="flex items-baseline justify-between">
        <Label>{label}</Label>
        <span className="tnum text-[12px] font-semibold">
          {format ? format(value) : `${value}${suffix}`}
        </span>
      </span>
      <input
        type="range"
        name={name}
        value={value}
        min={min}
        max={max}
        step={step}
        onChange={(e) => onChange(Number(e.target.value))}
        className="mt-1.5 w-full accent-[--color-brand]"
      />
      {hint && <Hint>{hint}</Hint>}
    </label>
  );
}

function ColourField({
  name, label, value, onChange, hint,
}: {
  name: string;
  label: string;
  value: string;
  onChange: (v: string) => void;
  hint?: string;
}) {
  return (
    <label className="block">
      <Label>{label}</Label>
      <span className="mt-1 flex gap-2">
        <input
          type="color"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="h-10 w-12 shrink-0 cursor-pointer rounded border border-line bg-canvas p-1"
          aria-label={`${label} picker`}
        />
        <input
          name={name}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="tnum min-w-0 flex-1 rounded-[var(--radius-card)] border border-line bg-surface px-3 text-[13px] focus:border-brand focus:bg-canvas focus:outline-none"
        />
      </span>
      {hint && <Hint>{hint}</Hint>}
    </label>
  );
}
