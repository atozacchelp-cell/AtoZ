import { readSyncConfig } from "@/lib/sync-config";
import { runSync } from "@/lib/sync-core";

/**
 * Automatic Google Sheet sync.
 *
 * Runs a timer inside the server process, so the shop keeps matching the
 * sheet without anyone pressing a button.
 *
 * Two things this deliberately does NOT do:
 *
 *  - It never syncs when no sheet link is saved, and never when the interval
 *    is set to 0. Off means off.
 *  - It never wipes the catalogue on a failure. `runSync` refuses when no row
 *    can be read, so a half-typed sheet or a dropped connection leaves the
 *    live shop exactly as it was.
 *
 * The timer is registered on `globalThis` because Next reloads modules in
 * development — without the guard, every hot reload would stack another timer
 * and the sheet would be fetched dozens of times a minute.
 */

const KEY = "__atozaccAutoSync";

type State = {
  timer: NodeJS.Timeout | null;
  minutes: number;
  running: boolean;
  lastResult?: { at: string; ok: boolean; message: string };
};

function state(): State {
  const g = globalThis as unknown as Record<string, State | undefined>;
  if (!g[KEY]) g[KEY] = { timer: null, minutes: 0, running: false };
  return g[KEY]!;
}

/**
 * Drops Next's cached copies of the shop pages after a scheduled sync.
 *
 * `revalidatePath` needs a request context and this runs on a timer, so the
 * server asks itself over HTTP instead. Failure is not worth reporting: the
 * file caches are mtime-aware, so a dynamically rendered page still shows the
 * new catalogue either way.
 */
async function revalidateShop(): Promise<void> {
  const base =
    process.env.NEXT_PUBLIC_SITE_URL ??
    `http://127.0.0.1:${process.env.PORT ?? 3000}`;

  try {
    await fetch(`${base}/api/revalidate-shop`, {
      method: "POST",
      signal: AbortSignal.timeout(10_000),
    });
  } catch {
    /* see above */
  }
}

async function tick(): Promise<void> {
  const s = state();

  // A slow sheet must not have two syncs overlapping and racing each other
  // to write the catalogue file.
  if (s.running) return;

  const config = await readSyncConfig();
  if (!config.productsUrl || !config.autoSyncMinutes) return;

  s.running = true;
  try {
    const result = await runSync(config.productsUrl, config.contentUrl);
    s.lastResult = {
      at: new Date().toISOString(),
      ok: result.ok,
      // A silent scheduled sync that quietly drops rows is worse than a
      // noisy one — the count of skipped rows is the only warning the owner
      // gets that a product left the shop without them deleting it.
      message: result.ok
        ? `${result.imported} products synced` +
          (result.skipped.length
            ? ` · ${result.skipped.length} row${result.skipped.length === 1 ? "" : "s"} skipped`
            : "")
        : (result.error ?? "Sync failed"),
    };

    if (result.ok) await revalidateShop();
  } catch (e) {
    s.lastResult = {
      at: new Date().toISOString(),
      ok: false,
      message: e instanceof Error ? e.message : "Sync failed",
    };
  } finally {
    s.running = false;
  }
}

/** Starts or reschedules the timer to match the saved interval. */
export async function startAutoSync(): Promise<void> {
  const s = state();
  const config = await readSyncConfig();
  const minutes = config.autoSyncMinutes ?? 0;

  if (s.timer && s.minutes === minutes) return; // already correct

  if (s.timer) {
    clearInterval(s.timer);
    s.timer = null;
  }

  s.minutes = minutes;
  if (minutes <= 0) return;

  s.timer = setInterval(() => void tick(), minutes * 60_000);
  // Never hold the process open just for this.
  s.timer.unref?.();
}

export async function autoSyncStatus(): Promise<{
  minutes: number;
  active: boolean;
  running: boolean;
  lastResult?: { at: string; ok: boolean; message: string };
}> {
  const s = state();
  return {
    minutes: s.minutes,
    active: s.timer !== null,
    running: s.running,
    lastResult: s.lastResult,
  };
}
