"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";

import { updateOrderStatus, type OrderStatus } from "@/lib/orders";

/**
 * Admin mutations.
 *
 * No authentication yet — the admin panel is not protected because there is
 * no login to protect it with. That is stated plainly in the UI rather than
 * implied, and it MUST be built before this is deployed anywhere public.
 */

const StatusSchema = z.object({
  orderNumber: z.string().min(1).max(40),
  status: z.enum([
    "PENDING",
    "CONFIRMED",
    "PACKED",
    "SHIPPED",
    "IN_TRANSIT",
    "OUT_FOR_DELIVERY",
    "DELIVERED",
    "FAILED_DELIVERY",
    "RTO",
    "CANCELLED",
  ]),
  note: z.string().max(300).optional(),
});

export async function setOrderStatus(formData: FormData): Promise<void> {
  const parsed = StatusSchema.safeParse({
    orderNumber: formData.get("orderNumber"),
    status: formData.get("status"),
    note: formData.get("note") ?? undefined,
  });
  if (!parsed.success) return;

  await updateOrderStatus(
    parsed.data.orderNumber,
    parsed.data.status as OrderStatus,
    parsed.data.note,
  );

  revalidatePath("/admin/orders");
  revalidatePath(`/admin/orders/${parsed.data.orderNumber}`);
  revalidatePath("/admin");
}
