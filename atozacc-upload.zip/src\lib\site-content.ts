import { fs } from "@/lib/data-fs";
import path from "node:path";

import { fileMtime } from "@/lib/data-fs";

/**
 * Customer-facing wording, editable from the Content tab of the sheet.
 *
 * Every string here is something a shopper reads and the owner might want to
 * change on a Tuesday — the announcement bar during a sale, the hero heading
 * for a festival, the offer strip when a coupon changes. None of it should
 * need a developer.
 */

const CONTENT_PATH = path.join(process.cwd(), "data", "content.json");

export type SiteContent = {
  announcement1: string;
  announcement2: string;
  announcement3: string;

  heroEyebrow: string;
  heroHeading: string;
  heroHighlight: string;
  heroBody: string;
  heroCta: string;
  heroCtaSecondary: string;

  offerStripTitle: string;
  offerStripBody: string;

  newArrivalsTitle: string;
  bestsellersTitle: string;
  trendingTitle: string;

  newsletterHeading: string;
  newsletterBody: string;

  footerAbout: string;
};

export const DEFAULT_CONTENT: SiteContent = {
  announcement1: "Free shipping over ₹699",
  announcement2: "Cash on delivery available",
  announcement3: "7-day returns",

  heroEyebrow: "Festive Edit 2026",
  heroHeading: "Accessories from",
  heroHighlight: "A to Z",
  heroBody:
    "Hand-picked jewellery, bags, watches and everyday pieces — priced so you can buy the whole look, not just one piece of it.",
  heroCta: "Shop the edit",
  heroCtaSecondary: "See offers",

  offerStripTitle: "",
  offerStripBody: "",

  newArrivalsTitle: "New arrivals",
  bestsellersTitle: "Bestsellers",
  trendingTitle: "Trending now",

  newsletterHeading: "Get first look at new drops",
  newsletterBody:
    "New arrivals, festive edits and the occasional discount. No more than twice a month.",

  footerAbout:
    "Accessories from A to Z. Fashion jewellery, bags, watches and everyday pieces, shipped across India.",
};

let cache: SiteContent | null = null;
let cachedMtime = -1;

export async function getContent(): Promise<SiteContent> {
  const mtime = fileMtime(CONTENT_PATH);
  if (cache && mtime === cachedMtime) return cache;

  let resolved: SiteContent;
  try {
    const stored = JSON.parse(await fs.readFile(CONTENT_PATH, "utf8"));
    // Merge over defaults so a partly-filled Content tab cannot blank the site.
    resolved = { ...DEFAULT_CONTENT, ...stored };
  } catch {
    resolved = DEFAULT_CONTENT;
  }

  cache = resolved;
  cachedMtime = mtime;
  return resolved;
}

export async function saveContent(partial: Partial<SiteContent>): Promise<void> {
  const current = await getContent();
  // Empty cells are ignored rather than treated as "clear this" — a blank
  // cell in a spreadsheet is almost always an omission, not an instruction.
  const cleaned = Object.fromEntries(
    Object.entries(partial).filter(([, v]) => typeof v === "string" && v.trim() !== ""),
  );

  const next = { ...current, ...cleaned };
  await fs.mkdir(path.dirname(CONTENT_PATH), { recursive: true });
  await fs.writeFile(CONTENT_PATH, JSON.stringify(next, null, 2), "utf8");
  cache = next;
  cachedMtime = fileMtime(CONTENT_PATH);
}

export function invalidateContent(): void {
  cache = null;
}

/** Keys the Content tab understands, shown in admin so nothing is guesswork. */
export const CONTENT_KEYS: { key: keyof SiteContent; where: string }[] = [
  { key: "announcement1", where: "Top bar, first item" },
  { key: "announcement2", where: "Top bar, second item" },
  { key: "announcement3", where: "Top bar, third item" },
  { key: "heroEyebrow", where: "Small red text above the homepage heading" },
  { key: "heroHeading", where: "Homepage heading, first part" },
  { key: "heroHighlight", where: "Homepage heading, underlined part" },
  { key: "heroBody", where: "Homepage paragraph under the heading" },
  { key: "heroCta", where: "Main homepage button" },
  { key: "heroCtaSecondary", where: "Second homepage button" },
  { key: "offerStripTitle", where: "Offer banner heading (blank hides it)" },
  { key: "offerStripBody", where: "Offer banner text" },
  { key: "newArrivalsTitle", where: "New arrivals section heading" },
  { key: "bestsellersTitle", where: "Bestsellers section heading" },
  { key: "trendingTitle", where: "Trending section heading" },
  { key: "newsletterHeading", where: "Newsletter box heading" },
  { key: "newsletterBody", where: "Newsletter box text" },
  { key: "footerAbout", where: "Footer paragraph under the logo" },
];
