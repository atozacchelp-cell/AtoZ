import fs from "node:fs";
export function parse(t){const rows=[];let row=[],f="",q=false;for(let i=0;i<t.length;i++){const c=t[i];
 if(q){if(c==='"'){if(t[i+1]==='"'){f+='"';i++}else q=false}else f+=c;continue}
 if(c==='"')q=true;else if(c===","){row.push(f);f=""}else if(c==="\n"){row.push(f);rows.push(row);row=[];f=""}else if(c!=="\r")f+=c}
 if(f||row.length){row.push(f);rows.push(row)}return rows.filter(r=>r.some(x=>x.trim()))}
const rows=parse(fs.readFileSync(process.argv[2],"utf8"));
const h=rows[0],i=n=>h.indexOf(n);
for(const r of rows.slice(1)) console.log(JSON.stringify({order:r[i("order_number")],PAID:r[i("paid")],paid_amount:r[i("paid_amount")],balance:r[i("balance_due")],ref:r[i("upi_reference")],verified:r[i("verified_at")]||"—"}));
