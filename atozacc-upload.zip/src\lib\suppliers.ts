import { fs } from "@/lib/data-fs";
import path from "node:path";

import { fileMtime } from "@/lib/data-fs";

/**
 * Suppliers, for dropshipped products.
 *
 * A dropshipped order is one you cannot fulfil yourself — it has to be
 * forwarded to whoever holds the stock. That makes three things matter that
 * do not matter for your own inventory:
 *
 *   1. WHERE to send the order (contact details)
 *   2. HOW LONG they take (so the delivery promise stays honest)
 *   3. WHETHER they accept cash on delivery (most Indian suppliers do not)
 *
 * The third is the one that quietly breaks stores: a customer picks COD on a
 * dropshipped item, the supplier refuses to ship without prepayment, and the
 * order is stuck with nobody having told the customer.
 */

const SUPPLIERS_PATH = path.join(process.cwd(), "data", "suppliers.json");

export type Supplier = {
  /** Matches the `supplier` column in the sheet, case-insensitively. */
  name: string;
  contactName?: string;
  email?: string;
  phone?: string;
  whatsapp?: string;
  /** Where they ship from — affects how long delivery takes. */
  city?: string;

  /** Working days before they hand the parcel to a courier. */
  dispatchDays: number;
  /**
   * Whether they will ship a cash-on-delivery order. When false, COD is
   * refused at checkout for anything they supply — with a reason, rather
   * than a silent failure later.
   */
  acceptsCod: boolean;
  /** What you pay them, as a share of your selling price. For margin sanity. */
  notes?: string;
};

export type SupplierStore = { suppliers: Supplier[] };

const EMPTY: SupplierStore = { suppliers: [] };

let cache: SupplierStore | null = null;
let cachedMtime = -1;

export async function getSuppliers(): Promise<Supplier[]> {
  const mtime = fileMtime(SUPPLIERS_PATH);
  if (cache && mtime === cachedMtime) return cache.suppliers;

  let resolved: SupplierStore;
  try {
    resolved = JSON.parse(await fs.readFile(SUPPLIERS_PATH, "utf8")) as SupplierStore;
    if (!Array.isArray(resolved.suppliers)) resolved = EMPTY;
  } catch {
    resolved = EMPTY;
  }

  cache = resolved;
  cachedMtime = mtime;
  return resolved.suppliers;
}

export async function findSupplier(name?: string): Promise<Supplier | null> {
  if (!name?.trim()) return null;
  const wanted = name.trim().toLowerCase();
  const all = await getSuppliers();
  return all.find((s) => s.name.trim().toLowerCase() === wanted) ?? null;
}

export async function saveSupplier(supplier: Supplier): Promise<void> {
  const all = [...(await getSuppliers())];
  const i = all.findIndex(
    (s) => s.name.trim().toLowerCase() === supplier.name.trim().toLowerCase(),
  );

  if (i >= 0) all[i] = supplier;
  else all.push(supplier);

  await write({ suppliers: all });
}

export async function deleteSupplier(name: string): Promise<void> {
  const all = await getSuppliers();
  await write({
    suppliers: all.filter(
      (s) => s.name.trim().toLowerCase() !== name.trim().toLowerCase(),
    ),
  });
}

async function write(store: SupplierStore): Promise<void> {
  await fs.mkdir(path.dirname(SUPPLIERS_PATH), { recursive: true });
  await fs.writeFile(SUPPLIERS_PATH, JSON.stringify(store, null, 2), "utf8");
  cache = store;
  cachedMtime = fileMtime(SUPPLIERS_PATH);
}

export function invalidateSuppliers(): void {
  cache = null;
}

/**
 * Delivery estimate for a product, in days.
 *
 * Own stock ships from Delhi in 1–2 days plus transit. A dropshipped item
 * waits on the supplier first, so its estimate has to be longer — showing the
 * same "4–7 days" on both is a promise the second one cannot keep, and a
 * missed date is the commonest reason a first-time customer never returns.
 */
export function deliveryEstimate(
  dispatchDays: number,
  zone: "ncr" | "metro" | "rest" = "rest",
): { min: number; max: number; label: string } {
  const transit = { ncr: [1, 2], metro: [3, 4], rest: [4, 7] }[zone];
  const min = dispatchDays + transit[0];
  const max = dispatchDays + transit[1];
  return { min, max, label: `${min}–${max} days` };
}
