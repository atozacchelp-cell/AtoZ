import Link from "next/link";

import { ProductForm } from "@/components/product-form";
import { PageHeader } from "@/components/admin-ui";
import { allCategories } from "@/lib/taxonomy";

export const metadata = { title: "Add product", robots: { index: false } };

export default function NewProductPage() {
  return (
    <>
      <Link
        href="/admin/products"
        className="text-[12.5px] font-semibold text-ink-mute hover:text-brand"
      >
        ← Products
      </Link>
      <div className="mt-2">
        <PageHeader
          title="Add a product"
          subtitle="Name, category, price and a photo are all that is required"
        />
      </div>
      <ProductForm categories={allCategories()} />
    </>
  );
}
