"use server";

import { revalidatePath } from "next/cache";

import { autoSyncStatus, startAutoSync } from "@/lib/auto-sync";
import { readSyncConfig, writeSyncConfig } from "@/lib/sync-config";
import { AUTO_SYNC_CHOICES } from "@/lib/sync-constants";
import { runSync, type RowIssue } from "@/lib/sync-core";

/**
 * The admin-facing wrapper around a sheet sync.
 *
 * All the actual work lives in `sync-core.ts` so the timer and the button run
 * identical code. What is left here is the form plumbing and telling Next to
 * repaint the pages the new catalogue affects.
 */

export type { RowIssue };

export type SyncState = {
  ok?: boolean;
  error?: string;
  summary?: {
    imported: number;
    skipped: RowIssue[];
    warnings: RowIssue[];
    contentKeys: number;
    reviewCount: number;
    syncedAt: string;
  };
};

export async function syncFromSheet(
  _prev: SyncState,
  formData: FormData,
): Promise<SyncState> {
  const result = await runSync(
    String(formData.get("productsUrl") ?? ""),
    String(formData.get("contentUrl") ?? ""),
    String(formData.get("reviewsUrl") ?? ""),
  );

  const summary = {
    imported: result.imported,
    skipped: result.skipped,
    warnings: result.warnings,
    contentKeys: result.contentKeys,
    reviewCount: result.reviewCount,
    syncedAt: result.syncedAt,
  };

  if (!result.ok) return { error: result.error, summary };

  revalidatePath("/", "layout");
  revalidatePath("/admin/products");

  return { ok: true, summary };
}

export type AutoSyncState = { ok?: boolean; error?: string; minutes?: number };

/** Turns the automatic sync on, off, or changes how often it runs. */
export async function updateAutoSync(
  _prev: AutoSyncState,
  formData: FormData,
): Promise<AutoSyncState> {
  const raw = Number(formData.get("autoSyncMinutes") ?? 0);
  const minutes = (AUTO_SYNC_CHOICES as readonly number[]).includes(raw) ? raw : 0;

  const config = await readSyncConfig();
  if (minutes > 0 && !config.productsUrl) {
    return {
      error:
        "Save your sheet link first — press Sync now once, then set the schedule.",
    };
  }

  await writeSyncConfig({ autoSyncMinutes: minutes });
  await startAutoSync();

  revalidatePath("/admin/sync");
  return { ok: true, minutes };
}

export async function getSyncConfig() {
  return readSyncConfig();
}

export async function getAutoSyncStatus() {
  // Reading the page is also the moment to make sure the timer survived a
  // server restart — a schedule that quietly stops running is worse than no
  // schedule at all, because the sheet still looks connected.
  await startAutoSync();
  return autoSyncStatus();
}
