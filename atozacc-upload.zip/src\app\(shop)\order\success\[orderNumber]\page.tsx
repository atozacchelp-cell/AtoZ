import Link from "next/link";
import { notFound } from "next/navigation";

import { OrderDetail } from "@/components/order-detail";
import { ButtonLink, Container } from "@/components/ui";
import { formatINR } from "@/lib/money";
import { getOrder } from "@/lib/orders";
import { getSettings } from "@/lib/settings";

export const metadata = {
  title: "Order confirmed",
  robots: { index: false },
};

export default async function OrderSuccessPage({
  params,
}: {
  params: Promise<{ orderNumber: string }>;
}) {
  const { orderNumber } = await params;
  const order = await getOrder(orderNumber);
  if (!order) notFound();

  const settings = await getSettings();

  return (
    <Container className="max-w-3xl py-10">
      <div className="text-center">
        <span className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-success/12 text-success">
          <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" aria-hidden>
            <path d="M20 6 9 17l-5-5" />
          </svg>
        </span>
        <h1 className="mt-4 font-display text-[30px] leading-tight sm:text-[36px]">
          Thank you — your order is placed
        </h1>
        <p className="tnum mx-auto mt-2 max-w-md text-[14px] text-ink-mid">
          Order <strong>{order.orderNumber}</strong>
          {order.shippingAddress.email
            ? ` · A confirmation is on its way to ${order.shippingAddress.email}`
            : ` · We will message you on ${order.shippingAddress.mobile}`}
        </p>

        {order.balanceAmount > 0 && (
          <p className="tnum mx-auto mt-4 max-w-md rounded-[var(--radius-card)] border border-brand/35 bg-blush px-4 py-3 text-[13px] text-ink-mid">
            <strong className="text-brand-deep">
              {formatINR(order.balanceAmount)} due on delivery.
            </strong>{" "}
            Please keep the amount ready for the delivery agent.
          </p>
        )}

        <div className="mt-6 flex flex-wrap justify-center gap-3">
          <ButtonLink href={`/track-order?order=${order.orderNumber}`} variant="secondary">
            Track this order
          </ButtonLink>
          <ButtonLink href="/shop">Continue shopping</ButtonLink>
        </div>
      </div>

      <hr className="my-10 border-line" />

      <OrderDetail order={order} />

      <p className="mt-10 rounded-[var(--radius-card)] border border-line bg-surface px-4 py-3 text-center text-[12.5px] text-ink-mute">
        Questions about this order? Write to{" "}
        <Link href="/contact" className="font-semibold text-brand">
          {settings.supportEmail}
        </Link>{" "}
        or message {settings.supportPhone} on WhatsApp.
      </p>
    </Container>
  );
}
