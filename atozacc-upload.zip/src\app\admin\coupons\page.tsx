import { PageHeader, Pill, Table } from "@/components/admin-ui";
import { COUPONS } from "@/data/coupons";
import { formatINR } from "@/lib/money";

export const metadata = { title: "Coupons", robots: { index: false } };

export default function AdminCoupons() {
  return (
    <>
      <PageHeader title="Coupons" subtitle="One coupon per order" />

      <Table head={["Code", "Type", "Value", "Min order", "Max discount", "Restrictions"]}>
        {COUPONS.map((c) => (
          <tr key={c.code} className="border-b border-line last:border-0">
            <td className="tnum px-3 py-2.5 font-bold tracking-wider">{c.code}</td>
            <td className="px-3 py-2.5 text-ink-mute">
              {c.type === "PERCENT"
                ? "Percentage"
                : c.type === "FIXED"
                  ? "Fixed amount"
                  : "Free shipping"}
            </td>
            <td className="tnum px-3 py-2.5 font-semibold">
              {c.type === "PERCENT"
                ? `${c.value / 100}%`
                : c.type === "FIXED"
                  ? formatINR(c.value)
                  : "—"}
            </td>
            <td className="tnum px-3 py-2.5 text-ink-mute">
              {c.minOrderValue ? formatINR(c.minOrderValue) : "—"}
            </td>
            <td className="tnum px-3 py-2.5 text-ink-mute">
              {c.maxDiscount ? formatINR(c.maxDiscount) : "—"}
            </td>
            <td className="px-3 py-2.5">
              {c.prepaidOnly ? (
                <Pill tone="warn">Prepaid only</Pill>
              ) : (
                <span className="text-ink-mute">None</span>
              )}
            </td>
          </tr>
        ))}
      </Table>

      <p className="mt-4 rounded-[var(--radius-card)] border border-line bg-canvas px-4 py-3 text-[12.5px] text-ink-mute">
        Coupons stack on top of product discounts by default. Blocking that
        would mean no coupon ever works, since nearly every product shows an
        MRP-versus-price saving. Usage limits, date windows and per-customer
        caps are modelled in the schema and become editable with the database.
      </p>
    </>
  );
}
