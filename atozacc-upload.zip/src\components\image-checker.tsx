"use client";

import Image from "next/image";
import { useState, useTransition } from "react";

import {
  checkProductImages,
  checkSingleImage,
  type CheckResult,
} from "@/lib/image-check";

/**
 * Answers "will my photo actually show?" with a test rather than a promise.
 *
 * Two modes: try one link before committing it to the sheet, or check every
 * product at once after a sync.
 */
export function ImageChecker() {
  const [pending, start] = useTransition();

  // Single-link test
  const [testUrl, setTestUrl] = useState("");
  const [single, setSingle] = useState<{
    ok: boolean;
    detail: string;
    resolved: string;
  } | null>(null);

  // Whole-catalogue check
  const [result, setResult] = useState<CheckResult | null>(null);

  function testOne() {
    if (!testUrl.trim()) return;
    setSingle(null);
    start(async () => setSingle(await checkSingleImage(testUrl)));
  }

  function checkAll() {
    setResult(null);
    start(async () => setResult(await checkProductImages()));
  }

  return (
    <section className="rounded-[var(--radius-card)] border border-line bg-canvas p-5">
      <h2 className="font-display text-lg">Will my photos show?</h2>
      <p className="mt-1 max-w-prose text-[12.5px] text-ink-mute">
        A wrong Drive link does not fail loudly — Google returns a web page with
        a success code, and the product just shows a blank box. This fetches
        each photo and tells you which actually load.
      </p>

      {/* --- test one --- */}
      <div className="mt-4 rounded-[var(--radius-card)] border border-line bg-surface p-4">
        <p className="text-[11.5px] font-bold uppercase tracking-[0.09em] text-ink-mute">
          Test one link first
        </p>
        <div className="mt-2 flex flex-wrap gap-2">
          <input
            value={testUrl}
            onChange={(e) => setTestUrl(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && testOne()}
            placeholder="Paste one Drive photo link to try it"
            className="min-w-0 flex-1 rounded-[var(--radius-card)] border border-line bg-canvas px-3 py-2.5 text-[13px] focus:border-brand focus:outline-none"
          />
          <button
            type="button"
            onClick={testOne}
            disabled={pending || !testUrl.trim()}
            className="rounded-[var(--radius-card)] border border-ink px-4 py-2.5 text-[13px] font-semibold hover:bg-ink hover:text-canvas disabled:opacity-50"
          >
            {pending ? "Checking…" : "Test"}
          </button>
        </div>

        {single && (
          <div className="mt-3 flex gap-4">
            <div>
              <p
                className={`text-[13px] font-bold ${
                  single.ok ? "text-success" : "text-brand"
                }`}
              >
                {single.ok ? "This photo loads" : "This photo will not show"}
              </p>
              <p className="mt-0.5 text-[12.5px] text-ink-mid">{single.detail}</p>
              <p className="mt-1.5 break-all font-mono text-[10.5px] text-ink-mute">
                {single.resolved}
              </p>
              {!single.ok && (
                <p className="mt-2 max-w-prose text-[12px] text-ink-mid">
                  Open the photo in Drive → <strong>Share</strong> → set
                  &ldquo;Anyone with the link&rdquo; to <strong>Viewer</strong>,
                  then copy the link again. Sharing the folder does not always
                  share files added to it afterwards.
                </p>
              )}
            </div>

            {single.ok && (
              <span className="relative h-24 w-24 shrink-0 overflow-hidden rounded-[var(--radius-card)] border border-line bg-surface-2">
                {/* Unoptimised on purpose: this is a diagnostic, and it must
                    show the real file rather than a cached rewrite of it. */}
                <Image
                  src={single.resolved}
                  alt="Test result"
                  fill
                  sizes="96px"
                  className="object-cover"
                  unoptimized
                />
              </span>
            )}
          </div>
        )}
      </div>

      {/* --- check all --- */}
      <div className="mt-4 flex flex-wrap items-center gap-3">
        <button
          type="button"
          onClick={checkAll}
          disabled={pending}
          className="rounded-[var(--radius-card)] bg-brand px-4 py-2.5 text-[13px] font-semibold text-white hover:bg-brand-deep disabled:opacity-60"
        >
          {pending ? "Checking every photo…" : "Check all product photos"}
        </button>
        {result && (
          <p className="tnum text-[13px]">
            <strong className="text-success">{result.ok} fine</strong>
            {result.broken.length > 0 && (
              <>
                {" · "}
                <strong className="text-brand">{result.broken.length} broken</strong>
              </>
            )}
            {result.placeholders > 0 && (
              <span className="text-ink-mute">
                {" · "}
                {result.placeholders} still placeholder art
              </span>
            )}
          </p>
        )}
      </div>

      {result && result.broken.length > 0 && (
        <div className="mt-3 max-h-72 overflow-auto rounded-[var(--radius-card)] border border-brand">
          <table className="w-full text-[12.5px]">
            <tbody>
              {result.broken.map((b, i) => (
                <tr key={`${b.sku}-${i}`} className="border-b border-line last:border-0">
                  <td className="px-3 py-2">
                    <span className="block max-w-[200px] truncate font-medium">
                      {b.name}
                    </span>
                    <span className="font-mono text-[10.5px] text-ink-mute">
                      {b.sku} · {b.slot}
                    </span>
                  </td>
                  <td className="px-3 py-2 text-brand-deep">{b.detail}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {result && result.broken.length === 0 && result.checked > 0 && (
        <p className="mt-3 rounded-[var(--radius-card)] border border-success/40 bg-success/10 px-3.5 py-2.5 text-[12.5px] font-medium text-success">
          Every photo loads. Nothing will show a blank box.
        </p>
      )}
    </section>
  );
}
