import { ProductListing, type SearchParamsShape } from "@/components/product-listing";

export const metadata = {
  title: "Bestsellers",
  description: "The most popular accessories at AtoZacc.",
};

export default async function Page({
  searchParams,
}: {
  searchParams: Promise<SearchParamsShape>;
}) {
  const sp = await searchParams;
  return (
    <ProductListing
      title={"Bestsellers"}
      description={"Our most-ordered pieces, ranked by what customers keep coming back for."}
      breadcrumbs={[{ label: "Bestsellers" }]}
      searchParams={sp}
      baseFilters={{ collection: "bestsellers" }}
    />
  );
}
