import { cookies } from "next/headers";

import { getAllProducts } from "@/lib/product-store";
import { categoryIndex } from "@/lib/taxonomy";
import { productHref } from "@/lib/catalog";
import type { PricedLine } from "@/lib/pricing";
import { stockForSize } from "@/lib/sizes";

/**
 * Cart storage.
 *
 * The cookie holds ONLY product identity and quantity — never a price. Prices
 * are re-read from the catalogue on every request, so a customer editing the
 * cookie changes what they are buying, not what it costs.
 */

const CART_COOKIE = "atz_cart";
const WISHLIST_COOKIE = "atz_wishlist";

export type CartCookieItem = {
  slug: string;
  colour?: string;
  size?: string;
  qty: number;
  savedForLater?: boolean;
};

export function variantKey(item: {
  slug: string;
  colour?: string;
  size?: string;
}): string {
  return [item.slug, item.colour ?? "", item.size ?? ""].join("|");
}

// ---------------------------------------------------------------------------
// Raw cookie access
// ---------------------------------------------------------------------------

export async function readCartCookie(): Promise<CartCookieItem[]> {
  const store = await cookies();
  const raw = store.get(CART_COOKIE)?.value;
  if (!raw) return [];

  try {
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) return [];
    // A hand-edited cookie must not crash the cart page, so every field is
    // re-validated rather than trusted.
    return parsed
      .filter((i): i is CartCookieItem => typeof i?.slug === "string")
      .map((i) => ({
        slug: i.slug,
        colour: typeof i.colour === "string" ? i.colour : undefined,
        size: typeof i.size === "string" ? i.size : undefined,
        qty: Math.min(10, Math.max(1, Number(i.qty) || 1)),
        savedForLater: i.savedForLater === true,
      }));
  } catch {
    return [];
  }
}

export async function writeCartCookie(items: CartCookieItem[]): Promise<void> {
  const store = await cookies();
  store.set(CART_COOKIE, JSON.stringify(items), {
    httpOnly: false, // the header badge reads count client-side
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 30,
  });
}

export async function readWishlist(): Promise<string[]> {
  const store = await cookies();
  const raw = store.get(WISHLIST_COOKIE)?.value;
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed.filter((s) => typeof s === "string") : [];
  } catch {
    return [];
  }
}

export async function writeWishlist(slugs: string[]): Promise<void> {
  const store = await cookies();
  store.set(WISHLIST_COOKIE, JSON.stringify(slugs), {
    httpOnly: false,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 90,
  });
}

// ---------------------------------------------------------------------------
// Resolving to priced lines
// ---------------------------------------------------------------------------

// Rebuilt whenever the sheet adds a category, so a page never renders from
// a snapshot taken before it existed.
const categoryBySlug = { get: (k: string) => categoryIndex().get(k), has: (k: string) => categoryIndex().has(k) };

/**
 * Turns cookie entries into fully priced lines by looking every product up in
 * the catalogue. Items whose product no longer exists are dropped silently —
 * a discontinued product should not break someone's cart.
 */
export async function getCartLines(): Promise<{
  active: PricedLine[];
  saved: PricedLine[];
}> {
  const items = await readCartCookie();
  const products = await getAllProducts();
  const active: PricedLine[] = [];
  const saved: PricedLine[] = [];

  for (const item of items) {
    const product = products.find((p) => p.slug === item.slug);
    if (!product) continue;

    const cat = categoryBySlug.get(product.category);
    // For a garment the number that matters is the stock of the size in the
    // cart, not the total across sizes — eight smalls do not make the large
    // in this cart available.
    const available = stockForSize(product, item.size);
    const qty = Math.min(item.qty, Math.max(1, available || 1));

    const line: PricedLine = {
      variantKey: variantKey(item),
      name: product.name,
      imageUrl: product.image,
      href: productHref(product),
      unitPrice: product.price,
      unitMrp: product.mrp,
      qty,
      taxRate: cat?.taxRate ?? 0,
      lineTotal: product.price * qty,
      lineMrpTotal: product.mrp * qty,
      lineTax: 0, // filled by the pricing engine
      outOfStock: available <= 0,
      codAllowed: product.isCodAllowed !== false,
      supplier: product.supplier,
      fulfilment: product.fulfilment ?? "self",
    };

    if (item.savedForLater) saved.push(line);
    else active.push(line);
  }

  return { active, saved };
}

export async function getCartCount(): Promise<number> {
  const items = await readCartCookie();
  return items.filter((i) => !i.savedForLater).reduce((n, i) => n + i.qty, 0);
}
