import Link from "next/link";

import { EmptyRow, PageHeader, Pill, Table } from "@/components/admin-ui";
import { formatINR } from "@/lib/money";
import {
  listOrders,
  ORDER_STATUS_LABELS,
  PAYMENT_STATUS_LABELS,
  type OrderStatus,
} from "@/lib/orders";

export const metadata = { title: "Orders", robots: { index: false } };

const FILTERS: { key: string; label: string; match?: OrderStatus[] }[] = [
  { key: "all", label: "All" },
  { key: "PENDING", label: "To confirm", match: ["PENDING"] },
  { key: "CONFIRMED", label: "To pack", match: ["CONFIRMED"] },
  { key: "PACKED", label: "To ship", match: ["PACKED"] },
  { key: "SHIPPED", label: "In transit", match: ["SHIPPED", "IN_TRANSIT", "OUT_FOR_DELIVERY"] },
  { key: "DELIVERED", label: "Delivered", match: ["DELIVERED"] },
  { key: "CANCELLED", label: "Cancelled", match: ["CANCELLED", "RTO", "FAILED_DELIVERY"] },
];

export default async function AdminOrders({
  searchParams,
}: {
  searchParams: Promise<{ status?: string }>;
}) {
  const { status = "all" } = await searchParams;
  const all = await listOrders();

  const filter = FILTERS.find((f) => f.key === status) ?? FILTERS[0];
  const orders = filter.match
    ? all.filter((o) => filter.match!.includes(o.status))
    : all;

  return (
    <>
      <PageHeader
        title="Orders"
        subtitle="Tap an order to confirm, pack, ship or cancel it"
      />

      {/* Filters double as a work queue — the counts say what is waiting. */}
      <nav className="scroll-x mb-4 -mx-1 flex gap-1.5 px-1 pb-1">
        {FILTERS.map((f) => {
          const count = f.match ? all.filter((o) => f.match!.includes(o.status)).length : all.length;
          const active = f.key === filter.key;
          return (
            <Link
              key={f.key}
              href={f.key === "all" ? "/admin/orders" : `/admin/orders?status=${f.key}`}
              className={
                active
                  ? "whitespace-nowrap rounded-[var(--radius-pill)] bg-ink px-3.5 py-1.5 text-[12.5px] font-semibold text-canvas"
                  : "whitespace-nowrap rounded-[var(--radius-pill)] border border-line bg-canvas px-3.5 py-1.5 text-[12.5px] font-semibold text-ink-mid hover:border-brand hover:text-brand"
              }
            >
              {f.label}
              <span className="tnum ml-1.5 opacity-60">{count}</span>
            </Link>
          );
        })}
      </nav>

      <Table head={["Order", "Date", "Customer", "Items", "Payment", "Paid", "Due", "Status"]}>
        {orders.length === 0 ? (
          <EmptyRow colSpan={8}>
            {all.length === 0
              ? "No orders yet. Place a test order from the storefront."
              : "No orders in this state."}
          </EmptyRow>
        ) : (
          orders.map((o) => (
            <tr key={o.orderNumber} className="border-b border-line last:border-0">
              <td className="px-3 py-2.5">
                <Link
                  href={`/admin/orders/${o.orderNumber}`}
                  className="tnum font-semibold hover:text-brand"
                >
                  {o.orderNumber}
                </Link>
              </td>
              <td className="tnum whitespace-nowrap px-3 py-2.5 text-ink-mute">
                {new Date(o.placedAt).toLocaleDateString("en-IN", {
                  day: "2-digit",
                  month: "short",
                })}
              </td>
              <td className="px-3 py-2.5">
                <span className="block max-w-[150px] truncate">{o.shippingAddress.name}</span>
                <span className="tnum text-[11.5px] text-ink-mute">
                  {o.shippingAddress.mobile}
                </span>
              </td>
              <td className="tnum px-3 py-2.5">{o.items.length}</td>
              <td className="px-3 py-2.5">
                <Pill tone={o.paymentMethod === "COD" ? "warn" : "good"}>
                  {o.paymentMethod === "COD"
                    ? "COD"
                    : o.paymentMethod === "PARTIAL"
                      ? "Part"
                      : "Prepaid"}
                </Pill>
                <span className="mt-0.5 block text-[10.5px] text-ink-mute">
                  {PAYMENT_STATUS_LABELS[o.paymentStatus]}
                </span>
              </td>
              <td className="tnum px-3 py-2.5">{formatINR(o.paidAmount)}</td>
              <td className="tnum px-3 py-2.5">
                <span className={o.balanceAmount > 0 ? "font-semibold text-brand" : "text-ink-mute"}>
                  {formatINR(o.balanceAmount)}
                </span>
              </td>
              <td className="px-3 py-2.5">
                <Pill
                  tone={
                    o.status === "DELIVERED"
                      ? "good"
                      : o.status === "PENDING"
                        ? "bad"
                        : o.status === "CANCELLED" || o.status === "RTO"
                          ? "bad"
                          : "neutral"
                  }
                >
                  {ORDER_STATUS_LABELS[o.status]}
                </Pill>
              </td>
            </tr>
          ))
        )}
      </Table>
    </>
  );
}
