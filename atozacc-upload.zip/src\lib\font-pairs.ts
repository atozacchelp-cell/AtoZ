/**
 * Font pairings — plain data, no Node imports.
 *
 * Kept separate from `branding.ts` on purpose: that file reads the filesystem,
 * and the appearance form is a client component. Importing the pairings from
 * there would drag `node:fs` into the browser bundle and fail the build.
 *
 * Pairings, not individual fonts: choosing a display and a body face
 * independently is how sites end up looking wrong. Each of these is
 * internally consistent, so any choice looks deliberate.
 */

export const FONT_PAIRS = {
  editorial: {
    label: "Editorial",
    note: "Warm serif headings, clean body. The current look.",
    display: "var(--font-fraunces)",
    body: "var(--font-manrope)",
  },
  classic: {
    label: "Classic luxury",
    note: "High-contrast serif. Jewellery and premium gifting.",
    display: "var(--font-playfair)",
    body: "var(--font-jost)",
  },
  modern: {
    label: "Modern",
    note: "Sharp serif display with a geometric companion.",
    display: "var(--font-dmserif)",
    body: "var(--font-dmsans)",
  },
  fashion: {
    label: "High fashion",
    note: "Light and airy. Best with strong photography.",
    display: "var(--font-cormorant)",
    body: "var(--font-jost)",
  },
  friendly: {
    label: "Friendly",
    note: "One rounded sans throughout. Approachable, very legible.",
    display: "var(--font-poppins)",
    body: "var(--font-poppins)",
  },
} as const;

export type FontPairKey = keyof typeof FONT_PAIRS;
