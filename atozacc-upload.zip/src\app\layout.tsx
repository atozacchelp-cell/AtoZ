import type { Metadata, Viewport } from "next";
import {
  Cormorant_Garamond,
  DM_Sans,
  DM_Serif_Display,
  Fraunces,
  Jost,
  Manrope,
  Playfair_Display,
  Poppins,
} from "next/font/google";

import { brandingToCss, getBranding } from "@/lib/branding";
import "./globals.css";

/*
 * Every selectable font pairing is declared here, but a browser only
 * downloads a face it actually has to render — so declaring five costs
 * nothing at runtime, and switching pairing in admin needs no rebuild.
 *
 * All are self-hosted by next/font: no request to Google at render time,
 * which matters when most traffic is mobile on Indian networks.
 */
const fraunces = Fraunces({
  variable: "--font-fraunces",
  subsets: ["latin"],
  display: "swap",
  axes: ["SOFT", "WONK"],
});

const manrope = Manrope({
  variable: "--font-manrope",
  subsets: ["latin"],
  display: "swap",
});

const playfair = Playfair_Display({
  variable: "--font-playfair",
  subsets: ["latin"],
  display: "swap",
});

const jost = Jost({
  variable: "--font-jost",
  subsets: ["latin"],
  display: "swap",
});

const dmSerif = DM_Serif_Display({
  variable: "--font-dmserif",
  subsets: ["latin"],
  display: "swap",
  weight: "400",
});

const dmSans = DM_Sans({
  variable: "--font-dmsans",
  subsets: ["latin"],
  display: "swap",
});

const cormorant = Cormorant_Garamond({
  variable: "--font-cormorant",
  subsets: ["latin"],
  display: "swap",
  weight: ["400", "500", "600", "700"],
});

const poppins = Poppins({
  variable: "--font-poppins",
  subsets: ["latin"],
  display: "swap",
  weight: ["400", "500", "600", "700"],
});

const FONT_VARS = [
  fraunces.variable,
  manrope.variable,
  playfair.variable,
  jost.variable,
  dmSerif.variable,
  dmSans.variable,
  cormorant.variable,
  poppins.variable,
].join(" ");

const siteUrl = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl),
  title: {
    default: "AtoZacc — Accessories from A to Z",
    template: "%s · AtoZacc",
  },
  description:
    "Fashion accessories for women, men and kids — jewellery, bags, watches, sunglasses and more. Cash on delivery available, free shipping over ₹699.",
  openGraph: {
    type: "website",
    locale: "en_IN",
    siteName: "AtoZacc",
  },
  robots: {
    // Nothing is indexed until the store actually launches.
    index: false,
    follow: false,
  },
};

export const viewport: Viewport = {
  themeColor: "#d42a4c",
  width: "device-width",
  initialScale: 1,
};

export default async function RootLayout({ children }: LayoutProps<"/">) {
  const branding = await getBranding();

  return (
    <html lang="en-IN" className={`${FONT_VARS} h-full antialiased`}>
      <head>
        {/*
          Branding overrides the stylesheet defaults at the root, so one saved
          setting repaints every page. Rendered on the server, so there is no
          flash of the old look before it applies.
        */}
        <style
          dangerouslySetInnerHTML={{ __html: `:root{${brandingToCss(branding)}}` }}
        />
      </head>
      <body className="min-h-full flex flex-col bg-canvas text-ink">
        {children}
      </body>
    </html>
  );
}
