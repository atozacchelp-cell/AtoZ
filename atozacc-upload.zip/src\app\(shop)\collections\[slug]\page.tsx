import { notFound } from "next/navigation";

import { ProductListing, type SearchParamsShape } from "@/components/product-listing";
import { getCollection, getCollections } from "@/lib/catalog";

export async function generateStaticParams() {
  return getCollections().map((c) => ({ slug: c.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const collection = await getCollection(slug);
  if (!collection) return { title: "Collection" };
  return { title: collection.name, description: collection.description };
}

export default async function CollectionPage({
  params,
  searchParams,
}: {
  params: Promise<{ slug: string }>;
  searchParams: Promise<SearchParamsShape>;
}) {
  const [{ slug }, sp] = await Promise.all([params, searchParams]);
  const collection = await getCollection(slug);
  if (!collection) notFound();

  return (
    <ProductListing
      title={collection.name}
      description={collection.description}
      breadcrumbs={[{ label: "Collections" }, { label: collection.name }]}
      searchParams={sp}
      baseFilters={{ collection: collection.slug }}
    />
  );
}
