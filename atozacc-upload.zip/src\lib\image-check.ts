"use server";

import { getAllProducts } from "@/lib/product-store";

/**
 * Checks that every product photo actually loads.
 *
 * Google Drive is a convenient place to keep photos and an unreliable place
 * to serve them: links change form, sharing gets switched off, and a wrong
 * link returns Drive's HTML viewer with a cheerful 200 rather than an error.
 * A broken product photo is a lost sale that nothing else reports, so this
 * fetches each image and says plainly which ones work.
 */

export type ImageStatus = {
  sku: string;
  name: string;
  url: string;
  slot: string;
  ok: boolean;
  detail: string;
};

export type CheckResult = {
  checked: number;
  ok: number;
  broken: ImageStatus[];
  placeholders: number;
};

/** Google's HTML viewer answers 200 with text/html — a 200 is not enough. */
async function checkOne(url: string): Promise<{ ok: boolean; detail: string }> {
  if (url.startsWith("/")) {
    return { ok: true, detail: "Local placeholder" };
  }

  try {
    const res = await fetch(url, {
      redirect: "follow",
      cache: "no-store",
      headers: { "User-Agent": "Mozilla/5.0 AtoZacc-ImageCheck" },
    });

    const type = res.headers.get("content-type") ?? "";

    // Verified against real Drive responses: an unshared or mistyped file id
    // answers 400, a folder id answers 404, and a genuine image answers 200
    // with an image/* type. Each gets the message that names the actual fix.
    if (res.status === 400) {
      return {
        ok: false,
        detail:
          "Not shared, or the link is wrong — open the photo in Drive, Share, set to Anyone with the link",
      };
    }
    if (res.status === 403) {
      return { ok: false, detail: "Access denied — this file is not shared publicly" };
    }
    if (res.status === 404) {
      return {
        ok: false,
        detail:
          "Not found — this looks like a folder link or a deleted file. Each product needs its own photo link",
      };
    }
    if (!res.ok) {
      return { ok: false, detail: `Google returned ${res.status}` };
    }

    if (type.startsWith("image/")) {
      const size = res.headers.get("content-length");
      const kb = size ? Math.round(Number(size) / 1024) : null;
      return {
        ok: true,
        detail: kb ? `${type.replace("image/", "").toUpperCase()}, ${kb} KB` : type,
      };
    }

    if (type.includes("text/html")) {
      return {
        ok: false,
        detail:
          "Returned a web page, not an image — the file is probably not shared, or this is a folder link rather than a file link",
      };
    }

    return { ok: false, detail: `Unexpected type: ${type || "unknown"}` };
  } catch (e) {
    return {
      ok: false,
      detail: e instanceof Error ? `Could not load: ${e.message}` : "Could not load",
    };
  }
}

export async function checkProductImages(): Promise<CheckResult> {
  const products = await getAllProducts();

  const targets: { sku: string; name: string; url: string; slot: string }[] = [];
  for (const p of products) {
    targets.push({ sku: p.sku, name: p.name, url: p.image, slot: "image" });
    (p.extraImages ?? []).forEach((u, i) =>
      targets.push({ sku: p.sku, name: p.name, url: u, slot: `image${i + 2}` }),
    );
  }

  const placeholders = targets.filter((t) => t.url.startsWith("/")).length;
  const remote = targets.filter((t) => !t.url.startsWith("/"));

  // Checked in small batches: firing 200 requests at Google at once is the
  // fastest way to get rate-limited and produce false failures.
  const results: ImageStatus[] = [];
  const BATCH = 6;

  for (let i = 0; i < remote.length; i += BATCH) {
    const batch = remote.slice(i, i + BATCH);
    const checked = await Promise.all(
      batch.map(async (t) => {
        const { ok, detail } = await checkOne(t.url);
        return { ...t, ok, detail };
      }),
    );
    results.push(...checked);
  }

  return {
    checked: targets.length,
    ok: results.filter((r) => r.ok).length + placeholders,
    broken: results.filter((r) => !r.ok),
    placeholders,
  };
}

/** Checks a single URL, for the "test one photo" box. */
export async function checkSingleImage(
  url: string,
): Promise<{ ok: boolean; detail: string; resolved: string }> {
  const { normaliseImageUrl } = await import("@/lib/google");
  const resolved = normaliseImageUrl(url);
  const { ok, detail } = await checkOne(resolved);
  return { ok, detail, resolved };
}
