import { fs } from "@/lib/data-fs";
import { randomUUID } from "node:crypto";
import path from "node:path";

import { hashPassword, verifyPassword } from "@/lib/auth";
import { fileMtime } from "@/lib/data-fs";

/**
 * Accounts.
 *
 * File-backed like everything else here, and shaped so the move to Postgres
 * is a change inside this file. Two things it is strict about:
 *
 *  - The password hash never leaves this module. `PublicUser` is what the
 *    rest of the app sees, and it has no hash field to leak into a page, a
 *    server-action return value, or a log line.
 *
 *  - `isAdmin` lives here, on the server, and is read fresh on every request.
 *    It is never written into the session cookie, so there is no admin flag
 *    anywhere a browser could edit.
 */

const USERS_PATH = path.join(process.cwd(), "data", "users.json");

export type User = {
  id: string;
  email: string;
  name: string;
  /** Absent for Google-only accounts, which have no password to check. */
  passwordHash?: string;
  /** Set when the account came from Google, so the two can be linked. */
  googleId?: string;
  isAdmin: boolean;
  createdAt: string;
  lastLoginAt?: string;
};

/** Everything about a user that is safe to hand to a page or a client. */
export type PublicUser = {
  id: string;
  email: string;
  name: string;
  isAdmin: boolean;
};

type Store = { users: User[] };

let cache: Store | null = null;
let cachedMtime = -1;

/** Emails are matched case-insensitively; Gmail does not care about case. */
const normalise = (email: string) => email.trim().toLowerCase();

export const toPublic = (u: User): PublicUser => ({
  id: u.id,
  email: u.email,
  name: u.name,
  isAdmin: u.isAdmin,
});

async function read(): Promise<Store> {
  const mtime = fileMtime(USERS_PATH);
  if (cache && mtime === cachedMtime) return cache;

  let resolved: Store;
  try {
    resolved = JSON.parse(await fs.readFile(USERS_PATH, "utf8")) as Store;
    if (!Array.isArray(resolved.users)) resolved = { users: [] };
  } catch {
    resolved = { users: [] };
  }

  cache = resolved;
  cachedMtime = mtime;
  return resolved;
}

async function write(store: Store): Promise<void> {
  await fs.mkdir(path.dirname(USERS_PATH), { recursive: true });
  await fs.writeFile(USERS_PATH, JSON.stringify(store, null, 2), "utf8");
  cache = store;
  cachedMtime = fileMtime(USERS_PATH);
}

export async function findById(id: string): Promise<User | null> {
  const { users } = await read();
  return users.find((u) => u.id === id) ?? null;
}

export async function findByEmail(email: string): Promise<User | null> {
  const { users } = await read();
  const wanted = normalise(email);
  return users.find((u) => normalise(u.email) === wanted) ?? null;
}

export async function countUsers(): Promise<number> {
  return (await read()).users.length;
}

export async function hasAdmin(): Promise<boolean> {
  return (await read()).users.some((u) => u.isAdmin);
}

/* -------------------------------------------------------------------------
   Creating and authenticating
   ------------------------------------------------------------------------- */

export type CreateResult =
  | { ok: true; user: PublicUser }
  | { ok: false; error: string };

export async function createUser(input: {
  email: string;
  name: string;
  password?: string;
  googleId?: string;
  isAdmin?: boolean;
}): Promise<CreateResult> {
  const email = normalise(input.email);
  if (!email.includes("@")) return { ok: false, error: "That email does not look right." };

  const store = await read();
  if (store.users.some((u) => normalise(u.email) === email)) {
    return { ok: false, error: "An account with that email already exists." };
  }

  const user: User = {
    id: randomUUID(),
    email,
    name: input.name.trim() || email.split("@")[0],
    passwordHash: input.password ? await hashPassword(input.password) : undefined,
    googleId: input.googleId,
    isAdmin: input.isAdmin === true,
    createdAt: new Date().toISOString(),
  };

  await write({ users: [...store.users, user] });
  return { ok: true, user: toPublic(user) };
}

/**
 * Checks an email and password.
 *
 * Always runs the password comparison, even when no such user exists, so the
 * time taken does not reveal which emails are registered. The caller gets one
 * indistinguishable failure for both cases, for the same reason.
 */
export async function authenticate(
  email: string,
  password: string,
): Promise<User | null> {
  const user = await findByEmail(email);
  const ok = await verifyPassword(password, user?.passwordHash);
  if (!ok || !user) return null;
  return user;
}

/** Finds or creates the account behind a Google sign-in. */
export async function upsertGoogleUser(profile: {
  googleId: string;
  email: string;
  name: string;
}): Promise<User> {
  const store = await read();
  const email = normalise(profile.email);

  const existing = store.users.find(
    (u) => u.googleId === profile.googleId || normalise(u.email) === email,
  );

  if (existing) {
    // Links Google to an account that was created with a password. The email
    // is the join key, which is safe here ONLY because Google is asserting it
    // is verified — an unverified email would let anyone claim the account.
    existing.googleId = profile.googleId;
    existing.lastLoginAt = new Date().toISOString();
    await write(store);
    return existing;
  }

  const user: User = {
    id: randomUUID(),
    email,
    name: profile.name.trim() || email.split("@")[0],
    googleId: profile.googleId,
    isAdmin: false,
    createdAt: new Date().toISOString(),
    lastLoginAt: new Date().toISOString(),
  };

  await write({ users: [...store.users, user] });
  return user;
}

export async function touchLogin(id: string): Promise<void> {
  const store = await read();
  const user = store.users.find((u) => u.id === id);
  if (!user) return;
  user.lastLoginAt = new Date().toISOString();
  await write(store);
}

export async function setAdmin(id: string, isAdmin: boolean): Promise<void> {
  const store = await read();
  const user = store.users.find((u) => u.id === id);
  if (!user) return;
  user.isAdmin = isAdmin;
  await write(store);
}
