import { fs } from "@/lib/data-fs";
import path from "node:path";

import {
  CATEGORIES,
  GENDERS,
  registerCategories,
  registerCollections,
  type Gender,
  type SeedCategory,
  type SeedCollection,
} from "@/data/catalog";

/**
 * Categories the shop learned from the sheet.
 *
 * The built-in list cannot anticipate what someone decides to sell. Rejecting
 * a product because its category is not on a list written months earlier puts
 * the software's tidiness ahead of the shop's stock, which is the wrong way
 * round: the catalogue is the business, the category list is bookkeeping.
 *
 * So anything unrecognised becomes a real category — persisted here, appended
 * to CATEGORIES at boot, and from then on indistinguishable from a built-in
 * one. It appears in the navigation, gets its own page, and is filterable.
 */

const STORE_PATH = path.join(process.cwd(), "data", "categories.json");

type Store = { categories: SeedCategory[] };

const GENDER_SLUGS = GENDERS.map((g) => g.slug) as readonly string[];

/** Title Case, with the small words people expect to stay small. */
function titleCase(words: string[]): string {
  const small = new Set(["and", "or", "for", "of", "the", "with", "in", "on"]);
  return words
    .map((w, i) =>
      i > 0 && small.has(w) ? w : w.charAt(0).toUpperCase() + w.slice(1),
    )
    .join(" ");
}

/**
 * Turns a sheet cell into a category.
 *
 * `raw` is what was typed; `genderHint` is the sheet's gender column, used
 * only when the cell itself carries no gender. Returns null when there is
 * nothing left to name a category after the gender is removed.
 */
export function deriveCategory(raw: string, genderHint = ""): SeedCategory | null {
  const tokens = (raw ?? "")
    .toLowerCase()
    .replace(/&/g, " and ")
    .split(/[^a-z0-9]+/)
    .filter(Boolean);

  if (tokens.length === 0) return null;

  let gender: string | undefined;
  const rest: string[] = [];
  for (const t of tokens) {
    if (GENDER_SLUGS.includes(t) && !gender) gender = t;
    else rest.push(t);
  }

  if (!gender) {
    const hint = (genderHint ?? "").trim().toLowerCase();
    gender = GENDER_SLUGS.includes(hint) ? hint : undefined;
  }
  // Anything that names no gender at all belongs to everyone. That is a
  // better default than guessing "women" on a shop that also sells men's and
  // kids' items.
  gender ??= "unisex";

  if (rest.length === 0) return null;

  return {
    // Always gender-prefixed, so a sheet saying "socks" under men and "socks"
    // under women produces two categories rather than one shared page whose
    // gender depends on whichever row synced first.
    slug: `${gender}-${rest.join("-")}`,
    name: titleCase(rest),
    gender: gender as Gender,
    image: "/placeholders/lifestyle.svg",
    // 18% is the band most accessories fall in. It is inert until the shop
    // registers for GST, and correct enough to not silently under-charge if
    // it does — the owner can adjust before registering.
    taxRate: 1800,
  };
}

async function read(): Promise<Store> {
  try {
    const parsed = JSON.parse(await fs.readFile(STORE_PATH, "utf8")) as Store;
    return Array.isArray(parsed.categories) ? parsed : { categories: [] };
  } catch {
    return { categories: [] };
  }
}

/** Loads saved categories into CATEGORIES. Safe to call more than once. */
export async function loadStoredCategories(): Promise<number> {
  const { categories } = await read();
  return registerCategories(categories).length;
}

/**
 * Adds categories and saves them, so they survive a restart.
 * Returns only the ones that were genuinely new.
 */
export async function addCategories(
  extra: SeedCategory[],
): Promise<SeedCategory[]> {
  const added = registerCategories(extra);
  if (added.length === 0) return [];

  const store = await read();
  store.categories.push(...added);

  await fs.mkdir(path.dirname(STORE_PATH), { recursive: true });
  await fs.writeFile(STORE_PATH, JSON.stringify(store, null, 2), "utf8");
  return added;
}

/** Which of the live categories came from the sheet rather than the code. */
export async function storedSlugs(): Promise<Set<string>> {
  const { categories } = await read();
  return new Set(categories.map((c) => c.slug));
}

export function allCategories(): SeedCategory[] {
  return CATEGORIES;
}

/* -------------------------------------------------------------------------
   Collections
   ------------------------------------------------------------------------- */

const COLLECTION_PATH = path.join(process.cwd(), "data", "collections.json");

type CollectionStore = { collections: SeedCollection[] };

/** Turns a tag from the sheet into a browsable collection. */
export function deriveCollection(raw: string): SeedCollection | null {
  const words = (raw ?? "")
    .toLowerCase()
    .replace(/&/g, " and ")
    .split(/[^a-z0-9]+/)
    .filter(Boolean);

  if (words.length === 0) return null;

  const name = titleCase(words);
  return {
    slug: words.join("-"),
    name,
    // Generic, but honest. The owner can write a better one in admin, and an
    // empty description would leave the collection page with a bare heading.
    description: `Our ${name.toLowerCase()} picks.`,
  };
}

async function readCollections(): Promise<CollectionStore> {
  try {
    const parsed = JSON.parse(
      await fs.readFile(COLLECTION_PATH, "utf8"),
    ) as CollectionStore;
    return Array.isArray(parsed.collections) ? parsed : { collections: [] };
  } catch {
    return { collections: [] };
  }
}

export async function loadStoredCollections(): Promise<number> {
  const { collections } = await readCollections();
  return registerCollections(collections).length;
}

export async function addCollections(
  extra: SeedCollection[],
): Promise<SeedCollection[]> {
  const added = registerCollections(extra);
  if (added.length === 0) return [];

  const store = await readCollections();
  store.collections.push(...added);

  await fs.mkdir(path.dirname(COLLECTION_PATH), { recursive: true });
  await fs.writeFile(COLLECTION_PATH, JSON.stringify(store, null, 2), "utf8");
  return added;
}
