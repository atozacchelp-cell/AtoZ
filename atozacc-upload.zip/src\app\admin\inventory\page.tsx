import { EmptyRow, PageHeader, Pill, Stat, Table } from "@/components/admin-ui";
import { allCategories } from "@/lib/taxonomy";
import { getAllProducts } from "@/lib/product-store";
import { formatINR } from "@/lib/money";
import { getSettings } from "@/lib/settings";

export const metadata = { title: "Inventory", robots: { index: false } };

const categoryName = new Map(allCategories().map((c) => [c.slug, c.name]));

export default async function AdminInventory() {
  const settings = await getSettings();
  const products = await getAllProducts();

  const out = products.filter((p) => p.stock <= 0);
  const low = products.filter(
    (p) => p.stock > 0 && p.stock <= settings.lowStockThreshold,
  );
  const units = products.reduce((s, p) => s + Math.max(0, p.stock), 0);
  const retailValue = products.reduce((s, p) => s + p.price * Math.max(0, p.stock), 0);

  // Attention first: what is out, then what is nearly out, then everything.
  const ordered = [
    ...out,
    ...low,
    ...products.filter((p) => p.stock > settings.lowStockThreshold).sort(
      (a, b) => a.stock - b.stock,
    ),
  ];

  return (
    <>
      <PageHeader
        title="Inventory"
        subtitle={`Low-stock threshold is ${settings.lowStockThreshold} units`}
      />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <Stat label="Units in stock" value={String(units)} />
        <Stat label="Retail value" value={formatINR(retailValue)} sub="At selling price" />
        <Stat
          label="Out of stock"
          value={String(out.length)}
          tone={out.length ? "bad" : "good"}
        />
        <Stat
          label="Low stock"
          value={String(low.length)}
          tone={low.length ? "warn" : "good"}
        />
      </div>

      <div className="mt-6">
        <Table head={["Product", "SKU", "Category", "Stock", "Value", "Status"]}>
          {ordered.length === 0 ? (
            <EmptyRow colSpan={6}>No products.</EmptyRow>
          ) : (
            ordered.map((p) => (
              <tr key={p.sku} className="border-b border-line last:border-0">
                <td className="px-3 py-2">
                  <span className="block max-w-[240px] truncate font-medium">{p.name}</span>
                </td>
                <td className="tnum whitespace-nowrap px-3 py-2 text-[11.5px] text-ink-mute">
                  {p.sku}
                </td>
                <td className="whitespace-nowrap px-3 py-2 text-ink-mute">
                  {categoryName.get(p.category) ?? p.category}
                </td>
                <td className="tnum px-3 py-2 font-semibold">
                  {p.stock}
                  {/* A garment's total hides the thing worth knowing: nine
                      mediums and no larges reads as "18 in stock" and looks
                      healthy right up to the moment someone wants a large. */}
                  {p.sizeStock && (
                    <span className="mt-0.5 block whitespace-nowrap text-[11px] font-normal">
                      {(p.sizes ?? Object.keys(p.sizeStock)).map((s) => (
                        <span
                          key={s}
                          className={
                            (p.sizeStock![s] ?? 0) <= 0
                              ? "mr-1.5 text-brand"
                              : (p.sizeStock![s] ?? 0) <= settings.lowStockThreshold
                                ? "mr-1.5 text-warning"
                                : "mr-1.5 text-ink-mute"
                          }
                        >
                          {s} {p.sizeStock![s] ?? 0}
                        </span>
                      ))}
                    </span>
                  )}
                </td>
                <td className="tnum px-3 py-2 text-ink-mute">
                  {formatINR(p.price * Math.max(0, p.stock))}
                </td>
                <td className="px-3 py-2">
                  {p.stock <= 0 ? (
                    <Pill tone="bad">Out of stock</Pill>
                  ) : p.stock <= settings.lowStockThreshold ? (
                    <Pill tone="warn">Reorder</Pill>
                  ) : p.sizeStock &&
                    Object.values(p.sizeStock).some((n) => n <= 0) ? (
                    // Healthy overall, but a size a customer will ask for is
                    // gone. That is the reorder signal for clothing.
                    <Pill tone="warn">Sizes out</Pill>
                  ) : (
                    <Pill tone="good">OK</Pill>
                  )}
                </td>
              </tr>
            ))
          )}
        </Table>
      </div>

      <p className="mt-4 rounded-[var(--radius-card)] border border-line bg-canvas px-4 py-3 text-[12.5px] text-ink-mute">
        Stock adjustments and the movement ledger arrive with the database. The
        schema already models the ledger as append-only, so every future change
        will record what the stock was, what it became and why.
      </p>
    </>
  );
}
