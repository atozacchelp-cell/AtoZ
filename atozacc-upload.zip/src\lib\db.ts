/**
 * The Postgres connection — which this shop does not have yet.
 *
 * Nothing here is imported at module load, on purpose. The previous version
 * did two things that only fail once deployed:
 *
 *  - It imported `@prisma/client` statically, so the bundler had to resolve a
 *    package that only exists after `prisma generate` has run. A clean install
 *    on Netlify has not run it yet, and the build failed on a dependency the
 *    running site never actually calls.
 *
 *  - It called `createClient()` at the top level, which throws when
 *    `DATABASE_URL` is unset. Every page would have crashed on first render.
 *
 * The store runs on Netlify Blobs today (see `storage.ts`). Prisma is kept for
 * the migration to Postgres later, and loaded only if a real database is
 * actually configured.
 */

/**
 * Is there a real database to talk to?
 *
 * The repo ships a placeholder DATABASE_URL so Prisma CLI commands work
 * before Neon is set up. Callers check this rather than firing a query that
 * is certain to fail — otherwise every page render logs a connection error
 * and waits on a doomed TCP attempt first.
 */
export function isDatabaseConfigured(): boolean {
  const url = process.env.DATABASE_URL;
  if (!url) return false;
  return !url.includes("placeholder");
}

/** Cached across hot reloads, so dev does not open a pool per edit. */
const globalForPrisma = globalThis as unknown as { prisma?: unknown };

/**
 * The Prisma client, or null when no database is configured.
 *
 * Deliberately `unknown`-typed at the boundary: typing it as PrismaClient
 * would drag the generated types back into the static graph and undo the
 * point of loading it dynamically.
 */
export async function getDb(): Promise<Record<string, never> | null> {
  if (!isDatabaseConfigured()) return null;
  if (globalForPrisma.prisma) {
    return globalForPrisma.prisma as Record<string, never>;
  }

  try {
    // Variable specifiers keep the bundler from trying to resolve these at
    // build time — which is what lets the site build before the client has
    // ever been generated.
    const clientPkg = "@prisma/client";
    const adapterPkg = "@prisma/adapter-pg";
    const { PrismaClient } = (await import(/* webpackIgnore: true */ clientPkg)) as {
      PrismaClient: new (opts: unknown) => unknown;
    };
    const { PrismaPg } = (await import(/* webpackIgnore: true */ adapterPkg)) as {
      PrismaPg: new (opts: unknown) => unknown;
    };

    const client = new PrismaClient({
      adapter: new PrismaPg({ connectionString: process.env.DATABASE_URL }),
      log: process.env.NODE_ENV === "development" ? ["warn", "error"] : ["error"],
    });

    if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = client;
    return client as Record<string, never>;
  } catch {
    // A configured-but-unusable database must not take the shop down; the
    // file and blob stores are the source of truth today regardless.
    return null;
  }
}
