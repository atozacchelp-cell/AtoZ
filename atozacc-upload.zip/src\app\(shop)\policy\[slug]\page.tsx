import Link from "next/link";
import { notFound } from "next/navigation";

import { Breadcrumbs, Container } from "@/components/ui";
import { buildPolicies } from "@/data/policies";
import { DEFAULT_SETTINGS, getSettings } from "@/lib/settings";

export async function generateStaticParams() {
  return buildPolicies(DEFAULT_SETTINGS).map((p) => ({ slug: p.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const policy = buildPolicies(DEFAULT_SETTINGS).find((p) => p.slug === slug);
  if (!policy) return { title: "Not found" };
  return { title: policy.title, description: policy.summary };
}

export default async function PolicyPage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const [{ slug }, settings] = await Promise.all([params, getSettings()]);
  const policies = buildPolicies(settings);
  const policy = policies.find((p) => p.slug === slug);
  if (!policy) notFound();

  return (
    <Container className="max-w-3xl py-8">
      <Breadcrumbs items={[{ label: policy.title }]} />

      <h1 className="font-display text-[30px] leading-tight sm:text-[36px]">
        {policy.title}
      </h1>
      <p className="mt-2 text-[14px] text-ink-mid">{policy.summary}</p>

      <div className="mt-10 space-y-9">
        {policy.sections.map((section) => (
          <section key={section.heading}>
            <h2 className="font-display text-xl">{section.heading}</h2>
            <div className="mt-2.5 space-y-2.5">
              {section.body.map((para, i) => (
                <p key={i} className="max-w-prose text-[14px] leading-relaxed text-ink-mid">
                  {para}
                </p>
              ))}
            </div>
          </section>
        ))}
      </div>

      <div className="mt-12 rounded-[var(--radius-card)] border border-line bg-surface p-5 text-[13px] text-ink-mid">
        <p>
          Questions about this policy? Write to{" "}
          <span className="font-semibold text-ink">{settings.supportEmail}</span> or
          message {settings.supportPhone} on WhatsApp, {settings.supportHours}.
        </p>
      </div>

      <nav className="mt-8 flex flex-wrap gap-2 border-t border-line pt-6">
        {policies
          .filter((p) => p.slug !== policy.slug)
          .map((p) => (
            <Link
              key={p.slug}
              href={`/policy/${p.slug}`}
              className="rounded-[var(--radius-pill)] border border-line px-3.5 py-1.5 text-[12.5px] font-medium text-ink-mute hover:border-brand hover:text-brand"
            >
              {p.title}
            </Link>
          ))}
      </nav>
    </Container>
  );
}
