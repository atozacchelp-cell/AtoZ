import type { MetadataRoute } from "next";

import { allCategories, allCollections } from "@/lib/taxonomy";
import { getAllProducts } from "@/lib/product-store";
import { buildPolicies } from "@/data/policies";
import { categoryHref, getGenders, productHref } from "@/lib/catalog";
import { DEFAULT_SETTINGS } from "@/lib/settings";

const base = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const products = await getAllProducts();
  const url = (path: string) => `${base}${path}`;

  return [
    { url: url("/"), priority: 1, changeFrequency: "daily" },
    { url: url("/shop"), priority: 0.9, changeFrequency: "daily" },
    { url: url("/new-arrivals"), priority: 0.8, changeFrequency: "daily" },
    { url: url("/bestsellers"), priority: 0.8, changeFrequency: "weekly" },
    { url: url("/trending"), priority: 0.8, changeFrequency: "daily" },
    { url: url("/offers"), priority: 0.8, changeFrequency: "daily" },

    ...getGenders().map((g) => ({
      url: url(`/${g.slug}`),
      priority: 0.9,
      changeFrequency: "weekly" as const,
    })),

    ...allCategories().map((c) => ({
      url: url(categoryHref(c)),
      priority: 0.7,
      changeFrequency: "weekly" as const,
    })),

    ...allCollections().map((c) => ({
      url: url(`/collections/${c.slug}`),
      priority: 0.7,
      changeFrequency: "weekly" as const,
    })),

    // Products carry the highest business value, so they get their own entries
    // rather than relying on category pages to surface them.
    ...products.map((p) => ({
      url: url(productHref(p)),
      priority: 0.8,
      changeFrequency: "weekly" as const,
    })),

    { url: url("/about"), priority: 0.5, changeFrequency: "monthly" },
    { url: url("/contact"), priority: 0.5, changeFrequency: "monthly" },
    { url: url("/faq"), priority: 0.6, changeFrequency: "monthly" },

    ...buildPolicies(DEFAULT_SETTINGS).map((p) => ({
      url: url(`/policy/${p.slug}`),
      priority: 0.3,
      changeFrequency: "yearly" as const,
    })),
  ];
}
