import {
  GENDERS,
  type Gender,
  type SeedCategory,
  type SeedProduct,
} from "@/data/catalog";
import { getAllProducts } from "@/lib/product-store";
import { allCategories, allCollections, categoryIndex } from "@/lib/taxonomy";
import { discountPercent } from "@/lib/money";

/**
 * Catalogue reads.
 *
 * Backed by the seed fixtures until a database is connected. Every function
 * here is async and returns the same DTO shape a Prisma-backed implementation
 * will, so swapping the backing store is a change inside this file and
 * nowhere else. Callers never see a SeedProduct.
 */

// ---------------------------------------------------------------------------
// DTOs
// ---------------------------------------------------------------------------

export type ProductListItem = {
  slug: string;
  href: string;
  sku: string;
  name: string;
  imageUrl: string;
  price: number;
  mrp: number;
  discount: number;
  rating?: number;
  reviewCount?: number;
  outOfStock: boolean;
  stockLeft?: number;
  isNew?: boolean;
  isTrending?: boolean;
  isBestseller?: boolean;
  isExclusive?: boolean;
  /** Overrides the automatic badge when the sheet supplies one. */
  badgeText?: string;
};

export type ProductDetail = ProductListItem & {
  gender: Gender;
  categorySlug: string;
  categoryName: string;
  shortDescription: string;
  description: string;
  colours: string[];
  sizes: string[];
  /** Units per size, for garments. Absent means `stock` covers the product. */
  sizeStock?: Record<string, number>;
  sizeChart?: { headers: string[]; rows: string[][] };
  material?: string;
  weightG: number;
  features: string[];
  care?: string;
  collections: string[];
  isReturnable: boolean;
  isCodAllowed: boolean;
  stock: number;
  taxRate: number;
  images: string[];
  fulfilment: "self" | "dropship";
  supplier?: string;
  dispatchDays?: number;
};

export type CategoryNode = SeedCategory & {
  href: string;
  children: CategoryNode[];
  productCount: number;
};

export type Facets = {
  colours: { value: string; count: number }[];
  sizes: { value: string; count: number }[];
  materials: { value: string; count: number }[];
  priceMin: number;
  priceMax: number;
};

export type { SortKey } from "./catalog-constants";
export { SORT_OPTIONS } from "./catalog-constants";
import type { SortKey } from "./catalog-constants";

export type ProductFilters = {
  gender?: Gender;
  category?: string;
  collection?: string;
  q?: string;
  colours?: string[];
  sizes?: string[];
  materials?: string[];
  minPrice?: number;
  maxPrice?: number;
  minRating?: number;
  minDiscount?: number;
  inStockOnly?: boolean;
};

// ---------------------------------------------------------------------------
// Mapping
// ---------------------------------------------------------------------------

// Rebuilt whenever the sheet adds a category, so a page never renders from
// a snapshot taken before it existed.
const categoryBySlug = { get: (k: string) => categoryIndex().get(k), has: (k: string) => categoryIndex().has(k) };

/**
 * Products live at /{gender}/{category}/{slug}. When a category has a parent,
 * the URL uses the parent's short name so the path reads the way the shopper
 * navigated: /women/jewellery/earrings -> /women/jewellery/oxidised-...
 */
export function productHref(p: Pick<SeedProduct, "gender" | "category" | "slug">): string {
  const cat = categoryBySlug.get(p.category);
  const segment = categorySegment(cat);
  return `/${p.gender}/${segment}/${p.slug}`;
}

function categorySegment(cat: SeedCategory | undefined): string {
  if (!cat) return "shop";
  // Strip the gender prefix: "women-earrings" -> "earrings"
  const root = cat.parent ? categoryBySlug.get(cat.parent) : cat;
  const base = root ?? cat;
  return base.slug.replace(/^(women|men|kids|unisex)-/, "");
}

export function categoryHref(cat: SeedCategory): string {
  const parent = cat.parent ? categoryBySlug.get(cat.parent) : undefined;
  const own = cat.slug.replace(/^(women|men|kids|unisex)-/, "");
  if (parent) {
    const parentSeg = parent.slug.replace(/^(women|men|kids|unisex)-/, "");
    const childSeg = own.replace(new RegExp(`^${parentSeg}-`), "");
    return `/${cat.gender}/${parentSeg}/${childSeg}`;
  }
  return `/${cat.gender}/${own}`;
}

function toListItem(p: SeedProduct): ProductListItem {
  return {
    slug: p.slug,
    href: productHref(p),
    sku: p.sku,
    name: p.name,
    imageUrl: p.image,
    price: p.price,
    mrp: p.mrp,
    discount: discountPercent(p.mrp, p.price),
    rating: p.rating,
    reviewCount: p.reviewCount,
    outOfStock: p.stock <= 0,
    stockLeft: p.stock > 0 && p.stock <= 3 ? p.stock : undefined,
    isNew: p.isNew,
    isTrending: p.isTrending,
    isBestseller: p.isBestseller,
    isExclusive: p.isExclusive,
    badgeText: p.badgeText,
  };
}

function toDetail(p: SeedProduct): ProductDetail {
  const cat = categoryBySlug.get(p.category);
  return {
    ...toListItem(p),
    gender: p.gender,
    categorySlug: p.category,
    categoryName: cat?.name ?? "Accessories",
    shortDescription: p.shortDescription,
    description: p.description,
    colours: p.colours ?? [],
    sizes: p.sizes ?? [],
    sizeStock: p.sizeStock,
    sizeChart: p.sizeChart,
    material: p.material,
    weightG: p.weightG,
    features: p.features ?? [],
    care: p.care,
    collections: p.collections ?? [],
    isReturnable: p.isReturnable !== false,
    isCodAllowed: p.isCodAllowed !== false,
    stock: p.stock,
    taxRate: cat?.taxRate ?? 0,
    images: [p.image, ...(p.extraImages ?? [])].filter(Boolean),
    fulfilment: p.fulfilment ?? "self",
    supplier: p.supplier,
    dispatchDays: p.dispatchDays,
  };
}

// ---------------------------------------------------------------------------
// Filtering & sorting
// ---------------------------------------------------------------------------

/**
 * A spread of real product photos, for the decorative strips on the homepage.
 *
 * Those blocks existed as hardcoded line drawings, which made the top of the
 * shop look like a wireframe of itself while 36 real photographs sat one
 * scroll further down. One product per category, so the collage shows the
 * range rather than four variations of the same earring — that range is the
 * actual argument for an A-to-Z accessories store.
 */
export async function getShowcaseImages(count: number): Promise<string[]> {
  const all = await getAllProducts();

  const byCategory = new Map<string, string>();
  for (const p of all) {
    if (isPlaceholder(p.image) || p.stock <= 0) continue;
    if (!byCategory.has(p.category)) byCategory.set(p.category, p.image);
  }

  const spread = [...byCategory.values()];
  if (spread.length >= count) return spread.slice(0, count);

  // Not enough distinct categories yet: top up with anything real rather than
  // falling back to icons, and only then pad with what is left.
  const rest = all
    .filter((p) => !isPlaceholder(p.image) && !spread.includes(p.image))
    .map((p) => p.image);

  return [...spread, ...rest].slice(0, count);
}

/** The stand-in line drawings, which are never worth showing over a real photo. */
const isPlaceholder = (url: string | undefined): boolean =>
  !url || url.startsWith("/placeholders/");

/** Descendant category slugs, so /women/jewellery includes earrings and rings. */
function categoryWithDescendants(slug: string): Set<string> {
  const out = new Set<string>([slug]);
  let grew = true;
  while (grew) {
    grew = false;
    for (const c of allCategories()) {
      if (c.parent && out.has(c.parent) && !out.has(c.slug)) {
        out.add(c.slug);
        grew = true;
      }
    }
  }
  return out;
}

/**
 * Three collections are DERIVED from product flags rather than tagged by
 * hand: new-arrivals, trending and bestsellers.
 *
 * They exist as both a flag (`isNew`) and a collection in the requirements,
 * and maintaining both by hand guarantees they drift — a product gets marked
 * "New" in admin but never added to the New Arrivals collection, and the
 * homepage rail silently empties. Deriving them means the flag is the single
 * control, and the collection can never disagree with it.
 */
function inCollection(p: SeedProduct, collection: string): boolean {
  switch (collection) {
    case "new-arrivals":
      return p.isNew === true;
    case "trending":
      return p.isTrending === true;
    case "bestsellers":
      return p.isBestseller === true;
    default:
      return (p.collections ?? []).includes(collection);
  }
}

function matches(p: SeedProduct, f: ProductFilters): boolean {
  if (f.gender && p.gender !== f.gender) return false;

  if (f.category) {
    const allowed = categoryWithDescendants(f.category);
    if (!allowed.has(p.category)) return false;
  }

  if (f.collection && !inCollection(p, f.collection)) return false;

  if (f.q) {
    const haystack = [p.name, p.sku, p.shortDescription, p.material ?? "", ...(p.collections ?? [])]
      .join(" ")
      .toLowerCase();
    const terms = f.q.toLowerCase().split(/\s+/).filter(Boolean);
    if (!terms.every((t) => haystack.includes(t))) return false;
  }

  if (f.colours?.length && !f.colours.some((c) => (p.colours ?? []).includes(c))) return false;
  if (f.sizes?.length && !f.sizes.some((s) => (p.sizes ?? []).includes(s))) return false;
  if (f.materials?.length && !f.materials.includes(p.material ?? "")) return false;

  if (f.minPrice !== undefined && p.price < f.minPrice) return false;
  if (f.maxPrice !== undefined && p.price > f.maxPrice) return false;

  if (f.minRating !== undefined && (p.rating ?? 0) < f.minRating) return false;
  if (f.minDiscount !== undefined && discountPercent(p.mrp, p.price) < f.minDiscount) return false;
  if (f.inStockOnly && p.stock <= 0) return false;

  return true;
}

function sortProducts(items: SeedProduct[], sort: SortKey): SeedProduct[] {
  const copy = [...items];
  switch (sort) {
    case "price-asc":
      return copy.sort((a, b) => a.price - b.price);
    case "price-desc":
      return copy.sort((a, b) => b.price - a.price);
    case "discount":
      return copy.sort(
        (a, b) => discountPercent(b.mrp, b.price) - discountPercent(a.mrp, a.price),
      );
    case "rating":
      return copy.sort((a, b) => (b.rating ?? 0) - (a.rating ?? 0));
    case "newest":
      return copy.sort((a, b) => Number(b.isNew ?? false) - Number(a.isNew ?? false));
    case "bestselling":
      return copy.sort(
        (a, b) =>
          Number(b.isBestseller ?? false) - Number(a.isBestseller ?? false) ||
          (b.reviewCount ?? 0) - (a.reviewCount ?? 0),
      );
    case "relevance":
    default:
      // Out-of-stock always sinks: showing someone a thing they cannot buy at
      // the top of a grid is the fastest way to lose them.
      return copy.sort(
        (a, b) =>
          Number(a.stock <= 0) - Number(b.stock <= 0) ||
          Number(b.isBestseller ?? false) - Number(a.isBestseller ?? false) ||
          (b.rating ?? 0) - (a.rating ?? 0),
      );
  }
}

function buildFacets(items: SeedProduct[]): Facets {
  const count = (values: (p: SeedProduct) => string[]) => {
    const m = new Map<string, number>();
    for (const p of items) for (const v of values(p)) m.set(v, (m.get(v) ?? 0) + 1);
    return [...m.entries()]
      .map(([value, c]) => ({ value, count: c }))
      .sort((a, b) => b.count - a.count || a.value.localeCompare(b.value));
  };

  const prices = items.map((p) => p.price);
  return {
    colours: count((p) => p.colours ?? []),
    sizes: count((p) => p.sizes ?? []),
    materials: count((p) => (p.material ? [p.material] : [])),
    priceMin: prices.length ? Math.min(...prices) : 0,
    priceMax: prices.length ? Math.max(...prices) : 0,
  };
}

// ---------------------------------------------------------------------------
// Public queries
// ---------------------------------------------------------------------------

export async function listProducts(
  filters: ProductFilters = {},
  sort: SortKey = "relevance",
  page = 1,
  perPage = 24,
): Promise<{
  items: ProductListItem[];
  total: number;
  page: number;
  totalPages: number;
  facets: Facets;
}> {
  const all = await getAllProducts();
  const matched = all.filter((p) => matches(p, filters));
  const sorted = sortProducts(matched, sort);
  const start = (page - 1) * perPage;

  return {
    items: sorted.slice(start, start + perPage).map(toListItem),
    total: matched.length,
    page,
    totalPages: Math.max(1, Math.ceil(matched.length / perPage)),
    // Facets come from the filtered set minus pagination, so counts reflect
    // what is actually reachable rather than the whole catalogue.
    facets: buildFacets(matched),
  };
}

export async function getProduct(slug: string): Promise<ProductDetail | null> {
  const all = await getAllProducts();
  const p = all.find((x) => x.slug === slug);
  return p ? toDetail(p) : null;
}

export async function getRelatedProducts(
  product: ProductDetail,
  limit = 4,
): Promise<ProductListItem[]> {
  const all = await getAllProducts();
  const sameCategory = all.filter(
    (p) => p.category === product.categorySlug && p.slug !== product.slug,
  );
  const sameGender = all.filter(
    (p) =>
      p.gender === product.gender &&
      p.category !== product.categorySlug &&
      p.slug !== product.slug,
  );
  return [...sameCategory, ...sameGender].slice(0, limit).map(toListItem);
}

export async function getCategoryTree(gender?: Gender): Promise<CategoryNode[]> {
  const counts = new Map<string, number>();
  const all = await getAllProducts();
  for (const p of all) counts.set(p.category, (counts.get(p.category) ?? 0) + 1);

  /**
   * The photo to show for a category.
   *
   * A line drawing of a handbag tells a shopper nothing they did not already
   * know from the word "Bags" underneath it. An actual bag from that category
   * shows them what this shop's bags look like, which is the only reason to
   * put a picture there at all — and it costs nothing, because the photo is
   * already in the catalogue.
   *
   * Preference order is bestseller, then anything in stock, then anything at
   * all: a category should never advertise itself with a sold-out item.
   */
  const pickImage = (slugs: Set<string>, fallback?: string): string | undefined => {
    const mine = all.filter((p) => slugs.has(p.category) && !isPlaceholder(p.image));
    if (mine.length === 0) return fallback;

    const best =
      mine.find((p) => p.isBestseller && p.stock > 0) ??
      mine.find((p) => p.stock > 0) ??
      mine[0];
    return best.image;
  };

  const build = (cat: SeedCategory): CategoryNode => {
    const children = allCategories().filter((c) => c.parent === cat.slug).map(build);
    const own = counts.get(cat.slug) ?? 0;
    // A parent shows the best photo from anywhere beneath it, so "Jewellery"
    // is illustrated by a real earring rather than staying an icon just
    // because nothing is filed at the top level.
    const descendants = categoryWithDescendants(cat.slug);
    return {
      ...cat,
      image: pickImage(descendants, cat.image),
      href: categoryHref(cat),
      children,
      productCount: own + children.reduce((s, c) => s + c.productCount, 0),
    };
  };

  return allCategories().filter((c) => !c.parent && (!gender || c.gender === gender)).map(build);
}

/**
 * Resolves a URL path back to a category by comparing against the href each
 * category GENERATES, rather than rebuilding a slug from the segments.
 *
 * Reconstructing the slug means the URL builder and the lookup each hold
 * their own idea of the naming scheme, and they drift: `women-earrings`
 * renders at /women/jewellery/earrings but a rebuild looks for
 * `women-jewellery-earrings` and 404s a page that is linked from the nav.
 * One source of truth removes the whole class of bug.
 */
export async function getCategoryBySegments(
  gender: Gender,
  segments: string[],
): Promise<SeedCategory | null> {
  if (segments.length === 0) return null;
  const wanted = `/${gender}/${segments.join("/")}`;
  return (
    allCategories().find((c) => c.gender === gender && categoryHref(c) === wanted) ?? null
  );
}

export function getGenders() {
  return GENDERS;
}

export function getCollections() {
  return allCollections();
}

export async function getCollection(slug: string) {
  return allCollections().find((c) => c.slug === slug) ?? null;
}

/** Header search suggestions. */
export async function quickSearch(q: string, limit = 6): Promise<ProductListItem[]> {
  if (!q.trim()) return [];
  const all = await getAllProducts();
  const matched = all.filter((p) => matches(p, { q }));
  return sortProducts(matched, "relevance").slice(0, limit).map(toListItem);
}

/** Every product slug, for sitemap generation and static params. */
export async function allProductRoutes() {
  const all = await getAllProducts();
  return all.map((p) => ({
    gender: p.gender,
    category: categorySegment(categoryBySlug.get(p.category)),
    slug: p.slug,
  }));
}
