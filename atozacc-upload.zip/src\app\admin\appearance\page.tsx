import { PageHeader } from "@/components/admin-ui";
import { AppearanceForm } from "@/components/appearance-form";
import { getBranding } from "@/lib/branding";

export const metadata = { title: "Appearance", robots: { index: false } };

export default async function AppearancePage() {
  const branding = await getBranding();

  return (
    <>
      <PageHeader
        title="Appearance"
        subtitle="Logo, fonts, text size and colour — applied across the whole shop"
      />
      <AppearanceForm branding={branding} />
    </>
  );
}
