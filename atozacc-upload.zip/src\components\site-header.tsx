import Image from "next/image";
import Link from "next/link";

import { HeaderHeightVar } from "@/components/header-height";
import { SearchBox } from "@/components/search-box";
import { getCartCount, readWishlist } from "@/lib/cart";
import { getCategoryTree, getGenders } from "@/lib/catalog";
import { currentUser } from "@/lib/session";
import { getSettings } from "@/lib/settings";
import { getBranding } from "@/lib/branding";
import { getContent } from "@/lib/site-content";
import { cn } from "@/lib/cn";

export async function SiteHeader() {
  const [cartCount, wishlist, settings, content, branding, genders, user] = await Promise.all([
    getCartCount(),
    readWishlist(),
    getSettings(),
    getContent(),
    getBranding(),
    Promise.resolve(getGenders()),
    currentUser(),
  ]);

  const trees = await Promise.all(
    genders.map(async (g) => ({ gender: g, tree: await getCategoryTree(g.slug) })),
  );

  return (
    <>
      {/* Announcement strip. Carries the free-shipping threshold, because that
          number is what lifts basket size and it should be visible everywhere. */}
      <div className="bg-ink text-canvas">
        <p className="mx-auto max-w-7xl px-4 py-2 text-center text-[11.5px] font-medium tracking-wide">
          {[content.announcement1, content.announcement2, content.announcement3]
            .filter(Boolean)
            .map((text, i) => (
              <span key={i}>
                {i > 0 && <span className="mx-2 opacity-40">·</span>}
                {text}
              </span>
            ))}
        </p>
      </div>

      <header className="sticky top-0 z-40 border-b border-line bg-canvas/95 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center gap-3 px-4 py-3 sm:gap-6">
          <Link href="/" className="shrink-0" aria-label={branding.logoText || "AtoZacc"}>
            {branding.logoUrl ? (
              // Sized by CSS from the logo’s own measured ratio: width follows
              // height automatically, and the height steps down on small
              // screens so a tall logo cannot eat a phone’s viewport.
              <span className="site-logo relative block">
                <Image
                  src={branding.logoUrl}
                  alt={branding.logoText || "AtoZacc"}
                  fill
                  priority
                  sizes="320px"
                  className="object-contain object-left"
                />
              </span>
            ) : (
              <span
                className="font-display font-semibold tracking-tight"
                style={{ fontSize: branding.logoHeight * 0.78 }}
              >
                {branding.logoText || "AtoZacc"}
              </span>
            )}
          </Link>

          {/* Desktop nav */}
          <nav className="hidden lg:flex lg:items-center lg:gap-1">
            {trees.map(({ gender, tree }) => (
              <NavItem key={gender.slug} label={gender.name} href={`/${gender.slug}`}>
                {tree.length > 0 && (
                  <div className="grid grid-cols-3 gap-x-8 gap-y-1 p-5">
                    {tree.map((cat) => (
                      <div key={cat.slug} className="mb-3">
                        <Link
                          href={cat.href}
                          className="block text-[13px] font-bold text-ink hover:text-brand"
                        >
                          {cat.name}
                        </Link>
                        {cat.children.map((child) => (
                          <Link
                            key={child.slug}
                            href={child.href}
                            className="mt-1 block text-[12.5px] text-ink-mute hover:text-brand"
                          >
                            {child.name}
                          </Link>
                        ))}
                      </div>
                    ))}
                  </div>
                )}
              </NavItem>
            ))}
            <TopLink href="/new-arrivals">New In</TopLink>
            <TopLink href="/offers" accent>
              Offers
            </TopLink>
            <TopLink href="/collections/gift-collection">Gifts</TopLink>
          </nav>

          <div className="ml-auto flex items-center gap-1 sm:gap-2">
            <div className="hidden w-56 md:block xl:w-72">
              <SearchBox />
            </div>

            <IconLink href="/track-order" label="Track order" className="hidden sm:grid">
              <PathIcon d="M12 2 3 7v10l9 5 9-5V7zM3 7l9 5 9-5M12 12v10" />
            </IconLink>

            <IconLink href="/wishlist" label="Wishlist" badge={wishlist.length}>
              <PathIcon d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1L12 21l7.7-7.7 1.1-1a5.5 5.5 0 0 0 0-7.8z" />
            </IconLink>

            <IconLink
              href={user ? "/account" : "/signin"}
              label={user ? `Account — ${user.name}` : "Sign in"}
              className="hidden sm:grid"
            >
              <PathIcon d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2M12 11a4 4 0 1 0 0-8 4 4 0 0 0 0 8z" />
            </IconLink>

            <IconLink href="/cart" label="Cart" badge={cartCount}>
              <PathIcon d="M6 2 3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4zM3 6h18M16 10a4 4 0 0 1-8 0" />
            </IconLink>
          </div>
        </div>

        {/* Mobile search sits on its own row — cramming it beside five icons
            makes every target too small to hit. */}
        <div className="border-t border-line px-4 py-2 md:hidden">
          <SearchBox />
        </div>
      </header>

      {/* Lets listing bars stick directly below the header instead of
          guessing its height. */}
      <HeaderHeightVar />
    </>
  );
}

function TopLink({
  href,
  children,
  accent,
}: {
  href: string;
  children: React.ReactNode;
  accent?: boolean;
}) {
  return (
    <Link
      href={href}
      className={cn(
        "rounded px-3 py-2 text-[13.5px] font-semibold transition-colors",
        accent ? "text-brand hover:text-brand-deep" : "text-ink hover:text-brand",
      )}
    >
      {children}
    </Link>
  );
}

/** Hover-revealed mega menu. CSS-only, so it works before hydration. */
function NavItem({
  label,
  href,
  children,
}: {
  label: string;
  href: string;
  children: React.ReactNode;
}) {
  return (
    <div className="group relative">
      <Link
        href={href}
        className="block rounded px-3 py-2 text-[13.5px] font-semibold text-ink transition-colors hover:text-brand"
      >
        {label}
      </Link>
      <div className="pointer-events-none absolute left-0 top-full z-50 w-[34rem] origin-top-left rounded-b-[var(--radius-card)] border border-line bg-canvas opacity-0 shadow-[var(--shadow-lift)] transition-opacity duration-150 group-hover:pointer-events-auto group-hover:opacity-100 group-focus-within:pointer-events-auto group-focus-within:opacity-100">
        {children}
      </div>
    </div>
  );
}

function IconLink({
  href,
  label,
  badge,
  children,
  className,
}: {
  href: string;
  label: string;
  badge?: number;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <Link
      href={href}
      aria-label={label}
      title={label}
      className={cn(
        "relative grid h-10 w-10 place-items-center rounded-full text-ink-mid transition-colors hover:bg-surface hover:text-brand",
        className,
      )}
    >
      {children}
      {badge !== undefined && badge > 0 && (
        <span className="tnum absolute -right-0.5 -top-0.5 grid h-[17px] min-w-[17px] place-items-center rounded-full bg-brand px-1 text-[10px] font-bold text-white">
          {badge > 99 ? "99+" : badge}
        </span>
      )}
    </Link>
  );
}

function PathIcon({ d }: { d: string }) {
  return (
    <svg
      width="19"
      height="19"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden
    >
      <path d={d} />
    </svg>
  );
}
