/**
 * Money handling for AtoZacc.
 *
 * EVERY monetary value in this system is an integer number of PAISE.
 * Never a float, never rupees. 0.1 + 0.2 !== 0.3, and a store that gets
 * this wrong produces invoices that do not add up.
 *
 * Rupees exist only at the edges: parsing admin input, and rendering to
 * the screen. In between it is paise all the way down.
 */

/** 100 paise to the rupee. */
const PAISE_PER_RUPEE = 100;

/** Percentages are stored as basis points: 1000 = 10.00%, 300 = 3.00%. */
const BASIS_POINTS = 10_000;

// ---------------------------------------------------------------------------
// Conversion
// ---------------------------------------------------------------------------

/** Rupees (as typed by an admin) to paise. Rounds — never truncates. */
export function toPaise(rupees: number): number {
  return Math.round(rupees * PAISE_PER_RUPEE);
}

/** Paise to rupees, for display or export. May be fractional. */
export function toRupees(paise: number): number {
  return paise / PAISE_PER_RUPEE;
}

/**
 * Parses a user-typed price string ("499", "₹499.50", "1,299") into paise.
 * Returns null when the input is not a usable number, so callers must decide
 * what to do rather than silently getting a 0.
 */
export function parsePriceToPaise(input: string): number | null {
  const cleaned = input.replace(/[₹,\s]/g, "").trim();
  if (cleaned === "") return null;

  const value = Number(cleaned);
  if (!Number.isFinite(value) || value < 0) return null;

  return toPaise(value);
}

// ---------------------------------------------------------------------------
// Formatting
// ---------------------------------------------------------------------------

const inrFormatter = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  minimumFractionDigits: 0,
  maximumFractionDigits: 0,
});

const inrFormatterWithPaise = new Intl.NumberFormat("en-IN", {
  style: "currency",
  currency: "INR",
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

/**
 * Formats paise as "₹1,299" using Indian lakh grouping.
 *
 * Whole rupees by default, because §7.6 rounds cart totals to the rupee and
 * a trailing ".00" on every price adds noise to a busy product grid.
 */
export function formatINR(paise: number, showPaise = false): string {
  const rupees = toRupees(paise);
  return showPaise
    ? inrFormatterWithPaise.format(rupees)
    : inrFormatter.format(Math.round(rupees));
}

/** Formats without the currency symbol — for CSV exports and input fields. */
export function formatAmount(paise: number): string {
  return toRupees(paise).toFixed(2);
}

// ---------------------------------------------------------------------------
// Rounding
// ---------------------------------------------------------------------------

/** §7.6 — the final cart total is rounded to the nearest whole rupee. */
export function roundToRupee(paise: number): number {
  return Math.round(paise / PAISE_PER_RUPEE) * PAISE_PER_RUPEE;
}

// ---------------------------------------------------------------------------
// Percentages
// ---------------------------------------------------------------------------

/**
 * Applies a basis-point percentage to an amount.
 * `percentOf(50000, 1000)` = 10% of ₹500 = ₹50.
 */
export function percentOf(paise: number, basisPoints: number): number {
  return Math.round((paise * basisPoints) / BASIS_POINTS);
}

/**
 * Discount percentage off MRP, as a whole number for the "44% OFF" badge.
 * Floors rather than rounds: claiming 45% when it is 44.6% is a small lie
 * that a customer can check with a calculator.
 */
export function discountPercent(mrp: number, price: number): number {
  if (mrp <= 0 || price >= mrp) return 0;
  return Math.floor(((mrp - price) / mrp) * 100);
}

// ---------------------------------------------------------------------------
// Tax
// ---------------------------------------------------------------------------

/**
 * §7.1 — displayed prices are TAX-INCLUSIVE.
 *
 * So GST is *extracted* from the price, not added to it:
 *     tax = price × rate / (1 + rate)
 *
 * A ₹500 item at 3% GST is ₹485.44 net + ₹14.56 tax, not ₹500 + ₹15.
 * This is what lets the store register for GST later without changing a
 * single displayed price.
 *
 * Returns 0 while `taxRate` is 0, which is the unregistered launch state.
 */
export function extractTax(inclusivePaise: number, taxRateBp: number): number {
  if (taxRateBp <= 0) return 0;
  return Math.round(
    (inclusivePaise * taxRateBp) / (BASIS_POINTS + taxRateBp),
  );
}

/** The ex-tax portion of a tax-inclusive price. */
export function netOfTax(inclusivePaise: number, taxRateBp: number): number {
  return inclusivePaise - extractTax(inclusivePaise, taxRateBp);
}

/** Basis points to a human string: 300 -> "3%", 1250 -> "12.5%". */
export function formatRate(basisPoints: number): string {
  const percent = basisPoints / 100;
  return `${Number.isInteger(percent) ? percent : percent.toFixed(2)}%`;
}

// ---------------------------------------------------------------------------
// Safety
// ---------------------------------------------------------------------------

/**
 * Guards a value that is about to be written to a money column.
 * Catches NaN, Infinity and accidental floats before they reach the database,
 * where they would be silently truncated.
 */
export function assertPaise(value: number, label = "amount"): number {
  if (!Number.isInteger(value)) {
    throw new Error(
      `${label} must be an integer number of paise, got ${value}`,
    );
  }
  if (!Number.isFinite(value)) {
    throw new Error(`${label} is not a finite number`);
  }
  return value;
}

/** Clamps to zero. Discounts must never make a line negative. */
export function atLeastZero(paise: number): number {
  return paise < 0 ? 0 : paise;
}
