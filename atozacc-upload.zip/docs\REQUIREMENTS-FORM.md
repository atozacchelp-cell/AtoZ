# AtoZacc — Requirement Collection Form

**Project:** AtoZacc — Indian fashion accessories & lifestyle e-commerce
**Status:** Requirement collection (no code written yet)
**Version:** 1.0
**Date raised:** 2026-08-26

---

## How to use this form

- Answer **inline in this file** (easiest — just type after each question), or answer module-by-module in chat.
- `[ ]` = tick one. `[ ] [ ]` on a "select all" question = tick as many as apply.
- **Bold questions are blocking** — I cannot design that part of the system without them.
- Questions marked _(default OK)_ have a sensible default. Write **"default"** and I'll use it.
- If you don't know yet, write **"decide later"** — I'll build it configurable from the admin panel instead of hard-coding it.

**Total: 30 modules.** Modules 1, 4, 7, 9, 10, 11, 12, 24, 26 are the ones that genuinely change the architecture. The rest mostly change configuration.

---

# MODULE 1 — BUSINESS INFORMATION

> Needed for: invoices, GST calculation, legal pages, order numbering, footer, contact.

**1.1 Registered legal entity name**
_(This goes on invoices. Example: "AtoZacc Retail Pvt. Ltd." or "Shreya Enterprises")_

> Answer: Currenlty I dont have any idea i have started yet

**1.2 Is "AtoZacc" the brand/trade name, and is the legal entity name different?**
- [ ] Same — the legal name is AtoZacc
- [ ] Different — legal name is: ______________
- [ ] Not registered yet (sole proprietor / to be decided)

> Answer: same legal name is

**1.3 Business type**
- [ ] A — Sole Proprietorship
- [ ] B — Partnership / LLP
- [ ] C — Private Limited Company
- [ ] D — Not registered yet

> Answer:sole proprietorship

**1.4 GST registration**
- [ ] A — Registered. GSTIN: ______________
- [ ] B — Not registered yet, but will be before launch
- [ ] C — Not registered, and will sell below the GST threshold (no GST on invoices)

> Answer: not registed yet we will take it after some time

**1.5 Business address** (used on invoices and as the "ship from" origin for shipping rates)

| Field | Your answer |
|---|---|
| Building / Street | | Ansal Tower - 38 1324
| Area | | Nehru Place
| City | | Delhi
| State | | New Delhi
| PIN code | | 110080

**1.6 Warehouse / pickup address** — same as above?
- [ ] Same
- [ ] Different: K-2 Sangam Vihar New Delhi - 110080

**1.7 Public contact details** (shown on the website)

| Field | Your answer |
|---|---|
| Support email | | ujjwalakki9633@gmail.com
| Support phone | |8447920965
| WhatsApp number | |8447920965
| Support hours (e.g. Mon–Sat 10am–7pm) | |

**1.8 Bank account for settlements** — do you already have a current account in the business name?
- [ ] Yes  - [no] No  - [ ] In progress

_(I never store bank details in the app — this only tells me whether payment gateway onboarding can proceed.)_

**1.9 Expected scale in the first 6 months** _(this decides hosting size and whether we need caching/queues on day one)_
- [ ] A — Under 20 orders/day, under 200 products
- [ ] B — 20–100 orders/day, 200–2,000 products
- [ ] C — 100–500 orders/day, 2,000–10,000 products
- [ ] D — 500+ orders/day

> Answer:under 20 order/day

**1.10 Target launch date**

> Answer: i dont know exact in september

---

# MODULE 2 — BRAND INFORMATION

> Needed for: design system, logo placement, colour tokens, typography, email templates.

**2.1 Do you have a logo for AtoZacc?**
- [ ] Yes — file available (please share the file; PNG/SVG preferred)
- [ ] No — need one designed
- [ ] Have a rough one, want it refined

> Answer: no i dont have currelty i will paste google drive link in code after that will create

**2.2 Brand colours** — pick one approach:
- [ ] A — I have exact brand colours. Primary: `#______` Secondary: `#______` Accent: `#______`
- [ ] B — I have a *feel* in mind (describe below), you pick the exact palette
- [ ] C — You propose 2–3 palettes and I'll choose

> Answer / describe the feel: think by you side and make it best like light colour not black and all and it should be attractive like attaction ex colours like white red and all

**2.3 Brand personality** — tick up to 3
- [ ] Premium / luxury
- [ ] Youthful & trendy
- [ ] Traditional / ethnic Indian
- [ ] Minimal & clean
- [ ] Bold & colourful
- [ ] Affordable / value-for-money
- [ ] Handcrafted / artisanal,

> Answer: Premium / luxury,Affordable / value-for-money,Youthful & trendy

**2.4 Tagline** _(e.g. "Accessories from A to Z")_
- [ ] I have one: ______________
- [ ] Suggest options for me
- [ ] No tagline

> Answer: think by your side

**2.5 Reference websites you like** _(2–3 links — Indian or international. This is the single most useful input for design.)_

> Answer: i dont have find online

**2.6 Websites you explicitly do NOT want to look like**

> Answer: i dont know take think by your side

**2.7 Language**
- [ ] A — English only (launch)
- [ ] B — English + Hindi
- [ ] C — English now, other languages later _(default OK — I'll build the structure so languages can be added)_

> Answer: english

---

# MODULE 3 — TARGET CUSTOMERS

> Needed for: homepage layout priority, default sort order, mobile vs desktop weighting, price filter ranges.

**3.1 Primary buyer** — tick up to 2
- [ ] Women 18–25
- [ ] Women 25–40
- [ ] Women 40+
- [ ] Men 18–35
- [ ] Parents buying for kids
- [ ] Gift buyers

> Answer: all basically main is new generation.

**3.2 Where do you sell?**
- [ ] A — All India
- [ ] B — Selected states only: ______________
- [ ] C — Local/city only: ______________
- [ ] D — India + international later

> Answer:all india

**3.3 Expected average order value (AOV)**
- [ ] A — Under ₹500
- [ ] B — ₹500–₹1,500
- [ ] C — ₹1,500–₹3,000
- [ ] D — Above ₹3,000

> Answer:500

**3.4 Expected traffic split**
- [ ] A — Mostly mobile (80%+) _(default assumption for Indian D2C)_
- [ ] B — Mixed mobile/desktop
- [ ] C — Don't know

> Answer: dont know think by your

**3.5 Where will traffic come from?** — tick all
- [ ] Instagram
- [ ] WhatsApp broadcast
- [ ] Google search (SEO)
- [ ] Google/Meta paid ads
- [ ] Offline store / word of mouth
- [ ] Influencers / reels

> Answer: tick all

---

# MODULE 4 — PRODUCT CATEGORIES

> Needed for: navigation menu, URL structure, filter behaviour, database category tree.

**4.1 Your brief listed both a gender tree (Women/Men/Girls/Boys/Kids/Unisex) and merchandising groups (Gift, Trending, Seasonal). These behave very differently. Confirm the structure:**

- [ ] **A — Gender is the top level** (recommended)
  `Women > Jewellery > Earrings`. "Trending", "Gift", "Seasonal" become **collections** a product can be tagged into, not categories. A product lives in exactly one category but any number of collections.
  URL: `/women/jewellery/oxidised-earrings`

- [ ] **B — Product type is the top level**
  `Jewellery > Earrings`, with gender as a filter. Better if most products are unisex or gender is a weak signal.
  URL: `/jewellery/earrings/oxidised-earrings`

- [ ] **C — Both, as parallel browsing paths** (most flexible, more work)

> Answer: think by your side

**4.2 Confirm / correct the category tree.** Below is your brief, restated. Edit freely — add, remove, rename.

```
Women      → Jewellery, Bags, Watches, Hair Accessories, Sunglasses,
              Wallets, Belts, Scarves, Fashion Accessories, Other
Men        → Wallets, Belts, Watches, Sunglasses, Bracelets, Bags, Caps, Other
Girls      → ?
Boys       → ?
Kids       → ?
Unisex     → ?
```

**Please fill in the sub-categories for Girls, Boys, Kids, Unisex:**

> Girls:
> Boys:
> Kids:
> Unisex:

**4.3 "Kids" vs "Girls"/"Boys" overlap — how should this work?**
- [ ] A — Kids is a parent; Girls and Boys sit under it
- [ ] B — Kids is for unisex/baby items only; Girls and Boys are separate top-level
- [ ] C — Drop "Kids" entirely, use Girls and Boys only

> Answer:think by your side

**4.4 How deep does the category tree go?**
- [ ] A — 2 levels (Women > Jewellery)
- [ ] B — 3 levels (Women > Jewellery > Earrings) _(default OK)_
- [ ] C — Unlimited depth

> Answer:think by your side

**4.5 Can one product appear in more than one category?**
_(e.g. a unisex watch in both Men > Watches and Women > Watches)_
- [ ] A — One primary category only, plus collections/tags
- [ ] B — Yes, multiple categories

> Answer:think by your side

---

# MODULE 5 — PRODUCT TYPES

> Needed for: which product fields are mandatory, which variant types to build, image aspect ratios.

**5.1 What will you actually sell at launch?** — tick all that apply

| | Category | | Category |
|---|---|---|---|
| [ ] | Imitation / fashion jewellery | [ ] | Oxidised / silver-look jewellery |
| [ ] | Earrings, necklaces, rings, bangles | [ ] | Hair accessories (clips, bands, pins) |
| [ ] | Handbags, slings, clutches | [ ] | Backpacks / laptop bags |
| [ ] | Wallets & purses | [ ] | Belts |
| [ ] | Watches | [ ] | Sunglasses / eyewear |
| [ ] | Caps & hats | [ ] | Scarves / stoles / dupattas |
| [ ] | Socks | [ ] | Phone accessories / covers |
| [ ] | Home décor / lifestyle | [ ] | Stationery / novelty |
| [ ] | Traditional / ethnic items | [ ] | Festive & seasonal (Rakhi, Diwali) |
| [ ] | Gift hampers / combos | [ ] | Personalised / custom items |
| [ ] | Other: ______________ | | |

**5.2 Approximate number of products at launch**
- [ ] Under 50  - [ ] 50–200  - [ ] 200–500  - [ ] 500–2,000  - [ ] 2,000+

> Answer: think by your side

**5.3 Do you sell any product that needs SIZE?** _(rings, bangles, belts, apparel)_
- [ ] Yes — which: ______________
- [ ] No — colour/design variants only

> Answer:think by your side

**5.4 Personalised / custom products** — do you sell any at launch?
- [ ] A — No _(simplest — I'll leave the hooks in place for later)_
- [ ] B — Yes. Customer types text (name/initials) at add-to-cart
- [ ] C — Yes. Customer uploads an image/photo
- [ ] D — Yes, both

If B/C/D: **what is the max characters / accepted file types, and does personalisation add to the price?**

> Answer:think by your side

**5.5 Combo / bundle products** — how do these work?
- [ ] A — A combo is just a normal product with its own SKU and its own stock
- [ ] B — A combo is made of other products; buying it should deduct stock from each component
- [ ] C — No combos at launch

> Answer:think by your side

**5.6 Product images — do you have photos ready?**
- [ ] Yes, professional shots
- [ ] Yes, phone/supplier photos
- [ ] Not yet
- [ ] Mixed

**Approximate images per product:** ______ (typical is 4–6)

**5.7 Product videos** — will you upload them?
- [ ] Yes  - [ ] No  - [ ] Later _(default: build support, leave optional)_

---

# MODULE 6 — PRODUCT ATTRIBUTES

> Needed for: the product form in admin, filters on the shop page, CSV import columns.
> Your brief listed ~45 product fields. A 45-field form is painful to fill for every product, so I need to know which are truly required.

**6.1 Mark each field: R = Required, O = Optional, N = Not needed**

| Field | R / O / N |
|---|---|
| SKU (auto-generated if blank) | |
| Product name | |
| Short description | |
| Full description | |
| Category | |
| Sub-category | |
| Gender | |
| Age group | |
| Brand | |
| Collection | |
| Tags | |
| Main image | |
| Gallery images | |
| Video | |
| Colour | |
| Size | |
| Material | |
| Weight (needed for shipping rates!) | |
| Dimensions | |
| Specifications table | |
| Key features (bullets) | |
| Care instructions | |
| Country of origin | |
| HSN code | |
| GST rate | |
| MRP | |
| Selling price | |
| Cost price (for profit reports) | |
| Stock quantity | |
| Low-stock threshold | |
| SEO title / description / slug | |

**6.2 Do you sell other people's brands, or is everything AtoZacc?**
- [ ] A — Everything is AtoZacc (no brand field needed)
- [ ] B — Multiple brands — brand field and brand filter required
- [ ] C — Mostly unbranded, occasionally branded

> Answer:

**6.3 Which filters must appear on the shop page?** — tick all
- [ ] Price range  - [ ] Category  - [ ] Gender  - [ ] Age group
- [ ] Brand  - [ ] Colour  - [ ] Size  - [ ] Material
- [ ] Rating  - [ ] In stock only  - [ ] Discount %  - [ ] Occasion
- [ ] New arrivals  - [ ] Other: ______________

**6.4 Fixed colour list, or free text per product?**
- [ ] A — Fixed master list I define once (better filters, consistent swatches) _(recommended)_
- [ ] B — Free text per product

> Answer:think by your side

**6.5 If A — list the colours you want** _(e.g. Black, White, Gold, Silver, Rose Gold, Red, Pink, Blue, Green, Maroon, Beige, Multi)_

> Answer:think by your side

---

# MODULE 7 — PRODUCT PRICING

> Needed for: price display, GST calculation, invoice format, discount maths. **Getting GST wrong means wrong invoices, so please be precise here.**

**7.1 Is your displayed selling price GST-inclusive or exclusive?**
- [ ] A — **Inclusive** — customer sees ₹499, and ₹499 is what they pay; GST is extracted from it for the invoice _(standard for Indian B2C, recommended)_
- [ ] B — **Exclusive** — customer sees ₹499 + GST added at checkout

> Answer:think by your side

**7.2 GST rates you deal with** — tick all
- [ ] 0%  - [ ] 3% (real jewellery)  - [ ] 5%  - [ ] 12%  - [ ] 18%  - [ ] 28%
- [ ] Not registered — no GST at all

> Answer:

**7.3 Is the GST rate the same for all products, or does it vary?**
- [ ] A — Same rate for everything: ____%
- [ ] B — Varies by category
- [ ] C — Varies per product

> Answer:

**7.4 Do you know the HSN codes for your products?**
- [ ] Yes  - [ ] No, will get from CA  - [ ] Not applicable (unregistered)

**7.5 How is discount entered in admin?**
- [ ] A — Enter MRP + selling price; discount % is calculated automatically _(recommended)_
- [ ] B — Enter MRP + discount %; selling price is calculated
- [ ] C — Both options available

> Answer:

**7.6 Price rounding on the final cart total**
- [ ] A — Round to nearest rupee _(default OK)_
- [ ] B — Keep paise
- [ ] C — Round up to nearest ₹5 / ₹10

> Answer:

**7.7 Do you need different prices for different customers?** _(wholesale/reseller tier)_
- [ ] A — No, one price for everyone _(default)_
- [ ] B — Yes, a wholesale tier is needed at launch
- [ ] C — Later

> Answer:

**7.8 Currency**
- [ ] INR only _(default)_  - [ ] INR + others later

---

# MODULE 8 — INVENTORY

> Needed for: stock deduction logic, overselling prevention, warehouse structure.

**8.1 Where is stock held?**
- [ ] A — One location _(default — simplest, and multi-warehouse can be added later)_
- [ ] B — Multiple locations from day one: ______________

> Answer:

**8.2 What happens when stock hits zero?**
- [ ] A — Show "Out of Stock", cannot be bought _(default)_
- [ ] B — Allow backorder / pre-order
- [ ] C — Hide the product entirely
- [ ] D — Show it, but with a "Notify me when back" button

> Answer:

**8.3 When should stock be reserved?** _(this is the classic overselling problem)_
- [ ] A — Reserve when the order is **placed and paid** _(default — simple, safe)_
- [ ] B — Reserve when the item is **added to cart**, released after N minutes. N = ____
- [ ] C — Reserve at **checkout start**, released if payment fails

> Answer:

**8.4 For COD orders — deduct stock immediately on order placement?**
- [ ] Yes _(default — recommended, prevents overselling)_
- [ ] No, only when the order is confirmed by your team

> Answer:

**8.5 Do you track cost price / purchase stock for profit reporting?**
- [ ] A — Yes, full stock ledger with purchases and profit reports
- [ ] B — Just current stock quantity, no purchase tracking _(simpler)_

> Answer:

**8.6 Low-stock alert threshold**
- [ ] A — One global number for all products: ______ units _(e.g. 5)_
- [ ] B — Set per product
- [ ] C — Both — global default, overridable per product _(default OK)_

> Answer:

**8.7 Who gets low-stock alerts, and how?**
- [ ] Admin panel notification only _(default)_  - [ ] + Email  - [ ] + WhatsApp

---

# MODULE 9 — PAYMENT

> Needed for: checkout design, payment gateway integration shape, order state machine.

**9.1 Which payment methods at launch?** — tick all
- [ ] UPI (GPay / PhonePe / Paytm)
- [ ] Credit / Debit card
- [ ] Net banking
- [ ] Wallets
- [ ] Cash on Delivery
- [ ] Partial / advance payment (see Module 10)
- [ ] Bank transfer / manual UPI with screenshot upload
- [ ] Store credit / wallet balance

> Answer:

**9.2 Should the customer be able to pay in full online AND choose COD, or is it one or the other?**
- [ ] A — Customer chooses at checkout: full online, COD, or partial
- [ ] B — Online only
- [ ] C — Depends on order value / product (rules in Modules 10 & 11)

> Answer:

**9.3 Do you want to encourage prepaid orders with a discount?**
_(e.g. "Pay online and get ₹50 off" — very common in India to reduce COD returns)_
- [ ] Yes — amount/percent: ______________
- [ ] No
- [ ] Later, make it configurable _(default OK)_

> Answer:

**9.4 Order confirmation timing**
- [ ] A — Order is confirmed automatically the moment payment succeeds _(default)_
- [ ] B — Every order needs manual confirmation by your team first

> Answer:

---

# MODULE 10 — PARTIAL / ADVANCE PAYMENT

> **This is the most business-specific part of your brief and the part I can assume nothing about.** Please answer every question here.
>
> Your example: order ₹2,000 → customer pays ₹500 online → ₹1,500 collected on delivery.

**10.1 Do you need partial payment at launch, or should I build it configurable-but-off?**
- [ ] A — Needed at launch, will use it immediately
- [ ] B — Build it, keep it disabled until I turn it on
- [ ] C — Not needed

> Answer:

**10.2 How is the advance amount calculated?**
- [ ] A — Fixed amount for every order: ₹______
- [ ] B — Percentage of order value: ______%
- [ ] C — Percentage, with a minimum floor: ______% but at least ₹______
- [ ] D — Percentage, with a maximum cap: ______% but not more than ₹______
- [ ] E — Admin sets it per product / per category
- [ ] F — Customer chooses any amount above a minimum of ₹______

> Answer:

**10.3 When is partial payment OFFERED to the customer?** — tick all that apply
- [ ] Always
- [ ] Only when order value is above ₹______
- [ ] Only when order value is below ₹______
- [ ] Only for specific products / categories: ______________
- [ ] Only for specific customers (approved/repeat buyers)
- [ ] Only for specific PIN codes / regions
- [ ] Only when COD is available for that address

> Answer:

**10.4 How is the REMAINING amount collected?** — tick all you'll offer
- [ ] A — Cash on delivery (courier collects the balance)
- [ ] B — Online payment link sent before dispatch (SMS/WhatsApp/email)
- [ ] C — Online payment link sent after delivery
- [ ] D — Manual — your team collects it and marks it paid in admin
- [ ] E — Customer pays from "My Orders" in their account

> Answer:

**10.5 What happens if the customer never pays the remaining amount?**
- [ ] A — Order is held, not dispatched, auto-cancelled after ______ days
- [ ] B — Order is dispatched anyway and balance becomes COD
- [ ] C — Admin decides case by case _(default)_

> Answer:

**10.6 Is the advance amount refundable if the order is cancelled?**
- [ ] A — Fully refundable
- [ ] B — Non-refundable (booking amount)
- [ ] C — Refundable only if cancelled before dispatch _(common)_
- [ ] D — Admin decides per case

> Answer:

**10.7 Should partial-payment orders still be allowed to use coupons?**
- [ ] Yes  - [ ] No  - [ ] Yes, but the coupon applies to the total before advance is calculated

> Answer:

**10.8 On the invoice, what should be shown?**
- [ ] A — Full order value, advance paid, balance due _(recommended)_
- [ ] B — Two separate receipts — one for the advance, one for the balance
- [ ] C — Single invoice generated only after full payment

> Answer:

**10.9 Confirm the payment statuses you want tracked** _(from your brief — remove any you don't need)_
Pending · Processing · Paid · Partially Paid · Failed · Refunded · Partially Refunded · COD Pending · COD Collected

> Answer / edits:

---

# MODULE 11 — CASH ON DELIVERY

**11.1 Offer COD at launch?**
- [ ] Yes  - [ ] No  - [ ] Yes, but restricted (answer below)

> Answer:

**11.2 COD order value limits**
- Minimum order value for COD: ₹______ _(blank = no minimum)_
- Maximum order value for COD: ₹______ _(blank = no maximum)_

**11.3 COD fee charged to the customer**
- [ ] A — No fee
- [ ] B — Flat fee: ₹______
- [ ] C — Percentage: ______%
- [ ] D — Free above ₹______, else ₹______

> Answer:

**11.4 COD restrictions** — tick all that apply
- [ ] Not available for certain PIN codes (I'll provide a list / use courier serviceability)
- [ ] Not available for certain products or categories: ______________
- [ ] Not available for personalised/custom products
- [ ] Not available for first-time customers
- [ ] Blocked for customers with a history of refused deliveries

> Answer:

**11.5 COD order verification** _(reduces fake orders — important in Indian D2C)_
- [ ] A — No verification, order is placed directly
- [ ] B — OTP sent to the mobile number; order confirmed only after OTP _(recommended)_
- [ ] C — Manual phone call confirmation by your team
- [ ] D — WhatsApp confirmation message with confirm/cancel buttons

> Answer:

**11.6 Auto-cancel unverified COD orders after how long?**
- [ ] Don't auto-cancel  - [ ] After ______ hours

---

# MODULE 12 — SHIPPING

> Needed for: cart shipping calculation, PIN-code serviceability, courier integration.

**12.1 Who ships the orders?**
- [ ] A — Courier aggregator (Shiprocket / iThink / Nimbuspost) — one integration, many couriers _(recommended for D2C)_
- [ ] B — Direct courier account (Delhivery / Blue Dart / DTDC / India Post)
- [ ] C — Manual — I book shipments myself and enter tracking numbers into admin
- [ ] D — Own delivery for local orders + courier for the rest
- [ ] E — Not decided yet

> Answer:

**12.2 If you already have an account with a courier/aggregator, which one?**

> Answer:

**12.3 How are shipping charges calculated?**
- [ ] A — Flat rate for all of India: ₹______
- [ ] B — Free shipping above ₹______, else ₹______
- [ ] C — Free shipping on everything (cost built into price)
- [ ] D — By weight — I'll provide slabs
- [ ] E — By zone (local / state / national) — I'll provide rates
- [ ] F — Live rates from the courier API

> Answer:

**12.4 If by weight or zone, fill in your slabs:**

| Zone / Weight | Charge |
|---|---|
| | |
| | |
| | |

**12.5 Free shipping threshold**
- [ ] No free shipping
- [ ] Free above ₹______
- [ ] Free above ₹______ for prepaid only

> Answer:

**12.6 Does free shipping apply to COD orders too?**
- [ ] Yes  - [ ] No, COD always pays shipping  - [ ] Yes, but COD fee still applies

**12.7 Delivery time estimate shown to the customer**
- [ ] A — Fixed text: "______ business days"
- [ ] B — By zone: Local ____ days / Metro ____ days / Rest of India ____ days
- [ ] C — Live from courier API
- [ ] D — Don't show an estimate

> Answer:

**12.8 PIN-code serviceability check on the product page / cart?**
- [ ] A — Yes, check against courier API
- [ ] B — Yes, check against a PIN list I upload
- [ ] C — No check — accept all Indian PIN codes _(default)_

> Answer:

**12.9 Order dispatch cut-off / working days**
- Orders placed before ______ (time) ship the same day
- Non-working days: ______________

**12.10 Confirm the shipping statuses you want** _(from your brief)_
Placed · Confirmed · Processing · Packed · Ready to ship · Shipped · In transit · Out for delivery · Delivered · Failed delivery · Returned · Cancelled

> Answer / edits:

---

# MODULE 13 — RETURNS

**13.1 Do you accept returns?**
- [ ] Yes  - [ ] No  - [ ] Only for damaged/wrong items _(common for jewellery)_

> Answer:

**13.2 Return window**
- [ ] ______ days from delivery _(typical: 7)_
- [ ] No returns

**13.3 Which products are NON-returnable?** — tick all
- [ ] Personalised / customised items
- [ ] Earrings / pierced jewellery (hygiene)
- [ ] Innerwear / socks
- [ ] Sale / clearance items
- [ ] Combo / gift hampers
- [ ] Nothing — everything is returnable
- [ ] Other: ______________

> Answer:

**13.4 How is the returned item collected?**
- [ ] A — Reverse pickup by courier _(you pay)_
- [ ] B — Customer self-ships, you reimburse
- [ ] C — Customer self-ships at their own cost
- [ ] D — Depends on the reason (your fault = reverse pickup; customer's choice = self-ship)

> Answer:

**13.5 Do you offer exchange/replacement as well as refund?**
- [ ] Refund only
- [ ] Exchange only
- [ ] Both — customer chooses
- [ ] Exchange for size issues, refund otherwise

> Answer:

**13.6 Is return approval automatic or manual?**
- [ ] A — Manual — every request reviewed by your team _(recommended)_
- [ ] B — Auto-approved if within window and reason is valid

> Answer:

**13.7 Is an unboxing video required for damage claims?**
- [ ] Yes  - [ ] No  - [ ] Preferred but not mandatory

**13.8 Confirm return reasons** _(from your brief)_
Damaged · Wrong product · Size issue · Not as expected · Missing item · Other

> Answer / edits:

---

# MODULE 14 — REFUNDS

**14.1 Refund methods you'll offer** — tick all
- [ ] Back to original payment method
- [ ] Store credit / wallet
- [ ] Bank transfer (for COD orders — you'll need customer bank details)
- [ ] UPI transfer
- [ ] Replacement instead of money back

> Answer:

**14.2 How are COD orders refunded?** _(there's no original payment method to reverse)_
- [ ] A — Bank transfer — collect account details in the return form
- [ ] B — UPI ID — collect UPI ID in the return form
- [ ] C — Store credit only
- [ ] D — Customer chooses

> Answer:

**14.3 Refund timeline promised to the customer** _(goes into your Refund Policy page)_
- [ ] ______ business days after the return is received and approved _(typical: 5–7)_

**14.4 Is the shipping charge refunded?**
- [ ] A — Yes, full refund including shipping
- [ ] B — No, product value only
- [ ] C — Yes only if the return is our fault (damaged/wrong item)

> Answer:

**14.5 Is the COD fee refunded?**
- [ ] Yes  - [ ] No

**14.6 Do you need partial refunds?** _(refund 1 item out of a 3-item order)_
- [ ] Yes _(default — recommended)_  - [ ] No, whole orders only

**14.7 Who can approve a refund?**
- [ ] A — Any admin
- [ ] B — Only Super Admin
- [ ] C — Any admin below ₹______; Super Admin above that

> Answer:

---

# MODULE 15 — CUSTOMER ACCOUNTS

**15.1 How do customers sign up / log in?** — tick all
- [ ] Mobile number + OTP _(recommended primary for India)_
- [ ] Email + password
- [ ] Google login
- [ ] WhatsApp OTP
- [ ] No accounts at all — guest checkout only

> Answer:

**15.2 Is guest checkout allowed?**
- [ ] A — Yes, no account needed _(recommended — increases conversion)_
- [ ] B — No, account required
- [ ] C — Guest checkout, but an account is auto-created from their mobile number

> Answer:

**15.3 Which OTP/SMS provider?** _(needed for mobile login and COD verification)_
- [ ] MSG91  - [ ] Twilio  - [ ] Fast2SMS  - [ ] Gupshup  - [ ] Don't know — recommend one
- [ ] Already have an account with: ______________

> Answer:

**15.4 Store credit / wallet — needed at launch?**
- [ ] A — Yes, needed (used for refunds and referrals)
- [ ] B — Build it, keep it off
- [ ] C — Not needed

> Answer:

**15.5 Which sections in the customer dashboard?** — tick all
- [ ] Profile  - [ ] Saved addresses  - [ ] My orders  - [ ] Track order
- [ ] Wishlist  - [ ] My reviews  - [ ] Returns  - [ ] Refunds
- [ ] Coupons  - [ ] Wallet  - [ ] Notifications  - [ ] Referrals

> Answer:

**15.6 How many addresses can a customer save?**
- [ ] Unlimited _(default)_  - [ ] Max ______

---

# MODULE 16 — OFFERS & COUPONS

**16.1 Which discount types do you need at launch?** — tick all
- [ ] Percentage off (10% off)
- [ ] Fixed amount off (₹100 off)
- [ ] Free shipping coupon
- [ ] First-order discount
- [ ] Minimum-order discount (₹100 off above ₹999)
- [ ] Category-specific discount
- [ ] Product-specific discount
- [ ] Buy X Get Y / BOGO
- [ ] Combo / bundle pricing
- [ ] Tiered (spend more, save more)
- [ ] Festival / flash sale (time-limited)

> Answer:

**16.2 Can two coupons be used on one order?**
- [ ] A — No, one coupon per order _(default, recommended)_
- [ ] B — Yes, stackable

> Answer:

**16.3 Can a coupon be applied on top of an already-discounted product?**
- [ ] Yes  - [ ] No  - [ ] Configurable per coupon _(default OK)_

**16.4 Confirm the coupon rules you need** — tick all
- [ ] Start / end date
- [ ] Total usage limit
- [ ] Per-customer usage limit
- [ ] Minimum order value
- [ ] Maximum discount cap
- [ ] Restricted to specific products
- [ ] Restricted to specific categories
- [ ] Restricted to specific customers
- [ ] Restricted to first-time customers only
- [ ] Prepaid-only coupon (not valid on COD)

> Answer:

**16.5 Automatic offers without a coupon code?** _(e.g. "Buy 2 Get 1 free" applied automatically)_
- [ ] Yes, needed  - [ ] Coupon codes only _(simpler)_

---

# MODULE 17 — MARKETING

**17.1 Homepage sections — confirm and order them.** Your brief listed everything below. Number them 1, 2, 3… in the order you want, or strike out what you don't want.

| | Section |
|---|---|
| ___ | Hero banner / slider |
| ___ | Category cards |
| ___ | Featured collections |
| ___ | New arrivals |
| ___ | Trending products |
| ___ | Best sellers |
| ___ | Limited-time offers / deal countdown |
| ___ | Discount / promo banners |
| ___ | Combo offers |
| ___ | Gift collection |
| ___ | Seasonal collection |
| ___ | Recommended for you |
| ___ | Recently viewed |
| ___ | Customer reviews |
| ___ | Testimonials |
| ___ | Instagram feed |
| ___ | Newsletter signup |
| ___ | Trust badges (secure payment / easy returns / COD) |

**17.2 How many hero banners, and do you have the artwork?**
- Count: ______
- [ ] Artwork ready  - [ ] Need design help  - [ ] Will use product photos

**17.3 Referral programme — needed at launch?**
- [ ] Yes — reward: ______________  - [ ] Later  - [ ] No

**17.4 Loyalty points — needed at launch?**
- [ ] Yes — earn rate: ______  - [ ] Later  - [ ] No

**17.5 Gift cards — needed at launch?**
- [ ] Yes  - [ ] Later  - [ ] No

**17.6 Exit-intent / entry popup?**
- [ ] Yes (newsletter or discount)  - [ ] No

**17.7 Abandoned cart recovery?** _(high ROI for Indian D2C)_
- [ ] Yes — via: [ ] Email [ ] SMS [ ] WhatsApp
- [ ] Later  - [ ] No

**17.8 Social media handles** _(for footer and Instagram section)*

| Platform | Handle / URL |
|---|---|
| Instagram | |
| Facebook | |
| YouTube | |
| Pinterest | |
| WhatsApp channel | |

---

# MODULE 18 — NOTIFICATIONS

**18.1 Which channels at launch?**

| Channel | Launch | Later | Never |
|---|---|---|---|
| Email | [ ] | [ ] | [ ] |
| SMS | [ ] | [ ] | [ ] |
| WhatsApp | [ ] | [ ] | [ ] |
| On-site / in-app | [ ] | [ ] | [ ] |
| Browser push | [ ] | [ ] | [ ] |

**18.2 Which events trigger a customer notification?** — tick all
- [ ] Order placed  - [ ] Payment received  - [ ] Partial payment received
- [ ] Balance payment reminder  - [ ] Order confirmed  - [ ] Order packed
- [ ] Order shipped (with tracking)  - [ ] Out for delivery  - [ ] Delivered
- [ ] Order cancelled  - [ ] Return requested  - [ ] Return approved
- [ ] Refund initiated  - [ ] Refund completed  - [ ] Back in stock
- [ ] Abandoned cart  - [ ] Promotional offers

> Answer:

**18.3 Which events notify YOU (admin)?** — tick all
- [ ] New order  - [ ] COD order  - [ ] Payment failed  - [ ] Low stock
- [ ] Out of stock  - [ ] Return request  - [ ] New review  - [ ] Daily sales summary

> Answer:

**18.4 Email sending — which provider?**
- [ ] Don't know — recommend one _(I'd suggest Resend or Brevo for India)_
- [ ] Already have: ______________
- [ ] Use my domain email (SMTP): ______________

**18.5 WhatsApp — do you have a WhatsApp Business API account?**
- [ ] Yes, via: ______________
- [ ] No, using a normal WhatsApp Business app (manual)
- [ ] Want to set it up — recommend a provider

**18.6 Sender identity**
- Email "from" name and address: ______________
- SMS sender ID (6 letters, e.g. ATOZAC): ______________

---

# MODULE 19 — ADMIN PANEL

**19.1 Who will use the admin panel?**
- [ ] Just me
- [ ] Me + ______ staff
- [ ] Me + staff + outsourced support

**19.2 How comfortable are the users with computers?**
- [ ] Very — power users are fine
- [ ] Moderate — needs to be simple and clear
- [ ] Low — needs to be extremely simple, mobile-friendly

> Answer:

**19.3 Will admin work be done on mobile?**
- [ ] A — Yes, frequently (order processing on phone) — admin must be fully responsive
- [ ] B — Occasionally
- [ ] C — Desktop only

> Answer:

**19.4 Confirm the admin menu.** Strike out anything you don't need at launch.

Dashboard · Products · Categories · Brands · Inventory · Orders · Customers · Payments · Refunds · Coupons · Offers · Shipping · Reviews · Banners · Content/Pages · Reports · Notifications · Settings · Users & Roles · Audit Logs

> Answer / edits:

**19.5 Bulk product upload via CSV/Excel — needed at launch?**
- [ ] A — Yes, essential (I have many products to load)
- [ ] B — Nice to have
- [ ] C — Not needed, I'll add products one by one

> Answer:

**19.6 Invoice format**
- [ ] A — Standard GST tax invoice _(default if GST registered)_
- [ ] B — Simple bill of supply (no GST)
- [ ] C — I'll provide a format / sample

**19.7 Order number format**
- [ ] A — `ATZ-0001`, `ATZ-0002`…
- [ ] B — `ATZ-2026-0001` (year included)
- [ ] C — Date-based: `ATZ-260826-001`
- [ ] D — Other: ______________

> Answer:

---

# MODULE 20 — ADMIN ROLES

**20.1 Which roles do you need at launch?** — tick all
- [ ] Super Admin (full access)
- [ ] Admin
- [ ] Manager
- [ ] Inventory Manager
- [ ] Order Manager / Packing staff
- [ ] Content Manager
- [ ] Customer Support
- [ ] Just Super Admin for now — add roles later

> Answer:

**20.2 For each role you ticked, what should they NOT be able to do?**
_(Most important: who can see cost price and profit? Who can issue refunds? Who can delete products?)_

| Role | Must NOT be able to |
|---|---|
| | |
| | |
| | |

**20.3 Should admin actions be logged?** _(who changed which price, who cancelled which order)_
- [ ] Yes, full audit log _(recommended once you have staff)_
- [ ] Only for sensitive actions (refunds, price changes, deletions)
- [ ] Not needed

> Answer:

**20.4 Two-factor authentication for admin login?**
- [ ] Yes  - [ ] No  - [ ] Only for Super Admin

---

# MODULE 21 — REPORTS

**21.1 Which reports do you actually need at launch?** — tick all
- [ ] Sales summary  - [ ] Order report  - [ ] Product-wise sales
- [ ] Category-wise sales  - [ ] Customer report  - [ ] Inventory / stock report
- [ ] Payment report  - [ ] COD report  - [ ] Refund report
- [ ] Return report  - [ ] Coupon usage  - [ ] Profit report (needs cost price)
- [ ] GST / tax report (for filing)  - [ ] Abandoned cart report

> Answer:

**21.2 Export formats needed**
- [ ] Excel / CSV  - [ ] PDF  - [ ] Both

**21.3 Do you need a scheduled report emailed to you?**
- [ ] Daily sales summary  - [ ] Weekly  - [ ] Monthly  - [ ] No

**21.4 Does your CA/accountant need a specific export format?**
- [ ] Yes — format: ______________  - [ ] No  - [ ] Will check

---

# MODULE 22 — SEO

**22.1 URL structure preference**
- [ ] A — `/women/jewellery/oxidised-earrings` (full category path) _(as in your brief)_
- [ ] B — `/product/oxidised-earrings` (flat, easier to maintain when a product changes category)
- [ ] C — `/p/oxidised-earrings-12345`

> Answer:

**22.2 Is there an existing website or domain with SEO to preserve?**
- [ ] No, brand new
- [ ] Yes: ______________ (I'll need redirects)

**22.3 Do you sell on marketplaces already?** _(Amazon/Flipkart/Meesho — affects product data reuse and duplicate content)_
- [ ] Yes: ______________  - [ ] No

**22.4 Blog / content section — needed?**
- [ ] Yes, at launch  - [ ] Later _(default — I'll leave the structure)_  - [ ] No

**22.5 Do you want Google Shopping / Merchant Center feed?**
- [ ] Yes  - [ ] Later  - [ ] No

**22.6 Who writes product descriptions and SEO text?**
- [ ] I will  - [ ] Need help  - [ ] Auto-generate a first draft, I'll edit

---

# MODULE 23 — WEBSITE DESIGN

**23.1 Overall look** — pick one
- [ ] A — Premium minimal (lots of white space, big images, thin type)
- [ ] B — Vibrant Indian D2C (colour, badges, urgency, dense offers)
- [ ] C — Ethnic / traditional (warm tones, ornamental detail)
- [ ] D — Youthful street/trendy (bold type, high contrast)

> Answer:

**23.2 Light or dark?**
- [ ] Light _(default for fashion e-commerce)_  - [ ] Dark  - [ ] Both, user-toggleable

**23.3 Product card style**
- [ ] A — Image only, details on hover (clean)
- [ ] B — Image + name + price + rating + discount badge _(recommended for conversion)_
- [ ] C — Image + name + price + quick-add button

> Answer:

**23.4 Which badges do you want?** — tick all
- [ ] NEW  - [ ] TRENDING  - [ ] BESTSELLER  - [ ] SALE
- [ ] LIMITED  - [ ] HOT  - [ ] EXCLUSIVE  - [ ] Only X left
- [ ] Custom: ______________

**23.5 Product image aspect ratio** _(this must be consistent — decide now)_
- [ ] A — Square 1:1 _(safest for accessories/jewellery)_
- [ ] B — Portrait 3:4
- [ ] C — Portrait 4:5

> Answer:

**23.6 Features to include** — tick all
- [ ] Quick view modal  - [ ] Quick add to cart  - [ ] Wishlist heart on cards
- [ ] Product comparison  - [ ] Image zoom  - [ ] 360° view
- [ ] Size chart popup  - [ ] Recently viewed  - [ ] "Frequently bought together"
- [ ] Sticky mobile bottom nav  - [ ] Sticky add-to-cart bar on mobile
- [ ] Live chat / WhatsApp float button

> Answer:

**23.7 Product comparison — your brief listed it. Confirm:**
- [ ] A — Include it
- [ ] B — Skip it _(honest note: comparison is rarely used for fashion accessories; it's built for electronics. I'd suggest skipping unless you have a specific reason.)_

> Answer:

---

# MODULE 24 — DOMAIN & HOSTING

**24.1 Domain**
- [ ] A — Already own: ______________
- [ ] B — Need to buy — preferred: `atozacc.com` / `atozacc.in` / other: ______
- [ ] C — Not decided

> Answer:

**24.2 Do you have a hosting preference or budget?**
- [ ] A — Cheapest that works reliably
- [ ] B — Managed / low-maintenance, willing to pay more
- [ ] C — Already have hosting: ______________
- [ ] D — No preference, you recommend

> Answer:

**24.3 Rough monthly budget for hosting + services** _(gateway fees excluded)_
- [ ] Under ₹1,000  - [ ] ₹1,000–₹3,000  - [ ] ₹3,000–₹10,000  - [ ] Above ₹10,000

**24.4 Who will maintain the site after launch?**
- [ ] A — Me, with minimal technical knowledge → needs to be very low-maintenance
- [ ] B — I have/will hire a developer
- [ ] C — Not decided

> Answer:

**24.5 Do you need email on your domain?** _(e.g. `support@atozacc.com`)_
- [ ] Yes  - [ ] Already have  - [ ] No

---

# MODULE 25 — DATABASE & TECHNOLOGY

> **This is the one section where I need to give you a recommendation rather than ask blindly**, because the honest answer depends on your scale and maintenance capacity (Modules 1.9 and 24.4).

**25.1 Build approach** — this is the biggest single decision:

- [ ] **A — Custom build (Next.js + PostgreSQL)**
  Full control, exactly the partial-payment logic you described, no monthly platform fee, everything in your brief is buildable.
  _Trade-off: you own maintenance, security updates and gateway/courier integration work._

- [ ] **B — Shopify + custom theme**
  Fastest to launch, payments/shipping/apps solved.
  _Trade-off: ₹2,000–7,000/month, and your custom partial-payment rules are hard or impossible to do properly._

- [ ] **C — WooCommerce (WordPress)**
  Cheap, huge plugin ecosystem, many Indian payment/COD plugins.
  _Trade-off: plugin sprawl, slower, more security upkeep._

- [ ] **D — You recommend, I'll trust the call**

> Answer:

_My recommendation, for the record: **A (Next.js + PostgreSQL)** — because Module 10 (partial payment with configurable rules per product/customer/order-value) and Module 8 (stock ledger) are custom business logic that platforms fight you on. But if launching in under a month matters more than exact rules, B is the honest choice._

**25.2 Database preference**
- [ ] PostgreSQL _(recommended)_  - [ ] MySQL  - [ ] MongoDB  - [ ] No preference

**25.3 Where should product images be stored?**
- [ ] A — Cloud storage + CDN (Cloudinary / S3) _(recommended — fast on Indian mobile networks)_
- [ ] B — On the server
- [ ] C — No preference

**25.4 Do you need a mobile app later?**
- [ ] Yes, within a year → affects architecture (I'd build an API-first backend)
- [ ] Maybe later
- [ ] No

> Answer:

**25.5 Data backup expectations**
- [ ] Daily automated backups _(recommended)_  - [ ] Weekly  - [ ] No preference

---

# MODULE 26 — PAYMENT GATEWAY

**26.1 Which gateway?**
- [ ] A — Razorpay _(most common, best docs, supports partial payments well)_
- [ ] B — Cashfree
- [ ] C — PhonePe PG
- [ ] D — PayU
- [ ] E — Don't know — recommend one
- [ ] F — Already have an account with: ______________

> Answer:

**26.2 Gateway account status**
- [ ] Account active with API keys ready
- [ ] Account created, KYC pending
- [ ] Not created yet

**26.3 Documents ready for gateway KYC?** _(PAN, GST, bank proof, address proof — gateways won't activate live mode without these)_
- [ ] All ready  - [ ] Partially  - [ ] Not started

**26.4 Do you want a payment-links feature?** _(essential if you chose 10.4-B or 10.4-C — sending balance payment links)_
- [ ] Yes  - [ ] No  - [ ] Depends on Module 10 answers

**26.5 Should I build a "test mode" so you can place fake orders before going live?**
- [ ] Yes _(recommended)_  - [ ] No

---

# MODULE 27 — SHIPPING PROVIDER

**27.1 Aggregator/courier account status** _(if you picked 12.1-A or B)_
- [ ] Active with API access
- [ ] Account created, not verified
- [ ] Not created
- [ ] Not applicable (manual shipping)

**27.2 Should the site auto-create a shipment when an order is confirmed?**
- [ ] A — Yes, fully automatic
- [ ] B — No, I'll click "Create shipment" per order _(recommended at low volume)_
- [ ] C — Manual — I book outside and paste the tracking number

> Answer:

**27.3 Should customers track their order on your website, or be sent to the courier's site?**
- [ ] A — On my website (tracking pulled from the courier API) _(better experience)_
- [ ] B — Link out to the courier's tracking page _(simpler)_

> Answer:

**27.4 Do you need shipping labels / packing slips printed from admin?**
- [ ] Yes  - [ ] No, the courier panel handles it

---

# MODULE 28 — LEGAL & POLICY

**28.1 Do you have policy text written for these pages?**

| Page | Have text | Need drafted |
|---|---|---|
| Shipping Policy | [ ] | [ ] |
| Return Policy | [ ] | [ ] |
| Refund Policy | [ ] | [ ] |
| Cancellation Policy | [ ] | [ ] |
| Privacy Policy | [ ] | [ ] |
| Terms & Conditions | [ ] | [ ] |
| About Us | [ ] | [ ] |

_Note: I can draft these from your answers as a starting point, but they should be reviewed by a lawyer or your CA before going live. I'm not able to give legal advice._

**28.2 Order cancellation by customer — allowed until when?**
- [ ] A — Until the order is packed
- [ ] B — Until the order is shipped
- [ ] C — Not allowed once placed
- [ ] D — Within ______ hours of placing

> Answer:

**28.3 Is there a cancellation charge?**
- [ ] No  - [ ] Yes: ______________

**28.4 Cookie consent banner needed?**
- [ ] Yes  - [ ] No  - [ ] Simple notice only

---

# MODULE 29 — ANALYTICS

**29.1 Which tools?** — tick all
- [ ] Google Analytics 4
- [ ] Google Tag Manager
- [ ] Meta / Facebook Pixel
- [ ] Google Search Console
- [ ] Google Merchant Center
- [ ] Microsoft Clarity / Hotjar (heatmaps & session recording)
- [ ] None for now

> Answer:

**29.2 Do you already have accounts / IDs for any of these?**

> Answer:

**29.3 Do you plan to run paid ads?**
- [ ] Yes, from launch → I'll add conversion tracking properly
- [ ] Later
- [ ] No

> Answer:

---

# MODULE 30 — FUTURE FEATURES

**30.1 Which of these might you actually want within 12–18 months?** — tick all that apply.
_(I'm not building these. I only need to know so the architecture doesn't block them.)_

- [ ] Mobile app (Android/iOS)
- [ ] Multi-vendor marketplace (other sellers list on AtoZacc)
- [ ] Multiple warehouses
- [ ] Multiple languages
- [ ] Multiple currencies / international shipping
- [ ] Loyalty points
- [ ] Referral programme
- [ ] Affiliate / influencer programme
- [ ] AI product recommendations
- [ ] AI chatbot support
- [ ] WhatsApp commerce (catalogue + ordering in WhatsApp)
- [ ] Instagram Shopping
- [ ] Google Shopping
- [ ] CRM integration
- [ ] ERP / accounting integration (Tally, Zoho Books)
- [ ] Physical store / POS integration
- [ ] Subscription boxes

> Answer:

**30.2 Of everything ticked above, which ONE matters most?**

> Answer:

---

# FINAL SECTION — PRIORITY & PHASING

**F.1 What is your single most important goal?**
- [ ] A — Launch as fast as possible, even with fewer features
- [ ] B — Launch complete, take the time it needs
- [ ] C — Launch a strong storefront first, add admin depth after

> Answer:

**F.2 If we had to launch with only these, which would you cut to Phase 2?** — tick what can wait
- [ ] Partial payment
- [ ] Product comparison
- [ ] Wallet / store credit
- [ ] Reviews with photo upload
- [ ] Referral / loyalty
- [ ] Advanced reports
- [ ] WhatsApp notifications
- [ ] Bulk CSV import
- [ ] Multi-role admin
- [ ] Gift cards
- [ ] Nothing — I want it all at launch

> Answer:

**F.3 Anything in your original brief you've changed your mind about, or anything missing?**

> Answer:

---

## What happens after you fill this in

1. You return this file (or answer module-by-module in chat).
2. I produce the **Final System Requirements Document** — feature list, sitemap, customer journey, admin journey, database schema, order/payment/partial-payment/COD/shipping/return flows, roles & permissions, notification matrix, integration list, security requirements, SEO plan, tech architecture, deployment plan and scalability roadmap.
3. You review and approve it.
4. **Only then** does development begin.

---

## Minimum answers needed to start

If filling in all 30 modules at once is too much, these are the ones that block everything else:

| Module | Question |
|---|---|
| 1.4, 1.9 | GST status, expected scale |
| 4.1 | Category structure (gender-first vs type-first) |
| 7.1, 7.2 | GST inclusive/exclusive, GST rates |
| 9.1 | Payment methods |
| 10.1, 10.2, 10.4 | Partial payment — needed? how calculated? how is the balance collected? |
| 11.1 | COD yes/no |
| 12.1, 12.3 | Who ships, how shipping is charged |
| 24.4 | Who maintains the site after launch |
| 25.1 | Build approach (custom vs Shopify vs Woo) |
| 26.1 | Payment gateway |
| F.1 | Speed vs completeness |

Answer just these 12 and I can produce a draft architecture; the rest can be filled in as we go.
