import { categoriesVersion, type SeedCategory } from "@/data/catalog";
import { allCategories, allCollections, categoryIndex } from "@/lib/taxonomy";

/**
 * Turning what someone typed in the sheet into a category.
 *
 * The strict version of this — exact slug, or exact name — rejected a third
 * of a real catalogue, and every rejection was a reasonable thing to have
 * written. Someone looking at a category called "Bangles & Bracelets" types
 * `women-bangles-bracelets`; someone with a sling bag types
 * `women-slingbags`. Being right about the code and unhelpful about the
 * product is the wrong trade for a shop owner filling in a spreadsheet.
 *
 * So this matches in widening rings, and stops at the first ring that gives
 * exactly one answer. Ambiguity is never guessed at — two equally good
 * candidates means the row is reported rather than filed somewhere arbitrary.
 */

const GENDERS = ["women", "men", "kids", "unisex"] as const;

/** Words people use for a gender that are not the gender's own name. */
const GENDER_ALIASES: Record<string, string> = {
  baby: "kids",
  babies: "kids",
  girl: "kids",
  girls: "kids",
  boy: "kids",
  boys: "kids",
  ladies: "women",
  woman: "women",
  womens: "women",
  female: "women",
  man: "men",
  mens: "men",
  male: "men",
  everyone: "unisex",
  all: "unisex",
};

/**
 * Genuine synonyms — different words for the same thing, which no amount of
 * prefix matching will bridge. Kept small on purpose: this list is for words
 * that mean the same product, not for spelling mistakes.
 */
const WORD_ALIASES: Record<string, string> = {
  backpack: "bags",
  backpacks: "bags",
  handbag: "handbags",
  purse: "wallets",
  purses: "wallets",
  stole: "scarves",
  stoles: "scarves",
  dupatta: "scarves",
  shades: "sunglasses",
  goggles: "sunglasses",
  goggle: "sunglasses",
  specs: "sunglasses",
  watch: "watches",
  bracelet: "bracelets",
  kada: "bangles",
  payal: "anklets",
  jhumka: "earrings",
  jhumkas: "earrings",
  studs: "earrings",
  pendant: "necklaces",
  pendants: "necklaces",
  chain: "necklaces",
  chains: "necklaces",
  clip: "hair",
  clips: "hair",
  scrunchie: "hair",
  scrunchies: "hair",
  hat: "caps",
  hats: "caps",
  tee: "tshirts",
  tees: "tshirts",
  tshirt: "tshirts",
  "t": "tshirts",
  cover: "phone",
  covers: "phone",
  case: "phone",
  cases: "phone",
};

const tokenise = (raw: string): string[] =>
  raw
    .toLowerCase()
    .replace(/&/g, " and ")
    .split(/[^a-z0-9]+/)
    .filter(Boolean)
    // "and" carries no meaning once "Bangles & Bracelets" is split up, and
    // keeping it would stop that name matching `women-bangles-bracelets`.
    .filter((t) => t !== "and" && t !== "the");

/** Every word that identifies a category, for matching against. */
function categoryTokens(c: SeedCategory): string[] {
  const fromName = tokenise(c.name);
  // Slug minus its gender prefix: "women-hair" -> ["hair"]
  const fromSlug = tokenise(c.slug).filter(
    (t) => !GENDERS.includes(t as (typeof GENDERS)[number]),
  );
  return [...new Set([...fromName, ...fromSlug])];
}

/**
 * Rebuilt whenever a category is added, so a code created by one sync is
 * matchable by the next. A snapshot taken at import time would keep rejecting
 * the very category it had just created.
 */
let indexCache: { at: number; index: { cat: SeedCategory; tokens: string[] }[] } | null =
  null;

function index() {
  // allCategories() may load new ones from disk and bump the version, so the
  // list must be fetched BEFORE the version is read or the cache gets
  // stamped with a number that is already out of date.
  const cats = allCategories();
  const v = categoriesVersion();
  if (indexCache && indexCache.at === v) return indexCache.index;
  const built = cats.map((c) => ({ cat: c, tokens: categoryTokens(c) }));
  indexCache = { at: v, index: built };
  return built;
}

/** Applies synonym replacement to each token. */
const canonical = (tokens: string[]): string[] =>
  tokens.map((t) => WORD_ALIASES[t] ?? t);

/**
 * Splits what was typed into a gender (if any) and the remaining words.
 * `genderHint` is the sheet's separate gender column, used when the category
 * cell carries no gender of its own.
 */
function split(raw: string, genderHint: string) {
  const tokens = tokenise(raw);
  let gender: string | undefined;
  const rest: string[] = [];

  for (const t of tokens) {
    const asGender = GENDERS.includes(t as (typeof GENDERS)[number])
      ? t
      : GENDER_ALIASES[t];
    // Only the FIRST gender word is treated as a gender. "women-mens-combo"
    // is not a thing, and a later one is more likely part of the name.
    if (asGender && !gender) gender = asGender;
    else rest.push(t);
  }

  if (!gender) {
    const hint = tokenise(genderHint)[0];
    gender = hint
      ? GENDERS.includes(hint as (typeof GENDERS)[number])
        ? hint
        : GENDER_ALIASES[hint]
      : undefined;
  }

  return { gender, rest: canonical(rest) };
}

type Scored = { cat: SeedCategory; score: number };

/**
 * Ranks candidates so ambiguity can be detected rather than silently
 * resolved. Score favours, in order: matching more of the typed words, and
 * matching them EARLIER — `women-anklets-toe-rings` matches both Anklets and
 * Rings, and Anklets is right because it is what the person wrote first.
 */
function score(tokens: string[], catTokens: string[]): number {
  let matched = 0;
  let firstAt = Infinity;

  for (const [i, t] of tokens.entries()) {
    const hit = catTokens.some(
      (ct) =>
        ct === t ||
        // Prefix only, never suffix: "slingbags" should find Slings, not Bags.
        (t.length >= 4 && t.startsWith(ct.replace(/s$/, ""))) ||
        (ct.length >= 4 && ct.startsWith(t.replace(/s$/, ""))),
    );
    if (hit) {
      matched++;
      firstAt = Math.min(firstAt, i);
    }
  }

  if (matched === 0) return 0;
  return matched * 100 - firstAt * 10 - catTokens.length;
}

function best(tokens: string[], pool: ReturnType<typeof index>): SeedCategory | null {
  const scored: Scored[] = pool
    .map(({ cat, tokens: ct }) => ({ cat, score: score(tokens, ct) }))
    .filter((s) => s.score > 0)
    .sort((a, b) => b.score - a.score);

  if (scored.length === 0) return null;
  // A clear winner only. A tie means we genuinely cannot tell.
  if (scored.length > 1 && scored[1].score === scored[0].score) return null;
  return scored[0].cat;
}

export function resolveCategory(raw: string, genderHint = ""): string | null {
  const value = (raw ?? "").trim().toLowerCase();
  if (!value) return null;

  // 1. Exactly the code we publish.
  if (categoryIndex().has(value)) return value;

  const { gender, rest } = split(value, genderHint);
  if (rest.length === 0) return null;

  // 2. Within the stated gender — the common case, and the safest.
  if (gender) {
    const inGender = index().filter((e) => e.cat.gender === gender);
    const hit = best(rest, inGender);
    if (hit) return hit.slug;
  }

  // 3. Across every gender. Reached when no gender was given at all
  //    (`keychains`), or when the gender given has no such category.
  return best(rest, index())?.slug ?? null;
}

/**
 * The closest code we can offer when nothing matched, so the error can say
 * "did you mean" instead of only "not recognised".
 */
export function suggestCategory(raw: string, genderHint = ""): string | null {
  const { gender, rest } = split((raw ?? "").toLowerCase(), genderHint);
  if (rest.length === 0) return null;

  const pool = gender ? index().filter((e) => e.cat.gender === gender) : index();
  const scored = (pool.length ? pool : index())
    .map(({ cat, tokens }) => ({ cat, score: score(rest, tokens) }))
    .filter((s) => s.score > 0)
    .sort((a, b) => b.score - a.score);

  return scored[0]?.cat.slug ?? null;
}

/**
 * Resolves a collection the same forgiving way as a category.
 *
 * Collections were previously taken from the sheet verbatim and never
 * checked, which is the worst of both worlds: `festive-gifting` was accepted,
 * matched no collection, and the product quietly appeared on no page at all.
 * A typo here failed more silently than a typo in the category column.
 */
export function resolveCollection(raw: string): string | null {
  const value = (raw ?? "").trim().toLowerCase();
  if (!value) return null;
  if (allCollections().some((c) => c.slug === value)) return value;

  // Gender words are noise here — "women-accessories" is not a collection
  // because of "women", and stripping it gives the real word a chance.
  const tokens = canonical(
    tokenise(value).filter(
      (t) => !GENDERS.includes(t as (typeof GENDERS)[number]) && !GENDER_ALIASES[t],
    ),
  );
  if (tokens.length === 0) return null;

  const scored = allCollections().map((c) => ({
    slug: c.slug,
    score: score(tokens, [...tokenise(c.slug), ...tokenise(c.name)]),
  }))
    .filter((s) => s.score > 0)
    .sort((a, b) => b.score - a.score);

  if (scored.length === 0) return null;
  if (scored.length > 1 && scored[1].score === scored[0].score) return null;
  return scored[0].slug;
}

/**
 * Catches the commonest wrong answer: a collection typed into the category
 * column. "Gifts", "Festive" and "Combo Offers" all read like categories, but
 * they cut across the tree rather than sitting in it — a gift hamper is still
 * jewellery. Saying so is more use than listing forty codes the person has
 * already failed to find the right one in.
 */
export function collectionHint(raw: string): string | null {
  const tokens = tokenise(raw ?? "");
  if (tokens.length === 0) return null;

  for (const col of allCollections()) {
    const colTokens = tokenise(col.slug).concat(tokenise(col.name));
    const hit = tokens.some((t) =>
      colTokens.some(
        (ct) =>
          ct === t ||
          (t.length >= 4 && ct.startsWith(t.replace(/s$/, ""))) ||
          (ct.length >= 4 && t.startsWith(ct.replace(/s$/, ""))),
      ),
    );
    if (hit) return col.slug;
  }
  return null;
}
