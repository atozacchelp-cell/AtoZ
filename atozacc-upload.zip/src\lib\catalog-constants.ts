export type SortKey =
  | "relevance"
  | "newest"
  | "price-asc"
  | "price-desc"
  | "discount"
  | "bestselling"
  | "rating";

export const SORT_OPTIONS: { key: SortKey; label: string }[] = [
  { key: "relevance", label: "Relevance" },
  { key: "newest", label: "Newest first" },
  { key: "price-asc", label: "Price: low to high" },
  { key: "price-desc", label: "Price: high to low" },
  { key: "discount", label: "Biggest discount" },
  { key: "bestselling", label: "Best selling" },
  { key: "rating", label: "Highest rated" },
];
