"use client";

import { useState } from "react";

/**
 * PIN-code delivery check.
 *
 * At launch every Indian PIN is serviceable, so this validates the format and
 * quotes the zone estimate rather than calling a courier API. It exists now
 * because it answers the question that stops a purchase — "will it even reach
 * me?" — and because the courier integration later swaps the lookup without
 * touching the UI.
 */

type Result = { ok: true; days: string; cod: boolean } | { ok: false; message: string };

/** Rough zone banding by PIN prefix, matching the published estimates. */
function estimate(pincode: string): { days: string } {
  const p = Number(pincode.slice(0, 3));
  if (p >= 110 && p <= 140) return { days: "1–2 days" }; // Delhi NCR
  const metros = [400, 560, 600, 700, 500, 411, 380];
  if (metros.some((m) => Math.abs(p - m) <= 3)) return { days: "3–4 days" };
  return { days: "4–7 days" };
}

export function PincodeCheck({
  codAllowed,
  freeShippingLabel,
}: {
  codAllowed: boolean;
  freeShippingLabel: string;
}) {
  const [pincode, setPincode] = useState("");
  const [result, setResult] = useState<Result | null>(null);

  function check() {
    // Indian PINs are six digits and never start with 0.
    if (!/^[1-9][0-9]{5}$/.test(pincode)) {
      setResult({ ok: false, message: "Enter a valid 6-digit PIN code." });
      return;
    }
    setResult({ ok: true, days: estimate(pincode).days, cod: codAllowed });
  }

  return (
    <div className="mt-6 rounded-[var(--radius-card)] border border-line bg-surface p-4">
      <label
        htmlFor="pincode"
        className="text-[12px] font-bold uppercase tracking-[0.09em] text-ink-mute"
      >
        Check delivery
      </label>
      <div className="mt-2 flex gap-2">
        <input
          id="pincode"
          inputMode="numeric"
          maxLength={6}
          value={pincode}
          onChange={(e) => {
            setPincode(e.target.value.replace(/\D/g, ""));
            setResult(null);
          }}
          onKeyDown={(e) => e.key === "Enter" && check()}
          placeholder="Enter PIN code"
          className="tnum min-w-0 flex-1 rounded-[var(--radius-card)] border border-line bg-canvas px-3 py-2 text-[13.5px] focus:border-brand focus:outline-none"
        />
        <button
          type="button"
          onClick={check}
          className="shrink-0 rounded-[var(--radius-card)] border border-ink px-4 py-2 text-[13px] font-semibold transition-colors hover:bg-ink hover:text-canvas"
        >
          Check
        </button>
      </div>

      {result && (
        <p role="status" className="mt-2.5 text-[12.5px]">
          {result.ok ? (
            <span className="text-ink-mid">
              <span className="font-semibold text-success">Delivers in {result.days}</span>
              {" · "}
              {result.cod ? "Cash on delivery available" : "Prepaid only"}
              {" · "}Free over {freeShippingLabel}
            </span>
          ) : (
            <span className="text-brand">{result.message}</span>
          )}
        </p>
      )}
    </div>
  );
}
