import Link from "next/link";

export const metadata = { title: "Page not found" };

export default function NotFound() {
  return (
    <main className="mx-auto flex min-h-[70vh] w-full max-w-lg flex-col items-center justify-center px-5 text-center">
      <p className="text-[11px] font-bold uppercase tracking-[0.16em] text-brand">404</p>
      <h1 className="mt-3 font-display text-[34px] leading-tight">
        We can&apos;t find that page
      </h1>
      <p className="mt-3 text-[14px] text-ink-mid">
        The link may be old, or the product may have sold out and been retired.
      </p>

      <div className="mt-7 flex flex-wrap justify-center gap-3">
        <Link
          href="/"
          className="rounded-[var(--radius-card)] bg-brand px-5 py-3 text-[14px] font-semibold text-white hover:bg-brand-deep"
        >
          Go home
        </Link>
        <Link
          href="/shop"
          className="rounded-[var(--radius-card)] border border-ink px-5 py-3 text-[14px] font-semibold hover:bg-ink hover:text-canvas"
        >
          Browse products
        </Link>
      </div>

      <nav className="mt-10 flex flex-wrap justify-center gap-x-5 gap-y-2 text-[13px] text-ink-mute">
        <Link href="/women" className="hover:text-brand">Women</Link>
        <Link href="/men" className="hover:text-brand">Men</Link>
        <Link href="/kids" className="hover:text-brand">Kids</Link>
        <Link href="/track-order" className="hover:text-brand">Track order</Link>
        <Link href="/contact" className="hover:text-brand">Contact</Link>
      </nav>
    </main>
  );
}
