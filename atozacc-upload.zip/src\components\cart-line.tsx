"use client";

import Image from "next/image";
import Link from "next/link";
import { useTransition } from "react";

import { removeFromCart, toggleSaveForLater, updateCartQty } from "@/lib/actions";
import { formatINR } from "@/lib/money";
import type { PricedLine } from "@/lib/pricing";

export function CartLine({ line, saved }: { line: PricedLine; saved?: boolean }) {
  const [pending, start] = useTransition();

  const run = (fn: (fd: FormData) => Promise<unknown>, extra?: Record<string, string>) => {
    const fd = new FormData();
    fd.set("key", line.variantKey);
    for (const [k, v] of Object.entries(extra ?? {})) fd.set(k, v);
    start(() => void fn(fd));
  };

  const [, colour, size] = line.variantKey.split("|");
  const variantLabel = [colour, size].filter(Boolean).join(" · ");

  return (
    <li
      className={`flex gap-4 border-b border-line py-5 ${pending ? "opacity-55" : ""}`}
    >
      <Link
        href={line.href}
        className="relative h-24 w-24 shrink-0 overflow-hidden rounded-[var(--radius-card)] border border-line bg-surface"
      >
        <Image src={line.imageUrl} alt={line.name} fill sizes="96px" className="object-cover" />
      </Link>

      <div className="min-w-0 flex-1">
        <Link
          href={line.href}
          className="line-clamp-2 text-[13.5px] font-semibold leading-snug hover:text-brand"
        >
          {line.name}
        </Link>

        {variantLabel && (
          <p className="mt-0.5 text-[12px] text-ink-mute">{variantLabel}</p>
        )}

        {line.outOfStock && (
          <p className="mt-1 text-[12px] font-semibold text-brand">
            Out of stock — remove to continue
          </p>
        )}

        <div className="tnum mt-1.5 flex items-baseline gap-2">
          <span className="text-[14px] font-bold">{formatINR(line.unitPrice)}</span>
          {line.unitMrp > line.unitPrice && (
            <span className="text-[12px] text-ink-mute line-through">
              {formatINR(line.unitMrp)}
            </span>
          )}
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-x-4 gap-y-2">
          {!saved && !line.outOfStock && (
            <div className="flex items-center rounded-[var(--radius-card)] border border-line">
              <button
                type="button"
                aria-label="Decrease quantity"
                disabled={pending}
                onClick={() => run(updateCartQty, { qty: String(line.qty - 1) })}
                className="grid h-8 w-8 place-items-center text-ink-mid hover:text-brand"
              >
                −
              </button>
              <span className="tnum w-8 text-center text-[13px] font-semibold">{line.qty}</span>
              <button
                type="button"
                aria-label="Increase quantity"
                disabled={pending || line.qty >= 10}
                onClick={() => run(updateCartQty, { qty: String(line.qty + 1) })}
                className="grid h-8 w-8 place-items-center text-ink-mid hover:text-brand disabled:opacity-30"
              >
                +
              </button>
            </div>
          )}

          <button
            type="button"
            disabled={pending}
            onClick={() => run(toggleSaveForLater)}
            className="text-[12.5px] font-semibold text-ink-mute hover:text-brand"
          >
            {saved ? "Move to cart" : "Save for later"}
          </button>

          <button
            type="button"
            disabled={pending}
            onClick={() => run(removeFromCart)}
            className="text-[12.5px] font-semibold text-ink-mute hover:text-brand"
          >
            Remove
          </button>
        </div>
      </div>

      <div className="tnum shrink-0 text-right">
        <p className="text-[14px] font-bold">{formatINR(line.lineTotal)}</p>
        {line.lineMrpTotal > line.lineTotal && (
          <p className="mt-0.5 text-[11.5px] text-success">
            −{formatINR(line.lineMrpTotal - line.lineTotal)}
          </p>
        )}
      </div>
    </li>
  );
}
