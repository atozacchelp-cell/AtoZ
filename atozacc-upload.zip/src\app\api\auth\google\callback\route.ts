import { cookies } from "next/headers";
import { NextResponse, type NextRequest } from "next/server";

import { createSessionToken, SESSION_COOKIE, sessionCookieOptions } from "@/lib/auth";
import { exchangeCode, googleConfigured, STATE_COOKIE } from "@/lib/google-auth";
import { upsertGoogleUser } from "@/lib/users";

/** Sends the browser back to sign-in with a reason, never a stack trace. */
function fail(req: NextRequest, reason: string) {
  const url = new URL("/signin", req.nextUrl.origin);
  url.searchParams.set("error", reason);
  return NextResponse.redirect(url);
}

export async function GET(req: NextRequest) {
  if (!googleConfigured()) return fail(req, "google-not-configured");

  const jar = await cookies();
  const stored = jar.get(STATE_COOKIE)?.value ?? "";
  // One use only, whatever happens next.
  jar.set(STATE_COOKIE, "", { path: "/", maxAge: 0 });

  const [expectedState, next = "/account"] = stored.split("|");
  const givenState = req.nextUrl.searchParams.get("state") ?? "";

  // The CSRF check. A callback that did not start at our own /api/auth/google
  // has no matching cookie and is refused.
  if (!expectedState || expectedState !== givenState) {
    return fail(req, "state-mismatch");
  }

  if (req.nextUrl.searchParams.get("error")) return fail(req, "cancelled");

  const code = req.nextUrl.searchParams.get("code");
  if (!code) return fail(req, "no-code");

  const profile = await exchangeCode(code, req.nextUrl.origin);
  if (!profile) return fail(req, "exchange-failed");

  // An unverified Google address must never sign anyone in: accounts here are
  // matched by email, so accepting one would let somebody register a Google
  // account with a victim's address and inherit their order history.
  if (!profile.emailVerified) return fail(req, "email-not-verified");

  const user = await upsertGoogleUser({
    googleId: profile.googleId,
    email: profile.email,
    name: profile.name,
  });

  const dest = next.startsWith("/") && !next.startsWith("//") ? next : "/account";
  const res = NextResponse.redirect(new URL(dest, req.nextUrl.origin));
  res.cookies.set(SESSION_COOKIE, createSessionToken(user.id), sessionCookieOptions());
  return res;
}
