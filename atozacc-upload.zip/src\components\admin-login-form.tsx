"use client";

import { useActionState } from "react";

import { claimAdmin, signIn, type AuthState } from "@/lib/auth-actions";

/**
 * The admin sign-in and first-run setup form.
 *
 * One component for both because they differ only in which action they post
 * to and what the button says — keeping them apart would mean two sets of
 * field names to drift out of step.
 */
export function AdminLoginForm({
  mode,
  next,
}: {
  mode: "signin" | "setup";
  next: string;
}) {
  const action = mode === "setup" ? claimAdmin : signIn;
  const [state, formAction, pending] = useActionState<AuthState, FormData>(
    action,
    {},
  );

  return (
    <form action={formAction} className="mt-6">
      <input type="hidden" name="next" value={next} />

      {mode === "setup" && (
        <Field
          label="Your name"
          name="name"
          type="text"
          autoComplete="name"
          placeholder="Ujjwal Kumar Jha"
        />
      )}

      <Field
        label="Email"
        name="email"
        type="email"
        required
        autoComplete="username"
        placeholder="you@example.com"
      />

      <Field
        label="Password"
        name="password"
        type="password"
        required
        // Tells a password manager to offer a new strong password on setup,
        // and the saved one on sign-in.
        autoComplete={mode === "setup" ? "new-password" : "current-password"}
        placeholder={mode === "setup" ? "At least 12 characters" : ""}
      />

      {state.error && (
        <p
          role="alert"
          className="mt-4 rounded-[var(--radius-card)] border border-brand bg-blush px-3.5 py-2.5 text-[12.5px] text-brand-deep"
        >
          {state.error}
        </p>
      )}

      <button
        type="submit"
        disabled={pending}
        className="mt-5 w-full rounded-[var(--radius-card)] bg-brand px-5 py-3 text-[14px] font-semibold text-white hover:bg-brand-deep disabled:opacity-60"
      >
        {pending
          ? "Please wait…"
          : mode === "setup"
            ? "Create admin account"
            : "Sign in"}
      </button>

      {mode === "setup" && (
        <p className="mt-3 text-[11.5px] text-ink-mute">
          Use a password you do not use anywhere else, and save it in your
          password manager. There is no reset link yet — losing it means
          editing a file on the server.
        </p>
      )}
    </form>
  );
}

function Field({
  label,
  ...props
}: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="mt-4 block first:mt-0">
      <span className="text-[11.5px] font-bold uppercase tracking-[0.09em] text-ink-mute">
        {label}
      </span>
      <input
        {...props}
        className="mt-1 w-full rounded-[var(--radius-card)] border border-line bg-surface px-3 py-2.5 text-[13.5px] focus:border-brand focus:bg-canvas focus:outline-none"
      />
    </label>
  );
}
