import { MobileNav } from "@/components/mobile-nav";
import { SiteFooter } from "@/components/site-footer";
import { SiteHeader } from "@/components/site-header";

/**
 * Storefront chrome. The admin panel sits outside this group so it does not
 * inherit the shop header, footer or bottom navigation.
 */
export default function ShopLayout({ children }: LayoutProps<"/">) {
  return (
    <>
      <SiteHeader />
      {/* Bottom padding clears the sticky mobile nav. */}
      <div className="flex-1 pb-20 lg:pb-0">{children}</div>
      <SiteFooter />
      <MobileNav />
    </>
  );
}
