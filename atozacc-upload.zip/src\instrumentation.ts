/**
 * Runs once when the server starts.
 *
 * Its only job is to start the Google Sheet timer, so an automatic sync
 * survives a restart without anyone opening the admin panel. The import is
 * dynamic and guarded, because this file is also evaluated in the Edge
 * runtime, where the file system the sync writes to does not exist.
 */
export async function register(): Promise<void> {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;

  // Categories the sheet created must be back in memory before the first
  // request, or a page for one of them 404s until something else loads them.
  const { loadStoredCategories, loadStoredCollections } = await import(
    "@/lib/category-store"
  );
  await loadStoredCategories();
  await loadStoredCollections();

  const { startAutoSync } = await import("@/lib/auto-sync");
  await startAutoSync();
}
