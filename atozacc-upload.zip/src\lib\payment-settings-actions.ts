"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";

import { normaliseImageUrl } from "@/lib/google";
import { saveSettings } from "@/lib/settings";
import { isValidUpiId } from "@/lib/upi";

export type PaymentSettingsState = { ok?: boolean; error?: string };

const Schema = z.object({
  onlinePaymentMode: z.enum(["upi", "off"]),
  upiId: z.string().trim().max(80),
  upiPayeeName: z.string().trim().max(60),
  upiQrImageUrl: z.string().trim().max(500),
  codEnabled: z.string().optional(),
  prepaidDiscountEnabled: z.string().optional(),
});

export async function updatePaymentSettings(
  _prev: PaymentSettingsState,
  formData: FormData,
): Promise<PaymentSettingsState> {
  const parsed = Schema.safeParse({
    onlinePaymentMode: formData.get("onlinePaymentMode") ?? "upi",
    upiId: formData.get("upiId") ?? "",
    upiPayeeName: formData.get("upiPayeeName") ?? "",
    upiQrImageUrl: formData.get("upiQrImageUrl") ?? "",
    codEnabled: formData.get("codEnabled") ?? undefined,
    prepaidDiscountEnabled: formData.get("prepaidDiscountEnabled") ?? undefined,
  });

  if (!parsed.success) {
    return { error: "Those settings were not valid." };
  }

  const d = parsed.data;

  // A malformed UPI id produces a QR that silently pays nobody, so it is
  // refused here rather than discovered by a customer.
  if (d.onlinePaymentMode === "upi" && !isValidUpiId(d.upiId)) {
    return {
      error:
        "That UPI ID does not look right. It should look like yourname@okhdfcbank or 9876543210@ybl.",
    };
  }

  if (d.onlinePaymentMode === "off" && d.codEnabled !== "on") {
    return {
      error:
        "Switching online payment off while cash on delivery is also off would leave customers no way to pay.",
    };
  }

  await saveSettings({
    onlinePaymentMode: d.onlinePaymentMode,
    upiId: d.upiId,
    upiPayeeName: d.upiPayeeName || "AtoZacc",
    upiQrImageUrl: d.upiQrImageUrl ? normaliseImageUrl(d.upiQrImageUrl) : "",
    onlinePaymentEnabled: d.onlinePaymentMode === "upi",
    codEnabled: d.codEnabled === "on",
    prepaidDiscountEnabled: d.prepaidDiscountEnabled === "on",
  });

  revalidatePath("/", "layout");
  return { ok: true };
}
