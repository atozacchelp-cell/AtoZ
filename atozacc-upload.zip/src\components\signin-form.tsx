"use client";

import { useActionState, useState } from "react";

import { signIn, signUp, type AuthState } from "@/lib/auth-actions";

/**
 * Customer sign-in and sign-up, with Google alongside.
 *
 * Google sits above the email form because it is the path most people will
 * take on a phone — no password to invent, no password to forget, and no
 * password for this shop to be responsible for storing.
 */
export function SignInForm({
  next,
  googleEnabled,
}: {
  next: string;
  googleEnabled: boolean;
}) {
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [state, action, pending] = useActionState<AuthState, FormData>(
    mode === "signin" ? signIn : signUp,
    {},
  );

  return (
    <div className="mt-6">
      {googleEnabled && (
        <>
          {/* A plain link, not a form post: this begins a redirect flow and
              has nothing to submit. */}
          <a
            href={`/api/auth/google?next=${encodeURIComponent(next)}`}
            className="flex w-full items-center justify-center gap-3 rounded-[var(--radius-card)] border border-line bg-canvas px-5 py-3 text-[14px] font-semibold transition-colors hover:border-ink"
          >
            <GoogleMark />
            Continue with Google
          </a>

          <div className="my-5 flex items-center gap-3 text-[11.5px] uppercase tracking-[0.1em] text-ink-mute">
            <span className="h-px flex-1 bg-line" />
            or
            <span className="h-px flex-1 bg-line" />
          </div>
        </>
      )}

      <div className="flex gap-1 rounded-[var(--radius-card)] bg-surface p-1">
        <Tab active={mode === "signin"} onClick={() => setMode("signin")}>
          Sign in
        </Tab>
        <Tab active={mode === "signup"} onClick={() => setMode("signup")}>
          Create account
        </Tab>
      </div>

      {/* Remounted when the mode changes, so a failed sign-in message does
          not linger over the sign-up form. */}
      <form key={mode} action={action} className="mt-5">
        <input type="hidden" name="next" value={next} />

        {mode === "signup" && (
          <Field label="Your name" name="name" type="text" autoComplete="name" />
        )}

        <Field
          label="Email"
          name="email"
          type="email"
          required
          autoComplete="username"
          placeholder="you@example.com"
        />

        <Field
          label="Password"
          name="password"
          type="password"
          required
          autoComplete={mode === "signup" ? "new-password" : "current-password"}
          placeholder={mode === "signup" ? "At least 8 characters" : ""}
        />

        {state.error && (
          <p
            role="alert"
            className="mt-4 rounded-[var(--radius-card)] border border-brand bg-blush px-3.5 py-2.5 text-[12.5px] text-brand-deep"
          >
            {state.error}
          </p>
        )}

        <button
          type="submit"
          disabled={pending}
          className="mt-5 w-full rounded-[var(--radius-card)] bg-brand px-5 py-3 text-[14px] font-semibold text-white hover:bg-brand-deep disabled:opacity-60"
        >
          {pending
            ? "Please wait…"
            : mode === "signin"
              ? "Sign in"
              : "Create account"}
        </button>
      </form>
    </div>
  );
}

function Tab({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={`flex-1 rounded-[calc(var(--radius-card)-2px)] py-2 text-[13px] font-semibold transition-colors ${
        active ? "bg-canvas text-ink shadow-sm" : "text-ink-mute hover:text-ink"
      }`}
    >
      {children}
    </button>
  );
}

function Field({
  label,
  ...props
}: { label: string } & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="mt-4 block first:mt-0">
      <span className="text-[11.5px] font-bold uppercase tracking-[0.09em] text-ink-mute">
        {label}
      </span>
      <input
        {...props}
        className="mt-1 w-full rounded-[var(--radius-card)] border border-line bg-surface px-3 py-2.5 text-[13.5px] focus:border-brand focus:bg-canvas focus:outline-none"
      />
    </label>
  );
}

function GoogleMark() {
  return (
    <svg width="17" height="17" viewBox="0 0 48 48" aria-hidden>
      <path
        fill="#4285F4"
        d="M45.1 24.5c0-1.6-.1-2.8-.4-4H24v7.3h12.1c-.2 2-1.6 5-4.5 7l-.1.3 6.5 5 .5.1c4.1-3.8 6.6-9.4 6.6-15.7"
      />
      <path
        fill="#34A853"
        d="M24 46c5.9 0 10.9-2 14.5-5.3l-6.9-5.4c-1.8 1.3-4.3 2.2-7.6 2.2-5.8 0-10.7-3.8-12.5-9.1l-.3.02-6.8 5.2-.1.3C4 41.1 13.3 46 24 46"
      />
      <path
        fill="#FBBC05"
        d="M11.5 28.4c-.5-1.4-.8-2.9-.8-4.4s.3-3 .7-4.4v-.3l-6.9-5.3-.2.1C2.8 17 2 20.4 2 24s.8 7 2.3 10z"
      />
      <path
        fill="#EB4335"
        d="M24 10.4c4.1 0 6.9 1.8 8.5 3.3l6.2-6C34.9 4.1 29.9 2 24 2 13.3 2 4 8.9 4.3 14l7.2 5.6c1.8-5.3 6.7-9.2 12.5-9.2"
      />
    </svg>
  );
}
