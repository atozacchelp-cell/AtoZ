import Link from "next/link";
import { notFound } from "next/navigation";

import { PageHeader } from "@/components/admin-ui";
import { ProductForm } from "@/components/product-form";
import { allCategories } from "@/lib/taxonomy";
import { productHref } from "@/lib/catalog";
import { removeProduct } from "@/lib/product-actions";
import { findProductBySku } from "@/lib/product-store";

export const metadata = { title: "Edit product", robots: { index: false } };

export default async function EditProductPage({
  params,
}: {
  params: Promise<{ sku: string }>;
}) {
  const { sku } = await params;
  const product = await findProductBySku(decodeURIComponent(sku));
  if (!product) notFound();

  return (
    <>
      <Link
        href="/admin/products"
        className="text-[12.5px] font-semibold text-ink-mute hover:text-brand"
      >
        ← Products
      </Link>

      <div className="mt-2 flex flex-wrap items-end justify-between gap-3">
        <PageHeader title="Edit product" subtitle={product.name} />
        <div className="mb-6 flex gap-2">
          <Link
            href={productHref(product)}
            className="rounded-[var(--radius-card)] border border-line px-3 py-2 text-[12.5px] font-semibold hover:border-brand hover:text-brand"
          >
            View in shop ↗
          </Link>
          <form action={removeProduct}>
            <input type="hidden" name="sku" value={product.sku} />
            <button
              type="submit"
              className="rounded-[var(--radius-card)] border border-line px-3 py-2 text-[12.5px] font-semibold text-ink-mute hover:border-brand hover:text-brand"
            >
              Delete
            </button>
          </form>
        </div>
      </div>

      <ProductForm categories={allCategories()} product={product} />
    </>
  );
}
