"use client";

import { useEffect, useState, useTransition } from "react";

import { toggleWishlist } from "@/lib/actions";
import { cn } from "@/lib/cn";

/**
 * The save-for-later heart on a product card.
 *
 * It reads its own initial state from the wishlist cookie on mount rather than
 * being told by the server. Every listing, rail and search result would
 * otherwise have to thread the saved-slug list down to each card, and a card
 * that renders in a dozen places should not make a dozen callers responsible
 * for one boolean.
 *
 * The cost is one frame where a saved item shows unsaved. That is the right
 * trade against the alternative — rendering it filled on the server and having
 * React tear it back down at hydration, which is a visible flicker on the
 * items the customer cares about most.
 */
export function WishlistHeart({
  slug,
  className,
}: {
  slug: string;
  className?: string;
}) {
  const [saved, setSaved] = useState(false);
  const [pending, start] = useTransition();

  useEffect(() => {
    setSaved(readWishlistCookie().includes(slug));
  }, [slug]);

  function toggle(e: React.MouseEvent) {
    // The card is a link. Without this, saving an item navigates away from
    // the grid the customer is still browsing.
    e.preventDefault();
    e.stopPropagation();

    const next = !saved;
    setSaved(next); // optimistic: the tap must feel instant on a phone

    const fd = new FormData();
    fd.set("slug", slug);
    start(async () => {
      const res = await toggleWishlist(fd);
      // Put it back if the server disagreed, so the heart never lies about
      // what was actually saved.
      if (!res.ok) setSaved(!next);
    });
  }

  return (
    <button
      type="button"
      onClick={toggle}
      aria-pressed={saved}
      aria-label={saved ? "Remove from wishlist" : "Save to wishlist"}
      className={cn(
        "absolute right-2 top-2 z-10 grid h-9 w-9 place-items-center rounded-full",
        "bg-canvas/90 backdrop-blur-sm transition-colors",
        // 36px is below the 44px touch target guideline, so the tap area is
        // widened past the visible circle rather than the circle being grown
        // into the photograph.
        "after:absolute after:-inset-1 after:content-['']",
        saved ? "text-brand" : "text-ink-mute hover:text-brand",
        pending && "opacity-70",
        className,
      )}
    >
      <svg
        width="16"
        height="16"
        viewBox="0 0 24 24"
        fill={saved ? "currentColor" : "none"}
        stroke="currentColor"
        strokeWidth="2"
        strokeLinecap="round"
        strokeLinejoin="round"
        aria-hidden
        className={cn("transition-transform", saved && "scale-110")}
      >
        <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1L12 21l7.7-7.7 1.1-1a5.5 5.5 0 0 0 0-7.8z" />
      </svg>
    </button>
  );
}

/**
 * The wishlist cookie is deliberately not httpOnly so the header badge can
 * count it without a round trip; this reads the same value.
 */
function readWishlistCookie(): string[] {
  try {
    const raw = document.cookie
      .split("; ")
      .find((c) => c.startsWith("atz_wishlist="))
      ?.slice("atz_wishlist=".length);
    if (!raw) return [];
    const parsed = JSON.parse(decodeURIComponent(raw));
    return Array.isArray(parsed) ? parsed.filter((s) => typeof s === "string") : [];
  } catch {
    return [];
  }
}
