import Link from "next/link";

import { getGenders } from "@/lib/catalog";
import { getSettings } from "@/lib/settings";
import { getContent } from "@/lib/site-content";

export async function SiteFooter() {
  const [settings, content] = await Promise.all([getSettings(), getContent()]);
  const genders = getGenders();
  const year = new Date().getFullYear();

  return (
    <footer className="mt-20 border-t border-line bg-surface">
      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6">
        {/* Newsletter */}
        <div className="mb-12 rounded-[var(--radius-card)] border border-line-firm bg-canvas p-6 sm:p-8">
          <div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <h2 className="font-display text-xl">{content.newsletterHeading}</h2>
              <p className="mt-1 max-w-md text-[13px] text-ink-mute">
                {content.newsletterBody}
              </p>
            </div>
            <form className="flex w-full max-w-sm gap-2">
              <label htmlFor="newsletter" className="sr-only">
                Email address
              </label>
              <input
                id="newsletter"
                type="email"
                required
                placeholder="you@email.com"
                className="min-w-0 flex-1 rounded-[var(--radius-card)] border border-line bg-surface px-3 py-2.5 text-[13px] focus:border-brand focus:bg-canvas focus:outline-none"
              />
              <button
                type="submit"
                className="shrink-0 rounded-[var(--radius-card)] bg-ink px-4 py-2.5 text-[13px] font-semibold text-canvas transition-colors hover:bg-brand"
              >
                Subscribe
              </button>
            </form>
          </div>
        </div>

        <div className="grid grid-cols-2 gap-8 sm:grid-cols-3 lg:grid-cols-5">
          <div className="col-span-2 sm:col-span-3 lg:col-span-1">
            <span className="font-display text-2xl font-semibold">AtoZacc</span>
            <p className="mt-2 max-w-xs text-[13px] text-ink-mute">
              {content.footerAbout}
            </p>
            <div className="mt-4 flex gap-2">
              <Social label="Instagram" d="M12 2.2c3.2 0 3.6 0 4.9.1 1.2.1 1.8.2 2.2.4.6.2 1 .5 1.4.9.4.4.7.8.9 1.4.2.4.4 1 .4 2.2.1 1.3.1 1.7.1 4.9s0 3.6-.1 4.9c0 1.2-.2 1.8-.4 2.2-.2.6-.5 1-.9 1.4-.4.4-.8.7-1.4.9-.4.2-1 .4-2.2.4-1.3.1-1.7.1-4.9.1s-3.6 0-4.9-.1c-1.2 0-1.8-.2-2.2-.4a3.9 3.9 0 0 1-1.4-.9 3.9 3.9 0 0 1-.9-1.4c-.2-.4-.4-1-.4-2.2C2.2 15.6 2.2 15.2 2.2 12s0-3.6.1-4.9c0-1.2.2-1.8.4-2.2.2-.6.5-1 .9-1.4.4-.4.8-.7 1.4-.9.4-.2 1-.4 2.2-.4C8.4 2.2 8.8 2.2 12 2.2zm0 3.4a6.4 6.4 0 1 0 0 12.8 6.4 6.4 0 0 0 0-12.8zm0 10.6a4.2 4.2 0 1 1 0-8.4 4.2 4.2 0 0 1 0 8.4zm8.2-10.9a1.5 1.5 0 1 1-3 0 1.5 1.5 0 0 1 3 0z" />
              <Social label="WhatsApp" d="M12 2a10 10 0 0 0-8.6 15L2 22l5.2-1.4A10 10 0 1 0 12 2zm5.8 14.2c-.2.7-1.4 1.3-2 1.4-.5.1-1.1.1-1.8-.1-.4-.1-1-.3-1.7-.6-3-1.3-4.9-4.3-5-4.5-.2-.2-1.2-1.6-1.2-3s.7-2.1 1-2.4c.2-.3.5-.4.7-.4h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.4 0 .5l-.3.4-.4.4c-.1.1-.3.3-.1.6.2.3.8 1.3 1.7 2.1 1.2 1 2.1 1.4 2.4 1.5.3.1.5.1.6 0l.9-1c.2-.2.4-.2.6-.1l2 .9c.2.1.4.2.4.3.1.2.1.6 0 1.2z" />
            </div>
          </div>

          <FooterCol title="Shop">
            {genders.map((g) => (
              <FooterLink key={g.slug} href={`/${g.slug}`}>
                {g.name}
              </FooterLink>
            ))}
            <FooterLink href="/shop">All Products</FooterLink>
            <FooterLink href="/new-arrivals">New Arrivals</FooterLink>
            <FooterLink href="/bestsellers">Bestsellers</FooterLink>
          </FooterCol>

          <FooterCol title="Collections">
            <FooterLink href="/trending">Trending</FooterLink>
            <FooterLink href="/offers">Offers</FooterLink>
            <FooterLink href="/collections/gift-collection">Gift Collection</FooterLink>
            <FooterLink href="/collections/combo-offers">Combo Offers</FooterLink>
            <FooterLink href="/collections/festive">Festive Edit</FooterLink>
            <FooterLink href="/collections/under-499">Under ₹499</FooterLink>
          </FooterCol>

          <FooterCol title="Help">
            <FooterLink href="/track-order">Track Order</FooterLink>
            <FooterLink href="/contact">Contact Us</FooterLink>
            <FooterLink href="/faq">FAQ</FooterLink>
            <FooterLink href="/policy/shipping">Shipping Policy</FooterLink>
            <FooterLink href="/policy/returns">Return Policy</FooterLink>
            <FooterLink href="/policy/refunds">Refund Policy</FooterLink>
          </FooterCol>

          <FooterCol title="Company">
            <FooterLink href="/about">About Us</FooterLink>
            <FooterLink href="/policy/cancellation">Cancellation Policy</FooterLink>
            <FooterLink href="/policy/privacy">Privacy Policy</FooterLink>
            <FooterLink href="/policy/terms">Terms &amp; Conditions</FooterLink>
          </FooterCol>
        </div>

        <div className="mt-10 flex flex-col gap-3 border-t border-line pt-6 text-[12.5px] text-ink-mute sm:flex-row sm:items-center sm:justify-between">
          <p>© {year} AtoZacc. All rights reserved.</p>
          <p className="flex flex-wrap items-center gap-x-4 gap-y-1">
            <span>{settings.supportEmail}</span>
            <span>{settings.supportPhone}</span>
            <span>{settings.supportHours}</span>
          </p>
        </div>
      </div>
    </footer>
  );
}

function FooterCol({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div>
      <h3 className="mb-3 font-sans text-[11px] font-bold uppercase tracking-[0.11em] text-ink">
        {title}
      </h3>
      <ul className="space-y-1.5">{children}</ul>
    </div>
  );
}

function FooterLink({ href, children }: { href: string; children: React.ReactNode }) {
  return (
    <li>
      <Link href={href} className="text-[13px] text-ink-mute transition-colors hover:text-brand">
        {children}
      </Link>
    </li>
  );
}

function Social({ label, d }: { label: string; d: string }) {
  return (
    <span
      title={label}
      className="grid h-8 w-8 place-items-center rounded-full border border-line text-ink-mute"
    >
      <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor" aria-hidden>
        <path d={d} />
      </svg>
      <span className="sr-only">{label}</span>
    </span>
  );
}
