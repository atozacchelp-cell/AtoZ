import { type ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";

/** Merges class names, with later Tailwind utilities winning over earlier. */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
