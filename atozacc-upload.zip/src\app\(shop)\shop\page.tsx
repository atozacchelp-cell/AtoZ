import { ProductListing, type SearchParamsShape } from "@/components/product-listing";

export const metadata = {
  title: "All Products",
  description: "Browse every AtoZacc accessory for women, men and kids.",
};

export default async function Page({
  searchParams,
}: {
  searchParams: Promise<SearchParamsShape>;
}) {
  const sp = await searchParams;
  return (
    <ProductListing
      title={"All Products"}
      description={"Every piece in the AtoZacc catalogue — jewellery, bags, watches, wallets and everyday accessories."}
      breadcrumbs={[{ label: "All Products" }]}
      searchParams={sp}
      baseFilters={{}}
    />
  );
}
