"use client";

import { useRouter } from "next/navigation";
import { useState, useTransition } from "react";

import { addToCart, toggleWishlist } from "@/lib/actions";
import { cn } from "@/lib/cn";
import { isFreeSize, type SizeStock } from "@/lib/sizes";

/**
 * Variant selection, quantity and add-to-cart.
 *
 * The form posts identity only — slug, colour, size, qty. Price is never sent
 * from here and never trusted from here; the server re-reads it.
 */
export function AddToCartForm({
  slug,
  colours,
  sizes,
  sizeStock,
  outOfStock,
  stock,
  inWishlist,
}: {
  slug: string;
  colours: string[];
  sizes: string[];
  /** Units per size, for garments. Absent means `stock` covers the product. */
  sizeStock?: SizeStock;
  outOfStock: boolean;
  stock: number;
  inWishlist: boolean;
}) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();

  // "Free Size" is not a decision, so it is chosen for the customer. A real
  // size is: pre-selecting one is how people end up with a medium they did not
  // want, so nothing is selected until they pick.
  const needsChoice = sizes.length > 1 || (sizes.length === 1 && !isFreeSize(sizes));

  const [colour, setColour] = useState(colours[0] ?? "");
  const [size, setSize] = useState(needsChoice ? "" : (sizes[0] ?? ""));
  const [qty, setQty] = useState(1);
  const [toast, setToast] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [saved, setSaved] = useState(inWishlist);

  // Stock follows the chosen size once there is per-size stock to follow.
  const sizeAvailable = (s: string) => (sizeStock ? (sizeStock[s] ?? 0) : stock);
  const availableNow = sizeStock && size ? sizeAvailable(size) : stock;

  const mustPickSize = needsChoice && !size;
  const soldOut = outOfStock || (!mustPickSize && availableNow <= 0);
  const maxQty = Math.min(10, Math.max(1, availableNow));

  function choose(next: string) {
    setSize(next);
    setError(null);
    // A quantity picked for a size with eight left must not survive a switch
    // to one with two.
    setQty((q) => Math.min(q, Math.max(1, sizeStock ? (sizeStock[next] ?? 1) : stock)));
  }

  function submit(then: "stay" | "checkout") {
    if (mustPickSize) {
      setError("Choose a size first");
      return;
    }

    const fd = new FormData();
    fd.set("slug", slug);
    if (colour) fd.set("colour", colour);
    if (size) fd.set("size", size);
    fd.set("qty", String(qty));

    startTransition(async () => {
      const res = await addToCart(fd);
      if (res.ok) {
        setError(null);
        setToast(res.message ?? null);
        if (then === "checkout") router.push("/cart");
        else router.refresh();
      } else {
        setToast(null);
        setError(res.message ?? "Could not add this to your cart");
      }
    });
  }

  function save() {
    const fd = new FormData();
    fd.set("slug", slug);
    startTransition(async () => {
      const res = await toggleWishlist(fd);
      if (res.ok) {
        setSaved((s) => !s);
        setToast(res.message ?? null);
      }
    });
  }

  return (
    <div className="mt-6">
      {colours.length > 1 && (
        <Options
          label="Colour"
          value={colour}
          options={colours.map((c) => ({ value: c }))}
          onChange={setColour}
        />
      )}

      {needsChoice && (
        <Options
          label="Size"
          value={size}
          placeholder="Select"
          options={sizes.map((s) => ({
            value: s,
            // Sold-out sizes stay visible and struck through. Hiding them
            // makes a half-stocked product look like it never had that size.
            disabled: sizeStock ? sizeAvailable(s) <= 0 : false,
            note:
              sizeStock && sizeAvailable(s) > 0 && sizeAvailable(s) <= 3
                ? `${sizeAvailable(s)} left`
                : undefined,
          }))}
          onChange={choose}
        />
      )}

      {!soldOut && !mustPickSize && (
        <div className="mt-5 flex items-center gap-3">
          <span className="text-[12px] font-bold uppercase tracking-[0.09em] text-ink-mute">
            Qty
          </span>
          <div className="flex items-center rounded-[var(--radius-card)] border border-line">
            <StepButton
              label="Decrease quantity"
              disabled={qty <= 1}
              onClick={() => setQty((q) => Math.max(1, q - 1))}
            >
              −
            </StepButton>
            <span className="tnum w-10 text-center text-[14px] font-semibold">{qty}</span>
            <StepButton
              label="Increase quantity"
              disabled={qty >= maxQty}
              onClick={() => setQty((q) => Math.min(maxQty, q + 1))}
            >
              +
            </StepButton>
          </div>
          {availableNow <= 5 && availableNow > 0 && (
            <span className="text-[12px] font-semibold text-warning">
              Only {availableNow} left{size ? ` in ${size}` : ""}
            </span>
          )}
        </div>
      )}

      <div className="mt-6 flex flex-wrap gap-3">
        <button
          type="button"
          disabled={soldOut || pending}
          onClick={() => submit("stay")}
          className={cn(
            "flex-1 rounded-[var(--radius-card)] border border-ink px-6 py-3.5 text-[14.5px] font-semibold transition-colors sm:flex-none sm:px-8",
            soldOut
              ? "cursor-not-allowed border-line text-ink-mute"
              : "bg-canvas text-ink hover:bg-ink hover:text-canvas",
          )}
        >
          {soldOut
            ? size
              ? `${size} is sold out`
              : "Out of stock"
            : pending
              ? "Adding…"
              : "Add to cart"}
        </button>

        <button
          type="button"
          disabled={soldOut || pending}
          onClick={() => submit("checkout")}
          className={cn(
            "flex-1 rounded-[var(--radius-card)] px-6 py-3.5 text-[14.5px] font-semibold text-white transition-colors sm:flex-none sm:px-8",
            soldOut ? "cursor-not-allowed bg-line-firm" : "bg-brand hover:bg-brand-deep",
          )}
        >
          Buy now
        </button>

        <button
          type="button"
          onClick={save}
          aria-pressed={saved}
          className={cn(
            "grid h-[50px] w-[50px] place-items-center rounded-[var(--radius-card)] border transition-colors",
            saved
              ? "border-brand bg-blush text-brand"
              : "border-line text-ink-mute hover:border-brand hover:text-brand",
          )}
          title={saved ? "Remove from wishlist" : "Save to wishlist"}
        >
          <svg
            width="19"
            height="19"
            viewBox="0 0 24 24"
            fill={saved ? "currentColor" : "none"}
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1L12 21l7.7-7.7 1.1-1a5.5 5.5 0 0 0 0-7.8z" />
          </svg>
          <span className="sr-only">{saved ? "Remove from wishlist" : "Save to wishlist"}</span>
        </button>
      </div>

      {error && (
        <p role="alert" className="mt-3 text-[13px] font-semibold text-brand">
          {error}
        </p>
      )}

      {toast && !error && (
        <p role="status" className="mt-3 text-[13px] font-medium text-success">
          {toast}
        </p>
      )}
    </div>
  );
}

function Options({
  label,
  value,
  options,
  onChange,
  placeholder,
}: {
  label: string;
  value: string;
  options: { value: string; disabled?: boolean; note?: string }[];
  onChange: (v: string) => void;
  placeholder?: string;
}) {
  return (
    <fieldset className="mt-5">
      <legend className="mb-2 text-[12px] font-bold uppercase tracking-[0.09em] text-ink-mute">
        {label}:{" "}
        <span className={value ? "text-ink" : "text-brand"}>
          {value || placeholder}
        </span>
      </legend>
      <div className="flex flex-wrap gap-2">
        {options.map((opt) => (
          <button
            key={opt.value}
            type="button"
            onClick={() => !opt.disabled && onChange(opt.value)}
            disabled={opt.disabled}
            aria-pressed={value === opt.value}
            title={opt.disabled ? `${opt.value} — sold out` : opt.note}
            className={cn(
              "min-h-[38px] rounded-[var(--radius-card)] border px-3.5 text-[13px] font-medium transition-colors",
              opt.disabled
                ? "cursor-not-allowed border-line text-ink-mute line-through decoration-line-firm"
                : value === opt.value
                  ? "border-ink bg-ink text-canvas"
                  : "border-line text-ink-mid hover:border-ink",
            )}
          >
            {opt.value}
            {opt.note && !opt.disabled && (
              <span className="ml-1.5 text-[10.5px] font-semibold text-warning">
                {opt.note}
              </span>
            )}
          </button>
        ))}
      </div>
    </fieldset>
  );
}

function StepButton({
  children,
  onClick,
  disabled,
  label,
}: {
  children: React.ReactNode;
  onClick: () => void;
  disabled?: boolean;
  label: string;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      disabled={disabled}
      aria-label={label}
      className="grid h-10 w-10 place-items-center text-[17px] text-ink-mid transition-colors hover:text-brand disabled:opacity-30"
    >
      {children}
    </button>
  );
}
