import { Card, PageHeader, Pill } from "@/components/admin-ui";
import { formatINR } from "@/lib/money";
import { getSettings } from "@/lib/settings";

export const metadata = { title: "Settings", robots: { index: false } };

export default async function AdminSettings() {
  const s = await getSettings();

  const groups: {
    title: string;
    note?: string;
    rows: { label: string; value: string; hint?: string; flag?: "on" | "off" }[];
  }[] = [
    {
      title: "Business",
      rows: [
        { label: "Store name", value: s.storeName },
        { label: "Support email", value: s.supportEmail },
        { label: "Support phone", value: s.supportPhone },
        { label: "WhatsApp", value: s.whatsappNumber },
        { label: "Support hours", value: s.supportHours },
        { label: "Order number format", value: `${s.orderNumberPrefix}-2026-0001` },
      ],
    },
    {
      title: "Tax",
      note: "Prices are tax-inclusive, so registering for GST will not change a single displayed price — only what the invoice breaks out.",
      rows: [
        {
          label: "GST registered",
          value: s.gstRegistered ? "Yes" : "No — Bill of Supply",
          flag: s.gstRegistered ? "on" : "off",
        },
        { label: "GSTIN", value: s.gstin ?? "Not set" },
        { label: "Prices include tax", value: s.pricesIncludeTax ? "Yes" : "No" },
      ],
    },
    {
      title: "Payment",
      rows: [
        {
          label: "Online payment",
          value: s.onlinePaymentEnabled ? "Live" : "Off — awaiting gateway KYC",
          flag: s.onlinePaymentEnabled ? "on" : "off",
        },
        {
          label: "Prepaid discount",
          value: formatINR(s.prepaidDiscount),
          hint: "The main lever against COD return losses",
          flag: s.prepaidDiscountEnabled ? "on" : "off",
        },
      ],
    },
    {
      title: "Cash on delivery",
      rows: [
        { label: "COD enabled", value: s.codEnabled ? "Yes" : "No", flag: s.codEnabled ? "on" : "off" },
        { label: "COD fee", value: formatINR(s.codFee) },
        { label: "Minimum order", value: formatINR(s.codMinOrderValue) },
        { label: "Maximum order", value: formatINR(s.codMaxOrderValue) },
        {
          label: "OTP verification",
          value: s.codOtpRequired ? "Required" : "Off",
          flag: s.codOtpRequired ? "on" : "off",
        },
        { label: "Auto-cancel unverified", value: `${s.codVerifyWindowHours} hours` },
        {
          label: "Block COD after",
          value: `${s.codRefusalBlockThreshold} refused deliveries`,
          hint: "The highest-value fraud control available",
        },
      ],
    },
    {
      title: "Shipping",
      rows: [
        {
          label: "Free shipping above",
          value: formatINR(s.freeShippingThreshold),
          hint: "Set just above the average order, to pull a second item into the basket",
        },
        { label: "Standard rate", value: formatINR(s.standardShippingRate) },
        {
          label: "Free shipping on COD",
          value: s.freeShippingAppliesToCod ? "Yes" : "No",
          flag: s.freeShippingAppliesToCod ? "on" : "off",
        },
      ],
    },
    {
      title: "Partial payment",
      note: "Built and configurable, switched off at launch: on a ₹500 order, paying part now and part on delivery is more friction than either full prepaid or plain COD. It earns its place on hampers and sets.",
      rows: [
        {
          label: "Enabled",
          value: s.partialPaymentEnabled ? "Yes" : "No",
          flag: s.partialPaymentEnabled ? "on" : "off",
        },
        { label: "Advance", value: `${s.partialAdvancePercent / 100}% of order value` },
        { label: "Minimum advance", value: formatINR(s.partialMinAdvance) },
        { label: "Offered above", value: formatINR(s.partialMinOrderValue) },
        { label: "Balance window", value: `${s.partialBalanceWindowDays} days` },
      ],
    },
    {
      title: "Inventory",
      rows: [
        { label: "Low stock threshold", value: `${s.lowStockThreshold} units` },
        {
          label: "Checkout stock hold",
          value: `${s.stockReservationMinutes} minutes`,
          hint: "Prevents the double-sell on a last remaining item",
        },
      ],
    },
    {
      title: "Returns & refunds",
      rows: [
        { label: "Returns enabled", value: s.returnsEnabled ? "Yes" : "No", flag: s.returnsEnabled ? "on" : "off" },
        { label: "Return window", value: `${s.returnWindowDays} days` },
        { label: "Refund window", value: `${s.refundWindowDays} working days` },
        {
          label: "Refund shipping",
          value: s.refundShippingOnOurFault ? "Only when our fault" : "Never",
        },
      ],
    },
  ];

  return (
    <>
      <PageHeader
        title="Settings"
        subtitle="Every business rule the storefront uses, in one place"
      />

      <div className="mb-5 rounded-[var(--radius-card)] border border-warning/40 bg-gold-soft px-4 py-3 text-[12.5px] text-ink-mid">
        <strong className="text-ink">Read-only for now.</strong> These values
        come from the defaults in <code>src/lib/settings.ts</code>. Editing lands
        with the database — the settings table and the loader that overrides
        each default already exist, so nothing here needs rewriting.
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        {groups.map((g) => (
          <Card key={g.title}>
            <h2 className="font-display text-lg">{g.title}</h2>
            {g.note && <p className="mt-1 text-[12px] text-ink-mute">{g.note}</p>}
            <dl className="mt-3 divide-y divide-line text-[13px]">
              {g.rows.map((r) => (
                <div key={r.label} className="flex items-start justify-between gap-3 py-2">
                  <dt className="text-ink-mute">
                    {r.label}
                    {r.hint && (
                      <span className="mt-0.5 block text-[11px] text-ink-mute/80">
                        {r.hint}
                      </span>
                    )}
                  </dt>
                  <dd className="tnum flex shrink-0 items-center gap-2 text-right font-semibold">
                    {r.value}
                    {r.flag && (
                      <Pill tone={r.flag === "on" ? "good" : "neutral"}>
                        {r.flag === "on" ? "On" : "Off"}
                      </Pill>
                    )}
                  </dd>
                </div>
              ))}
            </dl>
          </Card>
        ))}
      </div>
    </>
  );
}
