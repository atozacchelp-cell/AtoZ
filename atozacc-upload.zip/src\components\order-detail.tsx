import Image from "next/image";
import Link from "next/link";

import { formatINR } from "@/lib/money";
import {
  ORDER_STATUS_LABELS,
  PAYMENT_STATUS_LABELS,
  TRACKING_STEPS,
  type StoredOrder,
} from "@/lib/orders";
import { cn } from "@/lib/cn";

export function OrderDetail({ order }: { order: StoredOrder }) {
  const isCancelled = order.status === "CANCELLED" || order.status === "RTO";
  const currentStep = TRACKING_STEPS.indexOf(order.status);

  return (
    <div className="space-y-8">
      {/* Status */}
      <section className="rounded-[var(--radius-card)] border border-line bg-surface p-5">
        <div className="flex flex-wrap items-baseline justify-between gap-3">
          <div>
            <p className="text-[11px] font-bold uppercase tracking-[0.11em] text-ink-mute">
              Order
            </p>
            <p className="tnum font-display text-2xl">{order.orderNumber}</p>
          </div>
          <div className="text-right">
            <StatusPill status={order.status} />
            <p className="mt-1 text-[12px] text-ink-mute">
              Placed{" "}
              {new Date(order.placedAt).toLocaleDateString("en-IN", {
                day: "numeric",
                month: "short",
                year: "numeric",
              })}
            </p>
          </div>
        </div>

        {!isCancelled && (
          <ol className="mt-6 grid grid-cols-5 gap-1">
            {TRACKING_STEPS.map((step, i) => {
              const done = currentStep >= i && currentStep !== -1;
              return (
                <li key={step} className="text-center">
                  <div className="relative flex items-center justify-center">
                    {i > 0 && (
                      <span
                        aria-hidden
                        className={cn(
                          "absolute right-1/2 h-0.5 w-full",
                          done ? "bg-brand" : "bg-line",
                        )}
                      />
                    )}
                    <span
                      className={cn(
                        "relative z-10 grid h-6 w-6 place-items-center rounded-full text-[11px] font-bold",
                        done ? "bg-brand text-white" : "border border-line bg-canvas text-ink-mute",
                      )}
                    >
                      {done ? "✓" : i + 1}
                    </span>
                  </div>
                  <p
                    className={cn(
                      "mt-1.5 text-[10.5px] leading-tight",
                      done ? "font-semibold text-ink" : "text-ink-mute",
                    )}
                  >
                    {ORDER_STATUS_LABELS[step]}
                  </p>
                </li>
              );
            })}
          </ol>
        )}

        {order.status === "PENDING" && order.paymentMethod === "COD" && (
          <p className="mt-5 rounded-[var(--radius-card)] border border-warning/40 bg-gold-soft px-3.5 py-2.5 text-[12.5px] text-ink-mid">
            We will call or message you on{" "}
            <strong className="tnum">{order.shippingAddress.mobile}</strong> to
            confirm this cash-on-delivery order before dispatch.
          </p>
        )}
      </section>

      {/* Payment */}
      <section>
        <h2 className="font-display text-xl">Payment</h2>
        <div className="tnum mt-3 overflow-hidden rounded-[var(--radius-card)] border border-line">
          <table className="w-full text-[13.5px]">
            <tbody>
              <Row label="Method">
                {order.paymentMethod === "COD"
                  ? "Cash on delivery"
                  : order.paymentMethod === "PARTIAL"
                    ? "Part paid online"
                    : "Paid online"}
              </Row>
              <Row label="Status">{PAYMENT_STATUS_LABELS[order.paymentStatus]}</Row>
              <Row label="Order value">{formatINR(order.total)}</Row>
              <Row label="Paid">{formatINR(order.paidAmount)}</Row>
              <Row label="Balance due" last>
                <span className={order.balanceAmount > 0 ? "font-bold text-brand" : ""}>
                  {formatINR(order.balanceAmount)}
                </span>
                {order.balanceAmount > 0 && (
                  <span className="ml-2 text-[12px] text-ink-mute">
                    collected on delivery
                  </span>
                )}
              </Row>
            </tbody>
          </table>
        </div>
      </section>

      {/* Items */}
      <section>
        <h2 className="font-display text-xl">Items</h2>
        <ul className="mt-3 border-t border-line">
          {order.items.map((item, i) => (
            <li key={`${item.sku}-${i}`} className="flex gap-4 border-b border-line py-4">
              <Link
                href={item.href}
                className="relative h-20 w-20 shrink-0 overflow-hidden rounded-[var(--radius-card)] border border-line bg-surface"
              >
                <Image src={item.imageUrl} alt={item.name} fill sizes="80px" className="object-cover" />
              </Link>
              <div className="min-w-0 flex-1">
                <Link href={item.href} className="line-clamp-2 text-[13.5px] font-semibold hover:text-brand">
                  {item.name}
                </Link>
                {item.variantLabel && (
                  <p className="mt-0.5 text-[12px] text-ink-mute">{item.variantLabel}</p>
                )}
                <p className="tnum mt-1 text-[12.5px] text-ink-mute">
                  {formatINR(item.unitPrice)} × {item.qty}
                </p>
              </div>
              <p className="tnum shrink-0 text-[13.5px] font-bold">
                {formatINR(item.lineTotal)}
              </p>
            </li>
          ))}
        </ul>

        <dl className="tnum mt-4 space-y-1.5 text-[13px]">
          <SummaryRow label="Subtotal">
            {formatINR(order.subtotal + order.productDiscount)}
          </SummaryRow>
          {order.productDiscount > 0 && (
            <SummaryRow label="Product discount" tone="success">
              −{formatINR(order.productDiscount)}
            </SummaryRow>
          )}
          {order.couponDiscount > 0 && (
            <SummaryRow label={`Coupon ${order.couponCode ?? ""}`} tone="success">
              −{formatINR(order.couponDiscount)}
            </SummaryRow>
          )}
          {order.prepaidDiscount > 0 && (
            <SummaryRow label="Online payment discount" tone="success">
              −{formatINR(order.prepaidDiscount)}
            </SummaryRow>
          )}
          <SummaryRow label="Shipping">
            {order.shippingCharge === 0 ? "FREE" : formatINR(order.shippingCharge)}
          </SummaryRow>
          {order.codFee > 0 && (
            <SummaryRow label="COD fee">{formatINR(order.codFee)}</SummaryRow>
          )}
          <div className="flex justify-between border-t border-line-firm pt-2 text-[15px] font-bold">
            <span>Total</span>
            <span>{formatINR(order.total)}</span>
          </div>
        </dl>
      </section>

      {/* Address */}
      <section>
        <h2 className="font-display text-xl">Delivery address</h2>
        <address className="mt-3 rounded-[var(--radius-card)] border border-line bg-surface p-4 text-[13.5px] not-italic leading-relaxed text-ink-mid">
          <strong className="block text-ink">{order.shippingAddress.name}</strong>
          {order.shippingAddress.line1}
          {order.shippingAddress.line2 && <>, {order.shippingAddress.line2}</>}
          <br />
          {order.shippingAddress.area && <>{order.shippingAddress.area}, </>}
          {order.shippingAddress.city}
          <br />
          {order.shippingAddress.state} — <span className="tnum">{order.shippingAddress.pincode}</span>
          <br />
          <span className="tnum">{order.shippingAddress.mobile}</span>
        </address>
      </section>
    </div>
  );
}

export function StatusPill({ status }: { status: StoredOrder["status"] }) {
  const tone =
    status === "DELIVERED"
      ? "bg-success/12 text-success"
      : status === "CANCELLED" || status === "RTO" || status === "FAILED_DELIVERY"
        ? "bg-blush text-brand-deep"
        : status === "PENDING"
          ? "bg-gold-soft text-warning"
          : "bg-surface-2 text-ink-mid";

  return (
    <span
      className={cn(
        "inline-block rounded-[var(--radius-pill)] px-2.5 py-1 text-[11px] font-bold uppercase tracking-[0.07em]",
        tone,
      )}
    >
      {ORDER_STATUS_LABELS[status]}
    </span>
  );
}

function Row({
  label,
  children,
  last,
}: {
  label: string;
  children: React.ReactNode;
  last?: boolean;
}) {
  return (
    <tr className={last ? "" : "border-b border-line"}>
      <td className="w-[40%] bg-surface px-3.5 py-2.5 font-medium text-ink-mid">{label}</td>
      <td className="px-3.5 py-2.5">{children}</td>
    </tr>
  );
}

function SummaryRow({
  label,
  children,
  tone,
}: {
  label: string;
  children: React.ReactNode;
  tone?: "success";
}) {
  return (
    <div className="flex justify-between">
      <dt className="text-ink-mute">{label}</dt>
      <dd className={tone === "success" ? "font-semibold text-success" : ""}>{children}</dd>
    </div>
  );
}
