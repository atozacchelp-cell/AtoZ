"use client";

import Image from "next/image";
import Link from "next/link";
import { useActionState, useState } from "react";

import { COLLECTIONS, type SeedCategory, type SeedProduct } from "@/data/catalog";
import { cn } from "@/lib/cn";
import { discountPercent, formatINR, toRupees } from "@/lib/money";
import { upsertProduct, type ProductFormState } from "@/lib/product-actions";

/**
 * Converts a Drive share link to a URL that actually serves the image.
 * Mirrors the server-side helper — pasting a /file/d/../view link would
 * otherwise render Drive HTML and show a broken picture.
 */
function driveToDirect(url: string): string {
  const u = url.trim();
  if (!u.includes("drive.google.com") && !u.includes("docs.google.com")) return u;
  const id =
    u.match(/\/file\/d\/([a-zA-Z0-9-_]+)/)?.[1] ??
    u.match(/[?&]id=([a-zA-Z0-9-_]+)/)?.[1] ??
    u.match(/\/d\/([a-zA-Z0-9-_]+)/)?.[1];
  return id ? `https://lh3.googleusercontent.com/d/${id}=w1400` : u;
}

const PLACEHOLDERS = [
  "earrings", "necklace", "ring", "bangle", "anklet", "handbag", "sling",
  "clutch", "backpack", "hairclip", "scrunchie", "watch", "sunglass",
  "wallet", "belt", "scarf", "cap", "bracelet", "phonecase", "keychain",
  "socks", "lifestyle",
];

export function ProductForm({
  categories,
  product,
}: {
  categories: SeedCategory[];
  product?: SeedProduct;
}) {
  const [state, formAction, pending] = useActionState<ProductFormState, FormData>(
    upsertProduct,
    {},
  );

  const [image, setImage] = useState(product?.image ?? "/placeholders/earrings.svg");
  const [mrp, setMrp] = useState(product ? String(toRupees(product.mrp)) : "");
  const [price, setPrice] = useState(product ? String(toRupees(product.price)) : "");
  const [cost, setCost] = useState(
    product?.costPrice ? String(toRupees(product.costPrice)) : "",
  );

  const err = (f: string) => state.errors?.[f];

  // Live margin maths. At a ~₹500 average order, roughly ₹95 per order goes on
  // shipping, packaging and COD handling before product cost — so this tells
  // the owner whether a piece is actually worth stocking.
  const mrpN = Number(mrp.replace(/[^\d.]/g, "")) || 0;
  const priceN = Number(price.replace(/[^\d.]/g, "")) || 0;
  const costN = Number(cost.replace(/[^\d.]/g, "")) || 0;
  const discount = mrpN > 0 && priceN > 0 ? discountPercent(mrpN * 100, priceN * 100) : 0;
  const grossPerUnit = priceN - costN;
  const afterFulfilment = grossPerUnit - 95;

  return (
    <form action={formAction} className="grid gap-6 lg:grid-cols-[minmax(0,1fr)_320px]">
      {product && <input type="hidden" name="sku" value={product.sku} />}

      <div className="space-y-6">
        {state.formError && (
          <p role="alert" className="rounded-[var(--radius-card)] border border-brand bg-blush px-4 py-3 text-[13px] font-medium text-brand-deep">
            {state.formError}
          </p>
        )}

        <Section title="The basics">
          <Field label="Product name" name="name" defaultValue={product?.name} error={err("name")} required
                 hint="What a customer would call it. Include the material and type — this is what search matches on." />

          <label className="block">
            <Label required>Category</Label>
            <select
              name="category"
              defaultValue={product?.category ?? ""}
              required
              className={input(!!err("category"))}
            >
              <option value="" disabled>Choose a category</option>
              {categories.map((c) => (
                <option key={c.slug} value={c.slug}>
                  {categoryLabel(c, categories)}
                </option>
              ))}
            </select>
            {err("category") && <ErrorText>{err("category")}</ErrorText>}
          </label>

          <Field label="One-line description" name="shortDescription"
                 defaultValue={product?.shortDescription} error={err("shortDescription")}
                 hint="Shown under the name. One concrete thing about it." />

          <label className="block">
            <Label>Full description</Label>
            <textarea
              name="description"
              rows={4}
              defaultValue={product?.description}
              className={input(false)}
              placeholder="What it is, what it is made of, when someone would wear it."
            />
          </label>
        </Section>

        <Section title="Price and stock">
          <div className="grid gap-4 sm:grid-cols-3">
            <Field label="MRP (₹)" name="mrp" value={mrp} onChange={(e) => setMrp(e.target.value)}
                   error={err("mrp")} required inputMode="decimal" hint="The struck-through price" />
            <Field label="Selling price (₹)" name="price" value={price} onChange={(e) => setPrice(e.target.value)}
                   error={err("price")} required inputMode="decimal" hint="What they pay" />
            <Field label="Your cost (₹)" name="costPrice" value={cost} onChange={(e) => setCost(e.target.value)}
                   error={err("costPrice")} inputMode="decimal" hint="Optional — powers profit reports" />
          </div>

          {(mrpN > 0 || priceN > 0) && (
            <div className="tnum rounded-[var(--radius-card)] border border-line bg-surface p-3.5 text-[12.5px]">
              <div className="flex flex-wrap gap-x-6 gap-y-1.5">
                <span>Discount shown: <strong className={discount >= 10 ? "text-brand" : ""}>{discount}%</strong></span>
                {costN > 0 && (
                  <>
                    <span>Gross margin: <strong>{formatINR(grossPerUnit * 100)}</strong></span>
                    <span>
                      After fulfilment:{" "}
                      <strong className={afterFulfilment <= 0 ? "text-brand" : "text-success"}>
                        {formatINR(afterFulfilment * 100)}
                      </strong>
                    </span>
                  </>
                )}
              </div>
              {costN > 0 && afterFulfilment <= 0 && (
                <p className="mt-2 text-brand">
                  This loses money on every order. Shipping, packaging and COD
                  handling cost roughly ₹95 before product cost — you need to buy
                  cheaper or price higher.
                </p>
              )}
              {costN > 0 && priceN > 0 && costN / priceN > 0.4 && afterFulfilment > 0 && (
                <p className="mt-2 text-warning">
                  Thin. Aim to buy at 25–35% of the selling price — around{" "}
                  {formatINR(priceN * 30)} for this one.
                </p>
              )}
            </div>
          )}

          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Stock quantity" name="stock" type="number" min={0}
                   defaultValue={product?.stock ?? 0} error={err("stock")} required />
            <Field label="Weight (grams)" name="weightG" type="number" min={1}
                   defaultValue={product?.weightG ?? 100} error={err("weightG")} required
                   hint="Used for shipping rates — guess high rather than low" />
          </div>
        </Section>

        <Section title="Options">
          <div className="grid gap-4 sm:grid-cols-2">
            <Field label="Colours" name="colours" defaultValue={product?.colours?.join(", ")}
                   hint="Comma separated: Gold, Silver, Rose Gold" />
            <Field label="Sizes" name="sizes" defaultValue={product?.sizes?.join(", ")}
                   hint="Comma separated. Leave blank if one size" />
          </div>
          <Field label="Material" name="material" defaultValue={product?.material}
                 hint="Brass with gold plating, genuine leather, …" />
          <label className="block">
            <Label>Key features</Label>
            <textarea name="features" rows={3} defaultValue={product?.features?.join("\n")}
                      className={input(false)} placeholder={"One per line\nHypoallergenic posts\nPush-back clasp"} />
          </label>
          <Field label="Care instructions" name="care" defaultValue={product?.care} />
        </Section>

        <Section title="Merchandising">
          <div>
            <Label>Collections</Label>
            <div className="mt-1 flex flex-wrap gap-2">
              {COLLECTIONS.filter(
                (c) => !["new-arrivals", "trending", "bestsellers"].includes(c.slug),
              ).map((c) => (
                <label key={c.slug} className="flex cursor-pointer items-center gap-1.5 rounded-[var(--radius-pill)] border border-line px-3 py-1.5 text-[12.5px]">
                  <input type="checkbox" name="collections" value={c.slug}
                         defaultChecked={product?.collections?.includes(c.slug)}
                         className="h-3.5 w-3.5 accent-[--color-brand]" />
                  {c.name}
                </label>
              ))}
            </div>
            <p className="mt-1.5 text-[11.5px] text-ink-mute">
              New Arrivals, Trending and Bestsellers are set by the badges below,
              not here — one control each, so they cannot disagree.
            </p>
          </div>

          <div className="grid gap-2 sm:grid-cols-2">
            <Check name="isNew" label="New arrival" defaultChecked={product?.isNew} />
            <Check name="isTrending" label="Trending" defaultChecked={product?.isTrending} />
            <Check name="isBestseller" label="Bestseller" defaultChecked={product?.isBestseller} />
            <Check name="isExclusive" label="Exclusive" defaultChecked={product?.isExclusive} />
          </div>

          <div className="grid gap-2 sm:grid-cols-2">
            <Check name="isReturnable" label="Can be returned"
                   defaultChecked={product ? product.isReturnable !== false : true}
                   hint="Turn off for earrings, socks and personalised items" />
            <Check name="isCodAllowed" label="Cash on delivery allowed"
                   defaultChecked={product ? product.isCodAllowed !== false : true} />
          </div>
        </Section>
      </div>

      {/* Sidebar: image and live preview */}
      <aside>
        <div className="lg:sticky lg:top-6 space-y-4">
          <div className="rounded-[var(--radius-card)] border border-line bg-canvas p-4">
            <Label required>Image</Label>
            <div className="relative mt-2 aspect-square overflow-hidden rounded-[var(--radius-card)] border border-line bg-surface">
              {image && <Image src={image} alt="" fill sizes="300px" className="object-cover" />}
            </div>

            <input type="hidden" name="image" value={image} />
            <input
              value={image}
              onChange={(e) => setImage(driveToDirect(e.target.value))}
              onBlur={(e) => setImage(driveToDirect(e.target.value))}
              placeholder="Paste a Google Drive link, or any image URL"
              className={cn(input(!!err("image")), "text-[12px]")}
            />
            {err("image") && <ErrorText>{err("image")}</ErrorText>}

            <p className="mt-2 text-[11px] text-ink-mute">
              Paste a Google Drive share link and it converts automatically, or
              pick a placeholder until you have photos.
            </p>
            <div className="mt-2 grid grid-cols-6 gap-1">
              {PLACEHOLDERS.map((p) => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setImage(`/placeholders/${p}.svg`)}
                  title={p}
                  className={cn(
                    "relative aspect-square overflow-hidden rounded border",
                    image === `/placeholders/${p}.svg` ? "border-brand" : "border-line",
                  )}
                >
                  <Image src={`/placeholders/${p}.svg`} alt={p} fill sizes="40px" className="object-cover" />
                </button>
              ))}
            </div>
          </div>

          <div className="rounded-[var(--radius-card)] border border-line bg-canvas p-4">
            <button
              type="submit"
              disabled={pending}
              className="w-full rounded-[var(--radius-card)] bg-brand px-4 py-3 text-[14px] font-semibold text-white hover:bg-brand-deep disabled:opacity-60"
            >
              {pending ? "Saving…" : product ? "Save changes" : "Add product"}
            </button>
            <Link
              href="/admin/products"
              className="mt-2 block text-center text-[12.5px] font-semibold text-ink-mute hover:text-brand"
            >
              Cancel
            </Link>
            {product && (
              <p className="tnum mt-3 border-t border-line pt-2 text-[11px] text-ink-mute">
                SKU {product.sku}
              </p>
            )}
          </div>
        </div>
      </aside>
    </form>
  );
}

/* ------------------------------------------------------------------------ */

/**
 * Full path, not just gender and name.
 *
 * Without the parent, Kids > Girls > Jewellery and Kids > Boys > Watches both
 * collapse to "Kids · Jewellery" / "Kids · Watches", and there is no way to
 * tell the girls' list from the boys' when picking one.
 */
function categoryLabel(cat: SeedCategory, all: SeedCategory[]): string {
  const gender = cat.gender.charAt(0).toUpperCase() + cat.gender.slice(1);
  const parent = cat.parent ? all.find((c) => c.slug === cat.parent) : undefined;
  return [gender, parent?.name, cat.name].filter(Boolean).join(" · ");
}

function input(hasError: boolean) {
  return cn(
    "mt-1 w-full rounded-[var(--radius-card)] border bg-surface px-3 py-2.5 text-[13.5px] focus:bg-canvas focus:outline-none",
    hasError ? "border-brand" : "border-line focus:border-brand",
  );
}

function Label({ children, required }: { children: React.ReactNode; required?: boolean }) {
  return (
    <span className="text-[11.5px] font-bold uppercase tracking-[0.09em] text-ink-mute">
      {children} {required && <span className="text-brand">*</span>}
    </span>
  );
}

function ErrorText({ children }: { children: React.ReactNode }) {
  return <span role="alert" className="mt-1 block text-[11.5px] font-medium text-brand">{children}</span>;
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-[var(--radius-card)] border border-line bg-canvas p-5">
      <h2 className="mb-4 font-display text-lg">{title}</h2>
      <div className="space-y-4">{children}</div>
    </section>
  );
}

function Field({
  label, name, error, hint, required, ...rest
}: {
  label: string; name: string; error?: string; hint?: string; required?: boolean;
} & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="block">
      <Label required={required}>{label}</Label>
      <input name={name} required={required} aria-invalid={!!error} className={input(!!error)} {...rest} />
      {error ? <ErrorText>{error}</ErrorText>
        : hint ? <span className="mt-1 block text-[11px] text-ink-mute">{hint}</span> : null}
    </label>
  );
}

function Check({
  name, label, hint, defaultChecked,
}: { name: string; label: string; hint?: string; defaultChecked?: boolean }) {
  return (
    <label className="flex cursor-pointer items-start gap-2 rounded-[var(--radius-card)] border border-line px-3 py-2.5">
      <input type="checkbox" name={name} defaultChecked={defaultChecked}
             className="mt-0.5 h-3.5 w-3.5 accent-[--color-brand]" />
      <span>
        <span className="block text-[13px] font-medium">{label}</span>
        {hint && <span className="block text-[11px] text-ink-mute">{hint}</span>}
      </span>
    </label>
  );
}
