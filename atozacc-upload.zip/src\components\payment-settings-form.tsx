"use client";

import Image from "next/image";
import { useActionState, useState } from "react";

import {
  updatePaymentSettings,
  type PaymentSettingsState,
} from "@/lib/payment-settings-actions";
import type { Settings } from "@/lib/settings";
import { cn } from "@/lib/cn";

function driveToDirect(url: string): string {
  const u = url.trim();
  if (!u.includes("drive.google.com") && !u.includes("docs.google.com")) return u;
  const id =
    u.match(/\/file\/d\/([a-zA-Z0-9-_]+)/)?.[1] ??
    u.match(/[?&]id=([a-zA-Z0-9-_]+)/)?.[1] ??
    u.match(/\/d\/([a-zA-Z0-9-_]+)/)?.[1];
  return id ? `https://lh3.googleusercontent.com/d/${id}=w1400` : u;
}

const UPI_RE = /^[a-zA-Z0-9.\-_]{2,64}@[a-zA-Z]{2,32}$/;

export function PaymentSettingsForm({ settings }: { settings: Settings }) {
  const [state, action, pending] = useActionState<PaymentSettingsState, FormData>(
    updatePaymentSettings,
    {},
  );

  const [mode, setMode] = useState(settings.onlinePaymentMode);
  const [upiId, setUpiId] = useState(settings.upiId);
  const [payee, setPayee] = useState(settings.upiPayeeName);
  const [qrUrl, setQrUrl] = useState(settings.upiQrImageUrl);
  const [cod, setCod] = useState(settings.codEnabled);

  const upiLooksValid = UPI_RE.test(upiId.trim());

  return (
    <form action={action} className="space-y-5">
      <section className="rounded-[var(--radius-card)] border border-line bg-canvas p-5">
        <h2 className="font-display text-lg">Online payment</h2>
        <p className="mt-1 max-w-prose text-[12.5px] text-ink-mute">
          Money goes straight to your own UPI account. There is no gateway, no
          KYC wait and no percentage taken — the trade is that you confirm each
          payment yourself.
        </p>

        <div className="mt-4 space-y-2">
          {[
            {
              value: "upi" as const,
              title: "My UPI QR",
              body: "Customers scan a QR with the exact amount and send you the reference. You confirm it in Orders.",
            },
            {
              value: "off" as const,
              title: "Cash on delivery only",
              body: "No online payment offered at all.",
            },
          ].map((opt) => (
            <label
              key={opt.value}
              className={cn(
                "flex cursor-pointer gap-3 rounded-[var(--radius-card)] border p-3.5 transition-colors",
                mode === opt.value ? "border-brand bg-blush" : "border-line hover:border-ink",
              )}
            >
              <input
                type="radio"
                name="onlinePaymentMode"
                value={opt.value}
                checked={mode === opt.value}
                onChange={() => setMode(opt.value)}
                className="mt-0.5 h-4 w-4 shrink-0 accent-[--color-brand]"
              />
              <span>
                <span className="block text-[13.5px] font-bold">{opt.title}</span>
                <span className="mt-0.5 block text-[12px] text-ink-mute">{opt.body}</span>
              </span>
            </label>
          ))}
        </div>
      </section>

      {mode === "upi" && (
        <section className="rounded-[var(--radius-card)] border border-line bg-canvas p-5">
          <h2 className="font-display text-lg">Your UPI details</h2>

          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            <label className="block">
              <span className="text-[11.5px] font-bold uppercase tracking-[0.09em] text-ink-mute">
                UPI ID <span className="text-brand">*</span>
              </span>
              <input
                name="upiId"
                value={upiId}
                onChange={(e) => setUpiId(e.target.value)}
                placeholder="yourname@okhdfcbank"
                className={cn(
                  "mt-1 w-full rounded-[var(--radius-card)] border bg-surface px-3 py-2.5 text-[13.5px] focus:bg-canvas focus:outline-none",
                  upiId && !upiLooksValid ? "border-brand" : "border-line focus:border-brand",
                )}
              />
              {upiId && !upiLooksValid ? (
                <span className="mt-1 block text-[11.5px] font-medium text-brand">
                  Doesn&apos;t look like a UPI ID — it should be name@bank
                </span>
              ) : (
                <span className="mt-1 block text-[11px] text-ink-mute">
                  From GPay, PhonePe or your bank app. Money arrives here directly.
                </span>
              )}
            </label>

            <label className="block">
              <span className="text-[11.5px] font-bold uppercase tracking-[0.09em] text-ink-mute">
                Name shown to customers
              </span>
              <input
                name="upiPayeeName"
                value={payee}
                onChange={(e) => setPayee(e.target.value)}
                className="mt-1 w-full rounded-[var(--radius-card)] border border-line bg-surface px-3 py-2.5 text-[13.5px] focus:border-brand focus:bg-canvas focus:outline-none"
              />
              <span className="mt-1 block text-[11px] text-ink-mute">
                Appears in their UPI app when they scan.
              </span>
            </label>
          </div>

          <label className="mt-4 block">
            <span className="text-[11.5px] font-bold uppercase tracking-[0.09em] text-ink-mute">
              Your printed QR image (optional)
            </span>
            <input
              name="upiQrImageUrl"
              value={qrUrl}
              onChange={(e) => setQrUrl(driveToDirect(e.target.value))}
              placeholder="Drive link or /brand/qr.png — only used as a fallback"
              className="mt-1 w-full rounded-[var(--radius-card)] border border-line bg-surface px-3 py-2.5 text-[13px] focus:border-brand focus:bg-canvas focus:outline-none"
            />
            {/* Worth being clear about, or they will upload a static QR and
                wonder why the generated one is used instead. */}
            <span className="mt-1 block text-[11.5px] text-ink-mute">
              Not needed. The site builds a fresh QR per order with the exact
              amount already filled in, which a printed QR cannot do — a static
              one makes the customer type the amount, and they get it wrong.
            </span>
          </label>

          {qrUrl && (
            <span className="relative mt-3 block h-24 w-24 overflow-hidden rounded-[var(--radius-card)] border border-line">
              <Image src={qrUrl} alt="Your QR" fill unoptimized className="object-contain" />
            </span>
          )}
        </section>
      )}

      <section className="rounded-[var(--radius-card)] border border-line bg-canvas p-5">
        <h2 className="font-display text-lg">Cash on delivery</h2>
        <label className="mt-3 flex cursor-pointer items-start gap-2">
          <input
            type="checkbox"
            name="codEnabled"
            checked={cod}
            onChange={(e) => setCod(e.target.checked)}
            className="mt-0.5 h-3.5 w-3.5 accent-[--color-brand]"
          />
          <span>
            <span className="block text-[13.5px] font-medium">
              Offer cash on delivery
            </span>
            <span className="block text-[11.5px] text-ink-mute">
              Still 50–70% of Indian D2C orders. Turning it off will cost volume.
            </span>
          </span>
        </label>

        <label className="mt-3 flex cursor-pointer items-start gap-2">
          <input
            type="checkbox"
            name="prepaidDiscountEnabled"
            defaultChecked={settings.prepaidDiscountEnabled}
            className="mt-0.5 h-3.5 w-3.5 accent-[--color-brand]"
          />
          <span>
            <span className="block text-[13.5px] font-medium">
              Give a discount for paying online
            </span>
            <span className="block text-[11.5px] text-ink-mute">
              Pushes customers to UPI, where you get the money up front and
              carry no return risk.
            </span>
          </span>
        </label>
      </section>

      <div className="flex flex-wrap items-center gap-3">
        <button
          type="submit"
          disabled={pending}
          className="rounded-[var(--radius-card)] bg-brand px-5 py-3 text-[14px] font-semibold text-white hover:bg-brand-deep disabled:opacity-60"
        >
          {pending ? "Saving…" : "Save payment settings"}
        </button>
        {state.ok && (
          <span className="text-[13px] font-medium text-success">Saved</span>
        )}
        {state.error && (
          <span role="alert" className="text-[13px] font-medium text-brand">
            {state.error}
          </span>
        )}
      </div>
    </form>
  );
}
