import type { MetadataRoute } from "next";

const base = process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000";

/**
 * Nothing is indexed until the store actually launches. Flip `isLive` (or set
 * NEXT_PUBLIC_SITE_URL to the real domain) when going live — an unfinished
 * store that Google has already crawled is hard to undo.
 */
const isLive = base.includes("atozacc.");

export default function robots(): MetadataRoute.Robots {
  if (!isLive) {
    return {
      rules: { userAgent: "*", disallow: "/" },
    };
  }

  return {
    rules: {
      userAgent: "*",
      allow: "/",
      // Never index anything that is per-visitor or transactional.
      disallow: ["/admin", "/cart", "/checkout", "/account", "/order/", "/wishlist", "/search"],
    },
    sitemap: `${base}/sitemap.xml`,
  };
}
