"use client";

import { useActionState, useState } from "react";

import { removeSupplier, upsertSupplier, type SupplierState } from "@/lib/supplier-actions";
import type { Supplier } from "@/lib/suppliers";

export function SupplierForm({ suppliers }: { suppliers: Supplier[] }) {
  const [state, action, pending] = useActionState<SupplierState, FormData>(
    upsertSupplier,
    {},
  );
  const [editing, setEditing] = useState<Supplier | null>(null);

  // Remounting on selection lets defaultValue pick up the chosen supplier.
  const formKey = editing?.name ?? "new";

  return (
    <section className="rounded-[var(--radius-card)] border border-line bg-canvas p-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h2 className="font-display text-lg">
          {editing ? `Edit ${editing.name}` : "Add a supplier"}
        </h2>
        {suppliers.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {editing && (
              <button
                type="button"
                onClick={() => setEditing(null)}
                className="rounded-[var(--radius-pill)] border border-line px-3 py-1 text-[12px] font-semibold text-ink-mute hover:border-brand hover:text-brand"
              >
                + New
              </button>
            )}
            {suppliers.map((s) => (
              <button
                key={s.name}
                type="button"
                onClick={() => setEditing(s)}
                className={
                  editing?.name === s.name
                    ? "rounded-[var(--radius-pill)] bg-ink px-3 py-1 text-[12px] font-semibold text-canvas"
                    : "rounded-[var(--radius-pill)] border border-line px-3 py-1 text-[12px] font-semibold text-ink-mute hover:border-brand hover:text-brand"
                }
              >
                {s.name}
              </button>
            ))}
          </div>
        )}
      </div>

      <form key={formKey} action={action} className="mt-4 grid gap-4 sm:grid-cols-2">
        <Field
          label="Supplier name"
          name="name"
          defaultValue={editing?.name}
          required
          hint="Must match the supplier column in your sheet, exactly"
        />
        <Field label="Contact person" name="contactName" defaultValue={editing?.contactName} />
        <Field label="Phone" name="phone" defaultValue={editing?.phone} inputMode="numeric" />
        <Field
          label="WhatsApp"
          name="whatsapp"
          defaultValue={editing?.whatsapp}
          inputMode="numeric"
          hint="10 digits — adds a Send on WhatsApp button"
        />
        <Field label="Email" name="email" type="email" defaultValue={editing?.email} />
        <Field label="Ships from (city)" name="city" defaultValue={editing?.city} />

        <Field
          label="Days to dispatch"
          name="dispatchDays"
          type="number"
          min={0}
          max={30}
          defaultValue={editing?.dispatchDays ?? 2}
          required
          hint="Added to the delivery estimate customers see"
        />

        <label className="flex items-start gap-2 self-end rounded-[var(--radius-card)] border border-line px-3 py-2.5">
          <input
            type="checkbox"
            name="acceptsCod"
            defaultChecked={editing?.acceptsCod ?? false}
            className="mt-0.5 h-3.5 w-3.5 accent-[--color-brand]"
          />
          <span>
            <span className="block text-[13px] font-medium">
              Will ship cash on delivery
            </span>
            <span className="block text-[11px] text-ink-mute">
              Leave off unless you have confirmed it. Most Indian dropship
              suppliers want prepayment, and getting this wrong strands orders.
            </span>
          </span>
        </label>

        <div className="sm:col-span-2">
          <label className="block">
            <span className="text-[11.5px] font-bold uppercase tracking-[0.09em] text-ink-mute">
              Notes
            </span>
            <textarea
              name="notes"
              rows={2}
              defaultValue={editing?.notes}
              placeholder="Payment terms, minimum order, what they charge you"
              className="mt-1 w-full rounded-[var(--radius-card)] border border-line bg-surface px-3 py-2.5 text-[13px] focus:border-brand focus:bg-canvas focus:outline-none"
            />
          </label>
        </div>

        <div className="flex flex-wrap items-center gap-3 sm:col-span-2">
          <button
            type="submit"
            disabled={pending}
            className="rounded-[var(--radius-card)] bg-brand px-5 py-2.5 text-[13.5px] font-semibold text-white hover:bg-brand-deep disabled:opacity-60"
          >
            {pending ? "Saving…" : editing ? "Save changes" : "Add supplier"}
          </button>

          {state.ok && <span className="text-[12.5px] font-medium text-success">Saved</span>}
          {state.error && (
            <span role="alert" className="text-[12.5px] font-medium text-brand">
              {state.error}
            </span>
          )}
        </div>
      </form>

      {editing && (
        <form action={removeSupplier} className="mt-3 border-t border-line pt-3">
          <input type="hidden" name="name" value={editing.name} />
          <button
            type="submit"
            className="text-[12.5px] font-semibold text-ink-mute hover:text-brand"
          >
            Remove {editing.name}
          </button>
        </form>
      )}
    </section>
  );
}

function Field({
  label,
  name,
  hint,
  required,
  ...rest
}: {
  label: string;
  name: string;
  hint?: string;
  required?: boolean;
} & React.InputHTMLAttributes<HTMLInputElement>) {
  return (
    <label className="block">
      <span className="text-[11.5px] font-bold uppercase tracking-[0.09em] text-ink-mute">
        {label} {required && <span className="text-brand">*</span>}
      </span>
      <input
        name={name}
        required={required}
        className="mt-1 w-full rounded-[var(--radius-card)] border border-line bg-surface px-3 py-2.5 text-[13px] focus:border-brand focus:bg-canvas focus:outline-none"
        {...rest}
      />
      {hint && <span className="mt-1 block text-[11px] text-ink-mute">{hint}</span>}
    </label>
  );
}
