"use client";

import { useActionState } from "react";

import { syncFromSheet, type SyncState } from "@/lib/sheet-sync";
import type { SyncConfig } from "@/lib/sync-config";

export function SheetSyncForm({ config }: { config: SyncConfig }) {
  const [state, action, pending] = useActionState<SyncState, FormData>(
    syncFromSheet,
    {},
  );

  return (
    <>
      <form action={action} className="rounded-[var(--radius-card)] border border-line bg-canvas p-5">
        <label className="block">
          <span className="text-[11.5px] font-bold uppercase tracking-[0.09em] text-ink-mute">
            Products sheet link <span className="text-brand">*</span>
          </span>
          <input
            name="productsUrl"
            defaultValue={config.productsUrl ?? ""}
            required
            placeholder="https://docs.google.com/spreadsheets/d/…"
            className="mt-1 w-full rounded-[var(--radius-card)] border border-line bg-surface px-3 py-2.5 text-[13px] focus:border-brand focus:bg-canvas focus:outline-none"
          />
          <span className="mt-1 block text-[11.5px] text-ink-mute">
            Paste the address bar link. If your products are on a second tab,
            click that tab first so the link ends in the right{" "}
            <code>#gid=</code>.
          </span>
        </label>

        <label className="mt-4 block">
          <span className="text-[11.5px] font-bold uppercase tracking-[0.09em] text-ink-mute">
            Content sheet link
          </span>
          <input
            name="contentUrl"
            defaultValue={config.contentUrl ?? ""}
            placeholder="Optional — the tab holding your banner and heading text"
            className="mt-1 w-full rounded-[var(--radius-card)] border border-line bg-surface px-3 py-2.5 text-[13px] focus:border-brand focus:bg-canvas focus:outline-none"
          />
        </label>

        <label className="mt-4 block">
          <span className="text-[11.5px] font-bold uppercase tracking-[0.09em] text-ink-mute">
            Reviews sheet link
          </span>
          <input
            name="reviewsUrl"
            defaultValue={config.reviewsUrl ?? ""}
            placeholder="Optional — the tab holding customer testimonials"
            className="mt-1 w-full rounded-[var(--radius-card)] border border-line bg-surface px-3 py-2.5 text-[13px] focus:border-brand focus:bg-canvas focus:outline-none"
          />
        </label>

        <button
          type="submit"
          disabled={pending}
          className="mt-4 rounded-[var(--radius-card)] bg-brand px-5 py-2.5 text-[13.5px] font-semibold text-white hover:bg-brand-deep disabled:opacity-60"
        >
          {pending ? "Syncing…" : "Sync now"}
        </button>

        {config.lastSyncedAt && (
          <p className="tnum mt-3 text-[12px] text-ink-mute">
            Last synced {new Date(config.lastSyncedAt).toLocaleString("en-IN")} ·{" "}
            {config.lastCount} products
          </p>
        )}
      </form>

      {state.error && (
        <div
          role="alert"
          className="mt-4 rounded-[var(--radius-card)] border border-brand bg-blush p-4 text-[13px] text-brand-deep"
        >
          <p className="font-semibold">Sync failed</p>
          <p className="mt-1">{state.error}</p>
        </div>
      )}

      {state.summary && (
        <div className="mt-4 rounded-[var(--radius-card)] border border-line bg-canvas p-4 text-[13px]">
          {state.ok && (
            <p className="font-semibold text-success">
              {state.summary.imported} products are now live
              {state.summary.contentKeys > 0 &&
                ` · ${state.summary.contentKeys} text settings updated`}
            </p>
          )}

          {state.summary.warnings.length > 0 && (
            <>
              {/* Not failures — these rows are live. They are things that
                  would otherwise have happened invisibly, like a new category
                  appearing in the menu or a tag that matched nothing. */}
              <p className="mt-3 font-semibold text-ink-mid">
                {state.summary.warnings.length} note
                {state.summary.warnings.length === 1 ? "" : "s"}
              </p>
              <ul className="mt-1.5 max-h-56 space-y-1 overflow-y-auto">
                {state.summary.warnings.map((w, i) => (
                  <li key={i} className="text-ink-mute">
                    {w.row > 0 && (
                      <span className="tnum font-semibold text-ink-mid">
                        Row {w.row}{" "}
                      </span>
                    )}
                    {w.problem}
                  </li>
                ))}
              </ul>
            </>
          )}

          {state.summary.skipped.length > 0 && (
            <>
              {/* Every rejected row is named with its sheet row number, so it
                  can be found and fixed rather than hunted for. */}
              <p className="mt-3 font-semibold text-warning">
                {state.summary.skipped.length} row
                {state.summary.skipped.length === 1 ? "" : "s"} skipped
              </p>
              <ul className="mt-1.5 max-h-56 space-y-1 overflow-y-auto">
                {state.summary.skipped.map((s, i) => (
                  <li key={i} className="text-ink-mid">
                    <span className="tnum font-semibold">Row {s.row}</span>{" "}
                    <span className="text-ink-mute">({s.product})</span> — {s.problem}
                  </li>
                ))}
              </ul>
            </>
          )}
        </div>
      )}
    </>
  );
}
