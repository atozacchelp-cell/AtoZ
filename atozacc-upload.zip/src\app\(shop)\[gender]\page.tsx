import Image from "next/image";
import Link from "next/link";
import { notFound } from "next/navigation";

import { ProductRail } from "@/components/product-rail";
import { Breadcrumbs, Container, SectionHeading } from "@/components/ui";
import type { Gender } from "@/data/catalog";
import { getCategoryTree, getGenders, listProducts } from "@/lib/catalog";

const VALID = new Set(getGenders().map((g) => g.slug));

export async function generateStaticParams() {
  return getGenders().map((g) => ({ gender: g.slug }));
}

export async function generateMetadata({
  params,
}: {
  params: Promise<{ gender: string }>;
}) {
  const { gender } = await params;
  const meta = getGenders().find((g) => g.slug === gender);
  if (!meta) return { title: "Not found" };
  return {
    title: `${meta.name} Accessories`,
    description: `${meta.tagline} — shop AtoZacc accessories for ${meta.name.toLowerCase()}.`,
  };
}

export default async function GenderPage({
  params,
}: {
  params: Promise<{ gender: string }>;
}) {
  const { gender } = await params;
  if (!VALID.has(gender as Gender)) notFound();

  const g = gender as Gender;
  const meta = getGenders().find((x) => x.slug === g)!;

  const [tree, newIn, bestsellers, all] = await Promise.all([
    getCategoryTree(g),
    listProducts({ gender: g, collection: "new-arrivals" }, "newest", 1, 8),
    listProducts({ gender: g, collection: "bestsellers" }, "bestselling", 1, 8),
    listProducts({ gender: g }, "relevance", 1, 8),
  ]);

  return (
    <Container className="py-6">
      <Breadcrumbs items={[{ label: meta.name }]} />

      <header className="mb-8">
        <h1 className="font-display text-[32px] leading-tight sm:text-[40px]">
          {meta.name}
        </h1>
        <p className="mt-1.5 text-[14px] text-ink-mute">{meta.tagline}</p>
      </header>

      {/* Category tiles. Only categories that actually hold stock are shown —
          an empty category is worse than no category. */}
      <section>
        <SectionHeading title="Categories" />
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {tree
            .filter((c) => c.productCount > 0)
            .map((cat) => (
              <Link
                key={cat.slug}
                href={cat.href}
                className="group overflow-hidden rounded-[var(--radius-card)] border border-line transition-colors hover:border-brand"
              >
                <div className="relative aspect-[4/3] bg-surface">
                  {cat.image && (
                    <Image
                      src={cat.image}
                      alt=""
                      fill
                      sizes="(max-width: 640px) 46vw, 23vw"
                      className="object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  )}
                </div>
                <div className="p-3">
                  <p className="text-[13.5px] font-bold group-hover:text-brand">{cat.name}</p>
                  <p className="tnum text-[11.5px] text-ink-mute">
                    {cat.productCount} {cat.productCount === 1 ? "product" : "products"}
                  </p>
                  {cat.children.length > 0 && (
                    <p className="mt-1 line-clamp-1 text-[11.5px] text-ink-mute">
                      {cat.children.map((c) => c.name).join(" · ")}
                    </p>
                  )}
                </div>
              </Link>
            ))}
        </div>
      </section>

      <ProductRail
        title={`New in ${meta.name}`}
        products={newIn.items}
        href={`/${g}/all`}
      />
      <ProductRail title="Popular right now" products={bestsellers.items} />
      <ProductRail
        title={`All ${meta.name}`}
        products={all.items}
        href={`/shop?gender=${g}`}
        linkLabel="See everything"
      />
    </Container>
  );
}
