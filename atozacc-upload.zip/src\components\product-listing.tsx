import Link from "next/link";
import { Suspense } from "react";

import { FilterPanel, SortSelect } from "@/components/filter-panel";
import { ProductGrid } from "@/components/product-rail";
import { Breadcrumbs, Container, EmptyState } from "@/components/ui";
import {
  listProducts,
  type ProductFilters,
  type SortKey,
} from "@/lib/catalog";

export type SearchParamsShape = Record<string, string | string[] | undefined>;

/** Turns URL search params into typed filters. Everything is optional and
 *  anything unparseable is ignored rather than throwing — a mangled query
 *  string should degrade to an unfiltered grid, not a 500. */
export function parseFilters(
  sp: SearchParamsShape,
  base: ProductFilters = {},
): { filters: ProductFilters; sort: SortKey; page: number } {
  const many = (k: string): string[] | undefined => {
    const v = sp[k];
    if (!v) return undefined;
    return Array.isArray(v) ? v : [v];
  };
  const one = (k: string): string | undefined => {
    const v = sp[k];
    return Array.isArray(v) ? v[0] : v;
  };
  const num = (k: string): number | undefined => {
    const v = Number(one(k));
    return Number.isFinite(v) ? v : undefined;
  };

  return {
    filters: {
      ...base,
      q: one("q") ?? base.q,
      colours: many("colour"),
      sizes: many("size"),
      materials: many("material"),
      minPrice: num("minPrice"),
      maxPrice: num("maxPrice"),
      minRating: num("minRating"),
      minDiscount: num("minDiscount"),
      inStockOnly: one("inStock") === "1",
    },
    sort: (one("sort") as SortKey) ?? "relevance",
    page: Math.max(1, num("page") ?? 1),
  };
}

export async function ProductListing({
  title,
  description,
  breadcrumbs,
  searchParams,
  baseFilters = {},
  emptyAction,
}: {
  title: string;
  description?: string;
  breadcrumbs: { label: string; href?: string }[];
  searchParams: SearchParamsShape;
  baseFilters?: ProductFilters;
  emptyAction?: { href: string; label: string };
}) {
  const { filters, sort, page } = parseFilters(searchParams, baseFilters);
  const result = await listProducts(filters, sort, page, 24);

  return (
    <Container className="py-6">
      <Breadcrumbs items={breadcrumbs} />

      <header className="mb-6">
        <h1 className="font-display text-[30px] leading-tight sm:text-[36px]">{title}</h1>
        {description && (
          <p className="mt-1.5 max-w-2xl text-[13.5px] text-ink-mute">{description}</p>
        )}
      </header>

      <div className="lg:grid lg:grid-cols-[210px_minmax(0,1fr)] lg:gap-10">
        <Suspense fallback={null}>
          <FilterPanel facets={result.facets} totalCount={result.total} />
        </Suspense>

        <div className="min-w-0">
          {/* Pinned while the grid scrolls. On a phone this row is the only
              way to change sort or filters, and a customer who is forty
              products deep should not have to scroll back to the top to
              narrow down — which is why every large Indian store keeps it
              stuck to the header. */}
          <div className="sticky top-[var(--header-h,0px)] z-20 -mx-4 mb-5 flex items-center justify-between gap-3 border-b border-line bg-canvas/95 px-4 py-2.5 backdrop-blur-sm lg:static lg:mx-0 lg:px-0 lg:pb-3 lg:pt-0 lg:backdrop-blur-none">
            <p className="tnum text-[12.5px] text-ink-mute">
              {result.total} {result.total === 1 ? "product" : "products"}
            </p>
            <Suspense fallback={null}>
              <SortSelect />
            </Suspense>
          </div>

          {result.items.length === 0 ? (
            <EmptyState
              title="Nothing matches those filters"
              body="Try removing a filter or two — or browse everything and narrow down from there."
              action={emptyAction ?? { href: "/shop", label: "Browse all products" }}
            />
          ) : (
            <>
              <ProductGrid products={result.items} />
              <Pagination
                page={result.page}
                totalPages={result.totalPages}
                searchParams={searchParams}
              />
            </>
          )}
        </div>
      </div>
    </Container>
  );
}

function Pagination({
  page,
  totalPages,
  searchParams,
}: {
  page: number;
  totalPages: number;
  searchParams: SearchParamsShape;
}) {
  if (totalPages <= 1) return null;

  const linkFor = (p: number) => {
    const params = new URLSearchParams();
    for (const [k, v] of Object.entries(searchParams)) {
      if (k === "page" || v === undefined) continue;
      for (const value of Array.isArray(v) ? v : [v]) params.append(k, value);
    }
    if (p > 1) params.set("page", String(p));
    const qs = params.toString();
    return qs ? `?${qs}` : "?";
  };

  return (
    <nav className="mt-12 flex items-center justify-center gap-1" aria-label="Pagination">
      {page > 1 && (
        <Link
          href={linkFor(page - 1)}
          className="rounded-[var(--radius-card)] border border-line px-3 py-2 text-[13px] font-semibold hover:border-brand hover:text-brand"
        >
          Previous
        </Link>
      )}
      {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => (
        <Link
          key={p}
          href={linkFor(p)}
          aria-current={p === page ? "page" : undefined}
          className={
            p === page
              ? "tnum rounded-[var(--radius-card)] bg-ink px-3.5 py-2 text-[13px] font-semibold text-canvas"
              : "tnum rounded-[var(--radius-card)] border border-line px-3.5 py-2 text-[13px] hover:border-brand hover:text-brand"
          }
        >
          {p}
        </Link>
      ))}
      {page < totalPages && (
        <Link
          href={linkFor(page + 1)}
          className="rounded-[var(--radius-card)] border border-line px-3 py-2 text-[13px] font-semibold hover:border-brand hover:text-brand"
        >
          Next
        </Link>
      )}
    </nav>
  );
}
