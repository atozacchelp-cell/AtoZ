import { cookies } from "next/headers";

import {
  SESSION_COOKIE,
  createSessionToken,
  readSessionToken,
  sessionCookieOptions,
} from "@/lib/auth";
import { findById, toPublic, type PublicUser } from "@/lib/users";

/**
 * Who is making this request.
 *
 * The cookie proves an id and nothing else. The account — including whether
 * it is an admin — is loaded fresh from the store every time, so revoking
 * someone's admin rights takes effect on their next request rather than
 * whenever their two-week-old cookie happens to expire.
 */
export async function currentUser(): Promise<PublicUser | null> {
  const jar = await cookies();
  const payload = readSessionToken(jar.get(SESSION_COOKIE)?.value);
  if (!payload) return null;

  const user = await findById(payload.sub);
  return user ? toPublic(user) : null;
}

/** Convenience for pages that only need the yes/no. */
export async function currentAdmin(): Promise<PublicUser | null> {
  const user = await currentUser();
  return user?.isAdmin ? user : null;
}

/**
 * The guard for admin API routes.
 *
 * Route handlers are NOT wrapped by the admin layout, so the layout's check
 * does nothing for them — `/api/orders/export` was serving every customer's
 * name, phone number and address as a CSV to anyone who requested it. Each
 * such route calls this and returns the response it hands back.
 */
export async function requireAdmin(): Promise<Response | null> {
  const user = await currentUser();
  if (user?.isAdmin) return null;

  // 404 rather than 403: an endpoint that answers "forbidden" confirms it
  // exists and is worth attacking. This one simply is not there for you.
  return new Response("Not found", { status: 404 });
}

export async function startSession(userId: string): Promise<void> {
  const jar = await cookies();
  jar.set(SESSION_COOKIE, createSessionToken(userId), sessionCookieOptions());
}

export async function endSession(): Promise<void> {
  const jar = await cookies();
  // Overwritten with an immediate expiry rather than only deleted, so a
  // browser that ignores the delete still ends up with a dead cookie.
  jar.set(SESSION_COOKIE, "", { ...sessionCookieOptions(), maxAge: 0 });
}
